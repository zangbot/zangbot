#!/usr/bin/env python3
"""
backfill_call_details.py

Migrates existing `calls` documents into the hot/cold split created by
patch_hot_cold_split_v1.py.

    calls.extensionlegs  ─┐
    calls.trunklegs       ├─>  call_details   then $unset from calls
    calls.logs            │
    calls.recordings_raw ─┘

Measured starting point (nxts1-dc-001): 959,038 docs, 33 KB average,
24.7 GB. Expected finish: ~1.3 GB, which fits the WiredTiger cache
several times over.

═══════════════════════════════════════════════════════════════════
RUN THE PATCHER FIRST
═══════════════════════════════════════════════════════════════════

patch_hot_cold_split_v1.py must be applied AND the API rebuilt before
this runs. That patch adds the dual-read fallback to /api/calls/:id,
which is the only reason this is safe with the app live: a call reads
correctly whether or not it has been migrated yet.

Running this first would blank the detail tabs on every migrated call
until the rebuild caught up.

This script refuses to start if the fallback is not present.

═══════════════════════════════════════════════════════════════════
SAFETY
═══════════════════════════════════════════════════════════════════

  * No downtime. Ordinary batched writes; no collection lock.
  * Per document: insert into call_details FIRST, $unset second. A
    crash between them leaves an orphaned detail row, which the TTL
    reaps. The reverse order would lose the legs permanently.
  * Resumable. Selection is "still has trunklegs/extensionlegs/logs",
    so finished work is simply not selected again. Interrupt freely.
  * Throttled. --sleep-ms between batches. The backfill reads 24.7 GB
    of fat documents, which evicts the dashboard working set from
    cache -- so the app is SLOWER while this runs. Not down, sluggish.
  * NO ROLLBACK. Once unset, the fields live only in call_details.
    Take a mongodump first:

      docker compose exec -T mongo mongodump -u root -p "$MONGO_PASSWORD" \\
        --authenticationDatabase admin -d vodia_cdr -c calls \\
        --archive=/tmp/calls.archive --gzip
      docker compose cp mongo:/tmp/calls.archive ./calls-backup.archive

USAGE
    python3 backfill_call_details.py --dry-run
    python3 backfill_call_details.py                    # move (default)
    python3 backfill_call_details.py --mode unset       # discard cold data
    python3 backfill_call_details.py --batch 500 --sleep-ms 250
    python3 backfill_call_details.py --max-docs 5000    # trial run

  --mode move    preserve everything in call_details (recommended)
  --mode unset   discard the cold fields outright. Faster, but detail
                 tabs and future re-derivation are gone for historical
                 calls. transfer_type is already computed and stored,
                 so transfer detection is unaffected either way.
"""

import argparse
import json
import os
import re
import subprocess
import sys
import time

COLD_FIELDS = ["trunklegs", "extensionlegs", "logs", "recordings_raw"]


def _c(code, t):
    return f"\033[{code}m{t}\033[0m" if sys.stdout.isatty() else t


def ok(m):
    print(f"  {_c('32','OK')}    {m}")


def warn(m):
    print(f"  {_c('33','WARN')}  {m}")


def fail(m):
    print(f"  {_c('31','FAIL')}  {m}")


def info(m):
    print(f"  {_c('36','..')}    {m}")


def die(m, code=1):
    print()
    fail(m)
    sys.exit(code)


def find_root():
    for c in (os.getcwd(), os.path.dirname(os.path.abspath(__file__))):
        if os.path.isfile(os.path.join(c, "docker-compose.yml")) and \
           os.path.isdir(os.path.join(c, "api", "src")):
            return c
    die("Not a cdrstats install directory (need docker-compose.yml and api/src/).")


def env_value(root, key):
    """Read a key from .env without sourcing it.

    Deliberately not `. ./.env` -- at least one production install has a
    value containing a literal newline, which makes shell sourcing emit
    'command not found' noise and can truncate variables.
    """
    p = os.path.join(root, ".env")
    if not os.path.isfile(p):
        return None
    for line in open(p, encoding="utf-8", errors="replace"):
        m = re.match(rf"^\s*{re.escape(key)}\s*=\s*(.*?)\s*$", line)
        if m:
            return m.group(1).strip().strip('"').strip("'")
    return None


def mongo_eval(root, user, password, authdb, dbname, script, timeout=3600):
    """Run a mongosh script, return stdout."""
    cmd = ["docker", "compose", "exec", "-T", "mongo", "mongosh",
           "-u", user, "-p", password, "--authenticationDatabase", authdb,
           dbname, "--quiet", "--eval", script]
    r = subprocess.run(cmd, cwd=root, capture_output=True, timeout=timeout)
    out = r.stdout.decode(errors="replace")
    err = r.stderr.decode(errors="replace")
    if r.returncode != 0:
        raise RuntimeError((err or out).strip()[:600])
    return out


def preflight(root):
    """Refuse to run unless the dual-read fallback is deployed."""
    calls_js = os.path.join(root, "api", "src", "routes", "calls.js")
    if not os.path.isfile(calls_js):
        die("api/src/routes/calls.js not found.")
    src = open(calls_js, encoding="utf-8").read()
    if 'db.collection("call_details")' not in src:
        die("The dual-read fallback is NOT present in calls.js.\n"
            "        Run patch_hot_cold_split_v1.py and rebuild the API first:\n"
            "          docker compose build --no-cache api && docker compose up -d\n"
            "        Backfilling before that would blank the detail tabs on\n"
            "        every migrated call.")
    ok("dual-read fallback present in calls.js")


BATCH_SCRIPT = r'''
(function () {
  var MODE  = "%MODE%";
  var LIMIT = %LIMIT%;
  var sel = { $or: [
    { trunklegs:     { $exists: true } },
    { extensionlegs: { $exists: true } },
    { logs:          { $exists: true } },
    { recordings_raw:{ $exists: true } }
  ]};

  var cur = db.calls.find(sel, {
    system:1, domain:1, callid:1,
    trunklegs:1, extensionlegs:1, logs:1, recordings_raw:1
  }).limit(LIMIT);

  var moved = 0, unset = 0, errs = 0, bytes = 0;
  var ids = [];

  while (cur.hasNext()) {
    var d = cur.next();
    ids.push(d._id);
    try {
      if (MODE === "move") {
        var payload = {
          system: d.system, domain: d.domain, callid: d.callid,
          trunklegs:      d.trunklegs      || [],
          extensionlegs:  d.extensionlegs  || [],
          recordings_raw: d.recordings_raw || [],
          logs:           d.logs           || [],
          logs_stored:    Array.isArray(d.logs) && d.logs.length > 0,
          backfilled_at:  new Date()
        };
        bytes += Object.keys(payload).length ? bsonsize(payload) : 0;
        db.call_details.updateOne(
          { system: d.system, domain: d.domain, callid: d.callid },
          { $set: payload, $setOnInsert: { created_at: new Date() } },
          { upsert: true }
        );
        moved++;
      }
    } catch (e) { errs++; continue; }
  }

  if (ids.length) {
    var r = db.calls.updateMany(
      { _id: { $in: ids } },
      { $unset: { trunklegs:"", extensionlegs:"", logs:"", recordings_raw:"" },
        $set:   { has_trunk_leg_backfilled: true } }
    );
    unset = r.modifiedCount;
  }

  print(JSON.stringify({ seen: ids.length, moved: moved, unset: unset,
                         errs: errs, bytes: bytes }));
})();
'''

COUNT_SCRIPT = r'''
(function () {
  var sel = { $or: [
    { trunklegs:     { $exists: true } },
    { extensionlegs: { $exists: true } },
    { logs:          { $exists: true } },
    { recordings_raw:{ $exists: true } }
  ]};
  var s = db.calls.stats();
  print(JSON.stringify({
    remaining: db.calls.countDocuments(sel),
    total:     db.calls.estimatedDocumentCount(),
    details:   db.call_details.estimatedDocumentCount(),
    sizeMB:    Math.round(s.size / 1048576),
    storeMB:   Math.round(s.storageSize / 1048576),
    avgDoc:    Math.round(s.avgObjSize || 0)
  }));
})();
'''


def get_counts(root, user, pw, authdb, dbname):
    out = mongo_eval(root, user, pw, authdb, dbname, COUNT_SCRIPT, timeout=600)
    for line in out.strip().split("\n"):
        line = line.strip()
        if line.startswith("{"):
            return json.loads(line)
    raise RuntimeError("could not parse counts: " + out[:300])


def fmt_eta(seconds):
    if seconds < 0 or seconds > 86400 * 7:
        return "?"
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h}h{m:02d}m" if h else f"{m}m{s:02d}s"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["move", "unset"], default="move")
    ap.add_argument("--batch", type=int, default=500)
    ap.add_argument("--sleep-ms", type=int, default=200)
    ap.add_argument("--max-docs", type=int, default=0, help="0 = no limit")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--yes", action="store_true", help="skip confirmation")
    args = ap.parse_args()

    root = find_root()
    print()
    print(_c("1", "backfill_call_details  --  Vodia Analytics"))
    print(f"  install root : {root}")
    print(f"  mode         : {args.mode}")
    print(f"  batch        : {args.batch}   sleep: {args.sleep_ms}ms")
    print()

    preflight(root)

    pw = env_value(root, "MONGO_PASSWORD")
    dbname = env_value(root, "MONGO_DB") or "vodia_cdr"
    if not pw:
        die("MONGO_PASSWORD not found in .env")

    # root@admin preferred; fall back to the app user.
    user, authdb = "root", "admin"
    try:
        mongo_eval(root, user, pw, authdb, dbname, "print(1)", timeout=60)
        ok("authenticated as root")
    except Exception:
        user = env_value(root, "MONGO_USER") or "vodia_app"
        authdb = dbname
        try:
            mongo_eval(root, user, pw, authdb, dbname, "print(1)", timeout=60)
            ok(f"authenticated as {user}")
        except Exception as e:
            die(f"Could not authenticate to MongoDB: {e}")

    c = get_counts(root, user, pw, authdb, dbname)
    print()
    print(_c("1", "── Current state " + "─" * 42))
    info(f"calls total        : {c['total']:,}")
    info(f"still to migrate   : {c['remaining']:,}")
    info(f"call_details docs  : {c['details']:,}")
    info(f"calls logical size : {c['sizeMB']:,} MB   (this is what the cache holds)")
    info(f"calls on disk      : {c['storeMB']:,} MB   (compressed)")
    info(f"avg document       : {c['avgDoc']:,} bytes")

    if c["remaining"] == 0:
        print()
        ok("Nothing to migrate -- backfill already complete.")
        return

    batches = (c["remaining"] + args.batch - 1) // args.batch
    print()
    info(f"estimated batches  : {batches:,}")

    if args.dry_run:
        print()
        ok("Dry run -- no documents modified.")
        print()
        print("  When ready:")
        print(f"    python3 {os.path.basename(__file__)} --mode {args.mode} "
              f"--batch {args.batch} --sleep-ms {args.sleep_ms}")
        return

    if args.mode == "unset" and not args.yes:
        print()
        warn("--mode unset DISCARDS trunklegs / extensionlegs / logs permanently.")
        warn("Detail tabs and future re-derivation will be empty for these calls.")
        if input("  Type DISCARD to continue: ").strip() != "DISCARD":
            die("Aborted.", 0)
    elif not args.yes:
        print()
        warn("No rollback. Take a mongodump of `calls` first if you have not.")
        if input("  Continue? [y/N]: ").strip().lower() not in ("y", "yes"):
            die("Aborted.", 0)

    script = BATCH_SCRIPT.replace("%MODE%", args.mode).replace("%LIMIT%", str(args.batch))

    print()
    print(_c("1", "── Running " + "─" * 48))
    started = time.time()
    done = moved = unset = errs = 0
    stall = 0

    try:
        while True:
            if args.max_docs and done >= args.max_docs:
                print()
                ok(f"Reached --max-docs {args.max_docs:,}, stopping cleanly.")
                break

            t0 = time.time()
            try:
                out = mongo_eval(root, user, pw, authdb, dbname, script, timeout=1800)
            except Exception as e:
                errs += 1
                fail(f"batch failed: {str(e)[:200]}")
                if errs > 10:
                    die("Too many consecutive batch failures -- stopping.\n"
                        "        Progress so far is preserved; re-run to resume.")
                time.sleep(5)
                continue

            res = None
            for line in out.strip().split("\n"):
                if line.strip().startswith("{"):
                    res = json.loads(line.strip())
                    break
            if res is None:
                fail("could not parse batch result -- stopping")
                break

            if res["seen"] == 0:
                stall += 1
                if stall >= 2:
                    print()
                    ok("No documents left to migrate.")
                    break
                continue
            stall = 0

            done += res["seen"]
            moved += res["moved"]
            unset += res["unset"]
            elapsed = time.time() - started
            rate = done / elapsed if elapsed > 0 else 0
            left = max(0, c["remaining"] - done)
            eta = left / rate if rate > 0 else -1

            print(f"  {done:>8,} / {c['remaining']:,}  "
                  f"({done * 100 // max(1, c['remaining'])}%)  "
                  f"{rate:6.0f} docs/s  batch {time.time() - t0:4.1f}s  "
                  f"ETA {fmt_eta(eta)}", flush=True)

            if args.sleep_ms:
                time.sleep(args.sleep_ms / 1000.0)

    except KeyboardInterrupt:
        print()
        warn("Interrupted. Progress is preserved -- re-run to resume.")

    after = get_counts(root, user, pw, authdb, dbname)
    print()
    print(_c("1", "── Result " + "─" * 49))
    info(f"processed          : {done:,}")
    if args.mode == "move":
        info(f"moved to details   : {moved:,}")
    info(f"still to migrate   : {after['remaining']:,}")
    info(f"calls logical size : {c['sizeMB']:,} MB -> {after['sizeMB']:,} MB")
    info(f"avg document       : {c['avgDoc']:,} -> {after['avgDoc']:,} bytes")
    info(f"elapsed            : {fmt_eta(time.time() - started)}")

    if after["remaining"] == 0:
        print(f"""
  {_c('32', 'Backfill complete.')}

  Disk space is not returned to the filesystem until WiredTiger
  compacts. To reclaim it (takes a while, safe to run live):

    docker compose exec -T mongo mongosh -u root -p "$MONGO_PASSWORD" \\
      --authenticationDatabase admin {dbname} --quiet \\
      --eval 'db.runCommand({{ compact: "calls" }})'

  Then re-profile. The 87s country distinct, the 48s unbounded
  answering_queue query and the 31s category probe were all scanning
  959k fat documents -- they may now be fast enough to leave alone.
  Fix what is still slow against the new numbers, not the old ones.
""")
    else:
        print(f"\n  {after['remaining']:,} documents remain. Re-run to continue.\n")


if __name__ == "__main__":
    main()
