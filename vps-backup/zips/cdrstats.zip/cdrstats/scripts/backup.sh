#!/usr/bin/env bash
##
## Vodia CDR Platform — Automated Backup
## Backs up MongoDB + .env to /backups/
## Add to cron: 0 3 * * * /path/to/backup.sh
##

set -euo pipefail

BACKUP_DIR="/backups/vodia-cdr"
DATE=$(date +%Y%m%d-%H%M%S)
KEEP_DAYS=${BACKUP_RETENTION_DAYS:-30}

mkdir -p "$BACKUP_DIR"

# Source env for credentials
cd "$(dirname "$0")/.."
source .env 2>/dev/null || true

echo "[$(date)] Starting backup..."

# MongoDB dump
MONGO_PW="${MONGO_PASSWORD:-}"
if [ -n "$MONGO_PW" ]; then
  docker compose exec -T mongo mongodump \
    -u "${MONGO_USER:-vodia_app}" \
    -p "$MONGO_PW" \
    --authenticationDatabase "${MONGO_DB:-vodia_cdr}" \
    --db "${MONGO_DB:-vodia_cdr}" \
    --archive="/tmp/mongodump-${DATE}.gz" \
    --gzip 2>/dev/null

  docker cp "$(docker compose ps -q mongo):/tmp/mongodump-${DATE}.gz" \
    "${BACKUP_DIR}/mongodump-${DATE}.gz"

  docker compose exec -T mongo rm -f "/tmp/mongodump-${DATE}.gz"
  echo "  ✓ MongoDB backed up: mongodump-${DATE}.gz"
else
  docker compose exec -T mongo mongodump \
    --db "${MONGO_DB:-vodia_cdr}" \
    --archive="/tmp/mongodump-${DATE}.gz" \
    --gzip 2>/dev/null

  docker cp "$(docker compose ps -q mongo):/tmp/mongodump-${DATE}.gz" \
    "${BACKUP_DIR}/mongodump-${DATE}.gz"

  docker compose exec -T mongo rm -f "/tmp/mongodump-${DATE}.gz"
  echo "  ✓ MongoDB backed up: mongodump-${DATE}.gz"
fi

# Backup .env (contains secrets)
cp .env "${BACKUP_DIR}/env-${DATE}.bak"
chmod 600 "${BACKUP_DIR}/env-${DATE}.bak"
echo "  ✓ .env backed up"

# Clean old backups
find "$BACKUP_DIR" -name "mongodump-*.gz" -mtime +${KEEP_DAYS} -delete 2>/dev/null
find "$BACKUP_DIR" -name "env-*.bak" -mtime +${KEEP_DAYS} -delete 2>/dev/null
echo "  ✓ Cleaned backups older than ${KEEP_DAYS} days"

echo "[$(date)] Backup complete."
