#!/usr/bin/env python3
"""
cleanup_bull_backlog.py

Clears historical BullMQ job records that accumulated before retention
limits were added in 1.2.5.

WHY
    Transcription jobs were enqueued with no removeOnComplete/removeOnFail.
    BullMQ's default for both is `false` -- keep forever. Measured on a
    production install: 296,225 completed jobs, ~297,000 Redis keys,
    386 MB against a 256 MB maxmemory with noeviction.

    Once Redis is at maxmemory every write command fails, which takes down
    login (passkey challenge), the license cache, and CDR ingest at the
    same time. The visible symptom is a bare "Internal Server Error".

    patch_hot_cold_split_v1.py caps NEW jobs. It cannot clear the existing
    backlog: removeOnComplete trims only a little per completion, so a
    296k set would take an extremely long time to drain on its own.

    Measured result on the reference install:
        297,208 keys / 386.65 MB  ->  327 keys / 4.13 MB
    The transcription worker also went from 104% to 259% CPU, because it
    stopped doing ZADD+trim against a quarter-million-member sorted set on
    every job completion. Transcription throughput was being throttled by
    this backlog, not by the worker.

METHOD
    Two passes, because BullMQ stores each job twice:

      1. ZREMRANGEBYRANK on the completed/failed sorted sets -- removes the
         oldest by rank, server-side. No Lua, no argument marshalling.
      2. Sweep the orphaned job hashes (bull:<queue>:<numeric-id>) that
         pass 1 leaves behind. Without this DBSIZE barely moves.

    An earlier version used `redis-cli --eval` and hung forever waiting on
    stdin that was never piped. Deliberately not used here.

SAFE
    Touches only `completed` and `failed` -- work already processed, kept
    purely for history. Never touches wait / active / delayed / paused, so
    nothing pending is lost and a running worker is unaffected.

    The orphan sweep matches ^bull:<queue>:[0-9]+$ only, so :wait, :active,
    :meta, :events, :id and :marker cannot match.

    Safe to interrupt. Safe to re-run. Nothing is written, only removed.

USAGE
    python3 cleanup_bull_backlog.py --dry-run
    python3 cleanup_bull_backlog.py
    python3 cleanup_bull_backlog.py --queue transcription
    python3 cleanup_bull_backlog.py --keep 100 --batch 5000

  --keep N         leave the N most recent per set (default 100)
  --batch N        ids removed per round trip (default 5000)
  --queue NAME     limit to one queue; default is every queue found
  --skip-orphans   drain the sets only (not recommended -- memory will
                   barely move, since the job hashes hold the payload)
"""

import argparse
import os
import re
import subprocess
import sys
import time

DRAINABLE = ["completed", "failed"]
PENDING = ["wait", "active", "delayed", "paused"]


def _c(code, t):
    return f"\033[{code}m{t}\033[0m" if sys.stdout.isatty() else t


def ok(m):
    print(f"  {_c('32','OK')}    {m}")


def warn(m):
    print(f"  {_c('33','WARN')}  {m}")


def fail(m):
    print(f"  {_c('31','FAIL')}  {m}")


def info(m):
    print(f"  {_c('36','..')}    {m}")


def die(m, code=1):
    print()
    fail(m)
    sys.exit(code)


def find_root():
    here = os.path.dirname(os.path.abspath(__file__))
    for c in (os.getcwd(), here, os.path.dirname(here)):
        if os.path.isfile(os.path.join(c, "docker-compose.yml")):
            return c
    die("Not a cdrstats install directory (docker-compose.yml not found).")


def env_value(root, key):
    """Read .env directly rather than sourcing it -- at least one install
    has a value containing a literal newline, which breaks `source`."""
    p = os.path.join(root, ".env")
    if not os.path.isfile(p):
        return None
    for line in open(p, encoding="utf-8", errors="replace"):
        m = re.match(rf"^\s*{re.escape(key)}\s*=\s*(.*?)\s*$", line)
        if m:
            return m.group(1).strip().strip('"').strip("'")
    return None


class Redis:
    def __init__(self, root, password):
        self.root = root
        self.password = password

    def run(self, args, timeout=300):
        cmd = ["docker", "compose", "exec", "-T", "redis", "redis-cli",
               "-a", self.password, "--no-auth-warning"] + args
        r = subprocess.run(cmd, cwd=self.root, capture_output=True, timeout=timeout)
        if r.returncode != 0:
            raise RuntimeError(r.stderr.decode(errors="replace").strip()[:300])
        return r.stdout.decode(errors="replace").replace("\r", "").strip()

    def num(self, args):
        try:
            out = self.run(args)
            return int(re.sub(r"[^0-9-]", "", out.split("\n")[0]) or 0)
        except (ValueError, RuntimeError):
            return 0

    def zcard(self, key):
        return self.num(["ZCARD", key])

    def llen(self, key):
        return self.num(["LLEN", key])

    def dbsize(self):
        return self.num(["DBSIZE"])

    def _info_field(self, field):
        try:
            for line in self.run(["INFO", "memory"]).split("\n"):
                if line.startswith(field + ":"):
                    return line.split(":", 1)[1].strip()
        except RuntimeError:
            pass
        return "?"

    def memory_human(self):
        return self._info_field("used_memory_human")

    def maxmemory_human(self):
        return self._info_field("maxmemory_human")

    def queues(self):
        out = self.run(["--scan", "--pattern", "bull:*:meta"], timeout=600)
        names = set()
        for line in out.split("\n"):
            m = re.match(r"^bull:(.+):meta$", line.strip())
            if m:
                names.add(m.group(1))
        return sorted(names)

    def scan_job_hashes(self, queue):
        """Numeric job-id keys only -- cannot match :wait/:active/:meta."""
        out = self.run(["--scan", "--pattern", f"bull:{queue}:*"], timeout=900)
        pat = re.compile(rf"^bull:{re.escape(queue)}:[0-9]+$")
        return [ln.strip() for ln in out.split("\n") if pat.match(ln.strip())]

    def delete_keys(self, keys, chunk=500):
        removed = 0
        for i in range(0, len(keys), chunk):
            try:
                removed += self.num(["DEL"] + keys[i:i + chunk])
            except RuntimeError as e:
                fail(f"DEL batch failed: {e}")
                break
        return removed


def drain_set(r, queue, state, keep, batch):
    key = f"bull:{queue}:{state}"
    total = r.zcard(key)
    if total <= keep:
        return 0

    print(f"  {_c('1', key)}: {total:,} -> {keep:,}")
    removed = 0
    while True:
        current = r.zcard(key)
        if current <= keep:
            break
        # min() prevents overshooting into the records we mean to keep --
        # a fixed-size ZREMRANGEBYRANK on the last pass would take them too.
        n = min(batch, current - keep)
        try:
            r.run(["ZREMRANGEBYRANK", key, "0", str(n - 1)])
        except RuntimeError as e:
            fail(f"ZREMRANGEBYRANK failed: {e}")
            break
        removed += n
        print(f"    removed {removed:,}, remaining {r.zcard(key):,}", flush=True)
    return removed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep", type=int, default=100)
    ap.add_argument("--batch", type=int, default=5000)
    ap.add_argument("--queue", default=None)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--skip-orphans", action="store_true")
    ap.add_argument("--yes", action="store_true")
    args = ap.parse_args()

    root = find_root()
    pw = env_value(root, "REDIS_PASSWORD")
    if not pw:
        die("REDIS_PASSWORD not found in .env")

    print()
    print(_c("1", "cleanup_bull_backlog  --  Vodia Analytics"))
    print(f"  install root : {root}")
    print(f"  keep         : {args.keep} per set")
    print(f"  mode         : {'DRY RUN' if args.dry_run else 'APPLY'}")
    print()

    r = Redis(root, pw)
    try:
        mem_before = r.memory_human()
    except Exception as e:
        die(f"Could not reach Redis: {e}")

    keys_before = r.dbsize()
    info(f"used_memory : {mem_before}")
    info(f"maxmemory   : {r.maxmemory_human()}")
    info(f"total keys  : {keys_before:,}")
    print()

    queues = [args.queue] if args.queue else r.queues()
    if not queues:
        die("No BullMQ queues found.")

    print(_c("1", "── Current state " + "─" * 42))
    to_remove = 0
    for q in queues:
        for state in DRAINABLE:
            n = r.zcard(f"bull:{q}:{state}")
            over = max(0, n - args.keep)
            to_remove += over
            suffix = f"   -> remove {over:,}" if over else ""
            print(f"  bull:{q}:{state}".ljust(44) + f"{n:>9,}{suffix}")
        pend = "  ".join(f"{s}={r.llen(f'bull:{q}:{s}')}" for s in PENDING)
        info(f"bull:{q} pending (never touched): {pend}")
    print()

    info(f"job records to remove: {to_remove:,}")

    if args.dry_run:
        print()
        info("Orphaned job hashes are counted during the real run.")
        ok("Dry run -- nothing deleted.")
        return

    if not args.yes:
        print()
        warn("Removes COMPLETED and FAILED job history only.")
        warn("Pending work (wait/active/delayed/paused) is never touched.")
        if input("  Continue? [y/N]: ").strip().lower() not in ("y", "yes"):
            die("Aborted.", 0)

    started = time.time()

    print()
    print(_c("1", "── Pass 1: drain completed/failed sets " + "─" * 20))
    drained = 0
    for q in queues:
        for state in DRAINABLE:
            drained += drain_set(r, q, state, args.keep, args.batch)
    if drained == 0:
        info("nothing to drain")

    orphans_removed = 0
    if not args.skip_orphans:
        print()
        print(_c("1", "── Pass 2: sweep orphaned job hashes " + "─" * 22))
        info("ZREMRANGEBYRANK removes set members but leaves each job's")
        info("hash behind -- without this, memory barely moves.")
        for q in queues:
            try:
                hashes = r.scan_job_hashes(q)
            except RuntimeError as e:
                fail(f"scan failed for {q}: {e}")
                continue
            if not hashes:
                info(f"bull:{q}: no orphaned hashes")
                continue
            print(f"  {_c('1', 'bull:' + q)}: {len(hashes):,} job hashes")
            n = r.delete_keys(hashes)
            orphans_removed += n
            print(f"    deleted {n:,}")

    keys_after = r.dbsize()
    print()
    print(_c("1", "── Result " + "─" * 49))
    info(f"set members removed : {drained:,}")
    info(f"job hashes removed  : {orphans_removed:,}")
    info(f"total keys          : {keys_before:,} -> {keys_after:,}")
    info(f"used_memory         : {mem_before} -> {r.memory_human()}")
    info(f"elapsed             : {int(time.time() - started)}s")
    print()
    ok("Done. Retention limits added in 1.2.5 prevent this recurring.")
    print()


if __name__ == "__main__":
    main()