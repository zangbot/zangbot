#!/usr/bin/env bash
##
## Vodia CDR Analytics — Update Script
## Downloads latest release, backs up current install, applies update safely.
## Database migrations run automatically on API startup.
##
## Usage:
##   bash update.sh                    # Update to latest
##   bash update.sh --check            # Check for updates only
##   bash update.sh --rollback         # Rollback to previous version
##   bash update.sh --list             # List available backups
##   bash update.sh --rollback <tag>   # Rollback to specific backup
##

set -uo pipefail

# ── Config ─────────────────────────────────────────────
CDN_URL="${CDN_URL:-https://vodia.nyc3.cdn.digitaloceanspaces.com/cdrstats/cdrstats.zip}"
INSTALL_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKUP_DIR="${INSTALL_DIR}/backups"
MAX_BACKUPS=5
TMP_DIR="/tmp/vodia-cdr-update-$$"

# ── Colors ─────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { echo -e "${GREEN}✓${NC} $1"; }
warn() { echo -e "${YELLOW}⚠${NC} $1"; }
err()  { echo -e "${RED}✗${NC} $1"; exit 1; }
info() { echo -e "${BLUE}ℹ${NC} $1"; }

# ── Cleanup on exit ────────────────────────────────────
cleanup() { rm -rf "$TMP_DIR"; }
trap cleanup EXIT

# ── Files/dirs that are NEVER overwritten ──────────────
# .env contains secrets, docker-compose.override.yml is user customization
PROTECTED_FILES=(".env" "docker-compose.override.yml")

# ── Directories that contain only code (safe to update) ─
CODE_DIRS=("api/src" "worker/src" "frontend/src" "caddy" "scripts")
CODE_FILES=(
  "docker-compose.yml"
  "version.json"
  "update.sh"
  "api/package.json"
  "api/Dockerfile"
  "worker/package.json"
  "worker/Dockerfile"
  "frontend/package.json"
  "frontend/Dockerfile"
  "frontend/vite.config.js"
  "frontend/tailwind.config.js"
  "frontend/postcss.config.js"
  "frontend/index.html"
  ".env.example"
  "README.md"
)

# ── Get version from version.json ──────────────────────
get_version() {
  local dir="${1:-.}"
  if [ -f "${dir}/version.json" ]; then
    python3 -c "import json; print(json.load(open('${dir}/version.json'))['version'])" 2>/dev/null || echo "0.0.0"
  else
    echo "0.0.0"
  fi
}

get_build() {
  local dir="${1:-.}"
  if [ -f "${dir}/version.json" ]; then
    python3 -c "import json; print(json.load(open('${dir}/version.json'))['build'])" 2>/dev/null || echo "unknown"
  else
    echo "unknown"
  fi
}

# ── Version comparison (0 = equal, 1 = $1 > $2, 2 = $1 < $2)
version_compare() {
  if [ "$1" = "$2" ]; then echo 0; return; fi
  local higher
  higher=$(printf '%s\n' "$1" "$2" | sort -V | tail -1)
  if [ "$higher" = "$1" ]; then echo 1; else echo 2; fi
}

# ══════════════════════════════════════════════════════
# Backup current installation
# ══════════════════════════════════════════════════════
create_backup() {
  local current_ver
  current_ver=$(get_version "$INSTALL_DIR")
  local timestamp
  timestamp=$(date +%Y%m%d-%H%M%S)
  local backup_name="v${current_ver}_${timestamp}"
  local backup_path="${BACKUP_DIR}/${backup_name}"

  info "Creating backup: ${backup_name}"
  mkdir -p "$backup_path"

  # Backup code directories
  for dir in "${CODE_DIRS[@]}"; do
    if [ -d "${INSTALL_DIR}/${dir}" ]; then
      mkdir -p "${backup_path}/${dir}"
      cp -a "${INSTALL_DIR}/${dir}/." "${backup_path}/${dir}/"
    fi
  done

  # Backup individual code files
  for f in "${CODE_FILES[@]}"; do
    if [ -f "${INSTALL_DIR}/${f}" ]; then
      mkdir -p "${backup_path}/$(dirname "$f")"
      cp -a "${INSTALL_DIR}/${f}" "${backup_path}/${f}"
    fi
  done

  # Backup migration files specifically (critical for rollback)
  if [ -d "${INSTALL_DIR}/api/src/migrations" ]; then
    mkdir -p "${backup_path}/api/src/migrations"
    cp -a "${INSTALL_DIR}/api/src/migrations/." "${backup_path}/api/src/migrations/"
  fi

  # Save current version info
  echo "$current_ver" > "${backup_path}/.version"
  date -Iseconds > "${backup_path}/.timestamp"

  # Create a MongoDB dump for safety
  info "Backing up MongoDB..."
  if docker compose exec -T mongo mongodump \
    --uri="mongodb://root:${MONGO_PASSWORD}@localhost:27017/vodia_cdr?authSource=admin" \
    --archive 2>/dev/null > "${backup_path}/mongo-dump.archive"; then
    log "MongoDB backed up ($(du -sh "${backup_path}/mongo-dump.archive" | cut -f1))"
  else
    warn "MongoDB backup failed — continuing anyway (data is in Docker volume)"
  fi

  log "Backup created: backups/${backup_name}"

  # Prune old backups (keep MAX_BACKUPS most recent)
  local count
  count=$(ls -d "${BACKUP_DIR}"/v* 2>/dev/null | wc -l)
  if [ "$count" -gt "$MAX_BACKUPS" ]; then
    local to_delete=$((count - MAX_BACKUPS))
    ls -dt "${BACKUP_DIR}"/v* | tail -n "$to_delete" | while read -r old; do
      info "Pruning old backup: $(basename "$old")"
      rm -rf "$old"
    done
  fi

  echo "$backup_name"
}

# ══════════════════════════════════════════════════════
# List available backups
# ══════════════════════════════════════════════════════
list_backups() {
  if [ ! -d "$BACKUP_DIR" ] || [ -z "$(ls -A "$BACKUP_DIR" 2>/dev/null)" ]; then
    info "No backups found"
    return
  fi

  echo ""
  echo "  Available backups:"
  echo "  ─────────────────────────────────────────"
  for b in $(ls -dt "${BACKUP_DIR}"/v* 2>/dev/null); do
    local name
    name=$(basename "$b")
    local ver
    ver=$(cat "${b}/.version" 2>/dev/null || echo "?")
    local ts
    ts=$(cat "${b}/.timestamp" 2>/dev/null || echo "?")
    local has_db=""
    [ -f "${b}/mongo-dump.archive" ] && has_db=" [+DB]"
    local size
    size=$(du -sh "$b" 2>/dev/null | cut -f1)
    echo "  ${name}  (v${ver}, ${size})${has_db}"
  done
  echo ""
}

# ══════════════════════════════════════════════════════
# Rollback to a previous backup
# ══════════════════════════════════════════════════════
do_rollback() {
  local target="${1:-}"

  if [ -z "$target" ]; then
    # Use most recent backup
    target=$(ls -dt "${BACKUP_DIR}"/v* 2>/dev/null | head -1)
    if [ -z "$target" ]; then
      err "No backups found to rollback to"
    fi
    target=$(basename "$target")
  fi

  local backup_path="${BACKUP_DIR}/${target}"
  if [ ! -d "$backup_path" ]; then
    err "Backup not found: ${target}"
  fi

  local backup_ver
  backup_ver=$(cat "${backup_path}/.version" 2>/dev/null || echo "unknown")

  echo ""
  echo "══════════════════════════════════════════════════"
  echo "  Rolling back to: ${target} (v${backup_ver})"
  echo "══════════════════════════════════════════════════"
  echo ""

  read -r -p "  This will replace all code files. Continue? (y/N) " confirm
  if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
    info "Rollback cancelled"
    exit 0
  fi

  # Stop services
  info "Stopping services..."
  cd "$INSTALL_DIR"
  docker compose stop api worker 2>/dev/null || true

  # Restore code directories
  for dir in "${CODE_DIRS[@]}"; do
    if [ -d "${backup_path}/${dir}" ]; then
      rm -rf "${INSTALL_DIR:?}/${dir}"
      cp -a "${backup_path}/${dir}" "${INSTALL_DIR}/${dir}"
      log "Restored ${dir}/"
    fi
  done

  # Restore individual files
  for f in "${CODE_FILES[@]}"; do
    if [ -f "${backup_path}/${f}" ]; then
      mkdir -p "${INSTALL_DIR}/$(dirname "$f")"
      cp -a "${backup_path}/${f}" "${INSTALL_DIR}/${f}"
    fi
  done

  # Optionally restore MongoDB
  if [ -f "${backup_path}/mongo-dump.archive" ]; then
    echo ""
    read -r -p "  Also restore the database? Only needed if data is corrupted. (y/N) " restore_db
    if [[ "$restore_db" =~ ^[Yy]$ ]]; then
      info "Restoring MongoDB..."
      docker compose start mongo 2>/dev/null
      sleep 5
      if docker compose exec -T mongo mongorestore \
        --uri="mongodb://root:${MONGO_PASSWORD}@localhost:27017/vodia_cdr?authSource=admin" \
        --archive --drop < "${backup_path}/mongo-dump.archive" 2>/dev/null; then
        log "MongoDB restored"
      else
        warn "MongoDB restore failed — database may still be fine"
      fi
    fi
  fi

  # Rebuild and restart
  info "Rebuilding containers..."
  docker compose build --quiet 2>&1 | tail -3
  docker compose up -d
  sleep 5

  log "Rollback complete — now running v${backup_ver}"
  echo ""
}

# ══════════════════════════════════════════════════════
# Check for updates
# ══════════════════════════════════════════════════════
check_update() {
  local current_ver
  current_ver=$(get_version "$INSTALL_DIR")
  info "Current version: ${current_ver}"
  info "Checking ${CDN_URL}..."

  mkdir -p "$TMP_DIR"

  if ! wget -q "$CDN_URL" -O "${TMP_DIR}/update.zip" 2>/dev/null; then
    err "Failed to download from ${CDN_URL}"
  fi

  # Extract version.json from the zip
  if ! unzip -q "${TMP_DIR}/update.zip" -d "${TMP_DIR}/extracted" 2>/dev/null; then
    err "Failed to extract update package"
  fi

  # Find the extracted directory (might be nested)
  local extracted_root
  extracted_root=$(find "${TMP_DIR}/extracted" -name "version.json" -exec dirname {} \; | head -1)

  if [ -z "$extracted_root" ]; then
    err "No version.json found in update package"
  fi

  local remote_ver
  remote_ver=$(get_version "$extracted_root")
  local remote_build
  remote_build=$(get_build "$extracted_root")

  local cmp
  cmp=$(version_compare "$remote_ver" "$current_ver")

  echo ""
  if [ "$cmp" = "1" ]; then
    log "Update available: v${current_ver} → v${remote_ver} (built ${remote_build})"
    return 0
  elif [ "$cmp" = "0" ]; then
    info "Already up to date (v${current_ver})"
    return 1
  else
    warn "Remote version (v${remote_ver}) is older than current (v${current_ver})"
    return 1
  fi
}

# ══════════════════════════════════════════════════════
# Apply update
# ══════════════════════════════════════════════════════
do_update() {
  local current_ver
  current_ver=$(get_version "$INSTALL_DIR")

  echo ""
  echo "══════════════════════════════════════════════════"
  echo "  Vodia CDR Analytics — Update"
  echo "══════════════════════════════════════════════════"
  echo ""
  info "Current version: ${current_ver}"
  info "Downloading update..."

  mkdir -p "$TMP_DIR"

  # Download
  if ! wget -q --show-progress "$CDN_URL" -O "${TMP_DIR}/update.zip" 2>&1; then
    err "Download failed from ${CDN_URL}"
  fi

  # Extract
  if ! unzip -q "${TMP_DIR}/update.zip" -d "${TMP_DIR}/extracted" 2>/dev/null; then
    err "Failed to extract update package"
  fi

  # Find extracted root
  local extracted_root
  extracted_root=$(find "${TMP_DIR}/extracted" -name "version.json" -exec dirname {} \; | head -1)

  if [ -z "$extracted_root" ]; then
    err "Invalid update package — no version.json found"
  fi

  local remote_ver
  remote_ver=$(get_version "$extracted_root")
  local remote_build
  remote_build=$(get_build "$extracted_root")

  info "Update version: v${remote_ver} (built ${remote_build})"

  # Version check
  local cmp
  cmp=$(version_compare "$remote_ver" "$current_ver")
  if [ "$cmp" = "2" ]; then
    warn "Remote version (v${remote_ver}) is older than current (v${current_ver})"
    read -r -p "  Continue anyway? (y/N) " confirm
    if [[ ! "$confirm" =~ ^[Yy]$ ]]; then exit 0; fi
  fi

  # ── Create backup before touching anything ───────
  echo ""
  # Source .env for MONGO_PASSWORD
  if [ -f "${INSTALL_DIR}/.env" ]; then
    set +u
    source "${INSTALL_DIR}/.env"
    set -u
  fi

  local backup_name
  backup_name=$(create_backup)
  echo ""

  # ── Stop API and worker (Caddy keeps serving cached frontend) ─
  info "Stopping API and worker..."
  cd "$INSTALL_DIR"
  docker compose stop api worker 2>/dev/null || true

  # ── Apply code updates ───────────────────────────
  info "Applying update..."

  # Update code directories
  for dir in "${CODE_DIRS[@]}"; do
    if [ -d "${extracted_root}/${dir}" ]; then
      # Remove old code, replace with new
      rm -rf "${INSTALL_DIR:?}/${dir}"
      cp -a "${extracted_root}/${dir}" "${INSTALL_DIR}/${dir}"
      log "Updated ${dir}/"
    fi
  done

  # Update individual code files
  for f in "${CODE_FILES[@]}"; do
    if [ -f "${extracted_root}/${f}" ]; then
      mkdir -p "${INSTALL_DIR}/$(dirname "$f")"
      cp -a "${extracted_root}/${f}" "${INSTALL_DIR}/${f}"
    fi
  done

  # ── Protect user files ───────────────────────────
  for f in "${PROTECTED_FILES[@]}"; do
    if [ -f "${BACKUP_DIR}/${backup_name}/${f}" ] && [ ! -f "${INSTALL_DIR}/${f}" ]; then
      # Protected file was somehow removed — restore it
      cp -a "${BACKUP_DIR}/${backup_name}/${f}" "${INSTALL_DIR}/${f}"
      warn "Restored protected file: ${f}"
    fi
  done

  # ── Check for new .env variables ─────────────────
  if [ -f "${INSTALL_DIR}/.env.example" ] && [ -f "${INSTALL_DIR}/.env" ]; then
    local new_vars=0
    while IFS= read -r line; do
      # Skip comments and empty lines
      [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
      local key
      key=$(echo "$line" | cut -d= -f1)
      if ! grep -q "^${key}=" "${INSTALL_DIR}/.env" 2>/dev/null; then
        if [ "$new_vars" -eq 0 ]; then
          echo ""
          warn "New environment variables available:"
        fi
        echo "    ${key}"
        new_vars=$((new_vars + 1))
      fi
    done < "${INSTALL_DIR}/.env.example"
    if [ "$new_vars" -gt 0 ]; then
      warn "Add these to your .env file if needed (see .env.example)"
    fi
  fi

  # ── Rebuild containers ──────────────────────────
  echo ""
  info "Rebuilding containers..."
  docker compose build --quiet 2>&1 | tail -5

  # ── Start everything ────────────────────────────
  info "Starting services..."
  docker compose up -d
  sleep 5

  # ── Verify services are healthy ─────────────────
  local healthy=true
  for svc in api worker; do
    if docker compose ps "$svc" 2>/dev/null | grep -q "Up"; then
      log "${svc} is running"
    else
      err "${svc} failed to start"
      healthy=false
    fi
  done

  if [ "$healthy" = false ]; then
    echo ""
    err "Some services failed. Check logs: docker compose logs api worker"
    warn "To rollback: bash update.sh --rollback"
    exit 1
  fi

  # ── Verify API responds ─────────────────────────
  sleep 3
  if curl -sf http://localhost:3000/health > /dev/null 2>&1; then
    log "API health check passed"
  else
    warn "API health check failed — may still be starting. Check: docker compose logs api"
  fi

  echo ""
  echo "══════════════════════════════════════════════════"
  log "Update complete: v${current_ver} → v${remote_ver}"
  echo "══════════════════════════════════════════════════"
  echo ""
  echo "  Backup saved: backups/${backup_name}"
  echo "  Rollback:     bash update.sh --rollback"
  echo "  Logs:         docker compose logs -f api worker"
  echo ""
  echo "  Database migrations ran automatically on startup."
  echo "  Hard refresh your browser to load the new frontend."
  echo ""
}

# ══════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════

# Source .env for passwords (needed for backup)
if [ -f "${INSTALL_DIR}/.env" ]; then
  set +u
  source "${INSTALL_DIR}/.env" 2>/dev/null || true
  set -u
fi

case "${1:-}" in
  --check)
    check_update
    ;;
  --rollback)
    do_rollback "${2:-}"
    ;;
  --list)
    list_backups
    ;;
  --url)
    CDN_URL="${2:?Usage: bash update.sh --url <zip_url>}"
    do_update
    ;;
  --help|-h)
    echo "Usage: bash update.sh [option]"
    echo ""
    echo "  (no args)        Update to latest version"
    echo "  --check          Check for updates without installing"
    echo "  --rollback       Rollback to previous version"
    echo "  --rollback TAG   Rollback to specific backup"
    echo "  --list           List available backups"
    echo "  --url URL        Update from custom URL"
    echo "  --help           Show this help"
    echo ""
    ;;
  *)
    do_update
    ;;
esac
