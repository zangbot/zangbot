/**
 * WAV Stereo Channel Splitter
 *
 * Splits a dual-channel (stereo) WAV file into two mono WAV buffers.
 * Works with linear PCM WAV files (16-bit or 24-bit).
 * Pure Node.js — no external dependencies.
 */
import pino from "pino";

const logger = pino({ level: process.env.LOG_LEVEL || "info" });

/**
 * Mu-law to 16-bit linear PCM decode table
 */
const MULAW_DECODE = new Int16Array(256);
(function() {
  const BIAS = 0x84;
  for (let i = 0; i < 256; i++) {
    let t = ~i;
    let sign = t & 0x80;
    let exponent = (t >> 4) & 0x07;
    let mantissa = t & 0x0F;
    let sample = (mantissa << 3) + BIAS;
    sample <<= exponent;
    sample -= BIAS;
    MULAW_DECODE[i] = sign ? -sample : sample;
  }
})();

/**
 * A-law to 16-bit linear PCM decode table
 */
const ALAW_DECODE = new Int16Array(256);
(function() {
  for (let i = 0; i < 256; i++) {
    let t = i ^ 0x55;
    let sign = t & 0x80;
    let exponent = (t >> 4) & 0x07;
    let mantissa = t & 0x0F;
    let sample;
    if (exponent === 0) {
      sample = (mantissa << 4) + 8;
    } else {
      sample = ((mantissa << 4) + 0x108) << (exponent - 1);
    }
    ALAW_DECODE[i] = sign ? -sample : sample;
  }
})();



/**
 * Parse WAV header from a Buffer.
 * Returns { sampleRate, bitsPerSample, numChannels, dataOffset, dataSize }
 */
function parseWavHeader(buf) {
  if (buf.length < 44) throw new Error("Buffer too small for WAV header");
  const riff = buf.toString("ascii", 0, 4);
  if (riff !== "RIFF") throw new Error("Not a RIFF file");
  const wave = buf.toString("ascii", 8, 12);
  if (wave !== "WAVE") throw new Error("Not a WAVE file");

  // Find fmt chunk
  let offset = 12;
  let fmtFound = false;
  let audioFormat, numChannels, sampleRate, bitsPerSample, blockAlign;

  while (offset < buf.length - 8) {
    const chunkId = buf.toString("ascii", offset, offset + 4);
    const chunkSize = buf.readUInt32LE(offset + 4);

    if (chunkId === "fmt ") {
      audioFormat = buf.readUInt16LE(offset + 8);
      numChannels = buf.readUInt16LE(offset + 10);
      sampleRate = buf.readUInt32LE(offset + 12);
      // byteRate = buf.readUInt32LE(offset + 16);
      blockAlign = buf.readUInt16LE(offset + 20);
      bitsPerSample = buf.readUInt16LE(offset + 22);
      fmtFound = true;
    }

    if (chunkId === "data") {
      if (!fmtFound) throw new Error("data chunk before fmt chunk");
      return {
        audioFormat,
        numChannels,
        sampleRate,
        bitsPerSample,
        blockAlign,
        dataOffset: offset + 8,
        dataSize: chunkSize,
      };
    }

    offset += 8 + chunkSize;
    // Chunks must be word-aligned
    if (chunkSize % 2 !== 0) offset++;
  }

  throw new Error("Could not find data chunk in WAV file");
}

/**
 * Build a mono WAV buffer from raw PCM samples.
 */
function buildMonoWav(samples, sampleRate, bitsPerSample) {
  const bytesPerSample = bitsPerSample / 8;
  const dataSize = samples.length * bytesPerSample;
  const header = Buffer.alloc(44);

  // RIFF header
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write("WAVE", 8);

  // fmt chunk
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16); // chunk size
  header.writeUInt16LE(1, 20); // PCM format
  header.writeUInt16LE(1, 22); // mono
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * bytesPerSample, 28); // byte rate
  header.writeUInt16LE(bytesPerSample, 32); // block align
  header.writeUInt16LE(bitsPerSample, 34);

  // data chunk
  header.write("data", 36);
  header.writeUInt32LE(dataSize, 40);

  // Write sample data
  const data = Buffer.alloc(dataSize);
  for (let i = 0; i < samples.length; i++) {
    if (bitsPerSample === 16) {
      data.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(samples[i]))), i * 2);
    } else if (bitsPerSample === 24) {
      const val = Math.max(-8388608, Math.min(8388607, Math.round(samples[i])));
      data.writeIntLE(val, i * 3, 3);
    }
  }

  return Buffer.concat([header, data]);
}

/**
 * Split a stereo WAV buffer into two mono WAV buffers.
 * Returns { channel0: Buffer, channel1: Buffer, sampleRate, bitsPerSample, durationSeconds }
 *
 * If the input is mono, returns { channel0: originalBuffer, channel1: null, ... }
 */
export function splitStereoWav(wavBuffer) {
  const header = parseWavHeader(wavBuffer);

  logger.info({
    channels: header.numChannels,
    sampleRate: header.sampleRate,
    bitsPerSample: header.bitsPerSample,
    dataSize: header.dataSize,
    format: header.audioFormat,
  }, "Parsed WAV header");

  if (![1, 6, 7].includes(header.audioFormat)) {
    throw new Error(`Unsupported WAV format: ${header.audioFormat} (supported: 1=PCM, 6=A-law, 7=mu-law)`);
  }

  // For mu-law (7) and a-law (6), samples are 8-bit but decode to 16-bit
  const isCompressed = header.audioFormat === 6 || header.audioFormat === 7;
  const decodedBitsPerSample = isCompressed ? 16 : header.bitsPerSample;

  const srcBytesPerSample = header.bitsPerSample / 8;
  const totalSamples = header.dataSize / srcBytesPerSample;
  const samplesPerChannel = Math.floor(totalSamples / header.numChannels);
  const durationSeconds = samplesPerChannel / header.sampleRate;
  const decodeTable = header.audioFormat === 7 ? MULAW_DECODE : header.audioFormat === 6 ? ALAW_DECODE : null;

  if (header.numChannels === 1) {
    logger.info({ format: header.audioFormat, compressed: isCompressed }, "Mono WAV — no splitting needed");
    if (isCompressed) {
      // Decode to 16-bit PCM mono
      const decoded = new Float64Array(samplesPerChannel);
      for (let i = 0; i < samplesPerChannel; i++) {
        decoded[i] = decodeTable[wavBuffer[header.dataOffset + i]];
      }
      return {
        channel0: buildMonoWav(decoded, header.sampleRate, 16),
        channel1: null,
        sampleRate: header.sampleRate,
        bitsPerSample: 16,
        durationSeconds,
        isMono: true,
      };
    }
    return {
      channel0: wavBuffer,
      channel1: null,
      sampleRate: header.sampleRate,
      bitsPerSample: header.bitsPerSample,
      durationSeconds,
      isMono: true,
    };
  }

  if (header.numChannels !== 2) {
    throw new Error(`Unsupported channel count: ${header.numChannels}`);
  }

  // Deinterleave stereo samples
  const ch0 = new Float64Array(samplesPerChannel);
  const ch1 = new Float64Array(samplesPerChannel);

  const dataStart = header.dataOffset;

  for (let i = 0; i < samplesPerChannel; i++) {
    const frameOffset = dataStart + (i * header.numChannels * srcBytesPerSample);

    if (decodeTable) {
      // 8-bit mu-law or a-law → decode to 16-bit
      ch0[i] = decodeTable[wavBuffer[frameOffset]];
      ch1[i] = decodeTable[wavBuffer[frameOffset + srcBytesPerSample]];
    } else if (header.bitsPerSample === 16) {
      ch0[i] = wavBuffer.readInt16LE(frameOffset);
      ch1[i] = wavBuffer.readInt16LE(frameOffset + srcBytesPerSample);
    } else if (header.bitsPerSample === 24) {
      ch0[i] = wavBuffer.readIntLE(frameOffset, 3);
      ch1[i] = wavBuffer.readIntLE(frameOffset + srcBytesPerSample, 3);
    } else {
      throw new Error(`Unsupported bit depth: ${header.bitsPerSample}`);
    }
  }

  logger.info({ samplesPerChannel, durationSeconds: durationSeconds.toFixed(1) }, "Channels split");

  const outBits = decodeTable ? 16 : header.bitsPerSample;
  return {
    channel0: buildMonoWav(ch0, header.sampleRate, outBits),
    channel1: buildMonoWav(ch1, header.sampleRate, outBits),
    sampleRate: header.sampleRate,
    bitsPerSample: outBits,
    durationSeconds,
    isMono: false,
  };
}
