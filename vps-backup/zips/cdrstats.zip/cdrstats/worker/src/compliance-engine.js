/**
 * Compliance Rule Engine
 *
 * Rule types:
 *   required_phrase   — must appear (optionally within first N seconds, on a channel)
 *   prohibited_phrase — must NOT appear
 * Match modes: contains (case-insensitive), regex, ai (paraphrase — batched
 * into ONE AI call per call regardless of how many AI rules exist).
 *
 * Results are written onto the call document:
 *   compliance: { score, passed, violations[], rules_evaluated, unevaluated[], evaluated_at }
 *   compliance_score, compliance_passed  (top-level, for indexing/aggregation)
 */

const SEVERITY_WEIGHT = { low: 5, medium: 15, high: 30, critical: 100 };

export async function loadRules(db, system, domain) {
  return db.collection("compliance_rules").find({
    enabled: { $ne: false },
    $or: [
      { system, domain },
      { scope: "global" },
    ],
  }).toArray();
}

function ruleApplies(rule, call) {
  if (rule.direction && rule.direction !== "any") {
    if ((call.call_direction_origin || call.call_direction) !== rule.direction) return false;
  }
  if (rule.queue && call.answering_queue !== rule.queue) return false;
  if (rule.extension && call.answering_extension !== rule.extension) return false;
  return true;
}

function normalizeText(t) {
  return String(t || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Build the searchable text for a rule: JOINED segment text (fixes phrases
 * split across transcription segments), filtered by channel and — for
 * windowed required rules — by segment start time.
 */
function buildSearchText(transcript, rule, applyWindow) {
  let segs = Array.isArray(transcript.segments) ? transcript.segments : [];
  if (rule.channel && rule.channel !== "any") segs = segs.filter(s => s && s.speaker === rule.channel);
  if (applyWindow && rule.window_seconds > 0) segs = segs.filter(s => ((s && s.start) || 0) <= rule.window_seconds);
  if (segs.length > 0) return segs.map(s => (s && s.text) || "").join(" ");
  // Fallback for transcripts without segments
  if (!applyWindow || !(rule.window_seconds > 0)) {
    if (rule.channel === "channel_0") return transcript.channel_0_text || "";
    if (rule.channel === "channel_1") return transcript.channel_1_text || "";
    return transcript.full_text || "";
  }
  return "";
}

function textMatches(haystackRaw, rule) {
  if (rule.match_mode === "regex") {
    try {
      const m = new RegExp(rule.pattern, "i").exec(haystackRaw);
      return m ? { hit: true, index: m.index, length: m[0].length, source: haystackRaw } : { hit: false };
    } catch { return { hit: false }; }
  }
  // contains: punctuation/case-insensitive on normalized text
  const hay = normalizeText(haystackRaw);
  const needle = normalizeText(rule.pattern);
  if (!needle) return { hit: false };
  const idx = hay.indexOf(needle);
  return idx >= 0 ? { hit: true, index: idx, length: needle.length, source: hay } : { hit: false };
}

function evidenceSnippet(m) {
  const start = Math.max(0, m.index - 60);
  return m.source.slice(start, m.index + m.length + 60).trim().slice(0, 200);
}

function evaluateTextRule(rule, transcript) {
  if (rule.type === "required_phrase") {
    const text = buildSearchText(transcript, rule, true);
    const m = textMatches(text, rule);
    if (m.hit) return { passed: true };
    return {
      passed: false,
      evidence: rule.window_seconds > 0
        ? "Required phrase not found within first " + rule.window_seconds + "s"
        : "Required phrase not found in call",
    };
  }

  // prohibited_phrase
  const text = buildSearchText(transcript, rule, false);
  const m = textMatches(text, rule);
  if (m.hit) {
    return { passed: false, evidence: evidenceSnippet(m), at_seconds: offsetToSeconds(transcript, rule, false, m.index) };
  }
  return { passed: true };
}

/**
 * Map a character offset inside the joined search text back to the start time
 * of the segment it falls in. Mirrors buildSearchText's filtering and join so
 * the offsets line up. Returns null when it cannot be resolved.
 */
function offsetToSeconds(transcript, rule, applyWindow, charIndex) {
  if (typeof charIndex !== "number" || charIndex < 0) return null;
  let segs = Array.isArray(transcript.segments) ? transcript.segments : [];
  if (segs.length === 0) return null;
  if (rule.channel && rule.channel !== "any") segs = segs.filter(s => s && s.speaker === rule.channel);
  if (applyWindow && rule.window_seconds > 0) segs = segs.filter(s => ((s && s.start) || 0) <= rule.window_seconds);
  if (segs.length === 0) return null;

  let pos = 0;
  for (const s of segs) {
    const len = ((s && s.text) || "").length;
    if (charIndex <= pos + len) return typeof s.start === "number" ? s.start : null;
    pos += len + 1; // +1 for the join space
  }
  const last = segs[segs.length - 1];
  return last && typeof last.start === "number" ? last.start : null;
}

function buildAIRulesPrompt(aiRules, transcriptText) {
  const ruleList = aiRules.map((r, i) =>
    (i + 1) + '. id="' + r._id + '" type=' + r.type + ' — ' + (r.ai_description || r.pattern || r.name)
  ).join("\n");

  const systemPrompt = `You are a call center compliance auditor. Evaluate the transcript against each rule.
For "required_phrase" rules: passed=true only if the agent/caller clearly communicated the described content (paraphrasing counts).
For "prohibited_phrase" rules: passed=false if the described prohibited content occurs; include a short quote as evidence.
Respond in valid JSON only — no markdown, no backticks. Exact structure:
{"results":[{"id":"<rule id>","passed":true,"evidence":"short quote or reason"}]}

Rules to evaluate:
${ruleList}`;

  return [
    { role: "system", content: systemPrompt },
    { role: "user", content: "Transcript:\n\n" + transcriptText.slice(0, 8000) },
  ];
}

/**
 * Evaluate all applicable rules for one call.
 * aiFn: async (messages, maxTokens) => string, or null if AI unavailable.
 */
export async function evaluateCompliance(db, call, transcript, aiFn, logger) {
  let rules;
  try {
    rules = await loadRules(db, call.system, call.domain);
  } catch (err) {
    logger?.error({ callid: call.callid, err: err.message }, "Failed to load compliance rules");
    return null;
  }

  const applicable = rules.filter(r => ruleApplies(r, call));
  if (applicable.length === 0) return null;

  const violations = [];
  const unevaluated = [];
  const aiRules = [];

  for (const rule of applicable) {
    if (rule.match_mode === "ai") { aiRules.push(rule); continue; }
    const res = evaluateTextRule(rule, transcript);
    if (!res.passed) {
      violations.push({
        rule_id: String(rule._id), name: rule.name, type: rule.type,
        severity: rule.severity || "medium", evidence: res.evidence || null,
        at_seconds: typeof res.at_seconds === "number" ? res.at_seconds : null,
      });
    }
  }

  if (aiRules.length > 0) {
    if (!aiFn) {
      for (const r of aiRules) unevaluated.push({ rule_id: String(r._id), name: r.name, reason: "AI not configured" });
    } else {
      try {
        const raw = await aiFn(buildAIRulesPrompt(aiRules, transcript.full_text || ""), 1000);
        const cleaned = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
        let parsed;
        try {
          parsed = JSON.parse(cleaned);
        } catch {
          const a = cleaned.indexOf("{"), b = cleaned.lastIndexOf("}");
          if (a === -1 || b <= a) throw new Error("No JSON object in AI response");
          parsed = JSON.parse(cleaned.slice(a, b + 1));
        }
        const byId = {};
        for (const r of parsed.results || []) byId[String(r.id)] = r;
        for (const rule of aiRules) {
          const r = byId[String(rule._id)];
          if (!r) { unevaluated.push({ rule_id: String(rule._id), name: rule.name, reason: "No AI verdict" }); continue; }
          if (r.passed === false) {
            violations.push({
              rule_id: String(rule._id), name: rule.name, type: rule.type,
              severity: rule.severity || "medium",
              evidence: (r.evidence || "").slice(0, 200) || null, ai: true,
            });
          }
        }
      } catch (err) {
        logger?.error({ callid: call.callid, err: err.message }, "AI compliance evaluation failed");
        for (const r of aiRules) unevaluated.push({ rule_id: String(r._id), name: r.name, reason: "AI error" });
      }
    }
  }

  if (unevaluated.length > 0) {
    logger?.warn(
      { callid: call.callid, rules: unevaluated.map(u => u.name + " (" + u.reason + ")") },
      "Compliance rules NOT evaluated — check AI provider settings"
    );
  }

  const penalty = violations.reduce((s, v) => s + (SEVERITY_WEIGHT[v.severity] || 15), 0);
  const score = Math.max(0, 100 - penalty);
  const passed = violations.length === 0;

  const compliance = {
    score, passed, violations,
    rules_evaluated: applicable.length,
    unevaluated: unevaluated.length > 0 ? unevaluated : undefined,
    evaluated_at: new Date(),
  };

  try {
    await db.collection("calls").updateOne(
      { callid: call.callid, system: call.system, domain: call.domain },
      { $set: { compliance, compliance_score: score, compliance_passed: passed } }
    );
  } catch (err) {
    logger?.error({ callid: call.callid, err: err.message }, "Failed to store compliance result");
  }

  if (!passed) {
    logger?.info({ callid: call.callid, score, violations: violations.length }, "Compliance violations detected");
  }
  return { score, passed, violations };
}
