/**
 * Vodia CDR Analytics Platform — BullMQ Worker
 * Handles: recording monitoring + auto-transcription
 */

import { Worker } from "bullmq";
import { MongoClient } from "mongodb";
import Redis from "ioredis";
import pino from "pino";
import { splitStereoWav } from "./wav-splitter.js";
import { transcribeWav } from "./transcriber.js";
import { getObjectStream, deleteObject, getCurrentBackend } from "./storage.js";
import { getComplianceSettings, applyRedaction } from "./redactor.js";
import { evaluateCompliance } from "./compliance-engine.js";
import { scoreCallQA } from "./qa-scorer.js";

const logger = pino({ level: process.env.LOG_LEVEL || "info" });
const REDIS_URL = process.env.REDIS_URL || "redis://redis:6379";
const MONGO_URI = process.env.MONGO_URI || "mongodb://mongo:27017/vodia_cdr";

// ── MongoDB ───────────────────────────────────────────
const mongo = new MongoClient(MONGO_URI, {
  maxPoolSize: 5,
  minPoolSize: 1,
  serverSelectionTimeoutMS: 10000,
});
await mongo.connect();
const db = mongo.db();
logger.info("Worker MongoDB connected: %s", db.databaseName);

// Load AI provider config from DB settings
async function getWorkerAIConfig() {
  const crypto = (await import("crypto")).default || await import("crypto");
  const KEY_ENV = process.env.SMTP_ENCRYPTION_KEY || process.env.JWT_SECRET;

  function decrypt(encrypted) {
    try {
      const key = crypto.createHash("sha256").update(KEY_ENV).digest();
      const [ivHex, tagHex, data] = encrypted.split(":");
      if (!ivHex || !tagHex || !data) return null;
      const decipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(ivHex, "hex"));
      decipher.setAuthTag(Buffer.from(tagHex, "hex"));
      let dec = decipher.update(data, "hex", "utf8");
      dec += decipher.final("utf8");
      return dec;
    } catch { return null; }
  }

  // Try new ai_provider key first
  try {
    const doc = await db.collection("settings").findOne({ key: "ai_provider" });
    if (doc?.value) {
      return {
        provider: doc.value.provider || "openai",
        model: doc.value.model || "gpt-4o-mini",
        api_key: doc.value.api_key_encrypted ? decrypt(doc.value.api_key_encrypted) : null,
        endpoint: doc.value.endpoint || "",
      };
    }
  } catch (e) { logger.warn("Failed to load ai_provider from DB: %s", e.message); }

  // Fall back to legacy openai key
  try {
    const doc = await db.collection("settings").findOne({ key: "openai" });
    if (doc?.value?.api_key_encrypted) {
      return {
        provider: "openai",
        model: doc.value.model || "gpt-4o-mini",
        api_key: decrypt(doc.value.api_key_encrypted),
        endpoint: "",
      };
    }
  } catch {}

  // Fall back to env
  const envKey = process.env.OPENAI_API_KEY || "";
  return {
    provider: "openai",
    model: process.env.OPENAI_MODEL || "gpt-4o-mini",
    api_key: (envKey && envKey !== "sk-PASTE-YOUR-KEY-HERE") ? envKey : null,
    endpoint: "",
  };
}

// Worker-side chat completion — matches api/src/services/ai-provider.js logic
async function workerChatCompletion(config, messages, maxTokens = 1500) {
  const { provider, model, api_key, endpoint } = config;

  if (provider === "anthropic") {
    let systemMsg = "";
    const claudeMsgs = [];
    for (const m of messages) {
      if (m.role === "system") systemMsg += (systemMsg ? "\n" : "") + m.content;
      else claudeMsgs.push({ role: m.role, content: m.content });
    }
    const body = { model, max_tokens: maxTokens, messages: claudeMsgs };
    if (systemMsg) body.system = systemMsg;
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": api_key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify(body),
    });
    if (!res.ok) throw new Error(`Anthropic ${res.status}: ${(await res.text()).slice(0, 200)}`);
    const data = await res.json();
    return data.content?.map(b => b.type === "text" ? b.text : "").join("") || "";
  }

  if (provider === "gemini") {
    const contents = [];
    let sysInst = "";
    for (const m of messages) {
      if (m.role === "system") sysInst += (sysInst ? "\n" : "") + m.content;
      else contents.push({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] });
    }
    const body = { contents, generationConfig: { maxOutputTokens: maxTokens, temperature: 0.3 } };
    if (sysInst) body.systemInstruction = { parts: [{ text: sysInst }] };
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${api_key}`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    if (!res.ok) throw new Error(`Gemini ${res.status}: ${(await res.text()).slice(0, 200)}`);
    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.map(p => p.text).join("") || "";
  }

  if (provider === "ollama") {
    const url = `${endpoint.replace(/\/+$/, "")}/api/chat`;
    const res = await fetch(url, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model, messages, stream: false, options: { temperature: 0.3, num_predict: maxTokens } }),
    });
    if (!res.ok) throw new Error(`Ollama ${res.status}: ${(await res.text()).slice(0, 200)}`);
    const data = await res.json();
    return data.message?.content || "";
  }

  // Default: OpenAI (and OpenAI-compatible) -- OPENAI_PARAM_CONTRACT_V1
  const url = endpoint ? `${endpoint.replace(/\/+$/, "")}/v1/chat/completions` : "https://api.openai.com/v1/chat/completions";
  return await openaiChatRequest(url, api_key, model, messages, maxTokens, 0.3, endpoint);
}

// ── MinIO ─────────────────────────────────────────────
// Storage handled by ./storage.js

// ── Redis ─────────────────────────────────────────────
const connection = new Redis(REDIS_URL, {
  maxRetriesPerRequest: null,
});
connection.on("connect", () => logger.info("Worker Redis connected"));
connection.on("error", (err) => logger.error(err, "Worker Redis error"));

// ── Recording Fetch Worker ────────────────────────────
const recordingWorker = new Worker(
  "recording-fetch",
  async (job) => {
    const { system, domain, callid, file, account, extension } = job.data;

    logger.info({ jobId: job.id, system, domain, callid, file }, "Processing recording job");

    const existing = await db.collection("recordings").findOne({
      system, domain, callid, upload_status: "completed",
    });

    if (existing) {
      logger.info({ jobId: job.id, callid, key: existing.storage_key }, "Recording already uploaded — skipping");
      return { status: "already_uploaded", key: existing.storage_key };
    }

    const basename = file.replace(/^.*[/\\]/, "");
    await db.collection("recordings").updateOne(
      { system, domain, callid, original_filename: basename },
      {
        $setOnInsert: {
          system, domain, callid, original_filename: basename, original_path: file,
          account: account || null, extension: extension || null,
          upload_status: "pending", created_at: new Date(),
        },
        $set: { last_checked_at: new Date() },
      },
      { upsert: true }
    );

    logger.info({ jobId: job.id, callid, file: basename }, "Recording pending — waiting for PBX push");
    return { status: "pending", file: basename };
  },
  { connection, concurrency: 5, limiter: { max: 20, duration: 1000 } }
);

recordingWorker.on("completed", (job, result) => {
  logger.info({ jobId: job.id, result }, "Recording job completed");
});
recordingWorker.on("failed", (job, err) => {
  logger.error({ jobId: job?.id, err: err.message }, "Recording job failed");
});

// ── Transcription Worker ──────────────────────────────
const transcriptionWorker = new Worker(
  "transcription",
  async (job) => {
    const { system, domain, callid, recording_id, storage_key } = job.data;

    logger.info({ jobId: job.id, callid, storage_key }, "Starting transcription job");

    // Check if already transcribed
    const existingTranscript = await db.collection("transcripts").findOne({ callid, system, domain });
    if (existingTranscript) {
      logger.info({ callid }, "Already transcribed — skipping");
      return { status: "already_transcribed" };
    }

    // Find ALL completed recordings for this call
    const allRecordings = await db.collection("recordings").find({
      callid, system, domain, upload_status: "completed",
    }).sort({ created_at: 1 }).toArray();

    if (allRecordings.length === 0) {
      // Fallback to the single storage_key from the job
      allRecordings.push({ storage_key, _id: recording_id });
    }

    logger.info({ callid, recordingCount: allRecordings.length }, "Processing recordings for transcription");

    const allSegments = [];
    const channelTexts = [];
    let totalDuration = 0;
    let isMono = true;
    let timeOffset = 0;
    const recordingsMeta = [];
    let segMethod = null;

    for (let recIdx = 0; recIdx < allRecordings.length; recIdx++) {
      const rec = allRecordings[recIdx];
      const recKey = rec.storage_key || storage_key;

      // Download the WAV file from MinIO
      let wavBuffer;
      try {
        const recBackend = rec.storage_backend || "minio";
        const stream = await getObjectStream(db, recKey, recBackend);
        const chunks = [];
        for await (const chunk of stream) { chunks.push(chunk); }
        wavBuffer = Buffer.concat(chunks);
        logger.info({ callid, recording: recIdx + 1, size: wavBuffer.length, key: recKey }, "Downloaded recording from MinIO");
      } catch (err) {
        logger.error({ callid, key: recKey, err: err.message }, "Failed to download recording — skipping");
        continue;
      }

      // Split stereo channels
      let splitResult;
      try {
        splitResult = splitStereoWav(wavBuffer);
      } catch (err) {
        logger.error({ callid, key: recKey, err: err.message }, "Failed to split WAV channels — skipping");
        continue;
      }

      if (!splitResult.isMono) isMono = false;

      // Transcribe each channel
      const ch0Result = await transcribeWav(splitResult.channel0);

      let ch1Result = { text: "", segments: [] };
      if (splitResult.channel1) {
        ch1Result = await transcribeWav(splitResult.channel1);
      }

      // Segmentation quality is only "vad" if every channel managed it
      const thisMethod = ch0Result.method || ch1Result.method || "chunked";
      segMethod = segMethod === null ? thisMethod : (segMethod === "vad" && thisMethod === "vad" ? "vad" : "chunked");

      recordingsMeta.push({
        recording_id: rec._id ? String(rec._id) : null,
        index: recIdx,
        offset_seconds: Math.round(timeOffset * 100) / 100,
        duration_seconds: Math.round(splitResult.durationSeconds * 100) / 100,
      });

      // Persist waveform peaks so the player draws instantly without
      // downloading and decoding the whole file in the browser
      if (rec._id && (ch0Result.peaks || ch1Result.peaks)) {
        try {
          await db.collection("recordings").updateOne(
            { _id: rec._id },
            {
              $set: {
                peaks_ch0: ch0Result.peaks || null,
                peaks_ch1: ch1Result.peaks || null,
                peak_buckets: 1000,
                duration_seconds: Math.round(splitResult.durationSeconds * 100) / 100,
                offset_seconds: Math.round(timeOffset * 100) / 100,
                is_mono: !!splitResult.isMono,
              },
            }
          );
        } catch (pkErr) {
          logger.warn({ callid, err: pkErr.message }, "Failed to store waveform peaks");
        }
      }

      // Add segments with time offset for multi-recording alignment
      const recLabel = allRecordings.length > 1 ? ` (Rec ${recIdx + 1})` : "";

      for (const s of ch0Result.segments) {
        allSegments.push({
          ...s,
          start: s.start + timeOffset,
          end: s.end + timeOffset,
          speaker: "channel_0",
          recording: recIdx,
        });
      }
      for (const s of ch1Result.segments) {
        allSegments.push({
          ...s,
          start: s.start + timeOffset,
          end: s.end + timeOffset,
          speaker: "channel_1",
          recording: recIdx,
        });
      }

      channelTexts.push({
        recording: recIdx,
        channel_0: ch0Result.text,
        channel_1: ch1Result.text,
      });

      timeOffset += splitResult.durationSeconds;
      totalDuration += splitResult.durationSeconds;
    }

    // Sort all segments by time
    allSegments.sort((a, b) => a.start - b.start);

    // Build full text
    const fullText = allSegments
      .map(s => {
        const recLabel = allRecordings.length > 1 ? ` R${s.recording + 1}` : "";
        return `[${s.speaker === "channel_0" ? "Caller 1" : "Caller 2"}${recLabel} ${s.start.toFixed(1)}s] ${s.text}`;
      })
      .join("\n");

    const splitResult = { durationSeconds: totalDuration, isMono };

    // Store transcript
    const transcriptDoc = {
      callid,
      system,
      domain,
      recording_id: recording_id || null,
      recording_count: allRecordings.length,
      recordings_meta: recordingsMeta,
      segmentation: segMethod || "chunked",
      segments: allSegments,
      full_text: fullText,
      channel_0_text: channelTexts.map(c => c.channel_0).filter(Boolean).join(" "),
      channel_1_text: channelTexts.map(c => c.channel_1).filter(Boolean).join(" "),
      model: "whisper-base",
      duration_seconds: Math.round(totalDuration * 100) / 100,
      is_mono: isMono,
      error: null,
      created_at: new Date(),
    };

    // -- PII/PCI Redaction (compliance suite) ----------
    let complianceSettings = null;
    try {
      complianceSettings = await getComplianceSettings(db, system, domain);
      if (complianceSettings?.redaction?.enabled) {
        const redactResult = applyRedaction(transcriptDoc, complianceSettings.redaction);
        if (redactResult.total > 0) {
          logger.info({ callid, counts: redactResult.counts }, "Transcript redacted before storage");
        }
      }
    } catch (redErr) {
      logger.error({ callid, err: redErr.message }, "Redaction failed — transcript stored unredacted");
      transcriptDoc.redaction_error = redErr.message;
    }

    await db.collection("transcripts").updateOne(
      { callid, system, domain },
      { $set: transcriptDoc },
      { upsert: true }
    );

    // Update call document
    await db.collection("calls").updateOne(
      { callid, system, domain },
      { $set: { has_transcript: true, transcript_created_at: new Date() } }
    );

    logger.info({
      callid,
      recordings: allRecordings.length,
      segments: allSegments.length,
      duration: totalDuration.toFixed(1),
      fullTextLength: fullText.length,
    }, "Transcription complete — stored");

    // -- Compliance & QA evaluation (compliance suite) --
    try {
      if (!complianceSettings) complianceSettings = await getComplianceSettings(db, system, domain);
      const cqCall = await db.collection("calls").findOne({ callid, system, domain });
      if (cqCall && transcriptDoc.full_text && transcriptDoc.full_text.length > 10) {
        const cqAiCfg = await getWorkerAIConfig();
        const cqAiAvailable = !!(cqAiCfg.api_key || cqAiCfg.provider === "ollama");
        const cqAiFn = cqAiAvailable ? (msgs, maxTok) => workerChatCompletion(cqAiCfg, msgs, maxTok) : null;

        await evaluateCompliance(db, cqCall, transcriptDoc, cqAiFn, logger);

        const samplingPct = complianceSettings?.qa?.sampling_pct ?? 0;
        if (cqAiFn && samplingPct > 0 && Math.random() * 100 < samplingPct) {
          await scoreCallQA(db, cqCall, transcriptDoc, complianceSettings?.qa, cqAiFn, logger);
        }
      }
    } catch (cqErr) {
      logger.error({ callid, err: cqErr.message }, "Compliance/QA evaluation failed");
    }

    // Auto-summarize if tenant has it enabled
    try {
      const tenant = await db.collection("tenants").findOne({ system, domain });
      const globalAutoSummarize = process.env.AI_AUTO_SUMMARIZE === "true";

      if ((tenant?.ai_auto_summarize || globalAutoSummarize) && fullText.length > 10) {
        const aiConfig = await getWorkerAIConfig();

        if (aiConfig.api_key || aiConfig.provider === "ollama") {
          logger.info({ callid, domain, provider: aiConfig.provider }, "Auto-summarizing via %s", aiConfig.provider);

          const call = await db.collection("calls").findOne({ callid, system, domain });
          const callContext = [
            call?.call_direction ? "Direction: " + call.call_direction : null,
            call?.duration_seconds ? "Duration: " + Math.round(call.duration_seconds) + "s" : null,
            call?.answering_queue_name ? "Queue: " + call.answering_queue_name : null,
            call?.answering_extension_name ? "Agent: " + call.answering_extension_name : null,
            call?.is_answered ? "Status: Answered" : call?.is_abandoned ? "Status: Abandoned" : "Status: Missed",
          ].filter(Boolean).join(", ");

          const systemPrompt = 'You are an expert call center analyst. Analyze the following phone call transcript and provide a structured analysis. The call metadata: ' + callContext + '. The transcript has two channels: Channel 0 (Ch0): One party, Channel 1 (Ch1): The other party. Respond in valid JSON only — no markdown, no backticks, no preamble. Use this exact structure: {"summary":"2-3 sentence summary","sentiment":{"overall":"positive|neutral|negative","confidence":0.0-1.0,"caller_mood":"brief","agent_performance":"brief"},"topics":["topic1"],"action_items":["action1"],"resolution":"resolved|unresolved|transferred|callback_needed|unknown","key_phrases":["phrase1"]}';

          try {
            const raw = await workerChatCompletion(aiConfig, [
              { role: "system", content: systemPrompt },
              { role: "user", content: "Here is the call transcript:\n\n" + fullText.slice(0, 8000) },
            ], 1500);

            const cleaned = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
            const analysis = JSON.parse(cleaned);

            await db.collection("transcripts").updateOne(
              { callid, system, domain },
              { $set: { summary: { ...analysis, model: aiConfig.model, generated_at: new Date() } } }
            );

            await db.collection("calls").updateOne(
              { callid, system, domain },
              { $set: { has_summary: true, sentiment: analysis.sentiment?.overall || null, summary_generated_at: new Date() } }
            );

            logger.info({ callid, provider: aiConfig.provider, sentiment: analysis.sentiment?.overall }, "Auto-summary complete");
          } catch (aiErr) {
            logger.error({ callid, provider: aiConfig.provider, err: aiErr.message }, "Auto-summarize API call failed");
          }
        } else {
          logger.info({ callid }, "Auto-summarize enabled but no AI API key configured");
        }
      }
    } catch (sumErr) {
      logger.error(sumErr, "Auto-summarize error (non-fatal)");
    }

    return {
      status: "transcribed",
      recordings: allRecordings.length,
      segments: allSegments.length,
      fullTextLength: fullText.length,
    };
  },
  {
    connection,
    concurrency: parseInt(process.env.TRANSCRIPTION_CONCURRENCY || '1'),
    lockDuration: 600000, // 10 minutes — long calls need time
    lockRenewTime: 60000, // Renew lock every 60s
  }
);

transcriptionWorker.on("completed", (job, result) => {
  logger.info({ jobId: job.id, result }, "Transcription job completed");
});
transcriptionWorker.on("failed", (job, err) => {
  logger.error({ jobId: job?.id, err: err.message }, "Transcription job failed");
});

// ── Stale Upload Sweep ────────────────────────────────
const SWEEP_INTERVAL = 5 * 60 * 1000;
const UPLOAD_TIMEOUT = 10 * 60 * 1000;

async function sweepStaleUploads() {
  try {
    const cutoff = new Date(Date.now() - UPLOAD_TIMEOUT);
    const result = await db.collection("recordings").updateMany(
      { upload_status: "pending", created_at: { $lt: cutoff } },
      { $set: { upload_status: "timeout", timed_out_at: new Date() } }
    );
    if (result.modifiedCount > 0) {
      logger.warn({ count: result.modifiedCount }, "Marked stale recordings as timed out");
    }
  } catch (err) {
    logger.error(err, "Stale upload sweep failed");
  }
}

const sweepTimer = setInterval(sweepStaleUploads, SWEEP_INTERVAL);

// -- Compliance Backfill / Manual QA Worker -----------
const complianceWorker = new Worker(
  "compliance-eval",
  async (job) => {
    const { system, domain, callid, force_qa } = job.data;
    const callDoc = await db.collection("calls").findOne({ callid, system, domain });
    if (!callDoc) return { status: "call_not_found" };
    const transcriptDoc = await db.collection("transcripts").findOne({ callid, system, domain });
    if (!transcriptDoc || !transcriptDoc.full_text) return { status: "no_transcript" };

    const settings = await getComplianceSettings(db, system, domain);
    const aiCfg = await getWorkerAIConfig();
    const aiAvailable = !!(aiCfg.api_key || aiCfg.provider === "ollama");
    const aiFn = aiAvailable ? (msgs, maxTok) => workerChatCompletion(aiCfg, msgs, maxTok) : null;

    const result = await evaluateCompliance(db, callDoc, transcriptDoc, aiFn, logger);
    let qa = null;
    if (force_qa && aiFn) {
      qa = await scoreCallQA(db, callDoc, transcriptDoc, settings?.qa, aiFn, logger);
    }
    return { status: "evaluated", score: result?.score ?? null, qa_score: qa?.score ?? null };
  },
  { connection, concurrency: 2, limiter: { max: 5, duration: 1000 } }
);
complianceWorker.on("failed", (job, err) => {
  logger.error({ jobId: job?.id, err: err.message }, "Compliance job failed");
});

logger.info("BullMQ worker started (recording-fetch + transcription + compliance-eval)");

// ── Daily Retention Sweep ─────────────────────────────
async function retentionSweep() {
  try {
    const tenants = await db.collection("tenants")
      .find({ data_retention_days: { $gt: 0 } }).toArray();

    if (tenants.length === 0) return;

    for (const tenant of tenants) {
      const cutoffEpoch = (Date.now() - tenant.data_retention_days * 24 * 60 * 60 * 1000) / 1000;

      const filter = {
        system: tenant.system,
        domain: tenant.domain,
        start: { $lt: cutoffEpoch },
      };

      const expiredCalls = await db.collection("calls").find(
        filter, { projection: { callid: 1, recording_keys: 1 } }
      ).toArray();

      if (expiredCalls.length === 0) continue;

      const callids = expiredCalls.map(c => c.callid);
      const recordingKeys = expiredCalls.flatMap(c => c.recording_keys || []);

      // Delete recordings (backend-aware)
      if (recordingKeys.length > 0) {
        const recs = await db.collection("recordings").find(
          { callid: { $in: callids } },
          { projection: { storage_key: 1, storage_backend: 1 } }
        ).toArray();
        const recMap = {};
        for (const r of recs) { if (r.storage_key) recMap[r.storage_key] = r.storage_backend || "minio"; }
        for (const key of recordingKeys) {
          try { await deleteObject(db, key, recMap[key] || "minio"); } catch { }
        }
      }

      await db.collection("recordings").deleteMany({ callid: { $in: callids } });
      await db.collection("transcripts").deleteMany({ callid: { $in: callids } });
      const result = await db.collection("calls").deleteMany(filter);

      logger.info({
        tenant: tenant.domain,
        retention_days: tenant.data_retention_days,
        deleted: result.deletedCount,
      }, "Retention sweep completed");
    }
  } catch (err) {
    logger.error(err, "Retention sweep failed");
  }
}

// Run retention sweep every 24 hours
const retentionTimer = setInterval(retentionSweep, 24 * 60 * 60 * 1000);
// Also run once on startup (with 60s delay)
setTimeout(retentionSweep, 60 * 1000);

// ── Graceful Shutdown ─────────────────────────────────
async function shutdown(signal) {
  logger.info("Received %s — shutting down worker", signal);
  clearInterval(sweepTimer);
  clearInterval(retentionTimer);
  await recordingWorker.close();
  await transcriptionWorker.close();
  await connection.quit();
  await mongo.close();
  process.exit(0);
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));


/* ── OPENAI_PARAM_CONTRACT_V1 (worker copy) ────────────────────
 * Mirrors api/src/services/ai-provider.js. The gpt-5.x / o-series models
 * replaced `max_tokens` with `max_completion_tokens` and reject a
 * non-default `temperature`; OpenAI-compatible servers still want the
 * legacy shape. Negotiate per parameter, memoise per endpoint+model.
 *
 * Declared at module scope, so hoisting makes the position in the file
 * irrelevant -- these are initialised during module evaluation, long
 * before any queue job runs.
 * ───────────────────────────────────────────────────────────── */

const OPENAI_MODERN_MODEL_RE = /^(?:gpt-5|gpt-6|o[1-9])/i;
const openaiParamShapeCache = new Map();

function openaiDefaultShape(model, customEndpoint) {
  const modern = !customEndpoint && OPENAI_MODERN_MODEL_RE.test(String(model || ""));
  return modern
    ? { tokenParam: "max_completion_tokens", sendTemperature: false }
    : { tokenParam: "max_tokens", sendTemperature: true };
}

function openaiBuildBody(model, messages, maxTokens, temperature, shape) {
  const body = { model, messages };
  body[shape.tokenParam] = maxTokens;
  if (shape.sendTemperature) body.temperature = temperature;
  return body;
}

function openaiAdaptShape(shape, status, errBody) {
  if (status !== 400) return null;
  const t = String(errBody || "");
  if (!/unsupported_parameter|unsupported_value|unknown_parameter|is not supported with this model|does not support/i.test(t)) {
    return null;
  }

  const next = { tokenParam: shape.tokenParam, sendTemperature: shape.sendTemperature };
  let changed = false;

  if (shape.tokenParam === "max_tokens" && /max_tokens/.test(t)) {
    next.tokenParam = "max_completion_tokens";
    changed = true;
  } else if (shape.tokenParam === "max_completion_tokens" && /max_completion_tokens/.test(t)) {
    next.tokenParam = "max_tokens";
    changed = true;
  }

  if (shape.sendTemperature && /temperature/.test(t)) {
    next.sendTemperature = false;
    changed = true;
  }

  return changed ? next : null;
}

async function openaiChatRequest(url, apiKey, model, messages, maxTokens, temperature, customEndpoint) {
  const cacheKey = `${customEndpoint || "openai"}::${model}`;
  let shape = openaiParamShapeCache.get(cacheKey) || openaiDefaultShape(model, customEndpoint);

  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + apiKey },
      body: JSON.stringify(openaiBuildBody(model, messages, maxTokens, temperature, shape)),
    });

    if (!res.ok) {
      const errBody = await res.text();
      const next = openaiAdaptShape(shape, res.status, errBody);
      if (next && attempt < 2) {
        shape = next;
        continue;
      }
      throw new Error(`OpenAI ${res.status}: ${errBody.slice(0, 200)}`);
    }

    openaiParamShapeCache.set(cacheKey, shape);

    const data = await res.json();
    const choice = data.choices?.[0];
    const content = choice?.message?.content || "";

    if (!content && choice?.finish_reason === "length") {
      throw new Error(
        `OpenAI returned no content: the ${shape.tokenParam} budget (${maxTokens}) was consumed by reasoning before any output was produced.`
      );
    }

    return content;
  }

  throw new Error("OpenAI: could not negotiate a supported request format");
}
/* ── end OPENAI_PARAM_CONTRACT_V1 (worker copy) ─────────────── */
