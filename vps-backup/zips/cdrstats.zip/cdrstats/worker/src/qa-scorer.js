/**
 * AI Agent QA Scorecard
 *
 * Evaluates a transcript against a weighted rubric (per-tenant, editable).
 * Results stored on the call doc: qa {...} + qa_score (top-level for indexing).
 */

export const DEFAULT_RUBRIC = [
  { key: "greeting", label: "Greeting & Introduction", weight: 15 },
  { key: "listening", label: "Listening & Empathy", weight: 20 },
  { key: "professionalism", label: "Professionalism & Tone", weight: 15 },
  { key: "knowledge", label: "Knowledge & Accuracy", weight: 15 },
  { key: "resolution", label: "Resolution Effectiveness", weight: 25 },
  { key: "closing", label: "Call Closing", weight: 10 },
];

function buildQAPrompt(rubric, callContext, transcriptText) {
  const rubricList = rubric.map(r => '- "' + r.key + '": ' + r.label + ' (weight ' + r.weight + ')').join("\n");
  const keysJson = rubric.map(r => '"' + r.key + '": {"score": 0-100, "comment": "one sentence"}').join(", ");

  const systemPrompt = `You are a senior call center QA supervisor. Score the agent's performance on this call against the rubric below. Be fair but rigorous; 70 is competent, 90+ is exceptional. If a category is not applicable to this call, score it null.

Call metadata: ${callContext}
The transcript has two channels (Ch0/Ch1); infer which is the agent from context.

Rubric:
${rubricList}

Respond in valid JSON only — no markdown, no backticks, no preamble. Exact structure:
{"categories": {${keysJson}}, "strengths": ["..."], "coaching_tip": "one specific, actionable coaching suggestion", "overall_comment": "1-2 sentences"}`;

  return [
    { role: "system", content: systemPrompt },
    { role: "user", content: "Transcript:\n\n" + transcriptText.slice(0, 8000) },
  ];
}

/**
 * Score one call. aiFn: async (messages, maxTokens) => string.
 * qaCfg: { rubric: [...] } (falls back to DEFAULT_RUBRIC).
 */
export async function scoreCallQA(db, call, transcript, qaCfg, aiFn, logger) {
  if (!aiFn || !transcript?.full_text || transcript.full_text.length < 20) return null;

  const rubric = (qaCfg?.rubric && qaCfg.rubric.length > 0) ? qaCfg.rubric : DEFAULT_RUBRIC;

  const callContext = [
    call.call_direction_origin ? "Direction: " + call.call_direction_origin : null,
    call.duration_seconds ? "Duration: " + Math.round(call.duration_seconds) + "s" : null,
    call.answering_queue_name ? "Queue: " + call.answering_queue_name : null,
    call.answering_extension_name ? "Agent: " + call.answering_extension_name : null,
  ].filter(Boolean).join(", ");

  let analysis;
  try {
    const raw = await aiFn(buildQAPrompt(rubric, callContext, transcript.full_text), 1200);
    const cleaned = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
    analysis = JSON.parse(cleaned);
  } catch (err) {
    logger?.error({ callid: call.callid, err: err.message }, "QA scoring failed");
    return null;
  }

  // Weighted overall from scored categories only
  let weighted = 0, totalWeight = 0;
  const categories = {};
  for (const r of rubric) {
    const c = analysis.categories?.[r.key];
    const score = (c && typeof c.score === "number") ? Math.max(0, Math.min(100, c.score)) : null;
    categories[r.key] = { label: r.label, weight: r.weight, score, comment: c?.comment || null };
    if (score != null) { weighted += score * r.weight; totalWeight += r.weight; }
  }
  const overall = totalWeight > 0 ? Math.round(weighted / totalWeight) : null;
  if (overall == null) return null;

  const qa = {
    score: overall,
    categories,
    strengths: Array.isArray(analysis.strengths) ? analysis.strengths.slice(0, 5) : [],
    coaching_tip: analysis.coaching_tip || null,
    overall_comment: analysis.overall_comment || null,
    evaluated_at: new Date(),
  };

  try {
    await db.collection("calls").updateOne(
      { callid: call.callid, system: call.system, domain: call.domain },
      { $set: { qa, qa_score: overall } }
    );
    logger?.info({ callid: call.callid, qa_score: overall }, "QA scorecard stored");
  } catch (err) {
    logger?.error({ callid: call.callid, err: err.message }, "Failed to store QA result");
  }
  return qa;
}
