/**
 * PII/PCI Redaction v2 + Compliance Settings Loader
 *
 * Pure regex — zero AI cost. Runs BEFORE transcript storage so card numbers
 * never reach MongoDB. Redaction is destructive by design.
 *
 * v3: adds per-tenant strict digit redaction (any run of N+ digits,
 * regardless of Luhn) for speech-to-text-mangled card numbers.
 *
 * v2: cards read in CHUNKS across transcription segments are detected on the
 * joined per-channel text (Luhn-validated) and redacted in the segments and
 * in full_text / channel texts.
 */

export const DEFAULT_COMPLIANCE_SETTINGS = {
  redaction: {
    enabled: false,
    categories: { card: true, cvv: true, ssn: false, email: false, dob: false },
    strict_digits: 0,
  },
  qa: {
    sampling_pct: 20,
    rubric: [],
  },
};

export async function getComplianceSettings(db, system, domain) {
  const merged = JSON.parse(JSON.stringify(DEFAULT_COMPLIANCE_SETTINGS));
  try {
    const globalDoc = await db.collection("compliance_settings").findOne({ system: null, domain: null });
    const tenantDoc = await db.collection("compliance_settings").findOne({ system, domain });
    for (const doc of [globalDoc, tenantDoc]) {
      if (!doc) continue;
      if (doc.redaction) {
        if (doc.redaction.enabled != null) merged.redaction.enabled = !!doc.redaction.enabled;
        if (doc.redaction.categories) Object.assign(merged.redaction.categories, doc.redaction.categories);
        if (doc.redaction.strict_digits != null) merged.redaction.strict_digits = Math.max(0, Math.min(30, parseInt(doc.redaction.strict_digits) || 0));
      }
      if (doc.qa) {
        if (doc.qa.sampling_pct != null) merged.qa.sampling_pct = Math.max(0, Math.min(100, Number(doc.qa.sampling_pct) || 0));
        if (Array.isArray(doc.qa.rubric) && doc.qa.rubric.length > 0) merged.qa.rubric = doc.qa.rubric;
      }
    }
  } catch { /* defaults */ }
  return merged;
}

// -- Detectors ------------------------------------------------

function luhnValid(digits) {
  let sum = 0, dbl = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = digits.charCodeAt(i) - 48;
    if (d < 0 || d > 9) return false;
    if (dbl) { d *= 2; if (d > 9) d -= 9; }
    sum += d; dbl = !dbl;
  }
  return sum % 10 === 0;
}

const CARD_RE = /\b(?:\d[\s\-]?){12,18}\d\b/g;
const CVV_RE = /\b(?:cvv|cvc|cv2|card code|security code|verification code)\b.{0,12}?\b\d{3,4}\b/gi;
const SSN_RE = /\b\d{3}[\- ]\d{2}[\- ]\d{4}\b/g;
const EMAIL_RE = /\b[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}\b/g;
const DOB_RE = /\b(?:date of birth|d\.?o\.?b\.?|born(?: on)?)\b\W{0,15}(?:\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{2,4})/gi;

function strictDigitRe(minDigits) {
  // any run of >= minDigits digits, optionally separated by spaces/dashes
  return new RegExp("\\b(?:\\d[\\s\\-]?){" + (minDigits - 1) + ",29}\\d\\b", "g");
}

export function redactString(text, categories = {}, strictDigits = 0) {
  const counts = { card: 0, cvv: 0, ssn: 0, email: 0, dob: 0 };
  if (!text || typeof text !== "string") return { text, counts };
  let out = text;

  if (categories.card) {
    out = out.replace(CARD_RE, (m) => {
      const digits = m.replace(/\D/g, "");
      if (digits.length >= 13 && digits.length <= 19 && luhnValid(digits)) {
        counts.card++;
        return "[CARD REDACTED]";
      }
      return m;
    });
  }
  if (strictDigits > 0) {
    out = out.replace(strictDigitRe(strictDigits), (m) => {
      const digits = m.replace(/\D/g, "");
      if (digits.length >= strictDigits) { counts.card++; return "[CARD REDACTED]"; }
      return m;
    });
  }
  if (categories.cvv) {
    out = out.replace(CVV_RE, () => { counts.cvv++; return "[CVV REDACTED]"; });
  }
  if (categories.ssn) {
    out = out.replace(SSN_RE, () => { counts.ssn++; return "[SSN REDACTED]"; });
  }
  if (categories.email) {
    out = out.replace(EMAIL_RE, () => { counts.email++; return "[EMAIL REDACTED]"; });
  }
  if (categories.dob) {
    out = out.replace(DOB_RE, () => { counts.dob++; return "[DOB REDACTED]"; });
  }
  return { text: out, counts };
}

// -- Cross-segment card detection -----------------------------

function findCardMatch(text, strictDigits = 0) {
  CARD_RE.lastIndex = 0;
  let m;
  while ((m = CARD_RE.exec(text)) !== null) {
    const digits = m[0].replace(/\D/g, "");
    if (digits.length >= 13 && digits.length <= 19 && luhnValid(digits)) {
      return { index: m.index, length: m[0].length };
    }
  }
  if (strictDigits > 0) {
    const re = strictDigitRe(strictDigits);
    while ((m = re.exec(text)) !== null) {
      const digits = m[0].replace(/\D/g, "");
      if (digits.length >= strictDigits) return { index: m.index, length: m[0].length };
    }
  }
  return null;
}

function collapseTokens(t) {
  return String(t)
    .replace(/\[CARD REDACTED\](?:[\s,.\-]*\[CARD REDACTED\])+/g, "[CARD REDACTED]")
    .replace(/[ \t]{2,}/g, " ");
}

/**
 * Detect Luhn-valid card numbers split across consecutive segments of the
 * same channel; redact the affected portions of each segment and return the
 * literal digit-chunk substrings so callers can scrub them from other text
 * fields (full_text has speaker labels interleaved, so chunk replacement is
 * the only reliable way to keep it consistent).
 */
function redactCardsAcrossSegments(transcriptDoc, strictDigits = 0) {
  const segments = Array.isArray(transcriptDoc.segments) ? transcriptDoc.segments : [];
  if (segments.length === 0) return { count: 0, chunks: [] };

  const bySpeaker = {};
  segments.forEach((seg, i) => {
    const sp = (seg && seg.speaker) || "channel_0";
    (bySpeaker[sp] = bySpeaker[sp] || []).push(i);
  });

  let count = 0;
  const chunks = [];

  for (const sp of Object.keys(bySpeaker)) {
    const idxs = bySpeaker[sp];
    let guard = 0;
    while (guard++ < 10) {
      const texts = idxs.map(i => (segments[i] && segments[i].text) || "");
      const offsets = [];
      let pos = 0;
      for (const t of texts) { offsets.push(pos); pos += t.length + 1; } // +1 join space
      const joined = texts.join(" ");
      const match = findCardMatch(joined, strictDigits);
      if (!match) break;

      const mStart = match.index, mEnd = match.index + match.length;
      for (let j = 0; j < idxs.length; j++) {
        const segStart = offsets[j];
        const segEnd = segStart + texts[j].length;
        const ovStart = Math.max(mStart, segStart);
        const ovEnd = Math.min(mEnd, segEnd);
        if (ovEnd <= ovStart) continue;

        const localStart = ovStart - segStart;
        const localEnd = ovEnd - segStart;
        const piece = texts[j].slice(localStart, localEnd).trim();
        if (piece.replace(/[\s\-]/g, "").length >= 3) chunks.push(piece);

        segments[idxs[j]].text = collapseTokens(
          texts[j].slice(0, localStart) + "[CARD REDACTED]" + texts[j].slice(localEnd)
        ).trim();
      }
      count++;
    }
  }
  return { count, chunks };
}

/**
 * Redact a transcript document in place. Returns { total, counts }.
 */
export function applyRedaction(transcriptDoc, redactionCfg = {}) {
  const cats = redactionCfg.categories || {};
  const strictDigits = Math.max(0, Math.min(30, parseInt(redactionCfg.strict_digits) || 0));
  const totals = { card: 0, cvv: 0, ssn: 0, email: 0, dob: 0 };
  const add = (c) => { for (const k of Object.keys(totals)) totals[k] += c[k] || 0; };

  // Pass 1: per-field / per-segment (handles everything within one segment)
  for (const field of ["full_text", "channel_0_text", "channel_1_text"]) {
    if (transcriptDoc[field]) {
      const r = redactString(transcriptDoc[field], cats, strictDigits);
      transcriptDoc[field] = r.text;
      if (field === "full_text") add(r.counts); // count once — segments mirror full_text
    }
  }
  if (Array.isArray(transcriptDoc.segments)) {
    for (const seg of transcriptDoc.segments) {
      if (seg && seg.text) {
        const r = redactString(seg.text, cats, strictDigits);
        seg.text = r.text;
      }
    }
  }

  // Pass 2: cards split across segments (chunked read-outs)
  if (cats.card || strictDigits > 0) {
    const cross = redactCardsAcrossSegments(transcriptDoc, strictDigits);
    if (cross.count > 0) {
      totals.card += cross.count;
      for (const chunk of cross.chunks) {
        if (!chunk) continue;
        for (const field of ["full_text", "channel_0_text", "channel_1_text"]) {
          if (transcriptDoc[field] && transcriptDoc[field].includes(chunk)) {
            transcriptDoc[field] = transcriptDoc[field].split(chunk).join("[CARD REDACTED]");
          }
        }
      }
      for (const field of ["full_text", "channel_0_text", "channel_1_text"]) {
        if (transcriptDoc[field]) transcriptDoc[field] = collapseTokens(transcriptDoc[field]);
      }
    }
  }

  const total = Object.values(totals).reduce((a, b) => a + b, 0);
  if (total > 0) {
    transcriptDoc.redacted = true;
    transcriptDoc.redaction_counts = totals;
    transcriptDoc.redacted_at = new Date();
  }
  return { total, counts: totals };
}
