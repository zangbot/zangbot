/**
 * Transcription Service — sherpa-onnx whisper
 * With chunked processing, silence detection, and hallucination filtering
 */
import pino from "pino";

const logger = pino({ level: process.env.LOG_LEVEL || "info" });
const MODEL_DIR = process.env.WHISPER_MODEL_DIR || "/models/whisper-base";

// Whisper processes 30s chunks; use 28s with 2s overlap for continuity
const CHUNK_SECONDS = 28;
const OVERLAP_SECONDS = 2;
const SAMPLE_RATE = 16000;
const CHUNK_SAMPLES = CHUNK_SECONDS * SAMPLE_RATE;
const OVERLAP_SAMPLES = OVERLAP_SECONDS * SAMPLE_RATE;

// Silero VAD — utterance-level segmentation (falls back to fixed chunking)
const VAD_MODEL = process.env.SILERO_VAD_MODEL || "/models/vad/silero_vad.onnx";
const VAD_WINDOW = 512;
const PEAK_BUCKETS = 1000;

let sherpa = null;
let recognizer = null;
let vadUnavailable = false;

async function getRecognizer() {
  if (recognizer) return recognizer;

  try {
    sherpa = (await import("sherpa-onnx-node")).default;
  } catch (err) {
    logger.error(err, "Failed to import sherpa-onnx-node");
    return null;
  }

  try {
    recognizer = new sherpa.OfflineRecognizer({
      modelConfig: {
        whisper: {
          encoder: `${MODEL_DIR}/base-encoder.int8.onnx`,
          decoder: `${MODEL_DIR}/base-decoder.int8.onnx`,
        },
        tokens: `${MODEL_DIR}/base-tokens.txt`,
        numThreads: parseInt(process.env.WHISPER_NUM_THREADS || "2", 10),
        provider: "cpu",
      },
    });
    logger.info("sherpa-onnx recognizer created");
    return recognizer;
  } catch (err) {
    logger.error(err, "Failed to create recognizer");
    return null;
  }
}

function calculateRMS(samples) {
  if (!samples || samples.length === 0) return 0;
  let sum = 0;
  for (let i = 0; i < samples.length; i++) {
    sum += samples[i] * samples[i];
  }
  return Math.sqrt(sum / samples.length);
}

function isHallucination(text) {
  if (!text || text.length < 5) return false;
  const trimmed = text.trim().toLowerCase();

  const knownHallucinations = [
    "thank you for watching", "thanks for watching", "please subscribe",
    "like and subscribe", "thank you for listening", "you",
  ];
  for (const phrase of knownHallucinations) {
    if (trimmed === phrase || trimmed.startsWith(phrase + ".") || trimmed.startsWith(phrase + "!")) return true;
  }

  for (let len = 2; len <= Math.min(15, Math.floor(trimmed.length / 4)); len++) {
    const pattern = trimmed.slice(0, len);
    let count = 0, pos = 0;
    while (pos <= trimmed.length - len) {
      if (trimmed.slice(pos, pos + len) === pattern) { count++; pos += len; } else { pos++; }
    }
    if (count >= 4 && (count * len) > trimmed.length * 0.5) return true;
  }

  const chars = {};
  for (const c of trimmed.replace(/\s/g, "")) chars[c] = (chars[c] || 0) + 1;
  const totalChars = trimmed.replace(/\s/g, "").length;
  const maxCharCount = Math.max(...Object.values(chars));
  if (totalChars > 10 && maxCharCount / totalChars > 0.4) return true;

  if (/x\s*\d/.test(trimmed)) {
    const xCount = (trimmed.match(/x\s*\d/g) || []).length;
    if (xCount >= 4) return true;
  }

  return false;
}

export function wavToFloat32Samples(wavBuffer) {
  const numChannels = wavBuffer.readUInt16LE(22);
  const sampleRate = wavBuffer.readUInt32LE(24);
  const bitsPerSample = wavBuffer.readUInt16LE(34);
  const bytesPerSample = bitsPerSample / 8;

  let dataOffset = 12;
  while (dataOffset < wavBuffer.length - 8) {
    const chunkId = wavBuffer.toString("ascii", dataOffset, dataOffset + 4);
    const chunkSize = wavBuffer.readUInt32LE(dataOffset + 4);
    if (chunkId === "data") { dataOffset += 8; break; }
    dataOffset += 8 + chunkSize;
    if (chunkSize % 2 !== 0) dataOffset++;
  }

  const dataSize = wavBuffer.readUInt32LE(dataOffset - 4);
  const numSamples = Math.floor(dataSize / bytesPerSample);
  const samples = new Float32Array(numSamples);
  const maxVal = bitsPerSample === 16 ? 32768 : 8388608;

  for (let i = 0; i < numSamples; i++) {
    const offset = dataOffset + i * bytesPerSample;
    if (bitsPerSample === 16) {
      samples[i] = wavBuffer.readInt16LE(offset) / maxVal;
    } else if (bitsPerSample === 24) {
      samples[i] = wavBuffer.readIntLE(offset, 3) / maxVal;
    }
  }

  if (sampleRate !== 16000) {
    const ratio = sampleRate / 16000;
    const newLen = Math.floor(numSamples / ratio);
    const resampled = new Float32Array(newLen);
    for (let i = 0; i < newLen; i++) {
      const srcIdx = Math.floor(i * ratio);
      resampled[i] = samples[Math.min(srcIdx, numSamples - 1)];
    }
    logger.info({ from: sampleRate, to: 16000, origSamples: numSamples, newSamples: newLen }, "Resampled audio");
    return resampled;
  }

  return samples;
}

/**
 * Transcribe a single chunk of audio (max 30s).
 */
function transcribeChunk(rec, samples) {
  const stream = rec.createStream();
  stream.acceptWaveform({ sampleRate: SAMPLE_RATE, samples });
  rec.decode(stream);
  const result = rec.getResult(stream);
  return (result.text || "").trim();
}

/**
 * Transcribe a mono WAV buffer using chunked processing.
 * Splits audio into 28s chunks with 2s overlap for continuity.
 * Returns { text, segments: [{ start, end, text }] }
 */
/**
 * Downsample a channel to PEAK_BUCKETS absolute-max values, normalised to
 * 0-255 and returned base64. Reuses samples already decoded for transcription,
 * so the cost is one extra pass over the array.
 */
export function computePeaks(samples, buckets = PEAK_BUCKETS) {
  if (!samples || samples.length === 0) return null;
  const n = Math.min(buckets, Math.max(1, samples.length));
  const width = samples.length / n;
  const tmp = new Float32Array(n);
  let peak = 0;
  for (let i = 0; i < n; i++) {
    const s = Math.floor(i * width);
    const e = Math.min(samples.length, Math.floor((i + 1) * width));
    let mx = 0;
    for (let j = s; j < e; j++) {
      const v = samples[j] < 0 ? -samples[j] : samples[j];
      if (v > mx) mx = v;
    }
    tmp[i] = mx;
    if (mx > peak) peak = mx;
  }
  const out = new Uint8Array(n);
  const scale = peak > 0 ? 255 / peak : 0;
  for (let i = 0; i < n; i++) out[i] = Math.round(tmp[i] * scale);
  return Buffer.from(out).toString("base64");
}

/**
 * Construct a silero VAD. Returns null (and latches vadUnavailable) if the
 * installed sherpa-onnx-node build or the model file cannot provide one, so a
 * missing model never breaks transcription.
 */
function createVad() {
  if (vadUnavailable || !sherpa) return null;
  try {
    return new sherpa.Vad(
      {
        sileroVad: {
          model: VAD_MODEL,
          threshold: 0.5,
          minSilenceDuration: 0.35,
          minSpeechDuration: 0.2,
          maxSpeechDuration: 25,
          windowSize: VAD_WINDOW,
        },
        sampleRate: SAMPLE_RATE,
        numThreads: 1,
        debug: false,
      },
      60
    );
  } catch (err) {
    vadUnavailable = true;
    logger.warn({ err: err.message, model: VAD_MODEL }, "Silero VAD unavailable — using fixed chunking");
    return null;
  }
}

/** Returns [{ startSample, samples }] or null if VAD is not usable. */
function segmentByVad(samples) {
  const vad = createVad();
  if (!vad) return null;
  const segs = [];
  const drain = () => {
    while (!vad.isEmpty()) {
      const s = vad.front();
      if (s && s.samples && s.samples.length > 0) {
        segs.push({ startSample: s.start || 0, samples: s.samples });
      }
      vad.pop();
    }
  };
  try {
    // sherpa's Vad.acceptWaveform takes the Float32Array itself (unlike
    // OfflineStream.acceptWaveform, which takes { sampleRate, samples }).
    // slice() rather than subarray() so the addon gets a zero-offset buffer.
    for (let off = 0; off + VAD_WINDOW <= samples.length; off += VAD_WINDOW) {
      vad.acceptWaveform(samples.slice(off, off + VAD_WINDOW));
      drain();
    }
    if (typeof vad.flush === "function") vad.flush();
    drain();
  } catch (err) {
    vadUnavailable = true;
    logger.warn({ err: err.message }, "VAD segmentation failed — using fixed chunking");
    return null;
  }
  return segs;
}

/**
 * Transcribe a mono WAV. Tries VAD segmentation first for utterance-level
 * timings; falls back to the original fixed-window chunker on any problem.
 * Returns { text, segments, peaks, method }.
 */
export async function transcribeWav(monoWavBuffer) {
  const rec = await getRecognizer();
  if (!rec) {
    return { text: "", segments: [], peaks: null, method: "none", error: "sherpa-onnx not available" };
  }

  let samples = null;
  let peaks = null;
  try {
    samples = wavToFloat32Samples(monoWavBuffer);
    peaks = computePeaks(samples);
  } catch (err) {
    logger.error({ err: err.message }, "WAV decode for peaks failed — chunked fallback");
    const fb = await transcribeWavChunked(monoWavBuffer);
    return { ...fb, peaks: null, method: "chunked" };
  }

  if (calculateRMS(samples) < 0.005) {
    return { text: "", segments: [], peaks, method: "vad", skipped: "silence" };
  }

  const utterances = segmentByVad(samples);
  if (utterances && utterances.length > 0) {
    const segments = [];
    for (const u of utterances) {
      const startSec = u.startSample / SAMPLE_RATE;
      const durSec = u.samples.length / SAMPLE_RATE;
      if (durSec < 0.25) continue;

      if (durSec <= CHUNK_SECONDS) {
        const t = transcribeChunk(rec, u.samples);
        if (t && !isHallucination(t)) {
          segments.push({
            start: Math.round(startSec * 10) / 10,
            end: Math.round((startSec + durSec) * 10) / 10,
            text: t,
          });
        }
        continue;
      }

      let off = 0;
      while (off < u.samples.length) {
        const end = Math.min(off + CHUNK_SAMPLES, u.samples.length);
        const t = transcribeChunk(rec, u.samples.subarray(off, end));
        if (t && !isHallucination(t)) {
          segments.push({
            start: Math.round((startSec + off / SAMPLE_RATE) * 10) / 10,
            end: Math.round((startSec + end / SAMPLE_RATE) * 10) / 10,
            text: t,
          });
        }
        if (end >= u.samples.length) break;
        off += CHUNK_SAMPLES - OVERLAP_SAMPLES;
      }
    }

    if (segments.length > 0) {
      segments.sort((a, b) => a.start - b.start);
      logger.info({ utterances: segments.length }, "VAD transcription complete");
      return { text: segments.map((s) => s.text).join(" "), segments, peaks, method: "vad" };
    }
  }

  const fb = await transcribeWavChunked(monoWavBuffer);
  return { ...fb, peaks, method: "chunked" };
}

async function transcribeWavChunked(monoWavBuffer) {
  const rec = await getRecognizer();
  if (!rec) {
    return { text: "", segments: [], error: "sherpa-onnx not available" };
  }

  try {
    const samples = wavToFloat32Samples(monoWavBuffer);
    const totalSamples = samples.length;
    const durationSec = totalSamples / SAMPLE_RATE;

    // Silence detection on full audio
    const rms = calculateRMS(samples);
    logger.info({ durationSec: durationSec.toFixed(1), samples: totalSamples, rms: rms.toFixed(5) }, "Audio analysis");

    if (rms < 0.005) {
      logger.info({ rms: rms.toFixed(5), durationSec: durationSec.toFixed(1) }, "Channel is silence — skipping");
      return { text: "", segments: [], skipped: "silence" };
    }

    // Short audio (< 30s) — single pass
    if (totalSamples <= CHUNK_SAMPLES + OVERLAP_SAMPLES) {
      logger.info({ durationSec: durationSec.toFixed(1) }, "Short audio — single pass");
      const text = transcribeChunk(rec, samples);

      if (!text || isHallucination(text)) {
        return { text: "", segments: [], skipped: text ? "hallucination" : "empty" };
      }

      return { text, segments: [{ start: 0, end: durationSec, text }] };
    }

    // Long audio — chunked processing
    const segments = [];
    let offset = 0;
    let chunkNum = 0;
    const totalChunks = Math.ceil(totalSamples / (CHUNK_SAMPLES - OVERLAP_SAMPLES));

    logger.info({ durationSec: durationSec.toFixed(1), totalChunks, chunkSize: CHUNK_SECONDS + "s" }, "Chunked transcription starting");

    while (offset < totalSamples) {
      const end = Math.min(offset + CHUNK_SAMPLES, totalSamples);
      const chunk = samples.slice(offset, end);
      chunkNum++;

      // Skip silent chunks
      const chunkRms = calculateRMS(chunk);
      if (chunkRms < 0.005) {
        logger.info({ chunk: chunkNum, rms: chunkRms.toFixed(5) }, "Silent chunk — skipping");
        offset += CHUNK_SAMPLES - OVERLAP_SAMPLES;
        continue;
      }

      const chunkText = transcribeChunk(rec, chunk);
      const chunkStartSec = offset / SAMPLE_RATE;
      const chunkEndSec = end / SAMPLE_RATE;

      if (chunkText && !isHallucination(chunkText)) {
        segments.push({
          start: Math.round(chunkStartSec * 10) / 10,
          end: Math.round(chunkEndSec * 10) / 10,
          text: chunkText,
        });
        logger.info({ chunk: chunkNum, of: totalChunks, start: chunkStartSec.toFixed(1), len: chunkText.length }, "Chunk transcribed");
      } else {
        logger.info({ chunk: chunkNum, skipped: chunkText ? "hallucination" : "empty" }, "Chunk filtered");
      }

      // Advance by chunk size minus overlap
      offset += CHUNK_SAMPLES - OVERLAP_SAMPLES;
    }

    // Deduplicate overlap text between consecutive segments
    for (let i = 1; i < segments.length; i++) {
      const prev = segments[i - 1].text;
      const curr = segments[i].text;

      // Check if the start of current segment repeats the end of previous
      // Look for overlap in the last/first 50 chars
      const prevEnd = prev.slice(-60).toLowerCase();
      const currStart = curr.slice(0, 60).toLowerCase();

      // Find longest common suffix/prefix
      let bestOverlap = 0;
      for (let len = 5; len <= Math.min(50, prevEnd.length, currStart.length); len++) {
        if (prevEnd.endsWith(currStart.slice(0, len))) {
          bestOverlap = len;
        }
      }

      if (bestOverlap > 5) {
        // Trim the overlapping text from the start of current segment
        segments[i] = { ...segments[i], text: curr.slice(bestOverlap).trim() };
        logger.info({ overlap: bestOverlap, chunk: i + 1 }, "Removed overlap text");
      }
    }

    // Filter empty segments after dedup
    const finalSegments = segments.filter(s => s.text.length > 0);
    const fullText = finalSegments.map(s => s.text).join(" ");

    logger.info({
      textLength: fullText.length,
      segments: finalSegments.length,
      chunks: chunkNum,
      durationSec: durationSec.toFixed(1),
    }, "Chunked transcription complete");

    return { text: fullText, segments: finalSegments };

  } catch (err) {
    logger.error(err, "Transcription failed");
    return { text: "", segments: [], error: err.message };
  }
}
