/**
 * Worker Storage Service
 *
 * Provides getObject and deleteObject for both MinIO and S3 backends.
 * Loads S3 config from MongoDB settings, falls back to MinIO.
 */

import { S3Client, GetObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import crypto from "crypto";

let minioClient = null;
let s3Client = null;
let cachedConfig = null;
let configLoadedAt = 0;
const CONFIG_TTL = 30_000;

function decrypt(encrypted) {
  try {
    const KEY_ENV = process.env.SMTP_ENCRYPTION_KEY || process.env.JWT_SECRET;
    const key = crypto.createHash("sha256").update(KEY_ENV).digest();
    const [ivHex, tagHex, data] = encrypted.split(":");
    if (!ivHex || !tagHex || !data) return null;
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(ivHex, "hex"));
    decipher.setAuthTag(Buffer.from(tagHex, "hex"));
    let dec = decipher.update(data, "hex", "utf8");
    dec += decipher.final("utf8");
    return dec;
  } catch { return null; }
}

function getMinioClient() {
  if (minioClient) return minioClient;
  const endpoint = process.env.MINIO_ENDPOINT || "minio";
  const port = parseInt(process.env.MINIO_PORT || "9000", 10);
  minioClient = new S3Client({
    endpoint: `http://${endpoint}:${port}`,
    region: "us-east-1",
    credentials: {
      accessKeyId: process.env.MINIO_ACCESS_KEY || "vodia",
      secretAccessKey: process.env.MINIO_SECRET_KEY || "changeme123",
    },
    forcePathStyle: true,
  });
  return minioClient;
}

async function loadConfig(db) {
  if (cachedConfig && Date.now() - configLoadedAt < CONFIG_TTL) return cachedConfig;
  try {
    const doc = await db.collection("settings").findOne({ key: "storage" });
    if (doc?.value) {
      const cfg = { ...doc.value };
      if (cfg.access_key_encrypted) cfg.access_key = decrypt(cfg.access_key_encrypted);
      if (cfg.secret_key_encrypted) cfg.secret_key = decrypt(cfg.secret_key_encrypted);
      cachedConfig = cfg;
      configLoadedAt = Date.now();
      return cfg;
    }
  } catch { /* fall through */ }
  cachedConfig = null;
  configLoadedAt = Date.now();
  return null;
}

function getS3Client(config) {
  if (s3Client) return s3Client;
  const params = {
    region: config.region || "us-east-1",
    credentials: {
      accessKeyId: config.access_key,
      secretAccessKey: config.secret_key,
    },
    forcePathStyle: !!config.force_path_style,
  };
  if (config.endpoint) params.endpoint = config.endpoint;
  s3Client = new S3Client(params);
  return s3Client;
}

export async function getClientForBackend(db, backend) {
  if (backend === "s3") {
    const cfg = await loadConfig(db);
    if (!cfg || !cfg.access_key || !cfg.secret_key) {
      throw new Error("S3 not configured");
    }
    return { client: getS3Client(cfg), bucket: cfg.bucket || "recordings" };
  }
  return { client: getMinioClient(), bucket: process.env.MINIO_BUCKET || "recordings" };
}

export async function getCurrentBackend(db) {
  const cfg = await loadConfig(db);
  return cfg?.backend === "s3" ? "s3" : "minio";
}

export async function getObjectStream(db, key, backend = "minio") {
  const { client, bucket } = await getClientForBackend(db, backend);
  const response = await client.send(new GetObjectCommand({ Bucket: bucket, Key: key }));
  return response.Body;
}

export async function deleteObject(db, key, backend = "minio") {
  const { client, bucket } = await getClientForBackend(db, backend);
  await client.send(new DeleteObjectCommand({ Bucket: bucket, Key: key }));
}

export function clearConfigCache() {
  cachedConfig = null;
  configLoadedAt = 0;
  s3Client = null;
}
