#!/usr/bin/env python3
"""
patch_hot_cold_split_v1.py

Vodia Analytics -- hot/cold collection split, per-tenant retention,
Redis queue retention, and container log rotation.

═══════════════════════════════════════════════════════════════════
WHY
═══════════════════════════════════════════════════════════════════

Measured on a production install (nxts1-dc-001), 959,038 calls:

    avg document        33,038 bytes
      extensionlegs     15,495  (47%)
      trunklegs          9,313  (28%)
      logs               8,625  (26%)
      everything else    ~1,300 ( 4%)

    collection size     24.7 GB  (uncompressed / what the cache holds)
    WiredTiger cache     5.3 GB  -> only 21% of data is cacheable
    block reads           201 GB

Profiler evidence that size, not indexing, is the dominant cost:

    86,739ms  COLLSCAN                             examined 959,601
    47,997ms  IXSCAN {answering_queue:1, start:-1}  examined 152,410
     5,969ms  IXSCAN {answering_queue:1, start:-1}  examined  32,495

The 6-second query HAD a working index. 32,495 x 33 KB = 1.07 GB of
disk reads for one group-by. Indexes cannot fix a working set that is
5x the cache.

96% of every document is raw PBX payload read by exactly one page.

═══════════════════════════════════════════════════════════════════
WHAT
═══════════════════════════════════════════════════════════════════

  calls          hot,  ~1.3 KB/doc -- dashboards, list, exports
  call_details   cold, ~25 KB/doc  -- read only by /api/calls/:id

Expected: calls 24.7 GB -> ~1.3 GB, fits cache 4x over.

  1. ingest.js       split the write; expires_at; has_trunk_leg;
                     store_logs honoured per tenant
  2. calls.js        /api/calls/:id dual-reads call_details with
                     fallback to inline fields (makes the backfill
                     safe to run with zero downtime)
  3. stats.js        "trunklegs.0" -> has_trunk_leg (with fallback)
     exports.js      same
  4. migration       call_details collection, TTL indexes,
                     {start:-1}, {callid:1}
  5. tenants.js      retention + store_logs settings API
  6. compose         redis maxmemory configurable; OOM-detecting
                     healthcheck; LOG ROTATION (worker was writing
                     ~15 GB/day, 172 GB accumulated)
  7. Redis queue retention fixes (upload.js, ai.js, compliance.js,
     cdr.js) -- transcription jobs had no removeOnComplete, reaching
     296,187 keys and OOMing Redis, which took down login and ingest

RETENTION (per tenant, defaults; null = keep forever)
    retention_days_calls     365
    retention_days_details    90
    store_logs             false

Mechanism: expires_at + TTL index expireAfterSeconds:0. A document
with no expires_at never expires. One index, per-tenant clocks, no
scheduler.

NOTE ON store_logs=false: deriveTransferType() runs at INGEST against
the HTTP body, so transfer_type is computed and stored regardless.
Disabling logs costs the Logs tab and future re-derivation, not
transfer detection.

═══════════════════════════════════════════════════════════════════
NOT IN THIS PATCHER
═══════════════════════════════════════════════════════════════════

  * Backfill of the 959k existing documents -- separate script
    (backfill_call_details.py). Cannot be atomic, so folding it in
    would produce a patcher that cannot roll back.

  * Admin UI for the new settings. Defaults are sensible and the
    settings API is patched, so they are reachable now. Deferred
    because Admin.jsx varies across installs and a blind JSX edit
    is the riskiest thing I could do here.

  * The 87s country distinct / 48s unbounded query / 31s category
    probe. Deliberate: those scan 959k docs, which post-split is
    1.3 GB in cache instead of 24.7 GB from disk. Re-profile after
    the backfill and fix what is still slow, rather than optimising
    against numbers that are about to change by 20x.

═══════════════════════════════════════════════════════════════════

SAFETY: 4 phases -- verify anchors unique / timestamped backup /
apply / re-verify with auto-rollback. Idempotent. Files absent from
older installs are skipped, so this is safe to run across a fleet at
mixed versions.

USAGE
    cd ~/cdrstats
    python3 patch_hot_cold_split_v1.py --dry-run
    python3 patch_hot_cold_split_v1.py
    python3 patch_hot_cold_split_v1.py --rollback backups/<dir>
"""

import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

USE_COLOR = sys.stdout.isatty()


def _c(code, text):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def ok(m):
    print(f"  {_c('32','OK')}    {m}")


def warn(m):
    print(f"  {_c('33','WARN')}  {m}")


def fail(m):
    print(f"  {_c('31','FAIL')}  {m}")


def info(m):
    print(f"  {_c('36','..')}    {m}")


def phase(n, t):
    print()
    print(_c("1", f"── Phase {n}: {t} " + "─" * max(0, 48 - len(t))))


def die(m, code=1):
    print()
    fail(m)
    sys.exit(code)


# ═══════════════════════════════════════════════════════════════
# 1. ingest.js
# ═══════════════════════════════════════════════════════════════

ING_CFG_OLD = '''async function getTenantConfig(system, domain, db, redis) {
  const cacheKey = `tenant_norm:${system}:${domain}`;

  try {
    const cached = await redis.get(cacheKey);
    if (cached) return JSON.parse(cached);
  } catch { /* fall through */ }

  const tenant = await db.collection("tenants").findOne(
    { system, domain },
    { projection: { normalization: 1 } }
  );

  const config = tenant?.normalization || DEFAULT_CONFIG;

  try {
    await redis.set(cacheKey, JSON.stringify(config), "EX", 600);
  } catch { /* ignore */ }

  return config;
}'''

# New cache key prefix (tenant_cfg:) -- the cached shape changes, and
# reusing tenant_norm: would deserialise old-shape entries for 10 min
# after deploy.
ING_CFG_NEW = '''export const RETENTION_DEFAULTS = {
  retention_days_calls: 365,
  retention_days_details: 90,
  store_logs: false,
};

/**
 * Tenant config: normalization + retention + logging preferences.
 *
 * Cache key is tenant_cfg: (not tenant_norm:) because the cached shape
 * changed -- reusing the old prefix would deserialise stale-shape
 * entries for up to 10 minutes after deploy.
 */
async function getTenantConfig(system, domain, db, redis) {
  const cacheKey = `tenant_cfg:${system}:${domain}`;

  try {
    const cached = await redis.get(cacheKey);
    if (cached) return JSON.parse(cached);
  } catch { /* fall through */ }

  const tenant = await db.collection("tenants").findOne(
    { system, domain },
    { projection: { normalization: 1, retention: 1 } }
  );

  const config = {
    normalization: tenant?.normalization || DEFAULT_CONFIG,
    retention: { ...RETENTION_DEFAULTS, ...(tenant?.retention || {}) },
  };

  try {
    await redis.set(cacheKey, JSON.stringify(config), "EX", 600);
  } catch { /* ignore */ }

  return config;
}

/**
 * Absolute expiry for a document, or null to keep forever.
 * A null/0/absent retention value means "never expires" -- the TTL
 * index skips documents with no expires_at field.
 */
function computeExpiry(days) {
  if (days === null || days === undefined) return null;
  const n = Number(days);
  if (!Number.isFinite(n) || n <= 0) return null;
  return new Date(Date.now() + n * 86400 * 1000);
}'''

ING_PROC_OLD = '''export async function processCdr(cdr, system, db, redis) {
  const normConfig = await getTenantConfig(system, cdr.domain, db, redis);'''

ING_PROC_NEW = '''export async function processCdr(cdr, system, db, redis) {
  const tenantCfg = await getTenantConfig(system, cdr.domain, db, redis);
  const normConfig = tenantCfg.normalization;
  const retention = tenantCfg.retention;'''

ING_DOC_OLD = '''    trunklegs: cdr.trunklegs || [],
    extensionlegs: cdr.extensionlegs || [],
    states: cdr.states || [],
    recordings_raw: cdr.recordings || [],
    logs: cdr.logs || [],
'''

# states stays inline: 573 bytes avg, and stats/agents aggregations
# $unwind it. Only the three fat fields move.
ING_DOC_NEW = '''    states: cdr.states || [],
    has_trunk_leg: Array.isArray(cdr.trunklegs) && cdr.trunklegs.length > 0,
'''

ING_RET_OLD = '''    ingested_at: new Date(),
  };

  return doc;
}'''

ING_RET_NEW = '''    ingested_at: new Date(),
  };

  const callsExpiry = computeExpiry(retention.retention_days_calls);
  if (callsExpiry) doc.expires_at = callsExpiry;

  // Cold payload -- stripped by upsertCdr and written to call_details.
  // Non-enumerable so it never leaks into a $set or a JSON response.
  Object.defineProperty(doc, "__details", {
    value: {
      trunklegs: cdr.trunklegs || [],
      extensionlegs: cdr.extensionlegs || [],
      recordings_raw: cdr.recordings || [],
      logs: retention.store_logs ? (cdr.logs || []) : [],
      logs_stored: !!retention.store_logs,
      expires_at: computeExpiry(retention.retention_days_details),
    },
    enumerable: false,
    writable: true,
    configurable: true,
  });

  return doc;
}'''

ING_UPSERT_OLD = '''export async function upsertCdr(doc, db) {
  const filter = {
    system: doc.system,
    domain: doc.domain,
    callid: doc.callid,
  };

  return db.collection("calls").updateOne(
    filter,
    {
      $set: doc,
      $setOnInsert: { created_at: new Date() },
    },
    { upsert: true }
  );
}'''

# Details written FIRST: if the second write fails the detail row is
# merely orphaned, which the TTL reaps. The reverse order would leave
# a call with no legs and no way to recover them.
ING_UPSERT_NEW = '''export async function upsertCdr(doc, db) {
  const filter = {
    system: doc.system,
    domain: doc.domain,
    callid: doc.callid,
  };

  const details = doc.__details;

  // Cold payload first. If the hot write then fails, the detail row is
  // orphaned and the TTL reaps it. The reverse order would leave a call
  // with no legs and no way to recover them.
  if (details) {
    const detailDoc = {
      system: doc.system,
      domain: doc.domain,
      callid: doc.callid,
      trunklegs: details.trunklegs,
      extensionlegs: details.extensionlegs,
      recordings_raw: details.recordings_raw,
      logs: details.logs,
      logs_stored: details.logs_stored,
    };
    const update = { $set: detailDoc, $setOnInsert: { created_at: new Date() } };
    if (details.expires_at) update.$set.expires_at = details.expires_at;
    else update.$unset = { expires_at: "" };

    try {
      await db.collection("call_details").updateOne(filter, update, { upsert: true });
    } catch (err) {
      // Never fail the CDR over the cold write -- the call itself,
      // which is what every dashboard reads, still lands.
      if (err.code !== 11000) {
        console.error("[ingest] call_details write failed:", err.message);
      }
    }
  }

  const hotUpdate = {
    $set: doc,
    $setOnInsert: { created_at: new Date() },
  };
  if (!doc.expires_at) hotUpdate.$unset = { expires_at: "" };

  return db.collection("calls").updateOne(filter, hotUpdate, { upsert: true });
}'''


# ═══════════════════════════════════════════════════════════════
# 2. calls.js -- dual read
# ═══════════════════════════════════════════════════════════════

CALLS_DETAIL_OLD = '''    // Attach recordings
    const recordings = await db.collection("recordings")
      .find({
        system: call.system,
        domain: call.domain,
        callid: call.callid,
        upload_status: "completed",
      })
      .toArray();

    // Playback is token-gated; mint a signed short-lived URL per recording
    return {
      call: call.answer_seconds != null ? call : { ...call, answer_seconds: answerSecondsFor(call) },
      recordings: recordings.map((r) => ({ ...r, play_url: buildPlayUrl(r._id) })),
    };'''

# The fallback is what makes the backfill zero-downtime: a call reads
# correctly whether or not it has been migrated yet. It stays in the
# code permanently -- it costs one findOne and makes migration order
# irrelevant.
CALLS_DETAIL_NEW = '''    // Attach recordings
    const recordings = await db.collection("recordings")
      .find({
        system: call.system,
        domain: call.domain,
        callid: call.callid,
        upload_status: "completed",
      })
      .toArray();

    // Cold payload lives in call_details. Fall back to the inline fields
    // for calls not yet migrated -- this is what makes the backfill
    // zero-downtime, and it is kept permanently so migration order and
    // partial migrations are both safe.
    let detail = null;
    try {
      detail = await db.collection("call_details").findOne({
        system: call.system,
        domain: call.domain,
        callid: call.callid,
      });
    } catch { /* fall through to inline */ }

    const cold = detail || {};
    const legs = {
      trunklegs: cold.trunklegs || call.trunklegs || [],
      extensionlegs: cold.extensionlegs || call.extensionlegs || [],
      recordings_raw: cold.recordings_raw || call.recordings_raw || [],
      logs: cold.logs || call.logs || [],
      logs_stored: detail ? cold.logs_stored !== false : undefined,
    };

    const base = call.answer_seconds != null
      ? call
      : { ...call, answer_seconds: answerSecondsFor(call) };

    // Playback is token-gated; mint a signed short-lived URL per recording
    return {
      call: { ...base, ...legs },
      recordings: recordings.map((r) => ({ ...r, play_url: buildPlayUrl(r._id) })),
    };'''


# ═══════════════════════════════════════════════════════════════
# 3. trunklegs.0 -> has_trunk_leg
# ═══════════════════════════════════════════════════════════════

# $or keeps pre-migration documents (no has_trunk_leg field) matching.
STATS_TRUNK_OLD = '''    const filter = mergeFilter(buildDateFilter(request), {
      "trunklegs.0": { $exists: true },
    });'''

STATS_TRUNK_NEW = '''    // has_trunk_leg is a cheap indexed boolean set at ingest. The $or
    // keeps documents written before the hot/cold split matching, since
    // they carry trunklegs inline and no has_trunk_leg field.
    const filter = mergeFilter(buildDateFilter(request), {
      $or: [
        { has_trunk_leg: true },
        { has_trunk_leg: { $exists: false }, "trunklegs.0": { $exists: true } },
      ],
    });'''

EXPORTS_TRUNK_OLD = '''    const filter = { ...scopeFilter, "trunklegs.0": { $exists: true } };'''

EXPORTS_TRUNK_NEW = '''    const filter = {
      ...scopeFilter,
      $or: [
        { has_trunk_leg: true },
        { has_trunk_leg: { $exists: false }, "trunklegs.0": { $exists: true } },
      ],
    };'''


# ═══════════════════════════════════════════════════════════════
# 4. Redis queue retention (measured: 296,187 keys, OOM)
# ═══════════════════════════════════════════════════════════════

UPLOAD_OLD = '''      // Queue transcription job
      try {
        const { Queue } = await import("bullmq");
        const Redis = (await import("ioredis")).default;
        const tRedis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
        const tQueue = new Queue("transcription", { connection: tRedis });
        await tQueue.add("transcribe-" + callid, {
          system, domain, callid,
          storage_key: objectKey,
        }, {
          delay: 5000,
          attempts: 2,
          backoff: { type: "exponential", delay: 30000 },
        });
        app.log.info({ callid, key: objectKey }, "Transcription job queued");
        await tRedis.quit();
      } catch (qErr) {
        app.log.error(qErr, "Failed to queue transcription job");
      }'''

UPLOAD_NEW = '''      // Queue transcription job
      let tRedis = null;
      try {
        const { Queue } = await import("bullmq");
        const Redis = (await import("ioredis")).default;
        tRedis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
        const tQueue = new Queue("transcription", { connection: tRedis });
        await tQueue.add("transcribe-" + callid, {
          system, domain, callid,
          storage_key: objectKey,
        }, {
          delay: 5000,
          attempts: 2,
          backoff: { type: "exponential", delay: 30000 },
          removeOnComplete: 100,
          removeOnFail: 500,
        });
        app.log.info({ callid, key: objectKey }, "Transcription job queued");
      } catch (qErr) {
        app.log.error(qErr, "Failed to queue transcription job");
      } finally {
        if (tRedis) { try { await tRedis.quit(); } catch { /* already gone */ } }
      }'''

AI_OLD = '''    try {
      const Redis = (await import("ioredis")).default;
      const { Queue } = await import("bullmq");
      const redis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
      const queue = new Queue("transcription", { connection: redis });
      await queue.add("retranscribe-" + callid, {
        system: call.system, domain: call.domain, callid,
        recording_id: recording._id.toString(),
        storage_key: recording.storage_key,
      }, { attempts: 2, backoff: { type: "exponential", delay: 30000 } });
      await redis.quit();
      return { message: "Transcription job queued", callid };
    } catch (err) {
      app.log.error(err, "Failed to queue retranscription");
      return reply.code(500).send({ error: "Failed to queue transcription" });
    }'''

AI_NEW = '''    let qRedis = null;
    try {
      const Redis = (await import("ioredis")).default;
      const { Queue } = await import("bullmq");
      qRedis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
      const queue = new Queue("transcription", { connection: qRedis });
      await queue.add("retranscribe-" + callid, {
        system: call.system, domain: call.domain, callid,
        recording_id: recording._id.toString(),
        storage_key: recording.storage_key,
      }, { attempts: 2, backoff: { type: "exponential", delay: 30000 }, removeOnComplete: 100, removeOnFail: 500 });
      return { message: "Transcription job queued", callid };
    } catch (err) {
      app.log.error(err, "Failed to queue retranscription");
      return reply.code(500).send({ error: "Failed to queue transcription" });
    } finally {
      if (qRedis) { try { await qRedis.quit(); } catch { /* already gone */ } }
    }'''

# First four lines are byte-identical to the bulk handler 25 lines
# below; the anchor extends through the qa- add line to stay unique.
COMPLIANCE_QA_OLD = '''    const Redis = (await import("ioredis")).default;
    const { Queue } = await import("bullmq");
    const redis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
    const queue = new Queue("compliance-eval", { connection: redis });
    await queue.add("qa-" + call.callid, { system: call.system, domain: call.domain, callid: call.callid, force_qa: true }, { attempts: 1 });
    await redis.quit();
    return { message: "QA scoring queued", callid: call.callid };'''

COMPLIANCE_QA_NEW = '''    let qRedis = null;
    try {
      const Redis = (await import("ioredis")).default;
      const { Queue } = await import("bullmq");
      qRedis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
      const queue = new Queue("compliance-eval", { connection: qRedis });
      await queue.add("qa-" + call.callid, { system: call.system, domain: call.domain, callid: call.callid, force_qa: true }, { attempts: 1, removeOnComplete: 100, removeOnFail: 500 });
      return { message: "QA scoring queued", callid: call.callid };
    } catch (err) {
      app.log.error(err, "Failed to queue QA scoring");
      return reply.code(500).send({ error: "Failed to queue QA scoring" });
    } finally {
      if (qRedis) { try { await qRedis.quit(); } catch { /* already gone */ } }
    }'''

COMPLIANCE_BULK_OLD = '''    const Redis = (await import("ioredis")).default;
    const { Queue } = await import("bullmq");
    const redis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
    const queue = new Queue("compliance-eval", { connection: redis });
    await queue.addBulk(calls.map(c => ({
      name: "reeval-" + c.callid,
      data: { system: c.system, domain: c.domain, callid: c.callid, force_qa: !!body.include_qa },
      opts: { attempts: 1, removeOnComplete: 1000, removeOnFail: 500 },
    })));
    await redis.quit();'''

COMPLIANCE_BULK_NEW = '''    let bRedis = null;
    try {
      const Redis = (await import("ioredis")).default;
      const { Queue } = await import("bullmq");
      bRedis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
      const queue = new Queue("compliance-eval", { connection: bRedis });
      await queue.addBulk(calls.map(c => ({
        name: "reeval-" + c.callid,
        data: { system: c.system, domain: c.domain, callid: c.callid, force_qa: !!body.include_qa },
        opts: { attempts: 1, removeOnComplete: 1000, removeOnFail: 500 },
      })));
    } catch (err) {
      app.log.error(err, "Failed to queue compliance re-evaluation");
      return reply.code(500).send({ error: "Failed to queue re-evaluation" });
    } finally {
      if (bRedis) { try { await bRedis.quit(); } catch { /* already gone */ } }
    }'''

CDR_OLD = '''      // Queue recording fetch
      if (enriched.has_recording && app.recordingQueue) {
        for (const rec of cdr.recordings) {
          await app.recordingQueue.add("fetch-recording", {
            system,
            domain: cdr.domain,
            callid: cdr.callid,
            file: rec.file,
            account: rec.account,
            extension: rec.extension,
          }, {
            attempts: 3,
            backoff: { type: "exponential", delay: 5000 },
            removeOnComplete: 100,
            removeOnFail: 500,
          });
        }
      }'''

CDR_NEW = '''      // Queue recording fetch.
      // Isolated: a queue failure (e.g. Redis OOM) must NOT turn an
      // already-stored CDR into a 500. A 500 here costs the PBX its
      // upload response, so the recording is never uploaded either --
      // one Redis problem silently destroys the audio for every call.
      if (enriched.has_recording && app.recordingQueue) {
        for (const rec of cdr.recordings) {
          try {
            await app.recordingQueue.add("fetch-recording", {
              system,
              domain: cdr.domain,
              callid: cdr.callid,
              file: rec.file,
              account: rec.account,
              extension: rec.extension,
            }, {
              attempts: 3,
              backoff: { type: "exponential", delay: 5000 },
              removeOnComplete: 100,
              removeOnFail: 500,
            });
          } catch (qErr) {
            app.log.warn(
              { err: qErr.message, callid: cdr.callid, domain: cdr.domain, file: rec.file },
              "Recording fetch enqueue failed -- CDR stored, upload response still returned"
            );
          }
        }
      }'''


# ═══════════════════════════════════════════════════════════════
# 5. docker-compose.yml
# ═══════════════════════════════════════════════════════════════

COMPOSE_CMD_OLD = '''    command: redis-server --maxmemory 256mb --maxmemory-policy noeviction --appendonly yes --requirepass ${REDIS_PASSWORD:?Redis password required}'''
COMPOSE_CMD_NEW = '''    command: redis-server --maxmemory ${REDIS_MAXMEMORY:-256mb} --maxmemory-policy noeviction --appendonly yes --requirepass ${REDIS_PASSWORD:?Redis password required}'''

# PING is a read and succeeds during OOM -- the old check reported
# healthy while every write in the platform was failing. SET is denyoom.
COMPOSE_HC_OLD = '''      test: ["CMD", "redis-cli", "-a", "${REDIS_PASSWORD}", "ping"]'''
COMPOSE_HC_NEW = '''      test: ["CMD", "redis-cli", "-a", "${REDIS_PASSWORD}", "--no-auth-warning", "set", "hc:probe", "1", "EX", "30"]'''


def compose_add_logging(text):
    """Insert the x-logging anchor and apply it to every service.

    Measured: the worker wrote 1.3 GB of container log in ~2 hours
    (~15 GB/day); 172 GB had accumulated on nxts1-dc-001.
    """
    changed = False

    if "x-logging:" not in text:
        block = (
            "# Container log rotation. Without this the worker alone writes\n"
            "# ~15 GB/day and json-file grows without bound.\n"
            "x-logging: &default-logging\n"
            "  driver: json-file\n"
            "  options:\n"
            '    max-size: "50m"\n'
            '    max-file: "3"\n\n'
        )
        m = re.search(r"^services:\s*$", text, re.M)
        if not m:
            return text, False
        text = text[:m.start()] + block + text[m.start():]
        changed = True

    # Apply to each service that declares restart: but has no logging yet.
    out, count = [], 0
    for line in text.split("\n"):
        out.append(line)
        m = re.match(r"^(\s+)restart:\s", line)
        if m:
            out.append(f"{m.group(1)}logging: *default-logging")
            count += 1
    if count:
        text = "\n".join(out)
        changed = True
    return text, changed


def compose_logging_needed(text):
    if "x-logging:" not in text:
        return True
    for line in text.split("\n"):
        if re.match(r"^\s+restart:\s", line):
            return "logging: *default-logging" not in text
    return False


# ═══════════════════════════════════════════════════════════════
# 6. Migration
# ═══════════════════════════════════════════════════════════════

MIGRATION_BODY = '''/**
 * Migration @VER@: hot/cold split -- call_details, retention TTLs, indexes
 *
 * Measured on a 959,038-document production collection:
 *   avg doc 33,038 bytes; extensionlegs+trunklegs+logs = 96% of that.
 *   Collection 24.7 GB against a 5.3 GB WiredTiger cache.
 *   A query WITH a working index took 5,969ms for 32,495 documents,
 *   because 32,495 x 33 KB = 1.07 GB had to come off disk.
 *
 * Splitting the cold payload out takes `calls` to ~1.3 GB, which fits
 * in cache several times over.
 *
 * Indexes added to `calls`:
 *   idx_callid      -- /api/calls/:id falls back to a { callid } lookup
 *                      for every non-ObjectId callid. Was COLLSCAN,
 *                      47,303ms -> 0ms.
 *   idx_start       -- every dashboard aggregation matches on `start`
 *                      alone. No existing index had start as its leading
 *                      field, so all 8 tiles collection-scanned.
 *   idx_has_trunk_leg
 *
 * TTL: expires_at + expireAfterSeconds 0. Documents with NO expires_at
 * field are never expired, which is how "keep forever" tenants work.
 *
 * Idempotent -- safe where indexes were already built by hand.
 */
export default {
  version: @VER@,
  name: "hot-cold-split",

  async up(db) {
    const ensure = async (col, spec, opts) => {
      const existing = (await db.collection(col).indexes()).map(i => i.name);
      if (!existing.includes(opts.name)) {
        await db.collection(col).createIndex(spec, opts);
      }
    };

    const colls = (await db.listCollections().toArray()).map(c => c.name);
    if (!colls.includes("call_details")) await db.createCollection("call_details");

    await ensure("call_details", { system: 1, domain: 1, callid: 1 },
      { unique: true, name: "idx_details_call" });
    await ensure("call_details", { callid: 1 }, { name: "idx_details_callid" });
    await ensure("call_details", { expires_at: 1 },
      { expireAfterSeconds: 0, name: "idx_details_ttl" });

    await ensure("calls", { callid: 1 }, { name: "idx_callid" });
    await ensure("calls", { start: -1 }, { name: "idx_start" });
    await ensure("calls", { has_trunk_leg: 1, start: -1 },
      { name: "idx_has_trunk_leg", sparse: true });
    await ensure("calls", { expires_at: 1 },
      { expireAfterSeconds: 0, name: "idx_calls_ttl" });
  },
};
'''


# ═══════════════════════════════════════════════════════════════
# Edit table
# ═══════════════════════════════════════════════════════════════

EDITS = [
    ("api/src/services/ingest.js", [
        ("tenant config + retention helpers", ING_CFG_OLD, ING_CFG_NEW),
        ("processCdr reads tenant retention", ING_PROC_OLD, ING_PROC_NEW),
        ("move cold fields out of hot doc", ING_DOC_OLD, ING_DOC_NEW),
        ("attach cold payload + expires_at", ING_RET_OLD, ING_RET_NEW),
        ("upsertCdr splits hot/cold write", ING_UPSERT_OLD, ING_UPSERT_NEW),
    ], True),
    ("api/src/routes/calls.js", [
        ("call detail dual-read with fallback", CALLS_DETAIL_OLD, CALLS_DETAIL_NEW),
    ], True),
    ("api/src/routes/stats.js", [
        ("numbers: has_trunk_leg", STATS_TRUNK_OLD, STATS_TRUNK_NEW),
    ], True),
    ("api/src/routes/exports.js", [
        ("export numbers: has_trunk_leg", EXPORTS_TRUNK_OLD, EXPORTS_TRUNK_NEW),
    ], True),
    ("api/src/routes/upload.js", [
        ("transcription job retention + finally quit", UPLOAD_OLD, UPLOAD_NEW),
    ], True),
    ("api/src/routes/ai.js", [
        ("retranscribe job retention + finally quit", AI_OLD, AI_NEW),
    ], True),
    ("api/src/routes/compliance.js", [
        ("QA job retention + finally quit", COMPLIANCE_QA_OLD, COMPLIANCE_QA_NEW),
        ("bulk re-evaluate finally quit", COMPLIANCE_BULK_OLD, COMPLIANCE_BULK_NEW),
    ], False),
    ("api/src/routes/cdr.js", [
        ("isolate recordingQueue.add", CDR_OLD, CDR_NEW),
    ], True),
    ("docker-compose.yml", [
        ("configurable redis maxmemory", COMPOSE_CMD_OLD, COMPOSE_CMD_NEW),
        ("OOM-detecting redis healthcheck", COMPOSE_HC_OLD, COMPOSE_HC_NEW),
    ], True),
]

ENV_ADDITIONS = [
    ("REDIS_MAXMEMORY", "2gb",
     "# Redis memory ceiling. noeviction is intentional -- BullMQ state\n"
     "# must never be evicted. Raise on high-volume multi-tenant installs.\n"),
]


# ═══════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════

def find_root():
    for c in (os.getcwd(), os.path.dirname(os.path.abspath(__file__))):
        if os.path.isfile(os.path.join(c, "docker-compose.yml")) and \
           os.path.isdir(os.path.join(c, "api", "src")):
            return c
    die("Not a cdrstats install directory.\n"
        "        Expected docker-compose.yml and api/src/ here.")


def read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()


def write(p, t):
    with open(p, "w", encoding="utf-8") as f:
        f.write(t)


def next_migration(root):
    d = os.path.join(root, "api", "src", "migrations")
    if not os.path.isdir(d):
        return None, None
    hi = 0
    for n in os.listdir(d):
        m = re.match(r"^(\d{3})-", n)
        if m and n.endswith(".js"):
            if "hot-cold-split" in n:
                return None, os.path.join(d, n)
            hi = max(hi, int(m.group(1)))
    v = hi + 1
    return v, os.path.join(d, f"{v:03d}-hot-cold-split.js")


_NODE = None


def _node_mode(root):
    global _NODE
    if _NODE is not None:
        return _NODE
    try:
        subprocess.run(["node", "--version"], capture_output=True, check=True, timeout=15)
        _NODE = "host"
        return _NODE
    except Exception:
        pass
    try:
        r = subprocess.run(["docker", "compose", "exec", "-T", "api", "node", "--version"],
                           cwd=root, capture_output=True, timeout=30)
        if r.returncode == 0:
            _NODE = "container"
            return _NODE
    except Exception:
        pass
    _NODE = "none"
    return _NODE


def check_js(root, path):
    """node --check on a .mjs copy -- plain .js exits 0 on ESM syntax errors."""
    mode = _node_mode(root)
    if mode == "none":
        return True, "skipped (no node)"
    tmp = tempfile.mkdtemp(prefix="cdrstats-syn-")
    try:
        mjs = os.path.join(tmp, "check.mjs")
        shutil.copyfile(path, mjs)
        if mode == "host":
            r = subprocess.run(["node", "--check", mjs], capture_output=True, timeout=60)
            return r.returncode == 0, (r.stderr.decode(errors="replace").strip()[:400] or "clean")
        subprocess.run(["docker", "compose", "cp", mjs, "api:/tmp/check.mjs"],
                       cwd=root, capture_output=True, timeout=60, check=True)
        r = subprocess.run(["docker", "compose", "exec", "-T", "api", "node", "--check", "/tmp/check.mjs"],
                           cwd=root, capture_output=True, timeout=60)
        return r.returncode == 0, (r.stderr.decode(errors="replace").strip()[:400] or "clean")
    except Exception as e:
        return True, f"skipped ({e})"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def check_compose(root):
    try:
        r = subprocess.run(["docker", "compose", "config", "-q"],
                           cwd=root, capture_output=True, timeout=90)
        return r.returncode == 0, (r.stderr.decode(errors="replace").strip()[:400] or "clean")
    except Exception as e:
        return True, f"skipped ({e})"


def restore(root, backup_dir, created):
    for dp, _, fs in os.walk(backup_dir):
        for n in fs:
            src = os.path.join(dp, n)
            rel = os.path.relpath(src, backup_dir)
            dst = os.path.join(root, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(src, dst)
            print(f"        restored {rel}")
    for p in created:
        if os.path.isfile(p):
            os.remove(p)
            print(f"        removed   {os.path.relpath(p, root)}")


# ═══════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════

def main():
    args = sys.argv[1:]
    dry = "--dry-run" in args

    if "--rollback" in args:
        i = args.index("--rollback")
        if i + 1 >= len(args):
            die("--rollback requires a backup directory")
        root = find_root()
        b = args[i + 1]
        if not os.path.isdir(b):
            die(f"Backup directory not found: {b}")
        print(_c("1", "Manual rollback"))
        restore(root, b, [])
        ok("Rollback complete. Rebuild the API container to apply.")
        return

    root = find_root()
    print()
    print(_c("1", "patch_hot_cold_split_v1  --  Vodia Analytics"))
    print(f"  install root : {root}")
    print(f"  mode         : {'DRY RUN (no changes)' if dry else 'APPLY'}")

    phase(1, "Verify anchors")

    plan, already, problems = [], [], []

    for rel, edits, required in EDITS:
        path = os.path.join(root, rel)
        if not os.path.isfile(path):
            if required:
                problems.append(f"{rel}: file not found")
            else:
                warn(f"{rel} absent -- skipped (not in this version)")
            continue
        text = read(path)
        todo = []
        for label, old, new in edits:
            n_old, n_new = text.count(old), text.count(new)
            if n_new >= 1 and n_old == 0:
                already.append(f"{rel}: {label}")
                continue
            if n_old == 0:
                problems.append(f"{rel}: anchor not found -- {label}")
                continue
            if n_old > 1:
                problems.append(f"{rel}: anchor matched {n_old}x (must be 1) -- {label}")
                continue
            todo.append((label, old, new))
        if todo:
            plan.append((path, rel, todo))
            for label, _, _ in todo:
                ok(f"{rel}: {label}")

    # compose logging (structural, not a simple anchor)
    compose_path = os.path.join(root, "docker-compose.yml")
    do_logging = False
    if os.path.isfile(compose_path):
        if compose_logging_needed(read(compose_path)):
            do_logging = True
            ok("docker-compose.yml: container log rotation")
        else:
            already.append("docker-compose.yml: log rotation already present")

    mig_ver, mig_path = next_migration(root)
    create_mig = False
    if mig_path is None:
        warn("migrations directory not found -- migration skipped")
    elif mig_ver is None or os.path.exists(mig_path):
        already.append("migration already present")
    else:
        create_mig = True
        ok(f"api/src/migrations/{mig_ver:03d}-hot-cold-split.js: will be created")

    env_targets = []
    for envname in (".env", ".env.example"):
        p = os.path.join(root, envname)
        if not os.path.isfile(p):
            continue
        t = read(p)
        need = [a for a in ENV_ADDITIONS if not re.search(rf"^\s*{a[0]}\s*=", t, re.M)]
        if need:
            env_targets.append((p, need))
            ok(f"{envname}: {', '.join(a[0] for a in need)}")
        else:
            already.append(f"{envname}: env keys already set")

    for m in already:
        info(f"already applied -- {m}")

    if problems:
        print()
        for m in problems:
            fail(m)
        die("Refusing to run. Anchors did not match this deployment.\n"
            "        Nothing has been modified. Send me the output above.")

    if not plan and not create_mig and not env_targets and not do_logging:
        print()
        ok("Nothing to do -- all changes already applied.")
        return

    if dry:
        print()
        ok("Dry run complete. All anchors verified. No files changed.")
        return

    phase(2, "Backup")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup_dir = os.path.join(root, "backups", f"hot-cold-split-{stamp}")
    to_backup = {p for p, _, _ in plan} | {p for p, _ in env_targets}
    if do_logging:
        to_backup.add(compose_path)
    for p in sorted(to_backup):
        rel = os.path.relpath(p, root)
        dst = os.path.join(backup_dir, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copyfile(p, dst)
        ok(f"backed up {rel}")
    os.makedirs(backup_dir, exist_ok=True)
    info(f"backup dir: {os.path.relpath(backup_dir, root)}")

    created = []
    try:
        run_apply(root, plan, env_targets, create_mig, mig_path, mig_ver,
                  do_logging, compose_path, created)
    except SystemExit:
        raise
    except Exception as e:
        print()
        fail(f"Unexpected error: {type(e).__name__}: {e}")
        print()
        warn("Rolling back...")
        restore(root, backup_dir, created)
        die("Rolled back. Your install is unchanged.\n"
            f"        Backup retained at: {os.path.relpath(backup_dir, root)}")

    print()
    print(_c("1", "── Applied successfully " + "─" * 35))
    print(f"""
  Backup: {os.path.relpath(backup_dir, root)}

  DEPLOY (do this at your lowest-traffic hour -- the API is down for
  30-90s and the PBX does not retry failed /cdr pushes, so roughly
  30-60 CDRs will be lost in that window):

    docker compose build --no-cache api
    docker compose up -d

  VERIFY:
    1. Open an OLD call's detail page. Tabs must still render --
       that proves the dual-read fallback works.
    2. Push a new CDR, then confirm the split:
         db.call_details.countDocuments({{}})       > 0
         db.calls.findOne({{}}, {{trunklegs:1}})       no trunklegs
    3. Reload the dashboard. New calls are thin; the OLD 959k are
       still fat until the backfill runs, so expect only partial
       improvement at this stage.

  PER-TENANT RETENTION (defaults: calls 365d, details 90d, logs off).
  Set null to keep forever:

    db.tenants.updateOne({{domain:"x"}}, {{$set:{{retention:{{
      retention_days_calls: 30, retention_days_details: 30,
      store_logs: false }}}}}})

  Then flush the config cache so it takes effect within 10 minutes:
    redis-cli --scan --pattern 'tenant_cfg:*' | xargs -r redis-cli del

  NEXT: backfill_call_details.py migrates the existing 959k documents.
  New calls are already thin without it; the backfill is what makes
  HISTORICAL data fast. Take a mongodump first.
""")


def run_apply(root, plan, env_targets, create_mig, mig_path, mig_ver,
              do_logging, compose_path, created):
    phase(3, "Apply")

    for path, rel, todo in plan:
        text = read(path)
        for label, old, new in todo:
            text = text.replace(old, new, 1)
            ok(f"{rel}: {label}")
        write(path, text)

    if do_logging:
        text, changed = compose_add_logging(read(compose_path))
        if not changed:
            raise RuntimeError("could not insert logging block into docker-compose.yml")
        write(compose_path, text)
        ok("docker-compose.yml: container log rotation")

    if create_mig:
        write(mig_path, MIGRATION_BODY.replace("@VER@", str(mig_ver)))
        created.append(mig_path)
        ok(f"created {os.path.relpath(mig_path, root)}")

    for p, need in env_targets:
        text = read(p)
        if not text.endswith("\n"):
            text += "\n"
        for key, val, comment in need:
            text += f"\n{comment}{key}={val}\n"
        write(p, text)
        ok(f"{os.path.relpath(p, root)}: env keys added")

    phase(4, "Re-verify")
    failures = []

    for path, rel, todo in plan:
        text = read(path)
        for label, old, new in todo:
            if new not in text:
                failures.append(f"{rel}: replacement missing -- {label}")
            if old in text:
                failures.append(f"{rel}: original still present -- {label}")
        if rel.endswith(".js"):
            good, detail = check_js(root, path)
            if good:
                ok(f"syntax {rel}: {detail}")
            else:
                failures.append(f"{rel}: syntax error -- {detail}")

    if create_mig:
        good, detail = check_js(root, mig_path)
        if good:
            ok(f"syntax {os.path.relpath(mig_path, root)}: {detail}")
        else:
            failures.append(f"migration: syntax error -- {detail}")

    good, detail = check_compose(root)
    if good:
        ok(f"docker compose config: {detail}")
    else:
        failures.append(f"docker-compose.yml: invalid -- {detail}")

    if failures:
        print()
        for m in failures:
            fail(m)
        raise RuntimeError("phase 4 verification failed")


if __name__ == "__main__":
    main()
