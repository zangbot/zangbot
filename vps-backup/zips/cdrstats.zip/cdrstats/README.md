# Vodia CDR Analytics Platform

Self-hosted call detail record analytics for Vodia PBX systems.

## Features

- **CDR Ingest** — Webhook endpoint for Vodia PBX CDR data
- **Call Analytics** — Dashboard with KPIs, hourly/daily trends, queue & extension performance
- **Recording Storage** — MinIO S3-compatible storage with streaming playback
- **AI Transcription** — Automatic call transcription using Whisper (local, free)
- **AI Summaries** — On-demand or automatic call summaries via OpenAI (sentiment, topics, action items)
- **AI Insights** — Sentiment trends, top topics, transcript search, resolution tracking
- **Multi-tenant** — Multiple PBX systems, tenant-scoped data
- **RBAC** — Super admin, admin, viewer roles
- **Passkeys** — WebAuthn/FIDO2 passwordless authentication
- **Data Retention** — Configurable per-tenant retention policies
- **GDPR Purge** — Delete all data for a phone number
- **Security** — MongoDB auth, Redis auth, rate limiting, CORS, CSP, HSTS

## Quick Start

```bash
git clone https://github.com/YOUR_ORG/vodia-cdr-platform.git
cd vodia-cdr-platform
sudo ./install.sh
```

Requirements: Ubuntu 24.04 LTS, 2GB+ RAM (4GB+ recommended), domain name pointed to server.

## Configuration

All settings are in `.env`. The installer generates this automatically.

Key settings:
- `DOMAIN` — Your server's domain name
- `TRANSCRIPTION_CONCURRENCY` — Increase on bigger servers (default: 1)


## Updating

```bash
git pull
docker compose build --no-cache api worker
docker compose up -d
```

Database migrations run automatically on API startup. No data loss.

## Architecture

- **Caddy** — Reverse proxy, auto HTTPS
- **Fastify API** — REST API, CDR ingest, auth
- **BullMQ Worker** — Recording processing, transcription, auto-summarize
- **MongoDB 7** — Call data, transcripts, settings
- **Redis 7** — Queues, caching, rate limiting
- **MinIO** — Recording storage (S3-compatible)
- **Grafana** — Optional embedded dashboards
- **React** — Frontend SPA with Tailwind CSS

## License

Proprietary. All rights reserved.
