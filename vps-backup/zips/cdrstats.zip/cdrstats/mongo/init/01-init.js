/**
 * MongoDB First-Run Initialization
 *
 * MINIMAL — only creates the app user.
 * All collections, indexes, and schema are handled by
 * the API migration system (api/src/migrations/).
 */

const db = db.getSiblingDB(process.env.MONGO_INITDB_DATABASE || "vodia_cdr");
print("=== Vodia CDR Platform — MongoDB Init ===");
print("Database: " + db.getName());
print("Collections and indexes managed by API migration system.");
print("=== Init complete ===");
