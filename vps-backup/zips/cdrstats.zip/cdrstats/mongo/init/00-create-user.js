/**
 * Create application user with readWrite access.
 * Runs on first container start only.
 */
const adminDb = db.getSiblingDB("admin");
const appDb = db.getSiblingDB(process.env.MONGO_INITDB_DATABASE || "vodia_cdr");

const user = process.env.MONGO_USER || "vodia_app";
const password = process.env.MONGO_PASSWORD || "changeme";

try {
  appDb.createUser({
    user: user,
    pwd: password,
    roles: [{ role: "readWrite", db: appDb.getName() }],
  });
  print("✓ Created MongoDB user: " + user);
} catch (e) {
  if (e.codeName === "DuplicateKey" || e.code === 51003) {
    print("✓ MongoDB user already exists: " + user);
  } else {
    print("✗ Failed to create user: " + e.message);
  }
}
