#!/usr/bin/env bash
##
## Vodia CDR Analytics Platform — One-Command Installer
## Target: Ubuntu 24.04 LTS (fresh VPS)
##

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1" >&2; exit 1; }
info() { echo -e "${CYAN}[i]${NC} $1"; }

# ── Preflight ──────────────────────────────────────────
[[ $EUID -ne 0 ]] && err "Run as root: sudo ./install.sh"

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║   Vodia CDR Analytics Platform — Installer        ║${NC}"
echo -e "${CYAN}║   Ubuntu 24.04 LTS                                ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════╝${NC}"
echo ""

# ── Check OS ───────────────────────────────────────────
if [[ -f /etc/os-release ]]; then
    . /etc/os-release
    if [[ "$ID" != "ubuntu" ]]; then
        warn "This script targets Ubuntu. Detected: $ID $VERSION_ID"
        read -rp "Continue anyway? (y/N): " CONTINUE
        [[ "$CONTINUE" != "y" ]] && exit 1
    fi
fi

# ── Ensure swap exists (prevents OOM on 2GB VPS) ──────
if [ "$(swapon --show | wc -l)" -eq 0 ]; then
    info "Creating 2GB swap file (prevents out-of-memory during builds)..."
    fallocate -l 2G /swapfile
    chmod 600 /swapfile
    mkswap /swapfile > /dev/null
    swapon /swapfile
    echo "/swapfile none swap sw 0 0" >> /etc/fstab
    log "2GB swap enabled"
else
    log "Swap already configured"
fi

# ── Gather Configuration ──────────────────────────────
echo ""
echo -e "${CYAN}Configuration${NC}"
echo ""

read -rp "  Domain name (e.g. cdr.example.com, or 'localhost' for dev): " DOMAIN
DOMAIN=${DOMAIN:-localhost}

# ── DNS check for real domains ─────────────────────────
if [[ "$DOMAIN" != "localhost" ]]; then
    SERVER_IP=$(curl -sf https://api.ipify.org || curl -sf https://ifconfig.me || echo "")
    DOMAIN_IP=$(dig +short "$DOMAIN" 2>/dev/null | tail -1 || echo "")

    if [[ -z "$SERVER_IP" ]]; then
        warn "Could not detect server IP — skipping DNS check"
    elif [[ -z "$DOMAIN_IP" ]]; then
        warn "$DOMAIN does not resolve to any IP address"
        warn "HTTPS (Let's Encrypt) will fail without DNS pointed here"
        read -rp "  Continue anyway? (y/N): " DNS_CONTINUE
        [[ "$DNS_CONTINUE" != "y" ]] && exit 1
    elif [[ "$SERVER_IP" != "$DOMAIN_IP" ]]; then
        warn "$DOMAIN resolves to $DOMAIN_IP but this server is $SERVER_IP"
        warn "HTTPS (Let's Encrypt) will fail if DNS doesn't point here"
        read -rp "  Continue anyway? (y/N): " DNS_CONTINUE
        [[ "$DNS_CONTINUE" != "y" ]] && exit 1
    else
        log "$DOMAIN → $SERVER_IP (DNS OK)"
    fi
fi

read -rp "  Admin email: " ADMIN_EMAIL
ADMIN_EMAIL=${ADMIN_EMAIL:-admin@example.com}

read -srp "  Admin password: " ADMIN_PASSWORD
echo ""
ADMIN_PASSWORD=${ADMIN_PASSWORD:-changeme}
if [ ${#ADMIN_PASSWORD} -lt 8 ]; then
    err "Password must be at least 8 characters"
fi

read -srp "  OpenAI API key (optional, Enter to skip): " OPENAI_KEY
echo ""

read -rp "  PBX IP whitelist (comma-separated, optional): " CDR_IPS
echo ""

# ── Install system dependencies ────────────────────────
info "Installing system dependencies..."
apt-get update -qq
apt-get install -y -qq ca-certificates curl gnupg dnsutils git > /dev/null 2>&1
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs
log "System dependencies ready"

# ── Install Docker ─────────────────────────────────────
if ! command -v docker &>/dev/null; then
    info "Installing Docker Engine..."
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
        -o /etc/apt/keyrings/docker.asc
    chmod a+r /etc/apt/keyrings/docker.asc

    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] \
      https://download.docker.com/linux/ubuntu \
      $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
      > /etc/apt/sources.list.d/docker.list

    apt-get update -qq
    apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin

    systemctl enable --now docker
    log "Docker installed: $(docker --version)"
else
    log "Docker already installed: $(docker --version)"
fi

# Verify compose plugin
if ! docker compose version &>/dev/null; then
    err "docker compose plugin not found. Install docker-compose-plugin."
fi
log "Docker Compose: $(docker compose version --short)"

# ── Generate Secrets ───────────────────────────────────
gen() { openssl rand -base64 "$1" | tr -d '/+=' | head -c "$1"; }

CORES=$(nproc)
WORKER_REPLICAS=$(( CORES / 2 ))
[ "$WORKER_REPLICAS" -lt 1 ] && WORKER_REPLICAS=1
info "Detected ${CORES} CPU cores — using ${WORKER_REPLICAS} transcription worker(s)"

JWT_SECRET=$(gen 64)
MONGO_PASSWORD=$(gen 32)
REDIS_PASSWORD=$(gen 32)
MINIO_PASSWORD=$(gen 32)
GRAFANA_PASSWORD=$(gen 16)

log "Secrets generated"

# ── Write .env ─────────────────────────────────────────
cat > .env << ENVEOF
# Generated by install.sh at $(date -u +"%Y-%m-%dT%H:%M:%SZ")

DOMAIN=${DOMAIN}

MONGO_DB=vodia_cdr
MONGO_USER=vodia_app
MONGO_PASSWORD=${MONGO_PASSWORD}

REDIS_PASSWORD=${REDIS_PASSWORD}

MINIO_ROOT_USER=vodia
MINIO_ROOT_PASSWORD=${MINIO_PASSWORD}
MINIO_BUCKET=recordings

GRAFANA_USER=admin
GRAFANA_PASSWORD=${GRAFANA_PASSWORD}

API_PORT=3000
JWT_SECRET=${JWT_SECRET}

ADMIN_EMAIL=${ADMIN_EMAIL}
ADMIN_PASSWORD=${ADMIN_PASSWORD}

CDR_WHITELIST_IPS=${CDR_IPS}

OPENAI_API_KEY=${OPENAI_KEY}
OPENAI_MODEL=gpt-4o-mini
AI_AUTO_SUMMARIZE=false

# Transcription scaling. Whisper decode blocks, so parallelism comes from
# worker processes, not in-process concurrency. replicas x threads ~= cores.
WORKER_REPLICAS=${WORKER_REPLICAS}
WHISPER_NUM_THREADS=2
TRANSCRIPTION_CONCURRENCY=1

# Redis memory ceiling. noeviction is intentional -- BullMQ state
# must never be evicted. Raise on high-volume multi-tenant installs.
REDIS_MAXMEMORY=2gb

RP_ID=${DOMAIN}
RP_ORIGIN=$([ "$DOMAIN" = "localhost" ] && echo "http://localhost" || echo "https://${DOMAIN}")
RP_NAME=Vodia CDR Analytics

RATE_LIMIT_LOGIN=10
RATE_LIMIT_API=100
RATE_LIMIT_CDR=200
DATA_RETENTION_DAYS=0
SETUP_COMPLETE=true
ENVEOF

chmod 600 .env
log ".env generated"

# ── Build Frontend (Docker, no Node needed on host) ────
info "Building frontend (this takes ~60 seconds)..."
docker run --rm \
    -v "$(pwd)/frontend:/app" \
    -w /app \
    node:22-alpine \
    sh -c "npm ci --ignore-scripts 2>/dev/null && npm run build" 2>&1 | tail -3

if [ -f "frontend/dist/index.html" ]; then
    log "Frontend built successfully"
else
    err "Frontend build failed — check frontend/ for errors"
fi

# ── Create Grafana dirs ────────────────────────────────
mkdir -p setup
mkdir -p grafana/provisioning/datasources grafana/provisioning/dashboards
touch grafana/provisioning/datasources/.gitkeep grafana/provisioning/dashboards/.gitkeep

# ── Build & Start Containers ──────────────────────────
info "Building containers (worker downloads AI model ~150MB, first run takes 2-3 min)..."
docker compose build 2>&1 | tail -5

log "Starting services..."
docker compose up -d

# ── Wait for Health ────────────────────────────────────
info "Waiting for services to become healthy..."
MAX_WAIT=180
ELAPSED=0

while [[ $ELAPSED -lt $MAX_WAIT ]]; do
    if curl -sf http://localhost/health &>/dev/null 2>&1; then
        break
    fi
    sleep 3
    ELAPSED=$((ELAPSED + 3))
    echo -ne "\r  Waiting... ${ELAPSED}s / ${MAX_WAIT}s"
done
echo ""

if [[ $ELAPSED -ge $MAX_WAIT ]]; then
    warn "Timed out waiting for services."
    echo ""
    warn "Checking container status..."
    docker compose ps --format "table {{.Name}}\t{{.Status}}" 2>/dev/null || true
    echo ""
    warn "Check logs: docker compose logs api --tail 30"
    warn "Services may still be starting — try: curl http://localhost/health"
else
    log "All services healthy!"
fi

# ── UFW Firewall ───────────────────────────────────────
if command -v ufw &>/dev/null; then
    info "Configuring firewall..."
    ufw --force reset > /dev/null 2>&1
    ufw default deny incoming > /dev/null 2>&1
    ufw default allow outgoing > /dev/null 2>&1
    ufw allow ssh > /dev/null 2>&1
    ufw allow 80/tcp > /dev/null 2>&1
    ufw allow 443/tcp > /dev/null 2>&1
    ufw allow 443/udp > /dev/null 2>&1
    ufw --force enable > /dev/null 2>&1
    log "Firewall configured (SSH + HTTP/S only)"
fi

# ── Backup Cron ────────────────────────────────────────
if [ -f "scripts/backup.sh" ]; then
    CRON_LINE="0 3 * * * cd $(pwd) && bash scripts/backup.sh >> /var/log/vodia-backup.log 2>&1"
    (crontab -l 2>/dev/null | grep -v "vodia.*backup" ; echo "$CRON_LINE") | crontab -
    log "Daily backups configured (3:00 AM)"
fi

# ── Summary ────────────────────────────────────────────
echo ""
echo -e "${GREEN}════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  Installation Complete!                              ${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════${NC}"
echo ""

if [[ "$DOMAIN" == "localhost" ]]; then
    echo -e "  Dashboard:    ${CYAN}http://localhost${NC}"
else
    echo -e "  Dashboard:    ${CYAN}https://${DOMAIN}${NC}"
fi

echo ""
echo -e "  Admin Login:  ${YELLOW}${ADMIN_EMAIL}${NC}"
echo ""

if [[ "$DOMAIN" != "localhost" ]]; then
    echo -e "  ${CYAN}Configure your Vodia PBX:${NC}"
    echo -e "    webcdr URL:  ${YELLOW}https://${DOMAIN}/cdr${NC}"
    echo ""
fi

echo -e "  ${CYAN}Useful commands:${NC}"
echo -e "    docker compose logs -f api       — API logs"
echo -e "    docker compose logs -f worker    — Worker/AI logs"
echo -e "    docker compose ps                — Service status"
echo ""
echo -e "  ${CYAN}To update:${NC}"
echo -e "    git pull && docker compose build api worker && docker compose up -d"
echo ""

if [ -z "${OPENAI_KEY:-}" ]; then
    echo -e "  ${YELLOW}AI summaries disabled (no OpenAI key).${NC}"
    echo -e "  ${YELLOW}Add OPENAI_API_KEY to .env and run: docker compose restart api worker${NC}"
    echo ""
fi