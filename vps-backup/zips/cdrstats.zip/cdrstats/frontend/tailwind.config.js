/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        brand: {
          blue: "#007aff",
          green: "#34c759",
          red: "#ff3b30",
          orange: "#ff9500",
          purple: "#af52de",
          indigo: "#5856d6",
        },
        surface: {
          50: "#f8f9fa",
          100: "#f1f3f5",
          200: "#e9ecef",
          700: "#1e1e2e",
          800: "#16161f",
          850: "#121218",
          900: "#0a0a0f",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "-apple-system", "sans-serif"],
      },
      backdropBlur: {
        xs: "2px",
      },
    },
  },
  plugins: [],
};
