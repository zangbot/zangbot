/**
 * Shift UTC hourly data to a target timezone.
 *
 * Takes an array of 24 hourly buckets (indexed 0-23 in UTC)
 * and returns a new array re-indexed to the target timezone.
 *
 * @param {Array} hourlyUtc - 24 hourly buckets with `hour` field (0-23 UTC)
 * @param {string} [tz] - IANA timezone (e.g. "Australia/Sydney"). Omit for browser local.
 */
export function shiftHourlyToLocal(hourlyUtc, tz) {
  if (!hourlyUtc || hourlyUtc.length === 0) return hourlyUtc;

  // Calculate offset: use a reference date to find the UTC offset for the target timezone
  const offsetHours = getOffsetHours(tz);

  const shifted = new Array(24);

  for (let utcHour = 0; utcHour < 24; utcHour++) {
    const bucket = hourlyUtc.find(h => h.hour === utcHour) || {
      hour: utcHour, total: 0, inbound: 0, outbound: 0, internal: 0, abandoned: 0, answered: 0, avg_duration: 0,
    };

    let localHour = (utcHour + offsetHours) % 24;
    if (localHour < 0) localHour += 24;
    localHour = Math.round(localHour);

    shifted[localHour] = {
      ...bucket,
      hour: localHour,
      label: `${String(localHour).padStart(2, "0")}:00`,
    };
  }

  for (let i = 0; i < 24; i++) {
    if (!shifted[i]) {
      shifted[i] = { hour: i, label: `${String(i).padStart(2, "0")}:00`, total: 0, inbound: 0, outbound: 0, internal: 0, abandoned: 0, answered: 0 };
    }
  }

  return shifted;
}

/**
 * Get timezone label for display.
 * @param {string} [tz] - IANA timezone. Omit for browser local.
 * @returns {string} e.g. "AEST", "EST", "UTC+10"
 */
export function getTimezoneLabel(tz) {
  try {
    const opts = { timeZoneName: "short" };
    if (tz) opts.timeZone = tz;
    const fmt = new Intl.DateTimeFormat("en", opts);
    const parts = fmt.formatToParts(new Date());
    const tzPart = parts.find(p => p.type === "timeZoneName");
    return tzPart ? tzPart.value : "";
  } catch {
    const offset = getOffsetHours(tz);
    return `UTC${offset >= 0 ? "+" : ""}${offset}`;
  }
}

/**
 * Get the UTC offset in hours for a timezone.
 * @param {string} [tz] - IANA timezone. Omit for browser local.
 */
function getOffsetHours(tz) {
  if (!tz) {
    return -new Date().getTimezoneOffset() / 60;
  }
  // Compare UTC time with the timezone's local time
  const now = new Date();
  const utcStr = now.toLocaleString("en-US", { timeZone: "UTC" });
  const tzStr = now.toLocaleString("en-US", { timeZone: tz });
  const utcDate = new Date(utcStr);
  const tzDate = new Date(tzStr);
  return (tzDate - utcDate) / (1000 * 60 * 60);
}
