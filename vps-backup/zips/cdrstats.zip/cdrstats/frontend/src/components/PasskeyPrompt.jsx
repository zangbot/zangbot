import { useState, useEffect } from "react";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { Fingerprint, X } from "lucide-react";
import { startRegistration } from "@simplewebauthn/browser";

export default function PasskeyPrompt() {
  const { user } = useAuth();
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (!user) return;
    if (user.role === "super_admin") return;
    // Check if dismissed this session (shows again on next login)
    const dismissed = sessionStorage.getItem("passkey_prompt_dismissed");
    if (dismissed) return;
    // Check passkey count
    if (user.passkey_count === 0) setShow(true);
  }, [user]);

  const dismiss = () => {
    sessionStorage.setItem("passkey_prompt_dismissed", "1");
    setShow(false);
  };

  const register = async () => {
    setMsg(""); setLoading(true);
    try {
      const options = await api.post("/api/auth/passkey/register-options", {});
      if (options.error) { setMsg(options.error); setLoading(false); return; }
      const regResponse = await startRegistration({ optionsJSON: options });
      const result = await api.post("/api/auth/passkey/register-verify", regResponse);
      if (result.verified) {
        setMsg("Passkey registered!");
        setTimeout(() => setShow(false), 1500);
      } else {
        setMsg(result.error || "Failed");
      }
    } catch (err) {
      if (err.name === "NotAllowedError") setMsg("Cancelled");
      else setMsg(err.message);
    }
    setLoading(false);
  };

  if (!show) return null;

  return (
    <div className="mb-6 glass-card border-brand-indigo/30 bg-brand-indigo/5">
      <div className="flex items-start gap-4">
        <div className="p-3 rounded-xl bg-brand-indigo/15">
          <Fingerprint size={24} className="text-brand-indigo" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-base mb-1">Set up a Passkey</h3>
          <p className="text-sm opacity-50 mb-3">Sign in faster and more securely with your fingerprint, face, or security key. No more passwords to remember.</p>
          {msg && <div className={"text-sm mb-3 " + (msg.includes("registered") ? "text-brand-green" : "text-brand-red")}>{msg}</div>}
          <div className="flex items-center gap-3">
            <button onClick={register} disabled={loading}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium bg-brand-indigo text-white hover:bg-brand-indigo/80 transition-all disabled:opacity-50">
              <Fingerprint size={16} />
              {loading ? "Setting up..." : "Set up Passkey"}
            </button>
            <button onClick={dismiss} className="text-sm opacity-40 hover:opacity-70 transition">Maybe later</button>
          </div>
        </div>
        <button onClick={dismiss} className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition"><X size={16} className="opacity-30" /></button>
      </div>
    </div>
  );
}
