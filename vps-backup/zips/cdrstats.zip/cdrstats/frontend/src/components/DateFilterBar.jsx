import { useDateRange } from "../context/DateRangeContext";

export default function DateFilterBar() {
  const { preset, setPreset, customFrom, setCustomFrom, customTo, setCustomTo, PRESETS } = useDateRange();

  return (
    <div className="flex items-center gap-2 flex-wrap mb-6">
      {PRESETS.map(p => (
        <button key={p.value} onClick={() => setPreset(p.value)}
          className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
            preset === p.value ? "bg-brand-blue text-white shadow-sm shadow-brand-blue/30" : "bg-black/5 dark:bg-white/5 opacity-60 hover:opacity-100"
          }`}>
          {p.label}
        </button>
      ))}
      <button onClick={() => setPreset("custom")}
        className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
          preset === "custom" ? "bg-brand-blue text-white shadow-sm shadow-brand-blue/30" : "bg-black/5 dark:bg-white/5 opacity-60 hover:opacity-100"
        }`}>
        Custom
      </button>
      {preset === "custom" && (
        <div className="flex items-center gap-2 ml-2">
          <input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)}
            className="glass-input text-xs py-1.5 px-2" />
          <span className="opacity-30 text-xs">to</span>
          <input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)}
            className="glass-input text-xs py-1.5 px-2" />
        </div>
      )}
    </div>
  );
}
