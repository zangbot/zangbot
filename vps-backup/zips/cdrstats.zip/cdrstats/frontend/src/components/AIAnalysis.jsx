import { fmtISODateTime } from "../dateUtils";
import { useTenant } from "../context/TenantContext";
import { useState, useEffect } from "react";
import { api } from "../api/client";
import { Brain, Sparkles, Loader2, RefreshCw, MessageSquare, Tag, CheckCircle2, AlertTriangle, Minus, ChevronDown, ChevronUp } from "lucide-react";
import CallPlayer from "./CallPlayer";
import SyncedTranscript from "./SyncedTranscript";

const sentimentColors = {
  positive: { bg: "bg-brand-green/10", border: "border-brand-green/20", text: "text-brand-green", icon: CheckCircle2 },
  negative: { bg: "bg-brand-red/10", border: "border-brand-red/20", text: "text-brand-red", icon: AlertTriangle },
  neutral: { bg: "bg-brand-blue/10", border: "border-brand-blue/20", text: "text-brand-blue", icon: Minus },
};

function TranscriptViewer({ segments, isMono }) {
  const [expanded, setExpanded] = useState(true);

  if (!segments || segments.length === 0) return null;

  const speakerLabel = (s) => {
    if (isMono) return "Speaker";
    return s.speaker === "channel_0" ? "Caller 1" : "Caller 2";
  };

  const speakerColor = (s) => {
    if (isMono) return "text-brand-blue";
    return s.speaker === "channel_0" ? "text-brand-indigo" : "text-brand-green";
  };

  const speakerBg = (s) => {
    if (isMono) return "bg-brand-blue/5 border-brand-blue/10";
    return s.speaker === "channel_0" ? "bg-brand-indigo/5 border-brand-indigo/10" : "bg-brand-green/5 border-brand-green/10";
  };

  return (
    <div>
      <button onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-2 text-sm font-semibold mb-3 opacity-70 hover:opacity-100 transition">
        <MessageSquare size={16} />
        Transcript ({segments.length} segments)
        {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
      </button>

      {expanded && (
        <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
          {segments.map((s, i) => (
            <div key={i} className={`rounded-xl p-3 border ${speakerBg(s)}`}>
              <div className="flex items-center gap-2 mb-1">
                <span className={`text-[10px] font-bold uppercase ${speakerColor(s)}`}>
                  {speakerLabel(s)}
                </span>
                <span className="text-[10px] opacity-30 tabular-nums">
                  {s.start.toFixed(1)}s — {s.end.toFixed(1)}s
                </span>
              </div>
              <p className="text-sm leading-relaxed opacity-80">{s.text}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* Segment times are global across every recording on a call, but the player
   is per-recording. Match on recording_id, not array position: the worker
   skips recordings it cannot split, so their indexes drift apart. */
function metaForRecording(transcript, rec) {
  const meta = Array.isArray(transcript?.recordings_meta) ? transcript.recordings_meta : [];
  if (!rec || !rec._id || meta.length === 0) return null;
  return meta.find((m) => m && m.recording_id === String(rec._id)) || null;
}

/* Segments belonging to one recording, rebased to that file's own timeline.
   Falls back to the full global list for transcripts written before
   recordings_meta existed. */
function localSegments(transcript, rec) {
  const all = Array.isArray(transcript?.segments) ? transcript.segments : [];
  const m = metaForRecording(transcript, rec);
  if (!m) return all;
  const off = typeof m.offset_seconds === "number" ? m.offset_seconds : 0;
  const mine = all.filter((s) => s && s.recording === m.index);
  if (mine.length === 0) return all;
  return mine.map((s) => ({ ...s, start: s.start - off, end: s.end - off }));
}

function SummaryPanel({ summary, timezone }) {
  if (!summary) return null;

  const s = sentimentColors[summary.sentiment?.overall] || sentimentColors.neutral;
  const SentimentIcon = s.icon;

  return (
    <div className="space-y-4">
      {/* Sentiment Badge */}
      <div className={`${s.bg} ${s.border} border rounded-xl p-4`}>
        <div className="flex items-center gap-3 mb-2">
          <SentimentIcon size={20} className={s.text} />
          <div>
            <span className={`text-sm font-bold capitalize ${s.text}`}>
              {summary.sentiment?.overall || "Unknown"} Sentiment
            </span>
            {summary.sentiment?.confidence && (
              <span className="text-xs opacity-40 ml-2">
                ({Math.round(summary.sentiment.confidence * 100)}% confidence)
              </span>
            )}
          </div>
        </div>
        {summary.sentiment?.caller_mood && (
          <p className="text-xs opacity-60 mt-1">Caller: {summary.sentiment.caller_mood}</p>
        )}
        {summary.sentiment?.agent_performance && (
          <p className="text-xs opacity-60">Agent: {summary.sentiment.agent_performance}</p>
        )}
      </div>

      {/* Summary */}
      <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4">
        <h5 className="text-xs font-semibold opacity-40 uppercase tracking-wider mb-2">Summary</h5>
        <p className="text-sm leading-relaxed opacity-80">{summary.summary}</p>
      </div>

      {/* Resolution */}
      {summary.resolution && summary.resolution !== "unknown" && (
        <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4">
          <h5 className="text-xs font-semibold opacity-40 uppercase tracking-wider mb-2">Resolution</h5>
          <span className={`badge ${
            summary.resolution === "resolved" ? "badge-green" :
            summary.resolution === "unresolved" ? "badge-red" :
            summary.resolution === "callback_needed" ? "badge-orange" :
            "badge-blue"
          }`}>
            {summary.resolution.replace("_", " ")}
          </span>
        </div>
      )}

      {/* Topics */}
      {summary.topics?.length > 0 && (
        <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4">
          <h5 className="text-xs font-semibold opacity-40 uppercase tracking-wider mb-2">Topics</h5>
          <div className="flex flex-wrap gap-2">
            {summary.topics.map((t, i) => (
              <span key={i} className="badge-blue text-[10px]"><Tag size={10} className="mr-1" />{t}</span>
            ))}
          </div>
        </div>
      )}

      {/* Action Items */}
      {summary.action_items?.length > 0 && (
        <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4">
          <h5 className="text-xs font-semibold opacity-40 uppercase tracking-wider mb-2">Action Items</h5>
          <ul className="space-y-1">
            {summary.action_items.map((a, i) => (
              <li key={i} className="text-sm opacity-70 flex items-start gap-2">
                <CheckCircle2 size={14} className="text-brand-green flex-shrink-0 mt-0.5" />
                {a}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Key Phrases */}
      {summary.key_phrases?.length > 0 && (
        <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4">
          <h5 className="text-xs font-semibold opacity-40 uppercase tracking-wider mb-2">Key Phrases</h5>
          <div className="flex flex-wrap gap-2">
            {summary.key_phrases.map((p, i) => (
              <span key={i} className="badge-purple text-[10px]">"{p}"</span>
            ))}
          </div>
        </div>
      )}

      {/* Model info */}
      <div className="text-[10px] opacity-20 text-right">
        {summary.model} • {summary.generated_at ? fmtISODateTime(summary.generated_at, timezone) : ""}
      </div>
    </div>
  );
}

export default function AIAnalysis({
  callid,
  hasRecording,
  hasTranscript: initialHasTranscript,
  selectedRecording = null,
  currentTime = 0,
  view = "analysis",
}) {
  const { timezone } = useTenant();
  const [transcript, setTranscript] = useState(null);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);
  const [summarizing, setSummarizing] = useState(false);
  const [retranscribing, setRetranscribing] = useState(false);
  const [error, setError] = useState("");
  const [hasTranscript, setHasTranscript] = useState(initialHasTranscript);

  const loadTranscript = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await api.get(`/api/calls/${encodeURIComponent(callid)}/transcript`);
      setTranscript(data.transcript);
      setSummary(data.summary);
      setHasTranscript(true);
    } catch (err) {
      if (err.message.includes("404") || err.message.includes("No transcript")) {
        setError(hasRecording ? "Transcript is still processing..." : "No recording available for this call.");
      } else {
        setError(err.message);
      }
    }
    setLoading(false);
  };

  useEffect(() => {
    if (hasTranscript || hasRecording) loadTranscript();
  }, [callid]);

  const handleSummarize = async () => {
    setSummarizing(true);
    setError("");
    try {
      const data = await api.post(`/api/calls/${encodeURIComponent(callid)}/summarize`, {});
      setSummary(data.summary);
    } catch (err) {
      setError(err.message);
    }
    setSummarizing(false);
  };

  const handleRetranscribe = async () => {
    setRetranscribing(true);
    setError("");
    try {
      await api.post(`/api/calls/${encodeURIComponent(callid)}/retranscribe`, {});
      setTranscript(null);
      setSummary(null);
      setHasTranscript(false);
      setError("Re-transcription queued. Refresh in a moment to see the result.");
    } catch (err) {
      setError(err.message);
    }
    setRetranscribing(false);
  };

  if (!hasRecording && !hasTranscript) {
    return (
      <div className="text-center py-12">
        <Brain size={40} className="mx-auto mb-3 opacity-15" />
        <p className="text-sm opacity-30">No recording available for AI analysis</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with actions — analysis view only */}
      <div className={`items-center justify-between ${view === "transcript" ? "hidden" : "flex"}`}>
        <div className="flex items-center gap-2">
          <Brain size={20} className="text-brand-purple" />
          <h4 className="text-sm font-semibold">AI Analysis</h4>
        </div>
        <div className="flex items-center gap-2">
          {transcript && !summary && (
            <button onClick={handleSummarize} disabled={summarizing}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium bg-brand-purple/10 text-brand-purple hover:bg-brand-purple/20 transition-all disabled:opacity-50">
              {summarizing ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
              {summarizing ? "Analyzing..." : "Summarize with AI"}
            </button>
          )}
          {hasRecording && (
            <button onClick={handleRetranscribe} disabled={retranscribing}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium bg-black/5 dark:bg-white/5 opacity-50 hover:opacity-100 transition-all disabled:opacity-30"
              title="Re-transcribe from recording">
              {retranscribing ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />}
              Re-transcribe
            </button>
          )}
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="bg-brand-orange/10 border border-brand-orange/20 text-brand-orange text-sm px-4 py-3 rounded-xl">
          {error}
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="text-center py-12">
          <Loader2 size={24} className="mx-auto mb-3 animate-spin opacity-30" />
          <p className="text-sm opacity-30">Loading transcript...</p>
        </div>
      )}

      {/* Summary — analysis view only */}
      {view !== "transcript" && summary && <SummaryPanel summary={summary} timezone={timezone} />}

      {/* Transcript — transcript view only; follows the player, click to seek */}
      {view !== "analysis" && transcript && (
        <div>
          <div className="flex items-center gap-3 mb-2 text-xs opacity-30">
            <span>Model: {transcript.model}</span>
            <span>•</span>
            <span>Duration: {transcript.duration_seconds}s</span>
            <span>•</span>
            <span>{transcript.is_mono ? "Mono (single speaker)" : "Stereo (Caller 1 + Caller 2)"}</span>
          </div>
          {selectedRecording ? (
            <SyncedTranscript
              segments={localSegments(transcript, selectedRecording)}
              isMono={transcript.is_mono}
              currentTime={currentTime}
              coarse={(transcript.segmentation || "chunked") !== "vad"}
            />
          ) : (
            <TranscriptViewer segments={transcript.segments} isMono={transcript.is_mono} />
          )}
        </div>
      )}
    </div>
  );
}
