import { useEffect, useRef, useMemo } from "react";
import { MessageSquare, CornerDownRight } from "lucide-react";
import { fmtClock, seekActivePlayer } from "./CallPlayer";

/* Binary search for the segment containing t. Segments arrive sorted by start
   from the worker; we re-sort defensively because redaction can rewrite text
   and older transcripts predate the sort. */
function activeIndex(segs, t) {
  let lo = 0;
  let hi = segs.length - 1;
  let best = -1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (segs[mid].start <= t) {
      best = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  if (best >= 0 && t <= segs[best].end + 0.25) return best;
  return -1;
}

export default function SyncedTranscript({
  segments,
  isMono,
  currentTime = 0,
  coarse = false,
  autoScroll = true,
}) {
  const listRef = useRef(null);
  const lastActive = useRef(-1);

  const segs = useMemo(
    () => (Array.isArray(segments) ? segments.slice().sort((a, b) => a.start - b.start) : []),
    [segments]
  );

  const active = activeIndex(segs, currentTime);

  useEffect(() => {
    if (!autoScroll || active < 0 || active === lastActive.current) return;
    lastActive.current = active;
    const el = listRef.current?.querySelector(`[data-seg="${active}"]`);
    if (el && el.scrollIntoView) el.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [active, autoScroll]);

  if (segs.length === 0) return null;

  const label = (s) => (isMono ? "Speaker" : s.speaker === "channel_0" ? "Caller 1" : "Caller 2");
  const tone = (s) =>
    isMono ? "text-brand-blue" : s.speaker === "channel_0" ? "text-brand-indigo" : "text-brand-green";

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <span className="flex items-center gap-2 text-sm font-semibold opacity-70">
          <MessageSquare size={16} />
          Transcript ({segs.length} {coarse ? "segments" : "utterances"})
        </span>
        {coarse && (
          <span
            className="text-[10px] px-2 py-0.5 rounded-lg bg-brand-orange/10 text-brand-orange"
            title="Transcribed before utterance-level segmentation — timings are 28-second blocks"
          >
            coarse timings
          </span>
        )}
      </div>

      <div ref={listRef} className="space-y-1 max-h-[420px] overflow-y-auto pr-2">
        {segs.map((s, i) => {
          const on = i === active;
          return (
            <button
              key={i}
              data-seg={i}
              onClick={() => seekActivePlayer(s.start)}
              className={`w-full text-left flex gap-3 items-baseline px-2.5 py-2 rounded-xl border-l-[3px] transition-all ${
                on
                  ? "bg-brand-purple/10 border-brand-purple"
                  : "border-transparent hover:bg-black/5 dark:hover:bg-white/5"
              }`}
            >
              <span className="text-[10px] tabular-nums opacity-30 min-w-[34px] pt-0.5">
                {fmtClock(s.start)}
              </span>
              <span className={`text-[10px] font-bold uppercase min-w-[52px] pt-0.5 ${tone(s)}`}>
                {label(s)}
              </span>
              <span
                className={`text-sm leading-relaxed flex-1 ${on ? "opacity-100" : "opacity-70"}`}
              >
                {s.text}
              </span>
            </button>
          );
        })}
      </div>

      <p className="text-[10px] opacity-25 mt-2 flex items-center gap-1">
        <CornerDownRight size={10} /> click any line to jump - space plays, arrows skip 5s
      </p>
    </div>
  );
}
