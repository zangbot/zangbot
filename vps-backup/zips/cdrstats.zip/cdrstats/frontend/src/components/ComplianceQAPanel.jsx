import { ShieldCheck, ShieldAlert, Award, Play } from "lucide-react";
import { seekActivePlayer, fmtClock } from "./CallPlayer";

const SEV = { low: "badge-blue", medium: "badge-orange", high: "badge-red", critical: "badge-red" };

export default function ComplianceQAPanel({ call }) {
  const comp = call?.compliance;
  const qa = call?.qa;
  if (!comp && !qa) return null;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
      {comp && (
        <div className="glass-card">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              {comp.passed ? <ShieldCheck size={16} className="text-brand-green" /> : <ShieldAlert size={16} className="text-brand-red" />}
              Compliance
            </h4>
            <span className={comp.passed ? "badge-green" : "badge-red"}>{comp.score} / 100</span>
          </div>
          {comp.passed ? (
            <p className="text-xs opacity-50">All {comp.rules_evaluated} applicable rule{comp.rules_evaluated === 1 ? "" : "s"} passed.</p>
          ) : (
            <div className="space-y-2">
              {(comp.violations || []).map((v, i) => (
                <div key={i} className="p-2.5 rounded-lg bg-brand-red/5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium">{v.name}</span>
                    <span className={"text-[9px] uppercase font-bold px-1.5 py-0.5 rounded-full shrink-0 " + (SEV[v.severity] || "badge-gray")}>{v.severity}</span>
                  </div>
                  {v.evidence && <p className="text-[11px] opacity-50 mt-1 italic">"{v.evidence}"</p>}
                  {typeof v.at_seconds === "number" && (
                    <button onClick={() => seekActivePlayer(v.at_seconds)}
                      className="mt-1.5 inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-lg bg-brand-red/10 text-brand-red hover:bg-brand-red/20 transition"
                      title="Play the recording from this point">
                      <Play size={9} /> {fmtClock(v.at_seconds)}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
          {comp.unevaluated?.length > 0 && (
            <p className="text-[11px] text-brand-yellow mt-2">{comp.unevaluated.length} rule(s) could not be evaluated (AI unavailable).</p>
          )}
          <p className="text-[10px] opacity-25 mt-2">Evaluated {comp.evaluated_at ? new Date(comp.evaluated_at).toLocaleString() : ""}</p>
        </div>
      )}

      {qa && (
        <div className="glass-card">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-semibold flex items-center gap-2"><Award size={16} className="text-brand-purple" /> QA Scorecard</h4>
            <span className="badge-purple">{qa.score} / 100</span>
          </div>
          <div className="space-y-1.5 mb-3">
            {Object.entries(qa.categories || {}).map(([k, c]) => (c && c.score != null) ? (
              <div key={k}>
                <div className="flex items-center justify-between text-[11px] mb-0.5">
                  <span className="opacity-60">{c.label || k}</span>
                  <span className="font-semibold tabular-nums">{c.score}</span>
                </div>
                <div className="h-1 rounded-full bg-black/5 dark:bg-white/5">
                  <div className={"h-1 rounded-full " + (c.score >= 80 ? "bg-brand-green" : c.score >= 60 ? "bg-brand-yellow" : "bg-brand-red")} style={{ width: c.score + "%" }} />
                </div>
                {c.comment && <p className="text-[10px] opacity-35 mt-0.5">{c.comment}</p>}
              </div>
            ) : null)}
          </div>
          {qa.strengths?.length > 0 && (
            <p className="text-[11px] opacity-50 mb-1"><span className="font-semibold">Strengths:</span> {qa.strengths.join("; ")}</p>
          )}
          {qa.coaching_tip && (
            <p className="text-[11px] text-brand-blue"><span className="font-semibold">Coaching:</span> {qa.coaching_tip}</p>
          )}
          {qa.overall_comment && <p className="text-[11px] opacity-50 mt-1">{qa.overall_comment}</p>}
        </div>
      )}
    </div>
  );
}
