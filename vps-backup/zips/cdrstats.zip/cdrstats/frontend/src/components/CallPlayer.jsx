import { useEffect, useRef, useState, useCallback } from "react";
import WaveSurfer from "wavesurfer.js";
import { Play, Pause, Rewind, FastForward, Download, AudioLines } from "lucide-react";

/* Module-level handle so panels elsewhere in the drawer (compliance
   violations, QA notes) can seek the player without prop drilling. */
let activeSeek = null;
export function seekActivePlayer(seconds) {
  if (typeof activeSeek === "function") activeSeek(seconds);
  return typeof activeSeek === "function";
}
export function hasActivePlayer() {
  return typeof activeSeek === "function";
}

function decodePeaks(b64) {
  if (!b64 || typeof b64 !== "string") return null;
  try {
    const bin = atob(b64);
    const out = new Float32Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i) / 255;
    return out;
  } catch {
    return null;
  }
}

export function fmtClock(s) {
  if (!isFinite(s) || s < 0) s = 0;
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return m + ":" + String(r).padStart(2, "0");
}

const RATES = [0.75, 1, 1.25, 1.5, 2];

export default function CallPlayer({ recording, markers = [], onTime, onReady, onPlay, autoPlay = false }) {
  const holder = useRef(null);
  const ws = useRef(null);
  const [ready, setReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [dur, setDur] = useState(recording?.duration_seconds || 0);
  const [rate, setRate] = useState(1);
  const [failed, setFailed] = useState("");

  const src = recording?.play_url || (recording?._id ? "/api/recordings/play/" + recording._id : null);

  useEffect(() => {
    if (!holder.current || !src) return;
    let dead = false;

    const p0 = decodePeaks(recording?.peaks_ch0);
    const p1 = decodePeaks(recording?.peaks_ch1);
    const peaks = p0 ? (p1 ? [p0, p1] : [p0]) : undefined;
    const known = Number(recording?.duration_seconds) || 0;

    const style = getComputedStyle(document.documentElement);
    const dark = document.documentElement.classList.contains("dark");

    let inst;
    try {
      inst = WaveSurfer.create({
        container: holder.current,
        height: peaks && peaks.length > 1 ? 44 : 64,
        waveColor: dark ? "rgba(148,163,184,0.45)" : "rgba(100,116,139,0.35)",
        progressColor: "#7f77dd",
        cursorColor: dark ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.45)",
        cursorWidth: 1,
        barWidth: 2,
        barGap: 1,
        barRadius: 2,
        normalize: !peaks,
        interact: true,
        url: src,
        ...(peaks && known > 0 ? { peaks, duration: known } : {}),
        ...(peaks && peaks.length > 1 ? { splitChannels: [{}, {}] } : {}),
      });
    } catch (e) {
      setFailed(e.message || "Could not initialise the waveform");
      return;
    }

    ws.current = inst;

    inst.on("ready", () => {
      if (dead) return;
      setReady(true);
      const d = inst.getDuration() || known;
      setDur(d);
      if (onReady) onReady(d);
      if (autoPlay) {
        try {
          inst.play();
        } catch {
          /* browsers may refuse autoplay without a fresh gesture */
        }
      }
    });
    inst.on("timeupdate", (t) => {
      if (dead) return;
      setTime(t);
      if (onTime) onTime(t);
    });
    inst.on("play", () => {
      if (dead) return;
      setPlaying(true);
      if (onPlay) onPlay();
    });
    inst.on("pause", () => !dead && setPlaying(false));
    inst.on("finish", () => !dead && setPlaying(false));
    inst.on("error", (e) => {
      if (dead) return;
      setFailed(typeof e === "string" ? e : (e && e.message) || "Playback failed");
    });

    activeSeek = (seconds) => {
      const d = inst.getDuration() || known;
      if (!d) return;
      inst.seekTo(Math.max(0, Math.min(1, seconds / d)));
      if (!inst.isPlaying()) inst.play();
    };

    return () => {
      dead = true;
      if (activeSeek) activeSeek = null;
      try {
        inst.destroy();
      } catch {
        /* wavesurfer throws on destroy mid-fetch; harmless */
      }
      ws.current = null;
    };
  }, [src, recording?.peaks_ch0, recording?.peaks_ch1]);

  const toggle = useCallback(() => {
    if (ws.current) ws.current.playPause();
  }, []);

  const nudge = useCallback((delta) => {
    const w = ws.current;
    if (!w) return;
    const d = w.getDuration();
    if (!d) return;
    w.seekTo(Math.max(0, Math.min(1, (w.getCurrentTime() + delta) / d)));
  }, []);

  const changeRate = (r) => {
    setRate(r);
    if (ws.current) ws.current.setPlaybackRate(r, true);
  };

  useEffect(() => {
    const onKey = (e) => {
      if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
      if (e.code === "Space") {
        e.preventDefault();
        toggle();
      } else if (e.code === "ArrowLeft") {
        nudge(-5);
      } else if (e.code === "ArrowRight") {
        nudge(5);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle, nudge]);

  if (!src) return null;

  const pct = dur > 0 ? Math.min(100, (time / dur) * 100) : 0;
  const hasPeaks = !!recording?.peaks_ch0;

  return (
    <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs opacity-50 flex items-center gap-1.5">
          <AudioLines size={13} className="text-brand-purple" />
          {recording?.original_filename || "Recording"}
        </span>
        <span className="text-[11px] opacity-30">
          {recording?.size_bytes ? (recording.size_bytes / 1024).toFixed(0) + " KB" : ""}
          {!hasPeaks && <span className="ml-2">no stored waveform</span>}
        </span>
      </div>

      {failed ? (
        <div className="mb-3">
          <div className="text-xs text-brand-orange mb-2">{failed}</div>
          <audio controls className="w-full h-10" preload="metadata" src={src} />
        </div>
      ) : (
        <div className="relative mb-3">
          <div ref={holder} />
          {markers.map((m, i) =>
            dur > 0 && m.at_seconds != null ? (
              <button
                key={i}
                onClick={() => seekActivePlayer(m.at_seconds)}
                title={m.label || "Jump here"}
                aria-label={m.label || "Jump to marker"}
                className="absolute top-0 bottom-0 w-[2px] bg-brand-red/70 hover:bg-brand-red cursor-pointer"
                style={{ left: Math.min(99.7, (m.at_seconds / dur) * 100) + "%" }}
              />
            ) : null
          )}
          {!ready && (
            <div className="absolute inset-0 flex items-center justify-center text-[11px] opacity-30">
              loading waveform...
            </div>
          )}
        </div>
      )}

      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={() => nudge(-5)}
          aria-label="Back 5 seconds"
          className="p-2 rounded-xl hover:bg-black/10 dark:hover:bg-white/10 transition opacity-60 hover:opacity-100"
        >
          <Rewind size={15} />
        </button>
        <button
          onClick={toggle}
          aria-label={playing ? "Pause" : "Play"}
          className="p-2.5 rounded-full bg-brand-purple/15 text-brand-purple hover:bg-brand-purple/25 transition"
        >
          {playing ? <Pause size={16} /> : <Play size={16} />}
        </button>
        <button
          onClick={() => nudge(5)}
          aria-label="Forward 5 seconds"
          className="p-2 rounded-xl hover:bg-black/10 dark:hover:bg-white/10 transition opacity-60 hover:opacity-100"
        >
          <FastForward size={15} />
        </button>

        <span className="text-xs tabular-nums opacity-50 ml-1">
          {fmtClock(time)} / {fmtClock(dur)}
        </span>

        <div className="flex-1" />

        <div className="flex items-center gap-0.5">
          {RATES.map((r) => (
            <button
              key={r}
              onClick={() => changeRate(r)}
              className={`text-[11px] px-1.5 py-1 rounded-lg transition ${
                rate === r ? "bg-brand-purple/15 text-brand-purple" : "opacity-35 hover:opacity-70"
              }`}
            >
              {r}x
            </button>
          ))}
        </div>

        <a
          href={src}
          download={recording?.original_filename || "recording.wav"}
          aria-label="Download recording"
          className="p-2 rounded-xl hover:bg-black/10 dark:hover:bg-white/10 transition opacity-50 hover:opacity-100"
        >
          <Download size={15} />
        </a>
      </div>

      <div className="mt-2 h-[2px] bg-black/5 dark:bg-white/10 rounded-full overflow-hidden">
        <div className="h-full bg-brand-purple/40" style={{ width: pct + "%" }} />
      </div>
    </div>
  );
}
