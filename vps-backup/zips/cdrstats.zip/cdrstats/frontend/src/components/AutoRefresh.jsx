import { useState, useEffect, useCallback, useRef } from "react";
import { RefreshCw } from "lucide-react";

export function useAutoRefresh(loadFn, intervalSec = 60) {
  const [lastRefresh, setLastRefresh] = useState(Date.now());
  const [ago, setAgo] = useState("just now");
  const [refreshing, setRefreshing] = useState(false);
  const [paused, setPaused] = useState(false);
  const timerRef = useRef(null);
  const agoRef = useRef(null);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try { await loadFn(); } catch(e) { console.error(e); }
    setLastRefresh(Date.now());
    setRefreshing(false);
  }, [loadFn]);

  // Auto-refresh interval
  useEffect(() => {
    if (paused) return;
    timerRef.current = setInterval(() => { refresh(); }, intervalSec * 1000);
    return () => clearInterval(timerRef.current);
  }, [refresh, intervalSec, paused]);

  // Update "ago" text every 5s
  useEffect(() => {
    const update = () => {
      const diff = Math.floor((Date.now() - lastRefresh) / 1000);
      if (diff < 5) setAgo("just now");
      else if (diff < 60) setAgo(diff + "s ago");
      else setAgo(Math.floor(diff / 60) + "m ago");
    };
    update();
    agoRef.current = setInterval(update, 5000);
    return () => clearInterval(agoRef.current);
  }, [lastRefresh]);

  return { refresh, refreshing, ago, paused, setPaused };
}

export function RefreshIndicator({ refresh, refreshing, ago, paused, setPaused, interval }) {
  return (
    <div className="flex items-center gap-3">
      <button onClick={refresh} disabled={refreshing}
        className={"p-2 rounded-lg transition-all hover:bg-black/5 dark:hover:bg-white/5 " + (refreshing ? "animate-spin" : "")}
        title="Refresh now">
        <RefreshCw size={15} className={refreshing ? "text-brand-blue" : "opacity-30"} />
      </button>
      <span className="text-xs opacity-30 tabular-nums whitespace-nowrap">{ago}</span>
      <button onClick={() => setPaused(!paused)}
        className={"text-[10px] px-2 py-0.5 rounded-md transition-all " + (paused ? "bg-brand-orange/15 text-brand-orange" : "bg-black/5 dark:bg-white/5 opacity-30 hover:opacity-60")}
        title={paused ? "Resume auto-refresh" : "Pause auto-refresh"}>
        {paused ? "Paused" : interval + "s"}
      </button>
    </div>
  );
}
