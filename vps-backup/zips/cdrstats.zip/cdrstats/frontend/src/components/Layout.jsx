import { Outlet, NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useTenant } from "../context/TenantContext";
import { useTheme } from "../context/ThemeContext";
import { LayoutDashboard, Phone, Headphones, Settings, LogOut, Activity, Building, ChevronDown, Sun, Moon, Search, Brain, Radio, Clock, ShieldCheck } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import LicenseBanner from "./LicenseBanner";
import LicenseGate from "./LicenseGate";


function TimezonePill() {
  const { timezone } = useTenant();
  if (!timezone) return null;

  // Get abbreviated timezone name
  let abbr = "";
  try {
    const parts = new Intl.DateTimeFormat("en", { timeZone: timezone, timeZoneName: "short" }).formatToParts(new Date());
    abbr = parts.find(p => p.type === "timeZoneName")?.value || "";
  } catch {}

  // Friendly label: "Australia/Sydney" → "Sydney"
  const short = timezone.split("/").pop().replace(/_/g, " ");

  return (
    <div className="mx-4 mb-1 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-brand-orange/10 text-brand-orange text-[11px] font-medium">
      <Clock size={12} />
      <span>{short}</span>
      {abbr && <span className="opacity-50">({abbr})</span>}
    </div>
  );
}

const nav = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/calls", label: "Calls", icon: Phone },
  { to: "/queues", label: "Queues", icon: Activity },
  { to: "/agents", label: "Extensions & Numbers", icon: Headphones },
  { to: "/insights", label: "AI Insights", icon: Brain },
  { to: "/compliance", label: "Compliance", icon: ShieldCheck },
  { to: "/live", label: "Live", icon: Radio },
  { to: "/admin", label: "Admin", icon: Settings },
];

function TenantSwitcher() {
  const { tenants, activeTenant, setActiveTenant, loading } = useTenant();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) { setOpen(false); setSearch(""); } };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => { if (open && inputRef.current) inputRef.current.focus(); }, [open]);

  if (loading || tenants.length === 0) return null;

  const filtered = tenants.filter(t =>
    (t.display_name || t.domain).toLowerCase().includes(search.toLowerCase()) ||
    t.domain.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="px-4 pb-4 relative" ref={ref}>
      <div className="text-[10px] uppercase tracking-wider opacity-30 font-semibold mb-2 px-1">Tenant</div>
      <button onClick={() => { setOpen(!open); setSearch(""); }}
        className="w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/[0.08] hover:bg-black/10 dark:hover:bg-white/10 transition-all text-sm">
        <div className="flex items-center gap-2 min-w-0">
          <Building size={14} className="text-brand-blue flex-shrink-0" />
          <span className="truncate opacity-80">{activeTenant ? (activeTenant.display_name || activeTenant.domain) : "All Tenants"}</span>
        </div>
        <ChevronDown size={14} className={`opacity-40 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="absolute left-4 right-4 z-50 mt-1 bg-white dark:bg-surface-800 border border-black/10 dark:border-white/10 rounded-xl overflow-hidden shadow-2xl shadow-black/30">
          <div className="p-2 border-b border-black/5 dark:border-white/5">
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 opacity-30" />
              <input ref={inputRef} className="w-full bg-black/5 dark:bg-white/5 rounded-lg pl-8 pr-3 py-2 text-sm outline-none placeholder-black/30 dark:placeholder-white/30"
                placeholder="Search tenants..." value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto">
            <button onClick={() => { setActiveTenant(null); setOpen(false); setSearch(""); }}
              className={`w-full text-left px-3 py-2.5 text-sm transition-all hover:bg-black/5 dark:hover:bg-white/5 ${!activeTenant ? "text-brand-blue bg-brand-blue/10" : "opacity-60"}`}>
              All Tenants
            </button>
            {filtered.map(t => (
              <button key={t._id} onClick={() => { setActiveTenant(t); setOpen(false); setSearch(""); }}
                className={`w-full text-left px-3 py-2.5 text-sm transition-all hover:bg-black/5 dark:hover:bg-white/5 border-t border-black/5 dark:border-white/5 ${activeTenant?._id === t._id ? "text-brand-blue bg-brand-blue/10" : "opacity-60"}`}>
                <div className="truncate">{t.display_name || t.domain}</div>
                <div className="text-[10px] opacity-30 truncate">{t.system}</div>
              </button>
            ))}
            {filtered.length === 0 && <div className="px-3 py-4 text-sm opacity-30 text-center">No tenants match</div>}
          </div>
        </div>
      )}
    </div>
  );
}

export default function Layout() {
  const { user, logout } = useAuth();
  const { dark, toggle } = useTheme();

  return (
    <div className="min-h-screen flex bg-surface-50 dark:bg-surface-900 text-surface-900 dark:text-white">
      <aside className="w-64 flex-shrink-0 border-r border-black/5 dark:border-white/5 bg-white dark:bg-surface-850 flex flex-col">
        <div className="p-6 border-b border-black/5 dark:border-white/5 flex items-center justify-between">
          <div><h1 className="text-lg font-bold tracking-tight">Vodia</h1><p className="text-xs opacity-40 mt-1">Analytics</p></div>
          <button onClick={toggle} className="p-2 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition" title={dark ? "Light mode" : "Dark mode"}>
            {dark ? <Sun size={18} className="text-brand-orange" /> : <Moon size={18} className="text-brand-indigo" />}
          </button>
        </div>
        <TenantSwitcher />
        <TimezonePill />
        <nav className="flex-1 p-4 space-y-1">
          {nav.filter(n => n.to !== "/admin" || user?.role === "super_admin" || user?.role === "admin")
            .map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isActive ? "bg-brand-blue/15 text-brand-blue" : "opacity-50 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/5"
                }`}>
              <Icon size={18} />{label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-black/5 dark:border-white/5">
          <div className="text-[10px] opacity-20 text-center mb-3">Vodia Analytics 1.2.5</div>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-full bg-brand-blue/20 flex items-center justify-center text-brand-blue text-xs font-bold">{user?.email?.[0]?.toUpperCase() || "?"}</div>
            <div className="flex-1 min-w-0"><div className="text-sm font-medium truncate">{user?.email}</div><div className="text-xs opacity-40 capitalize">{user?.role?.replace("_", " ")}</div></div>
          </div>
          <button onClick={logout} className="w-full flex items-center gap-2 px-4 py-2 rounded-xl text-sm opacity-40 hover:text-brand-red hover:opacity-100 hover:bg-brand-red/10 transition-all"><LogOut size={16} /> Sign Out</button>
        </div>
      </aside>
      <div className="flex-1 flex flex-col overflow-hidden">
        <LicenseBanner />
        <main className="flex-1 overflow-y-auto"><div className="p-8"><LicenseGate><Outlet /></LicenseGate></div></main>
      </div>
    </div>
  );
}
