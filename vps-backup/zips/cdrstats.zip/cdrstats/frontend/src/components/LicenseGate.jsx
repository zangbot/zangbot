import { useLicense } from "../context/LicenseContext";
import { ShieldAlert } from "lucide-react";

export default function LicenseGate({ children }) {
  const { license, loading } = useLicense();
  if (loading) return null;
  if (!license || license.mode !== "cloud" || !license.locked) return children;

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-10">
      <ShieldAlert size={64} className="text-red-500 mb-5" />
      <h2 className="text-2xl font-semibold mb-3">Plan Limit Exceeded</h2>
      <p className="text-base opacity-60 max-w-lg leading-relaxed">
        Your instance has <strong>{license.extensionCount}</strong> active extensions
        but your <strong>{license.planName}</strong> plan allows <strong>{license.limit}</strong>.
      </p>
      <p className="text-base opacity-60 max-w-lg mt-3 leading-relaxed">
        Please upgrade your plan in your cloud provider marketplace to restore access.
      </p>
      <p className="text-sm opacity-40 mt-6">
        CDR data continues to be collected and will be available after upgrading.
      </p>
    </div>
  );
}
