import { useState, useRef, useEffect } from "react";
import { api } from "../api/client";
import { ShieldCheck, ShieldOff, QrCode, Copy, Check } from "lucide-react";

export default function TotpSetup() {
  const [status, setStatus] = useState(null);
  const [setup, setSetup] = useState(null);
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const codeRefs = useRef([]);

  const loadStatus = async () => {
    try { setStatus(await api.get("/api/auth/totp/status")); } catch (e) { console.error(e); }
  };
  useEffect(() => { loadStatus(); }, []);

  const startSetup = async () => {
    setError(""); setSuccess(""); setLoading(true);
    try {
      const data = await api.post("/api/auth/totp/setup");
      if (data.error) { setError(data.error); setLoading(false); return; }
      setSetup(data);
      setCode(["", "", "", "", "", ""]);
      setTimeout(() => codeRefs.current[0]?.focus(), 100);
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const handleInput = (index, value) => {
    if (!/^\d*$/.test(value)) return;
    const newCode = [...code];
    newCode[index] = value.slice(-1);
    setCode(newCode);
    if (value && index < 5) codeRefs.current[index + 1]?.focus();
    if (newCode.every(d => d !== "") && newCode.join("").length === 6) verifyCode(newCode.join(""));
  };

  const handleKeyDown = (index, e) => {
    if (e.key === "Backspace" && !code[index] && index > 0) codeRefs.current[index - 1]?.focus();
  };

  const handlePaste = (e) => {
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    if (pasted.length === 6) { setCode(pasted.split("")); verifyCode(pasted); }
  };

  const verifyCode = async (codeStr) => {
    setError(""); setLoading(true);
    try {
      const data = await api.post("/api/auth/totp/enable", { code: codeStr });
      if (data.error) {
        setError(data.error);
        setCode(["", "", "", "", "", ""]);
        setTimeout(() => codeRefs.current[0]?.focus(), 100);
      } else { setSuccess("2FA is now active!"); setSetup(null); loadStatus(); }
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const disableTotp = async () => {
    if (!confirm("Are you sure you want to disable 2FA?")) return;
    setError(""); setLoading(true);
    try {
      const data = await api.post("/api/auth/totp/disable");
      if (data.error) setError(data.error);
      else { setSuccess("2FA has been disabled."); setSetup(null); loadStatus(); }
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const copyKey = () => {
    navigator.clipboard.writeText(setup.manual_key);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!status) return null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ShieldCheck size={20} className={status.totp_enabled ? "text-brand-green" : "opacity-30"} />
          <div>
            <div className="text-sm font-medium">Two-Factor Authentication</div>
            <div className="text-xs opacity-40">
              {status.totp_enabled ? "Enabled — your account is protected" : "Not configured"}
              {status.totp_enforced && !status.totp_enabled && " — Required for your account"}
            </div>
          </div>
        </div>
        {status.totp_enabled ? (
          <button onClick={disableTotp} disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-brand-red bg-brand-red/10 hover:bg-brand-red/20 transition">
            <ShieldOff size={14} /> Disable 2FA
          </button>
        ) : (
          <button onClick={startSetup} disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-brand-blue bg-brand-blue/10 hover:bg-brand-blue/20 transition">
            <QrCode size={14} /> {loading ? "Loading..." : "Set Up 2FA"}
          </button>
        )}
      </div>

      {error && <div className="p-3 rounded-xl bg-brand-red/10 text-brand-red text-sm">{error}</div>}
      {success && <div className="p-3 rounded-xl bg-brand-green/10 text-brand-green text-sm">{success}</div>}

      {setup && (
        <div className="border border-black/10 dark:border-white/[0.08] rounded-xl p-5 space-y-4">
          <div className="text-center">
            <p className="text-sm font-medium mb-3">Scan this QR code with your authenticator app</p>
            <img src={setup.qr} alt="TOTP QR Code" className="mx-auto rounded-xl" style={{ width: 200, height: 200 }} />
          </div>
          <div className="text-center">
            <p className="text-xs opacity-40 mb-1">Or enter this key manually:</p>
            <div className="flex items-center justify-center gap-2">
              <code className="text-xs font-mono bg-black/5 dark:bg-white/5 px-3 py-1.5 rounded-lg select-all">{setup.manual_key}</code>
              <button onClick={copyKey} className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition">
                {copied ? <Check size={14} className="text-brand-green" /> : <Copy size={14} className="opacity-40" />}
              </button>
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-center mb-3">Enter the 6-digit code to verify</p>
            <div className="flex justify-center gap-2" onPaste={handlePaste}>
              {code.map((digit, i) => (
                <input key={i} ref={el => codeRefs.current[i] = el}
                  type="text" inputMode="numeric" maxLength={1} value={digit}
                  onChange={e => handleInput(i, e.target.value)}
                  onKeyDown={e => handleKeyDown(i, e)}
                  className="w-11 h-13 text-center text-xl font-mono rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/[0.08] outline-none focus:border-brand-blue transition" />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
