import { useState } from "react";
import { Download, Check, Loader2 } from "lucide-react";

export default function ExportButton({ url, label = "Export CSV" }) {
  const [state, setState] = useState("idle"); // idle | loading | done

  const doExport = async () => {
    setState("loading");
    try {
      const token = localStorage.getItem("access_token");
      const r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) throw new Error("Export failed");
      const blob = await r.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      const cd = r.headers.get("Content-Disposition") || "";
      const fn = cd.match(/filename="([^"]+)"/)?.[1] || `export-${Date.now()}.csv`;
      a.download = fn;
      a.click();
      URL.revokeObjectURL(a.href);
      setState("done");
      setTimeout(() => setState("idle"), 2000);
    } catch (e) {
      console.error(e);
      setState("idle");
    }
  };

  return (
    <button onClick={doExport} disabled={state === "loading"}
      className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium bg-brand-green/10 text-brand-green hover:bg-brand-green/20 transition-all disabled:opacity-50">
      {state === "loading" ? <Loader2 size={14} className="animate-spin" /> : state === "done" ? <Check size={14} /> : <Download size={14} />}
      {state === "done" ? "Downloaded" : label}
    </button>
  );
}
