import { useState, useEffect, useCallback } from "react";
import { api } from "../api/client";
import { CalendarClock, Plus, Trash2, Play, Save, Pencil } from "lucide-react";

const EMPTY_SCHED = { context: "dashboard", frequency: "weekly", hour: 8, day_of_week: 1, day_of_month: 1, range: "last_7d", recipients: "", domain: "", enabled: true };
const DOWS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export default function BriefingSchedules() {
  const [schedules, setSchedules] = useState([]);
  const [tenants, setTenants] = useState([]);
  const [form, setForm] = useState(null);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";

  const load = useCallback(() => {
    api.get("/api/briefing/schedules").then(d => setSchedules(d.schedules || [])).catch(console.error);
  }, []);

  useEffect(() => {
    load();
    api.get("/api/tenants").then(d => setTenants(d.tenants || [])).catch(console.error);
  }, [load]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  // Timezone follows the selected tenant; falls back to browser timezone
  const tzFor = (domain) => {
    const t = tenants.find(x => x.domain === domain);
    return (t && t.timezone) || browserTz;
  };

  const save = async () => {
    setBusy(true); setMsg(null);
    try {
      const body = { ...form, domain: form.domain || null, timezone: tzFor(form.domain) };
      if (form._id) await api.put("/api/briefing/schedules/" + form._id, body);
      else await api.post("/api/briefing/schedules", body);
      setMsg({ ok: true, text: "Schedule saved" }); setForm(null); load();
    } catch (e) { setMsg({ ok: false, text: e.message }); }
    setBusy(false);
  };

  const runNow = async (s) => {
    setMsg({ ok: true, text: "Generating briefing — this can take up to a minute..." });
    try { const r = await api.post("/api/briefing/schedules/" + s._id + "/run", {}); setMsg({ ok: true, text: r.message }); load(); }
    catch (e) { setMsg({ ok: false, text: e.message }); }
  };

  const remove = async (s) => {
    if (!confirm("Delete this schedule?")) return;
    try { await api.del("/api/briefing/schedules/" + s._id); load(); } catch (e) { setMsg({ ok: false, text: e.message }); }
  };

  const fmtNext = (d, tz) => {
    if (!d) return "—";
    try { return new Date(d).toLocaleString(undefined, { timeZone: tz || undefined, month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }); }
    catch { return new Date(d).toLocaleString(); }
  };

  return (
    <div>
      <h3 className="text-lg font-semibold mb-1 flex items-center gap-2"><CalendarClock size={18} /> Scheduled Briefings</h3>
      <p className="text-xs opacity-40 mb-4">AI briefings generated and emailed automatically. Requires SMTP to be configured. Times run in the selected tenant's timezone.</p>

      {msg && <div className={`text-sm px-4 py-2.5 rounded-xl mb-4 ${msg.ok ? "bg-brand-green/10 text-brand-green" : "bg-brand-red/10 text-brand-red"}`}>{msg.text}</div>}

      {!form && (
        <button onClick={() => setForm({ ...EMPTY_SCHED })} className="btn-primary text-sm flex items-center gap-2 mb-4"><Plus size={14} /> New Schedule</button>
      )}

      {form && (
        <div className="glass-card mb-6">
          <h4 className="text-base font-semibold mb-4">{form._id ? "Edit Schedule" : "New Scheduled Briefing"}</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Tenant</label>
              <select className="glass-select w-full" value={form.domain} onChange={e => set("domain", e.target.value)}>
                <option value="">All Tenants</option>
                {tenants.map(t => <option key={t.domain} value={t.domain}>{t.display_name || t.domain}</option>)}
              </select>
              <div className="text-[10px] opacity-30 mt-1">Timezone: {tzFor(form.domain)}</div>
            </div>
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Briefing</label>
              <select className="glass-select w-full" value={form.context} onChange={e => set("context", e.target.value)}>
                <option value="dashboard">Dashboard</option><option value="queues">Queues</option><option value="insights">AI Insights</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Frequency</label>
              <select className="glass-select w-full" value={form.frequency} onChange={e => set("frequency", e.target.value)}>
                <option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Hour (0–23)</label>
              <input type="number" min="0" max="23" className="glass-input w-full" value={form.hour} onChange={e => set("hour", e.target.value)} />
            </div>
            {form.frequency === "weekly" && (
              <div>
                <label className="block text-xs font-medium opacity-60 mb-1.5">Day of Week</label>
                <select className="glass-select w-full" value={form.day_of_week} onChange={e => set("day_of_week", parseInt(e.target.value))}>
                  {DOWS.map((d, i) => <option key={i} value={i}>{d}</option>)}
                </select>
              </div>
            )}
            {form.frequency === "monthly" && (
              <div>
                <label className="block text-xs font-medium opacity-60 mb-1.5">Day of Month (1–28)</label>
                <input type="number" min="1" max="28" className="glass-input w-full" value={form.day_of_month} onChange={e => set("day_of_month", e.target.value)} />
              </div>
            )}
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Data Range</label>
              <select className="glass-select w-full" value={form.range} onChange={e => set("range", e.target.value)}>
                <option value="last_24h">Last 24 hours</option><option value="last_7d">Last 7 days</option><option value="last_30d">Last 30 days</option>
              </select>
            </div>
            <div className="md:col-span-3">
              <label className="block text-xs font-medium opacity-60 mb-1.5">Recipients (comma-separated emails)</label>
              <input className="glass-input w-full" placeholder="manager@company.com, ops@company.com" value={form.recipients} onChange={e => set("recipients", e.target.value)} />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={save} disabled={busy} className="btn-primary text-sm flex items-center gap-2 disabled:opacity-30"><Save size={14} /> {busy ? "Saving..." : "Save Schedule"}</button>
            <button onClick={() => setForm(null)} className="btn-secondary text-sm">Cancel</button>
          </div>
        </div>
      )}

      <div className="glass-card">
        {schedules.length === 0 ? <div className="opacity-30 text-sm py-10 text-center">No scheduled briefings yet.</div> : (
          <div className="space-y-2">
            {schedules.map(s => (
              <div key={s._id} className="flex items-center justify-between p-3 rounded-xl bg-black/[0.03] dark:bg-white/[0.03]">
                <div className="min-w-0">
                  <div className="text-sm font-medium capitalize">{s.context} — {s.frequency}{s.frequency === "weekly" ? " (" + (DOWS[s.day_of_week] || "") + ")" : s.frequency === "monthly" ? " (day " + s.day_of_month + ")" : ""} at {String(s.hour).padStart(2, "0")}:00 <span className="opacity-40 normal-case">({s.timezone || "UTC"})</span></div>
                  <div className="text-xs opacity-40 truncate mt-0.5">
                    <span className="font-medium">{s.domain || "All tenants"}</span> • To: {(s.recipients || []).join(", ")} • Next: {fmtNext(s.next_run_at, s.timezone)}
                    {s.last_status && <span className={s.last_status.startsWith("ok") ? " text-brand-green" : " text-brand-red"}> • {s.last_status}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0 ml-3">
                  <button onClick={() => runNow(s)} className="opacity-40 hover:opacity-100" title="Run now"><Play size={14} /></button>
                  <button onClick={() => setForm({ ...EMPTY_SCHED, ...s, domain: s.domain || "", recipients: (s.recipients || []).join(", ") })} className="opacity-40 hover:opacity-100"><Pencil size={14} /></button>
                  <button onClick={() => remove(s)} className="text-brand-red opacity-40 hover:opacity-100"><Trash2 size={14} /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
