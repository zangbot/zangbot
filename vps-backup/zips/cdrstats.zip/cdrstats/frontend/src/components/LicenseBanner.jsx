import { useLicense } from "../context/LicenseContext";
import { AlertTriangle } from "lucide-react";

export default function LicenseBanner() {
  const { license } = useLicense();
  if (!license || license.mode !== "cloud" || !license.overLimit) return null;
  if (license.graceExpired) return null;

  return (
    <div className="bg-amber-500 text-amber-950 px-5 py-2.5 flex items-center gap-2.5 text-sm font-medium">
      <AlertTriangle size={18} />
      <span>
        You are using <strong>{license.extensionCount}</strong> extensions
        but your plan allows <strong>{license.limit}</strong>.
        {license.daysRemaining > 0
          ? ` Please upgrade within ${license.daysRemaining} day${license.daysRemaining !== 1 ? "s" : ""} to avoid service restrictions.`
          : " Your grace period expires today."}
      </span>
    </div>
  );
}
