import { useState } from "react";
import {
  X, Sparkles, Send, Share2, Copy, Check, Loader2,
  Mail, Link2, ChevronDown, ChevronUp
} from "lucide-react";
import { api } from "../api/client";

/* ── Simple markdown renderer ─────────────────────── */
function renderMarkdown(md) {
  if (!md) return null;
  const lines = md.split("\n");
  const elements = [];
  let listItems = [];
  let key = 0;

  const flushList = () => {
    if (listItems.length > 0) {
      elements.push(
        <ul key={key++} className="space-y-1.5 my-3 ml-4">
          {listItems.map((li, i) => (
            <li key={i} className="text-sm leading-relaxed opacity-80 flex gap-2">
              <span className="text-brand-blue mt-1.5 shrink-0">•</span>
              <span dangerouslySetInnerHTML={{ __html: bold(li) }} />
            </li>
          ))}
        </ul>
      );
      listItems = [];
    }
  };

  const bold = (t) => t.replace(/\*\*(.+?)\*\*/g, '<strong class="opacity-100 font-semibold">$1</strong>');

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) { flushList(); elements.push(<div key={key++} className="h-2" />); continue; }

    if (trimmed.startsWith("# ")) {
      flushList();
      elements.push(<h1 key={key++} className="text-lg font-bold mt-5 mb-2">{trimmed.slice(2)}</h1>);
    } else if (trimmed.startsWith("## ")) {
      flushList();
      elements.push(<h2 key={key++} className="text-base font-bold mt-5 mb-2 text-brand-blue">{trimmed.slice(3)}</h2>);
    } else if (trimmed.startsWith("### ")) {
      flushList();
      elements.push(<h3 key={key++} className="text-sm font-bold mt-4 mb-1.5 opacity-70">{trimmed.slice(4)}</h3>);
    } else if (/^[-*] /.test(trimmed)) {
      listItems.push(trimmed.replace(/^[-*] /, ""));
    } else if (/^\d+\. /.test(trimmed)) {
      listItems.push(trimmed.replace(/^\d+\. /, ""));
    } else {
      flushList();
      elements.push(<p key={key++} className="text-sm leading-relaxed opacity-80 my-1.5" dangerouslySetInnerHTML={{ __html: bold(trimmed) }} />);
    }
  }
  flushList();
  return elements;
}

/* ── BriefingModal ────────────────────────────────── */
export default function BriefingModal({ context, buildQs, selectedQueue }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [briefing, setBriefing] = useState(null);
  const [briefingId, setBriefingId] = useState(null);
  const [dateRange, setDateRange] = useState("");
  const [error, setError] = useState(null);

  // Email state
  const [showEmail, setShowEmail] = useState(false);
  const [emailTo, setEmailTo] = useState("");
  const [emailNote, setEmailNote] = useState("");
  const [emailSending, setEmailSending] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  // Share state
  const [shareUrl, setShareUrl] = useState(null);
  const [shareCopied, setShareCopied] = useState(false);
  const [shareLoading, setShareLoading] = useState(false);

  const generate = async () => {
    setOpen(true);
    setLoading(true);
    setError(null);
    setBriefing(null);
    setShareUrl(null);
    setEmailSent(false);

    try {
      // Parse current filters from the page's query string builder
      const qs = buildQs ? buildQs() : "";
      const params = new URLSearchParams(qs.startsWith("?") ? qs.slice(1) : qs);
      const filters = {};
      if (params.get("start_from")) filters.start_from = params.get("start_from");
      if (params.get("start_to")) filters.start_to = params.get("start_to");
      if (params.get("domain")) filters.domain = params.get("domain");
      if (selectedQueue) filters.queue = selectedQueue;

      const data = await api.post("/api/ai/briefing", { context, filters });
      setBriefing(data.briefing);
      setBriefingId(data.briefing_id);
      setDateRange(data.date_range);
    } catch (e) {
      setError(e.response?.data?.error || e.message || "Failed to generate briefing");
    }
    setLoading(false);
  };

  const handleEmail = async () => {
    if (!emailTo) return;
    setEmailSending(true);
    try {
      await api.post("/api/ai/briefing/email", {
        to: emailTo,
        briefing,
        context,
        date_range: dateRange,
        note: emailNote || undefined,
      });
      setEmailSent(true);
      setEmailTo("");
      setEmailNote("");
    } catch (e) {
      setError(e.response?.data?.error || "Failed to send email");
    }
    setEmailSending(false);
  };

  const handleShare = async () => {
    setShareLoading(true);
    try {
      const data = await api.post("/api/ai/briefing/share", { briefing_id: briefingId });
      setShareUrl(data.share_url);
    } catch (e) {
      setError(e.response?.data?.error || "Failed to create share link");
    }
    setShareLoading(false);
  };

  const copyShareUrl = () => {
    if (!shareUrl) return;
    navigator.clipboard.writeText(shareUrl);
    setShareCopied(true);
    setTimeout(() => setShareCopied(false), 2000);
  };

  const contextLabels = { dashboard: "Dashboard", queues: "Queue Performance", insights: "AI Insights" };

  return (
    <>
      {/* Trigger button */}
      <button
        onClick={generate}
        className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium
          bg-gradient-to-r from-purple-500/10 to-blue-500/10
          hover:from-purple-500/20 hover:to-blue-500/20
          border border-purple-500/20 hover:border-purple-500/30
          text-purple-600 dark:text-purple-400 transition-all duration-200"
        title="Generate AI Briefing"
      >
        <Sparkles size={14} />
        <span>AI Briefing</span>
      </button>

      {/* Modal overlay */}
      {open && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="relative w-full max-w-2xl max-h-[85vh] flex flex-col
            bg-white dark:bg-surface-800 rounded-2xl shadow-2xl border border-black/5 dark:border-white/10 overflow-hidden">

            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-black/5 dark:border-white/10 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                  <Sparkles size={18} className="text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-base">{contextLabels[context]} Briefing</h2>
                  {dateRange && <p className="text-xs opacity-50 mt-0.5">{dateRange}</p>}
                </div>
              </div>
              <button onClick={() => setOpen(false)} className="p-2 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                <X size={18} />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-5">
              {loading && (
                <div className="flex flex-col items-center justify-center py-16 gap-4">
                  <Loader2 size={32} className="animate-spin text-purple-500" />
                  <p className="text-sm opacity-50">Analyzing your data and generating briefing...</p>
                </div>
              )}

              {error && !loading && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-sm text-red-600 dark:text-red-400">
                  {error}
                </div>
              )}

              {briefing && !loading && (
                <div className="prose-container">
                  {renderMarkdown(briefing)}
                </div>
              )}
            </div>

            {/* Footer actions */}
            {briefing && !loading && (
              <div className="border-t border-black/5 dark:border-white/10 p-4 space-y-3 shrink-0">

                {/* Share URL display */}
                {shareUrl && (
                  <div className="flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-xl p-3">
                    <Link2 size={14} className="text-green-500 shrink-0" />
                    <input
                      value={shareUrl}
                      readOnly
                      className="flex-1 bg-transparent text-xs font-mono outline-none truncate"
                    />
                    <button onClick={copyShareUrl} className="shrink-0 p-1.5 rounded-lg hover:bg-green-500/10 transition-colors">
                      {shareCopied ? <Check size={14} className="text-green-500" /> : <Copy size={14} className="opacity-50" />}
                    </button>
                  </div>
                )}

                {/* Email form */}
                {showEmail && (
                  <div className="bg-surface-50 dark:bg-surface-700/50 rounded-xl p-3 space-y-2">
                    <input
                      type="email"
                      placeholder="Recipient email"
                      value={emailTo}
                      onChange={(e) => setEmailTo(e.target.value)}
                      className="w-full bg-white dark:bg-surface-800 border border-black/10 dark:border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-brand-blue"
                    />
                    <input
                      type="text"
                      placeholder="Optional note..."
                      value={emailNote}
                      onChange={(e) => setEmailNote(e.target.value)}
                      className="w-full bg-white dark:bg-surface-800 border border-black/10 dark:border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-brand-blue"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => setShowEmail(false)}
                        className="px-3 py-1.5 text-xs rounded-lg hover:bg-black/5 dark:hover:bg-white/5"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleEmail}
                        disabled={!emailTo || emailSending}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-brand-blue text-white disabled:opacity-50"
                      >
                        {emailSending ? <Loader2 size={12} className="animate-spin" /> : <Send size={12} />}
                        Send
                      </button>
                    </div>
                    {emailSent && <p className="text-xs text-green-500 text-center">✓ Briefing sent!</p>}
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowEmail(!showEmail)}
                    className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-xl
                      bg-surface-100 dark:bg-surface-700 hover:bg-surface-200 dark:hover:bg-surface-600 transition-colors"
                  >
                    <Mail size={14} />
                    Email
                  </button>
                  <button
                    onClick={handleShare}
                    disabled={shareLoading || shareUrl}
                    className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-xl
                      bg-surface-100 dark:bg-surface-700 hover:bg-surface-200 dark:hover:bg-surface-600 transition-colors
                      disabled:opacity-50"
                  >
                    {shareLoading ? <Loader2 size={14} className="animate-spin" /> : <Share2 size={14} />}
                    {shareUrl ? "Link Created" : "Share Link"}
                  </button>
                  <button
                    onClick={() => { navigator.clipboard.writeText(briefing); }}
                    className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-xl
                      bg-surface-100 dark:bg-surface-700 hover:bg-surface-200 dark:hover:bg-surface-600 transition-colors ml-auto"
                  >
                    <Copy size={14} />
                    Copy Text
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
