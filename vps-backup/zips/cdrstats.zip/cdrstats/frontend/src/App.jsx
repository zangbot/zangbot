import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Calls from "./pages/Calls";
import Queues from "./pages/Queues";
import Agents from "./pages/Agents";
import Admin from "./pages/Admin";
import Insights from "./pages/Insights";
import Live from "./pages/Live";
import Compliance from "./pages/Compliance";
import SharedCall from "./pages/SharedCall";
import SharedBriefing from "./pages/SharedBriefing";
import Setup2FA from "./pages/Setup2FA";
import Setup from "./pages/Setup";
import { LicenseProvider } from "./context/LicenseContext";

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-surface-50 dark:bg-surface-900">
      <div className="animate-pulse opacity-50 text-lg">Loading...</div>
    </div>
  );
  return user ? children : <Navigate to="/login" />;
}

export default function App() {
  return (
    <Routes>
          <Route path="/share/:token" element={<SharedCall />} />
          <Route path="/briefing/:token" element={<SharedBriefing />} />
      <Route path="/setup" element={<Setup />} />
      <Route path="/login" element={<Login />} />
      <Route path="/setup-2fa" element={<ProtectedRoute><Setup2FA /></ProtectedRoute>} />
      <Route path="/" element={<ProtectedRoute><LicenseProvider><Layout /></LicenseProvider></ProtectedRoute>}>
        <Route index element={<Navigate to="/dashboard" />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="calls" element={<Calls />} />
        <Route path="queues" element={<Queues />} />
        <Route path="agents" element={<Agents />} />
        <Route path="insights" element={<Insights />} />
        <Route path="compliance" element={<Compliance />} />
        <Route path="live" element={<Live />} />
        <Route path="admin" element={<Admin />} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" />} />
    </Routes>
  );
}
