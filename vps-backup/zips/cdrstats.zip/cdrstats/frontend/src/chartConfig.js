// Theme-aware chart colors
export function useChartColors(dark) {
  return {
    tick: dark ? "rgba(255,255,255,0.4)" : "rgba(0,0,0,0.4)",
    grid: dark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.08)",
    tooltip: {
      backgroundColor: dark ? "rgba(20,20,30,0.95)" : "rgba(255,255,255,0.97)",
      border: dark ? "1px solid rgba(255,255,255,0.1)" : "1px solid rgba(0,0,0,0.1)",
      borderRadius: "12px",
      padding: "10px 14px",
      fontSize: "13px",
      color: dark ? "#fff" : "#1d1d1f",
    },
  };
}
