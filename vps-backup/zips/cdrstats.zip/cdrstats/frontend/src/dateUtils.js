/**
 * Date formatting utilities with optional timezone support.
 * Pass a valid IANA timezone (e.g. "Australia/Sydney") or omit for browser local.
 */
export function fmtDateTime(ts, tz) {
  if (!ts) return "—";
  const opts = {
    year: "numeric",
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  };
  if (tz) opts.timeZone = tz;
  return new Date(ts * 1000).toLocaleString(undefined, opts);
}

export function fmtDate(ts, tz) {
  if (!ts) return "—";
  const opts = {};
  if (tz) opts.timeZone = tz;
  return new Date(ts * 1000).toLocaleDateString(undefined, opts);
}

export function fmtTime(ts, tz) {
  if (!ts) return "—";
  const opts = {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  };
  if (tz) opts.timeZone = tz;
  return new Date(ts * 1000).toLocaleTimeString(undefined, opts);
}

/**
 * Format a JS Date or ISO string (not epoch) with optional timezone.
 * Used for non-CDR timestamps like AI analysis dates.
 */
export function fmtISODateTime(dateVal, tz) {
  if (!dateVal) return "";
  const opts = {
    year: "numeric",
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  };
  if (tz) opts.timeZone = tz;
  return new Date(dateVal).toLocaleString(undefined, opts);
}
