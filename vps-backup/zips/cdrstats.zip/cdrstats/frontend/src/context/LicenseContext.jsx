import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { api } from "../api/client";

const LicenseContext = createContext(null);

export function LicenseProvider({ children }) {
  const [license, setLicense] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchLicense = useCallback(async () => {
    try {
      const data = await api.get("/api/license");
      setLicense(data);
    } catch (err) {
      console.error("Failed to fetch license:", err);
      setLicense({ mode: "self_hosted" });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLicense();
    const interval = setInterval(fetchLicense, 15 * 60 * 1000);
    return () => clearInterval(interval);
  }, [fetchLicense]);

  return (
    <LicenseContext.Provider value={{ license, loading, refetch: fetchLicense }}>
      {children}
    </LicenseContext.Provider>
  );
}

export function useLicense() {
  const ctx = useContext(LicenseContext);
  if (!ctx) throw new Error("useLicense must be used within LicenseProvider");
  return ctx;
}

export function useIsCloud() {
  const { license } = useLicense();
  return license?.mode === "cloud";
}

export function useIsLocked() {
  const { license } = useLicense();
  return license?.locked === true;
}

export function useIsGracePeriod() {
  const { license } = useLicense();
  return license?.overLimit === true && license?.graceExpired === false;
}
