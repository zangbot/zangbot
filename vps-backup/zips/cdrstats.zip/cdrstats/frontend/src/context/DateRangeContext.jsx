import { createContext, useContext, useState } from "react";

const DateRangeContext = createContext(null);

const PRESETS = [
  { label: "1h", value: "1h", ms: 1*60*60*1000 },
  { label: "2h", value: "2h", ms: 2*60*60*1000 },
  { label: "4h", value: "4h", ms: 4*60*60*1000 },
  { label: "8h", value: "8h", ms: 8*60*60*1000 },
  { label: "12h", value: "12h", ms: 12*60*60*1000 },
  { label: "24h", value: "24h", ms: 24*60*60*1000 },
  { label: "7d", value: "7d", ms: 7*24*60*60*1000 },
  { label: "30d", value: "30d", ms: 30*24*60*60*1000 },
  { label: "90d", value: "90d", ms: 90*24*60*60*1000 },
  { label: "6mo", value: "6mo", ms: 180*24*60*60*1000 },
  { label: "12mo", value: "12mo", ms: 365*24*60*60*1000 },
];

export function DateRangeProvider({ children }) {
  const [preset, setPreset] = useState("7d");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");

  function getRange() {
    if (preset === "custom" && customFrom && customTo) {
      // Custom dates — use local timezone start/end of day
      const from = new Date(customFrom + "T00:00:00");
      const to = new Date(customTo + "T23:59:59");
      return {
        from: (from.getTime() / 1000).toString(),
        to: (to.getTime() / 1000).toString(),
      };
    }
    const p = PRESETS.find(pr => pr.value === preset);
    if (!p) return { from: "", to: "" };
    const now = new Date();
    return {
      from: ((now.getTime() - p.ms) / 1000).toString(),
      to: (now.getTime() / 1000).toString(),
    };
  }

  function toQueryParams() {
    const r = getRange();
    if (!r.from) return "";
    return `start_from=${r.from}&start_to=${r.to}`;
  }

  return (
    <DateRangeContext.Provider value={{ preset, setPreset, customFrom, setCustomFrom, customTo, setCustomTo, getRange, toQueryParams, PRESETS }}>
      {children}
    </DateRangeContext.Provider>
  );
}

export const useDateRange = () => useContext(DateRangeContext);
