/**
 * LiveContext — WebSocket state management for the Live page
 *
 * Connects to /api/ws/live?tenant=DOMAIN&token=JWT
 * Manages reconnection, exposes live call/queue/agent state.
 */

import { createContext, useContext, useEffect, useRef, useState, useCallback } from "react";

const LiveContext = createContext(null);

export function LiveProvider({ tenant, token, children }) {
  const [connectionState, setConnectionState] = useState("disconnected");
  const [calls, setCalls] = useState([]);
  const [queueStats, setQueueStats] = useState({});
  const [queueList, setQueueList] = useState([]);
  const [agentStatus, setAgentStatus] = useState({});
  const [accounts, setAccounts] = useState([]);

  const wsRef = useRef(null);
  const reconnectTimer = useRef(null);
  const reconnectAttempts = useRef(0);
  const mountedRef = useRef(true);

  const connect = useCallback(() => {
    if (!tenant || !token) return;
    if (wsRef.current && wsRef.current.readyState <= 1) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/api/ws/live?tenant=${encodeURIComponent(tenant)}&token=${encodeURIComponent(token)}`;

    setConnectionState("connecting");
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      if (!mountedRef.current) return;
      reconnectAttempts.current = 0;
    };

    ws.onmessage = (event) => {
      if (!mountedRef.current) return;
      try {
        const msg = JSON.parse(event.data);
        handleMessage(msg);
      } catch {}
    };

    ws.onclose = () => {
      if (!mountedRef.current) return;
      wsRef.current = null;
      setConnectionState("disconnected");
      scheduleReconnect();
    };

    ws.onerror = () => {
      // onclose will fire after this
    };
  }, [tenant, token]);

  const handleMessage = useCallback((msg) => {
    switch (msg.type) {
      case "connection-state":
        setConnectionState(msg.state);
        break;

      case "snapshot":
        setCalls(msg.calls || []);
        setAccounts(msg.accounts || []);
        setQueueList(msg.queueList || []);
        if (msg.queueStats) setQueueStats(msg.queueStats);
        if (msg.agentStatus) setAgentStatus(msg.agentStatus);
        break;

      case "call-state":
        setCalls(msg.calls || []);
        break;

      case "domain-state":
        setAccounts(msg.accounts || []);
        break;

      case "wallboard":
        setQueueStats(prev => ({
          ...prev,
          [msg.queue]: { ...msg.data, queueName: msg.queueName },
        }));
        break;

      case "blf":
        setAgentStatus(prev => {
          const existing = prev[msg.user] || {};
          const existingCalls = existing.calls || [];
          let newCalls = msg.calls || [];

          // Preserve remote party info when call transitions (early → confirmed)
          if (newCalls.length > 0 && !newCalls[0].remote && existingCalls.length > 0 && existingCalls[0].remote) {
            newCalls = newCalls.map((c, i) => {
              if (!c.remote && existingCalls[i]?.remote) {
                return { ...c, remote: existingCalls[i].remote, name: existingCalls[i].name, number: existingCalls[i].number };
              }
              return c;
            });
          }

          return {
            ...prev,
            [msg.user]: {
              ...existing,
              name: msg.name || existing.name,
              dnd: msg.dnd,
              calls: newCalls,
              registered: msg.registered,
              queues: msg.queues || existing.queues || [],
              loggedIn: msg.loggedIn || existing.loggedIn || {},
            },
          };
        });
        break;

      case "error":
        console.warn("Live WS error:", msg.message);
        break;
    }
  }, []);

  const scheduleReconnect = useCallback(() => {
    const delay = Math.min(2000 * Math.pow(2, reconnectAttempts.current), 30000);
    reconnectAttempts.current++;
    reconnectTimer.current = setTimeout(() => {
      if (mountedRef.current) connect();
    }, delay);
  }, [connect]);

  const requestSnapshot = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ action: "snapshot" }));
    }
  }, []);

  const refreshQueues = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ action: "refresh-queues" }));
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    connect();

    return () => {
      mountedRef.current = false;
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      if (wsRef.current) {
        wsRef.current.onclose = null;
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [connect]);

  return (
    <LiveContext.Provider value={{
      connectionState,
      calls,
      queueStats,
      queueList,
      agentStatus,
      accounts,
      requestSnapshot,
      refreshQueues,
    }}>
      {children}
    </LiveContext.Provider>
  );
}

export function useLive() {
  const ctx = useContext(LiveContext);
  if (!ctx) throw new Error("useLive must be used within LiveProvider");
  return ctx;
}
