import { createContext, useContext, useState, useEffect } from "react";
import { api } from "../api/client";
import { useAuth } from "./AuthContext";

const TenantContext = createContext(null);

export function TenantProvider({ children }) {
  const { user } = useAuth();
  const [tenants, setTenants] = useState([]);
  const [activeTenant, setActiveTenant] = useState(null); // null = all tenants
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      api.get("/api/tenants")
        .then(data => setTenants(data.tenants || []))
        .catch(console.error)
        .finally(() => setLoading(false));
    } else {
      setTenants([]);
      setLoading(false);
    }
  }, [user]);

  // Build query param for domain filtering
  const domainParam = activeTenant ? `&domain=${encodeURIComponent(activeTenant.domain)}` : "";

  return (
    <TenantContext.Provider value={{ tenants, activeTenant, setActiveTenant, loading, domainParam, timezone: activeTenant?.timezone || null }}>
      {children}
    </TenantContext.Provider>
  );
}

export const useTenant = () => useContext(TenantContext);
