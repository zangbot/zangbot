import { useState, useEffect, useCallback } from "react";
import { api } from "../api/client";
import BriefingModal from "../components/BriefingModal";
import { useTenant } from "../context/TenantContext";
import { useDateRange } from "../context/DateRangeContext";
import { useTheme } from "../context/ThemeContext";
import { useChartColors } from "../chartConfig";
import { useNavigate } from "react-router-dom";
import DateFilterBar from "../components/DateFilterBar";
import { shiftHourlyToLocal, getTimezoneLabel } from "../tzUtils";
import ExportButton from "../components/ExportButton";
import PasskeyPrompt from "../components/PasskeyPrompt";
import { useAutoRefresh, RefreshIndicator } from "../components/AutoRefresh";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, CartesianGrid, Legend, ComposedChart } from "recharts";
import { Phone, PhoneIncoming, PhoneOutgoing, PhoneMissed, Clock, Star, TrendingUp, Zap, Moon as MoonIcon, User } from "lucide-react";

const C = { blue: "#007aff", green: "#34c759", red: "#ff3b30", orange: "#ff9500", purple: "#af52de", indigo: "#5856d6", gray: "#636366" };
const PIE_C = [C.green, C.blue, C.gray];

function KPI({ icon: Icon, label, value, sub, color = "blue" }) {
  const c = C[color] || C.blue;
  return (
    <div className="glass-card">
      <div className="flex items-start justify-between mb-3">
        <div className="p-2 rounded-xl" style={{ backgroundColor: c + "15" }}><Icon size={18} style={{ color: c }} /></div>
      </div>
      <div className="text-2xl font-bold tracking-tight tabular-nums" style={{ color: c }}>{value}</div>
      <div className="text-sm font-medium opacity-70 mt-1">{label}</div>
      {sub && <div className="text-xs opacity-40 mt-0.5">{sub}</div>}
    </div>
  );
}

const fmtTime = (s) => { if (!s) return "0s"; s = Math.round(s); return s < 60 ? s+"s" : Math.floor(s/60)+"m "+s%60+"s"; };

export default function Dashboard() {
  const { domainParam, activeTenant , timezone} = useTenant();
  const { toQueryParams, preset, customFrom, customTo } = useDateRange();
  const { dark } = useTheme();
  const cc = useChartColors(dark);
  const [o, setO] = useState({});
  const [hourly, setHourly] = useState([]);
  const [daily, setDaily] = useState([]);
  const [directions, setDirections] = useState([]);
  const [routing, setRouting] = useState([]);
  const [quality, setQuality] = useState([]);
  const [agents, setAgents] = useState([]);
  const [gos, setGos] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const buildQs = useCallback(() => {
    const dp = domainParam ? domainParam.slice(1) : "";
    const drp = toQueryParams();
    const q = [dp, drp].filter(Boolean).join("&");
    return q ? "?" + q : "";
  }, [domainParam, toQueryParams]);

  const loadData = useCallback(async () => {
    setLoading(true);
    const qs = buildQs();
    try {
      const [ov, hr, dy, dr, rt, ql, ag, gs] = await Promise.all([
        api.get("/api/stats/overview" + qs),
        api.get("/api/stats/hourly-detailed" + qs),
        api.get("/api/stats/daily" + qs),
        api.get("/api/stats/directions" + qs),
        api.get("/api/stats/routing" + qs),
        api.get("/api/stats/quality" + qs),
        api.get("/api/stats/agents" + qs),
        api.get("/api/stats/gos" + qs),
      ]);
      setO(ov || {}); setHourly(shiftHourlyToLocal(hr.hourly || [], timezone)); setDaily(dy.daily || []);
      setDirections(dr.directions || []); setRouting(rt.routing || []);
      setQuality(ql.quality || []); setAgents(ag.agents || []); setGos(gs || null);
    } catch(e) { console.error(e); }
    setLoading(false);
  }, [buildQs]);

  useEffect(() => { loadData(); }, [loadData]);

  const autoRefresh = useAutoRefresh(loadData, 1800);

  if (loading) return <div className="opacity-50 text-center py-20 animate-pulse">Loading dashboard...</div>;

  const dirData = directions.map(d => ({ name: d.direction, value: d.total }));
  const routingData = routing.map(r => ({ name: r.method, value: r.total }));
  const PIE_R = [C.blue, C.green, C.purple, C.orange, C.red, C.indigo, C.gray];

  const maxH = hourly.reduce((a, b) => b.total > a.total ? b : a, { total: 0, label: "N/A" });
  const nonZero = hourly.filter(h => h.total > 0);
  const minH = nonZero.length > 0 ? nonZero.reduce((a, b) => b.total < a.total ? b : a) : { label: "N/A" };
  const topByCalls = agents[0] || {};
  const topByTalk = [...agents].sort((a, b) => (b.total_talk || 0) - (a.total_talk || 0))[0] || {};
  const exportQs = buildQs().slice(1);

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-2xl font-bold">Dashboard</h2>
          <p className="text-sm opacity-40 mt-1">{activeTenant ? activeTenant.domain : "All Tenants"}</p>
        </div>
        <div className="flex items-center gap-3">
          <RefreshIndicator {...autoRefresh} interval={1800} />
          <BriefingModal context="dashboard" buildQs={buildQs} />
          <ExportButton url={"/api/export/calls?" + exportQs} label="Export Calls" />
          <ExportButton url={"/api/export/agents?" + exportQs} label="Export Agents" />
        </div>
      </div>

      <PasskeyPrompt />
      <DateFilterBar />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <KPI icon={Phone} label="Total Calls" value={o.total_calls || 0} color="blue" />
        <KPI icon={PhoneIncoming} label="Inbound" value={o.inbound_calls || 0} sub={(o.answer_rate || 0) + "% answer rate"} color="green" />
        <KPI icon={PhoneOutgoing} label="Outbound" value={o.outbound_calls || 0} color="indigo" />
        <KPI icon={PhoneMissed} label="Abandoned" value={o.abandoned_calls || 0} sub={(o.abandon_rate || 0) + "%"} color="red" />
      </div>

      {/* Call Outcome Breakdown */}
      {o.total_calls > 0 && (
        <div className="glass-card mb-4">
          <h3 className="text-sm font-semibold mb-3 opacity-70">Call Outcomes</h3>
          <div className="flex items-center gap-2 mb-2">
            <div className="flex-1 h-6 rounded-full overflow-hidden flex bg-black/5 dark:bg-white/5">
              {o.total_calls > 0 && <>
                <div className="h-full bg-brand-green transition-all" style={{width: `${((o.answered_calls - (o.attended_transfers||0) - (o.blind_transfers||0) - (o.forwarded_calls||0)) / o.total_calls * 100)}%`}} title={`Answered: ${o.answered_calls - (o.attended_transfers||0) - (o.blind_transfers||0) - (o.forwarded_calls||0)}`} />
                <div className="h-full bg-brand-purple transition-all" style={{width: `${((o.attended_transfers||0) / o.total_calls * 100)}%`}} title={`Att. Transfer: ${o.attended_transfers||0}`} />
                <div className="h-full bg-brand-blue transition-all" style={{width: `${((o.blind_transfers||0) / o.total_calls * 100)}%`}} title={`Blind Transfer: ${o.blind_transfers||0}`} />
                <div className="h-full bg-brand-orange transition-all" style={{width: `${((o.forwarded_calls||0) / o.total_calls * 100)}%`}} title={`Forwarded: ${o.forwarded_calls||0}`} />
                <div className="h-full bg-brand-red transition-all" style={{width: `${((o.abandoned_calls||0) / o.total_calls * 100)}%`}} title={`Abandoned: ${o.abandoned_calls||0}`} />
                <div className="h-full bg-gray-400 transition-all" style={{width: `${((o.missed_calls||0) / o.total_calls * 100)}%`}} title={`Missed: ${o.missed_calls||0}`} />
              </>}
            </div>
          </div>
          <div className="flex flex-wrap gap-4 text-xs">
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-brand-green" />Answered {o.answered_calls - (o.attended_transfers||0) - (o.blind_transfers||0) - (o.forwarded_calls||0)}</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-brand-purple" />Att. Transfer {o.attended_transfers||0}</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-brand-blue" />Blind Transfer {o.blind_transfers||0}</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-brand-orange" />Forwarded {o.forwarded_calls||0}</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-brand-red" />Abandoned {o.abandoned_calls||0}</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-gray-400" />Missed {o.missed_calls||0}</span>
          </div>
        </div>
      )}


      {/* Grade of Service */}
      {gos && gos.scored > 0 && (
        <div className="glass-card mb-4">
          <div className="flex items-start justify-between mb-4 flex-wrap gap-3">
            <div>
              <h3 className="text-sm font-semibold opacity-70">Grade of Service</h3>
              <p className="text-xs opacity-40 mt-0.5">
                Inbound answered calls by time to answer &mdash; {gos.scored} of {gos.answered} measured
                {gos.unscored > 0 ? " (" + gos.unscored + " awaiting backfill)" : ""}
              </p>
            </div>
            <div className="text-right">
              <div className={"text-2xl font-bold tabular-nums " + (gos.sla && gos.sla.met ? "text-brand-green" : "text-brand-red")}>
                {gos.sla ? gos.sla.achieved_pct : 0}%
              </div>
              <div className="text-[11px] opacity-40">
                answered in {gos.sla ? gos.sla.target_seconds : 30}s (target {gos.sla ? gos.sla.target_pct : 80}%)
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            {[
              { l: "Within 30s", v: gos.summary.within_30s_pct,  n: gos.summary.within_30s,  c: C.green },
              { l: "Within 60s", v: gos.summary.within_60s_pct,  n: gos.summary.within_60s,  c: C.blue },
              { l: "Within 5m",  v: gos.summary.within_300s_pct, n: gos.summary.within_300s, c: C.orange },
              { l: "Over 5m",    v: gos.summary.over_300s_pct,   n: gos.summary.over_300s,   c: C.red },
            ].map((s, i) => (
              <div key={i} className="bg-black/5 dark:bg-white/5 rounded-xl p-3">
                <div className="text-lg font-bold tabular-nums" style={{ color: s.c }}>{s.v}%</div>
                <div className="text-[11px] opacity-40">{s.l} <span className="opacity-60">({s.n})</span></div>
              </div>
            ))}
          </div>

          {/* Bars: how many landed in each band. Line: running cumulative
              percentage, i.e. the service-level curve. Click a bar to open the
              Calls page filtered to that band. */}
          <div className="h-64"><ResponsiveContainer><ComposedChart data={gos.buckets}>
            <CartesianGrid strokeDasharray="3 3" stroke={cc.grid} />
            <XAxis dataKey="label" tick={{ fill: cc.tick, fontSize: 10 }} />
            <YAxis yAxisId="left" tick={{ fill: cc.tick, fontSize: 11 }} />
            <YAxis yAxisId="right" orientation="right" domain={[0, 100]} unit="%"
              tick={{ fill: cc.tick, fontSize: 11 }} />
            <Tooltip contentStyle={cc.tooltip}
              formatter={(v, n) => (n === "Cumulative" ? [v + "%", "Answered by this point"] : [v + " calls", "In this band"])} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Bar yAxisId="left" dataKey="count" name="Calls" fill={C.indigo} radius={[4,4,0,0]}
              cursor="pointer"
              onClick={(d) => { if (d && d.key) navigate("/calls?answer_bucket=" + encodeURIComponent(d.key)); }} />
            <Line yAxisId="right" type="monotone" dataKey="cumulative_pct" name="Cumulative"
              stroke={C.green} strokeWidth={2} dot={{ r: 3 }} />
          </ComposedChart></ResponsiveContainer></div>

          <div className="flex flex-wrap gap-4 text-xs mt-3 opacity-50">
            <span>Avg answer {fmtTime(gos.avg_answer_seconds)}</span>
            <span>Longest {fmtTime(gos.max_answer_seconds)}</span>
            {gos.abandoned_wait && gos.abandoned_wait.count > 0 && (
              <span className="text-brand-red">
                {gos.abandoned_wait.count} abandoned &mdash; avg wait {fmtTime(gos.abandoned_wait.avg_seconds)}
              </span>
            )}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <KPI icon={Clock} label="Avg Talk" value={fmtTime(o.avg_talk_time)} color="orange" />
        <KPI icon={Star} label="Avg MOS" value={o.avg_mos || "N/A"} color="purple" />
        <KPI icon={Zap} label="Busiest Hour" value={maxH.label} sub={maxH.total + " calls"} color="blue" />
        <KPI icon={MoonIcon} label="Quietest Hour" value={minH.label} sub={minH.total > 0 ? minH.total + " calls" : ""} color="gray" />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPI icon={User} label="Top Ext (Calls)" value={topByCalls.name ? topByCalls.name + " (" + topByCalls.extension + ")" : "N/A"} sub={topByCalls.total_calls ? topByCalls.total_calls + " calls" : ""} color="blue" />
        <KPI icon={User} label="Top Ext (Talk)" value={topByTalk.name ? topByTalk.name + " (" + topByTalk.extension + ")" : "N/A"} sub={topByTalk.total_talk ? fmtTime(topByTalk.total_talk) : ""} color="indigo" />
        <KPI icon={TrendingUp} label="Avg Queue Wait" value={fmtTime(o.avg_queue_wait)} color="orange" />
        <KPI icon={Phone} label="Avg Ring Time" value={fmtTime(o.avg_ring_time)} color="gray" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="glass-card lg:col-span-2">
          <h3 className="text-lg font-semibold mb-1">Hourly Distribution</h3>
          <p className="text-xs opacity-40 mb-4">Inbound, Outbound, Internal and Abandoned by hour ({getTimezoneLabel(timezone)})</p>
          <div className="h-72"><ResponsiveContainer><BarChart data={hourly}>
            <CartesianGrid strokeDasharray="3 3" stroke={cc.grid} />
            <XAxis dataKey="label" tick={{ fill: cc.tick, fontSize: 10 }} interval={1} />
            <YAxis tick={{ fill: cc.tick, fontSize: 11 }} />
            <Tooltip contentStyle={cc.tooltip} /><Legend />
            <Bar dataKey="inbound" name="Inbound" stackId="a" fill={C.green} />
            <Bar dataKey="outbound" name="Outbound" stackId="a" fill={C.blue} />
            <Bar dataKey="internal" name="Internal" stackId="a" fill={C.gray} />
            <Bar dataKey="abandoned" name="Abandoned" stackId="b" fill={C.red} radius={[4,4,0,0]} />
          </BarChart></ResponsiveContainer></div>
        </div>

        <div className="glass-card">
          <h3 className="text-lg font-semibold mb-4">Call Directions</h3>
          <div className="h-64"><ResponsiveContainer><PieChart>
            <Pie data={dirData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" paddingAngle={3} label={({name,value}) => name + " (" + value + ")"}>
              {dirData.map((_, i) => <Cell key={i} fill={PIE_C[i % PIE_C.length]} />)}
            </Pie><Tooltip contentStyle={cc.tooltip} />
          </PieChart></ResponsiveContainer></div>
        </div>

        <div className="glass-card">
          <h3 className="text-lg font-semibold mb-4">Routing Methods</h3>
          <div className="h-64"><ResponsiveContainer><PieChart>
            <Pie data={routingData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" paddingAngle={3} label={({name,value}) => name + " (" + value + ")"}>
              {routingData.map((_, i) => <Cell key={i} fill={PIE_R[i % PIE_R.length]} />)}
            </Pie><Tooltip contentStyle={cc.tooltip} />
          </PieChart></ResponsiveContainer></div>
        </div>

        <div className="glass-card">
          <h3 className="text-lg font-semibold mb-4">Daily Trend</h3>
          <div className="h-64"><ResponsiveContainer><LineChart data={daily}>
            <CartesianGrid strokeDasharray="3 3" stroke={cc.grid} />
            <XAxis dataKey="date" tick={{ fill: cc.tick, fontSize: 10 }} />
            <YAxis tick={{ fill: cc.tick, fontSize: 11 }} />
            <Tooltip contentStyle={cc.tooltip} />
            <Line type="monotone" dataKey="total" name="Total" stroke={C.blue} strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="answered" name="Answered" stroke={C.green} strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="abandoned" name="Abandoned" stroke={C.red} strokeWidth={2} dot={false} />
          </LineChart></ResponsiveContainer></div>
        </div>

        <div className="glass-card">
          <h3 className="text-lg font-semibold mb-4">Voice Quality (MOS)</h3>
          <div className="h-64"><ResponsiveContainer><BarChart data={quality}>
            <CartesianGrid strokeDasharray="3 3" stroke={cc.grid} />
            <XAxis dataKey="range" tick={{ fill: cc.tick, fontSize: 9 }} angle={-15} textAnchor="end" height={50} />
            <YAxis tick={{ fill: cc.tick, fontSize: 11 }} />
            <Tooltip contentStyle={cc.tooltip} />
            <Bar dataKey="count" name="Calls" fill={C.purple} radius={[4,4,0,0]} />
          </BarChart></ResponsiveContainer></div>
        </div>
      </div>

      <div className="glass overflow-hidden">
        <div className="px-6 py-4 border-b border-black/5 dark:border-white/5"><h3 className="text-lg font-semibold">Extension Performance</h3></div>
        <div className="overflow-x-auto"><table className="w-full"><thead><tr className="bg-black/5 dark:bg-white/[0.03]">
          <th className="table-header">Extension</th><th className="table-header text-center">Calls</th><th className="table-header text-center">Inbound</th><th className="table-header text-center">Outbound</th>
          <th className="table-header text-center">Total Talk</th><th className="table-header text-center">Avg Talk</th><th className="table-header text-center">MOS</th>
        </tr></thead><tbody>
          {agents.length === 0 ? <tr><td colSpan={7} className="table-cell text-center opacity-30 py-8">No agent data</td></tr> :
          agents.slice(0, 20).map(a => (
            <tr key={a.extension} className="hover:bg-black/5 dark:hover:bg-white/[0.03] cursor-pointer" onClick={() => navigate(`/calls?agent=${a.extension}`)}>
              <td className="table-cell font-medium">{a.name} <span className="text-xs opacity-30">({a.extension})</span></td>
              <td className="table-cell text-center tabular-nums">{a.total_calls}</td>
              <td className="table-cell text-center tabular-nums text-brand-green">{a.inbound}</td>
              <td className="table-cell text-center tabular-nums text-brand-blue">{a.outbound}</td>
              <td className="table-cell text-center tabular-nums">{fmtTime(a.total_talk)}</td>
              <td className="table-cell text-center tabular-nums">{fmtTime(a.avg_talk)}</td>
              <td className="table-cell text-center">{a.avg_mos ? (
                <span className={a.avg_mos >= 4 ? "text-brand-green" : a.avg_mos >= 3 ? "text-brand-orange" : "text-brand-red"}>{a.avg_mos}</span>
              ) : <span className="opacity-30">-</span>}</td>
            </tr>
          ))}
        </tbody></table></div>
      </div>
    </div>
  );
}
