/**
 * Live Page — Real-time PBX events
 *
 * Two tabs:
 *   1. Tenant Calls — all active calls in the tenant
 *   2. Queue Wallboard — queue stats + agent status grid
 */

import { useState, useEffect, useRef, useContext } from "react";
import { Radio, Phone, PhoneCall, PhoneOff, PhoneIncoming, Users, Headphones, Moon, Wifi, WifiOff, RefreshCw, Eye, EyeOff, Clock, ArrowRight } from "lucide-react";
import { LiveProvider, useLive } from "../context/LiveContext.jsx";
import { useTenant } from "../context/TenantContext";
import { useAuth } from "../context/AuthContext.jsx";

// ── Connection Status Bar ──
function ConnectionBar() {
  const { connectionState } = useLive();

  const config = {
    connected: { color: "bg-brand-green/10 text-brand-green", icon: Wifi, text: "Connected to PBX" },
    connecting: { color: "bg-brand-orange/10 text-brand-orange", icon: RefreshCw, text: "Connecting to PBX..." },
    disconnected: { color: "bg-brand-red/10 text-brand-red", icon: WifiOff, text: "Disconnected from PBX" },
    error: { color: "bg-brand-red/10 text-brand-red", icon: WifiOff, text: "Connection error" },
    unavailable: { color: "bg-black/5 dark:bg-white/5 opacity-60", icon: WifiOff, text: "Live features not configured for this tenant" },
  }[connectionState] || { color: "bg-black/5 dark:bg-white/5 opacity-60", icon: WifiOff, text: "Unknown" };

  const Icon = config.icon;

  return (
    <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium ${config.color}`}>
      <Icon size={12} className={connectionState === "connecting" ? "animate-spin" : ""} />
      {config.text}
    </div>
  );
}

// ── Format duration from epoch timestamp to now ──
function liveDuration(startEpoch, connectEpoch) {
  if (!startEpoch) return "—";
  const ref = connectEpoch && parseFloat(connectEpoch) > 0 ? parseFloat(connectEpoch) : parseFloat(startEpoch);
  const secs = Math.max(0, Math.floor(Date.now() / 1000 - ref));
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  if (m >= 60) {
    const h = Math.floor(m / 60);
    return `${h}:${String(m % 60).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

// ── State Badge ──
function StateBadge({ state }) {
  const styles = {
    alerting: "bg-brand-orange/15 text-brand-orange",
    ringing: "bg-brand-orange/15 text-brand-orange",
    connected: "bg-brand-green/15 text-brand-green",
    confirmed: "bg-brand-green/15 text-brand-green",
    held: "bg-brand-yellow/15 text-brand-yellow",
  };

  return (
    <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${styles[state] || "bg-black/5 dark:bg-white/5 opacity-60"}`}>
      {state || "unknown"}
    </span>
  );
}

// ══════════════════════════════════════════════════
// TAB 1: Tenant Calls
// ══════════════════════════════════════════════════
function resolveCallState(call, agentStatus) {
  if (call.state === "alerting" || call.state === "early") {
    for (const ext of (call.extensions || [])) {
      const cleanExt = ext.replace("*", "");
      const agent = agentStatus[cleanExt];
      if (agent?.calls?.some(c => ["confirmed", "connected", "established"].includes(c.state?.toLowerCase()))) {
        return "connected";
      }
    }
  }
  return call.state;
}

function TenantCallsTab() {
  const { calls, connectionState, agentStatus, queueStats } = useLive();
  const [, setTick] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  if (connectionState === "unavailable") {
    return (
      <div className="flex flex-col items-center justify-center py-20 opacity-40">
        <WifiOff size={40} className="mb-3" />
        <p className="text-sm">Live features are not configured for this tenant</p>
        <p className="text-xs mt-1">Configure PBX connection in Admin \u2192 IP Whitelist</p>
      </div>
    );
  }

  // Resolve states and categorize
  const resolvedCalls = calls.map(c => ({ ...c, resolvedState: resolveCallState(c, agentStatus) }));
  const ringingCalls = resolvedCalls.filter(c => ["alerting", "ringing", "early"].includes(c.resolvedState));
  const connectedCalls = resolvedCalls.filter(c => ["connected", "confirmed", "established"].includes(c.resolvedState));
  const otherCalls = resolvedCalls.filter(c => !["alerting", "ringing", "early", "connected", "confirmed", "established"].includes(c.resolvedState));
  const sortedCalls = [...ringingCalls, ...connectedCalls, ...otherCalls];

  // Compute longest duration
  const longestSecs = resolvedCalls.reduce((max, c) => {
    const ref = c.connect && parseFloat(c.connect) > 0 ? parseFloat(c.connect) : parseFloat(c.start || 0);
    const secs = Math.max(0, Math.floor(Date.now() / 1000 - ref));
    return Math.max(max, secs);
  }, 0);

  if (calls.length === 0) {
    return (
      <div>
        {/* Summary strip — empty state */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <SummaryCard icon={Phone} label="Active Calls" value={0} color="text-brand-blue" />
          <SummaryCard icon={PhoneCall} label="Connected" value={0} color="text-brand-green" />
          <SummaryCard icon={PhoneIncoming} label="Ringing" value={0} color="text-brand-orange" />
          <SummaryCard icon={Clock} label="Longest Call" value="00:00" color="text-brand-purple" />
        </div>
        <div className="flex flex-col items-center justify-center py-16 opacity-30">
          <Phone size={40} className="mb-3" />
          <p className="text-sm">No active calls</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Summary Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <SummaryCard icon={Phone} label="Active Calls" value={calls.length} color="text-brand-blue" />
        <SummaryCard icon={PhoneCall} label="Connected" value={connectedCalls.length} color="text-brand-green" />
        <SummaryCard icon={PhoneIncoming} label="Ringing" value={ringingCalls.length} color="text-brand-orange" alert={ringingCalls.length > 3} />
        <SummaryCard icon={Clock} label="Longest Call" value={fmtDuration(longestSecs)} color="text-brand-purple" />
      </div>

      {/* Call Cards */}
      <div className="flex flex-col gap-3">
        {sortedCalls.map(call => {
          const state = call.resolvedState;
          const isRinging = ["alerting", "ringing", "early"].includes(state);
          const isConnected = ["connected", "confirmed", "established"].includes(state);

          const borderColor = isRinging ? "border-brand-orange/50" : isConnected ? "border-brand-green/30" : "border-transparent";
          const stateColor = isRinging ? "text-brand-orange" : isConnected ? "text-brand-green" : "opacity-50";
          const stateBg = isRinging ? "bg-brand-orange/10" : isConnected ? "bg-brand-green/10" : "bg-black/5 dark:bg-white/5";
          const stateLabel = isRinging ? "Ringing" : isConnected ? "Connected" : state || "Unknown";
          const pulseClass = isRinging ? "animate-pulse" : "";

          // Resolve agent name from extensions
          const agentNames = (call.extensions || []).map(ext => {
            const cleanExt = ext.replace("*", "");
            const agent = agentStatus[cleanExt];
            return agent?.name || cleanExt;
          });

          return (
            <div key={call.id} className={`glass-card border ${borderColor} transition-all ${pulseClass}`}>
              <div className="flex items-center gap-3">
                {/* From */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white ${isRinging ? "bg-brand-orange" : isConnected ? "bg-brand-green" : "bg-gray-400"}`}>
                      {(call.fromName || call.fromNumber || "?").charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <div className="font-medium text-sm truncate">{call.fromName || call.fromNumber}</div>
                      {call.fromName && <div className="text-[11px] opacity-40 truncate">{call.fromNumber}</div>}
                    </div>
                  </div>
                </div>

                {/* Flow Arrow + State */}
                <div className="flex flex-col items-center gap-0.5 px-2 shrink-0">
                  <div className={`flex items-center gap-1 ${stateColor}`}>
                    <div className={`h-px w-6 ${isConnected ? "bg-brand-green/50" : isRinging ? "bg-brand-orange/50 animate-pulse" : "bg-black/10 dark:bg-white/10"}`} style={isRinging ? { backgroundImage: "repeating-linear-gradient(90deg, currentColor 0 4px, transparent 4px 8px)", backgroundSize: "8px 1px", height: "1px", backgroundColor: "transparent" } : {}} />
                    <ArrowRight size={12} />
                  </div>
                  <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${stateBg} ${stateColor}`}>
                    {stateLabel}
                  </span>
                  <span className="text-[10px] tabular-nums font-mono opacity-50">
                    {liveDuration(call.start, call.connect)}
                  </span>
                </div>

                {/* To */}
                <div className="flex-1 min-w-0 text-right">
                  <div className="flex items-center gap-2 justify-end mb-0.5">
                    <div className="min-w-0">
                      <div className="font-medium text-sm truncate">{call.toName || call.toNumber}</div>
                      {call.toName && <div className="text-[11px] opacity-40 truncate">{call.toNumber}</div>}
                    </div>
                    <div className="w-8 h-8 rounded-full bg-brand-blue/15 flex items-center justify-center text-xs font-bold text-brand-blue shrink-0">
                      {(call.toName || call.toNumber || "?").charAt(0).toUpperCase()}
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom bar: extensions + type */}
              {((call.extensions || []).length > 0 || call.account) && (
                <div className="flex items-center gap-2 mt-2 pt-2 border-t border-black/5 dark:border-white/5">
                  {agentNames.map((name, i) => (
                    <span key={i} className="text-[10px] bg-brand-blue/10 text-brand-blue px-1.5 py-0.5 rounded">
                      {name}
                    </span>
                  ))}
                  {(call.trunks || []).length > 0 && (
                    <span className="text-[10px] bg-brand-purple/10 text-brand-purple px-1.5 py-0.5 rounded">trunk</span>
                  )}
                  {call.account && queueStats[call.account] && (
                    <span className="text-[10px] bg-brand-orange/10 text-brand-orange px-1.5 py-0.5 rounded">Q: {queueStats[call.account]?.queueName || call.account}</span>
                  )}
                  {call.callType && (
                    <span className="text-[10px] opacity-30 ml-auto">{call.callType}</span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════
// TAB 2: Queue Wallboard
// ══════════════════════════════════════════════════
function QueueWallboardTab() {
  const { queueStats, agentStatus, connectionState, calls, refreshQueues } = useLive();
  const { user } = useAuth();
  const [, setTick] = useState(0);
  const [hiddenQueues, setHiddenQueues] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem("hiddenQueues") || "[]"); } catch { return []; }
  });
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleRefresh = () => {
    refreshQueues();
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 2000);
  };

  const toggleHideQueue = (qName) => {
    setHiddenQueues(prev => {
      const next = prev.includes(qName) ? prev.filter(q => q !== qName) : [...prev, qName];
      try { sessionStorage.setItem("hiddenQueues", JSON.stringify(next)); } catch {}
      return next;
    });
  };

  if (connectionState === "unavailable") {
    return (
      <div className="flex flex-col items-center justify-center py-20 opacity-40">
        <WifiOff size={40} className="mb-3" />
        <p className="text-sm">Live features are not configured for this tenant</p>
        <p className="text-xs mt-1">Configure PBX connection in Admin → IP Whitelist</p>
      </div>
    );
  }

  // Filter queues for queue_manager role
  const allQueues = Object.entries(queueStats);
  const queues = user?.role === "queue_manager"
    ? allQueues.filter(([qName]) => (user.queues || []).includes(qName))
    : allQueues;

  // Sort queues: waiting first, then active, then by name
  const sortedQueues = [...queues].sort(([, a], [, b]) => {
    const aWait = a.queueLength ?? 0;
    const bWait = b.queueLength ?? 0;
    if (aWait !== bWait) return bWait - aWait;
    const aActive = Array.isArray(a.agentsActive) ? a.agentsActive.length : 0;
    const bActive = Array.isArray(b.agentsActive) ? b.agentsActive.length : 0;
    if (aActive !== bActive) return bActive - aActive;
    return (a.queueName || a.displayName || "").localeCompare(b.queueName || b.displayName || "");
  });

  // Visible vs hidden
  const visibleQueues = sortedQueues.filter(([qName]) => !hiddenQueues.includes(qName));
  const hiddenQueueList = sortedQueues.filter(([qName]) => hiddenQueues.includes(qName));

  // Filter agents for queue_manager role
  const allAgents = Object.entries(agentStatus);
  const agents = user?.role === "queue_manager"
    ? allAgents.filter(([, a]) => (a.queues || []).some(q => (user.queues || []).includes(q)))
    : allAgents;

  // Calculate summary totals from visible queues only
  let totalCalls = 0, totalAnswered = 0, totalAbandoned = 0, totalWaiting = 0, totalActiveAgents = 0, totalDndAgents = 0;
  for (const [, q] of visibleQueues) {
    const stats = q.stats || {};
    totalCalls += stats.calls || 0;
    totalAnswered += stats.connected || 0;
    totalAbandoned += stats["calls-abandoned"] || 0;
    totalWaiting += q.queueLength ?? 0;
    totalActiveAgents += Array.isArray(q.agentsActive) ? q.agentsActive.length : 0;
  }
  for (const [, a] of agents) {
    if (a.dnd) totalDndAgents++;
  }

  const talkingStates = ["connected", "established", "confirmed"];
  const ringingStates = ["alerting", "ringing", "early"];
  const sortedAgents = agents.sort(([, a], [, b]) => {
    const aTalking = (a.calls || []).some(c => talkingStates.includes(c.state?.toLowerCase()));
    const bTalking = (b.calls || []).some(c => talkingStates.includes(c.state?.toLowerCase()));
    const aRinging = (a.calls || []).some(c => ringingStates.includes(c.state?.toLowerCase()));
    const bRinging = (b.calls || []).some(c => ringingStates.includes(c.state?.toLowerCase()));
    if (aTalking && !bTalking) return -1;
    if (!aTalking && bTalking) return 1;
    if (aRinging && !bRinging) return -1;
    if (!aRinging && bRinging) return 1;
    if (a.dnd && !b.dnd) return 1;
    if (!a.dnd && b.dnd) return -1;
    return (a.name || "").localeCompare(b.name || "");
  });

  return (
    <div>
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 mb-6">
        <SummaryCard icon={Phone} label="Total Calls" value={totalCalls} color="text-brand-blue" />
        <SummaryCard icon={PhoneCall} label="Answered" value={totalAnswered} color="text-brand-green" />
        <SummaryCard icon={PhoneOff} label="Abandoned" value={totalAbandoned} color="text-brand-orange" alert={totalCalls > 0 && (totalAbandoned / totalCalls) > 0.25} />
        <SummaryCard icon={PhoneIncoming} label="Waiting" value={totalWaiting} color="text-brand-red" alert={totalWaiting > 2} critical={totalWaiting > 5} />
        <SummaryCard icon={Users} label="Active Agents" value={totalActiveAgents} color="text-gray-500" />
        <SummaryCard icon={Moon} label="DND Agents" value={totalDndAgents} color="text-brand-purple" />
      </div>

      {/* Queue Rows */}
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Headphones size={18} />
          Queues ({visibleQueues.length}{hiddenQueueList.length > 0 ? ` / ${hiddenQueueList.length} hidden` : ""})
        </h3>
        <button
          onClick={handleRefresh}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
          title="Refresh queue data from PBX"
        >
          <RefreshCw size={12} className={refreshing ? "animate-spin" : ""} />
          Refresh
        </button>
      </div>
      {visibleQueues.length === 0 && hiddenQueueList.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 opacity-30">
          <Headphones size={40} className="mb-3" />
          <p className="text-sm">Waiting for queue data...</p>
        </div>
      ) : (
        <div className="flex flex-col gap-4 mb-6">
          {visibleQueues.map(([queueName, q]) => {
            const waiting = q.queueLength ?? 0;
            const active = Array.isArray(q.agentsActive) ? q.agentsActive.length : 0;
            const idle = Array.isArray(q.agentsIdle) ? q.agentsIdle.length : 0;
            const activeCalls = q.activeCalls ?? 0;
            const allAgentCount = Array.isArray(q.allAgents) ? q.allAgents.length : 0;
            const stats = q.stats || {};
            const totalQ = stats.calls || 0;
            const answered = stats.connected || 0;
            const abandoned = stats["calls-abandoned"] || 0;
            const answerRate = totalQ > 0 ? Math.round((answered / totalQ) * 100) : 0;
            const abandonRate = totalQ > 0 ? Math.round((abandoned / totalQ) * 100) : 0;
            const avgWait = stats.num_wait > 0 ? Math.round(stats.durationwait / stats.num_wait / 1000) : 0;
            const maxWait = Math.round((stats.max_wait || 0) / 1000);

            // DND count
            const dndInQueue = Array.isArray(q.agentsDnd) ? q.agentsDnd.length :
              (q.allAgents || []).filter(ext => agentStatus[ext]?.dnd).length;

            const borderClass = waiting > 5 ? "border-brand-red/50 shadow-brand-red/10" :
              waiting > 2 ? "border-brand-orange/50" :
              abandonRate > 50 ? "border-brand-red/30" :
              abandonRate > 25 ? "border-brand-orange/30" : "border-transparent";

            return (
              <div key={queueName} className={`glass-card border-2 ${borderClass} transition-all`}>
                {/* Queue Header */}
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-black/5 dark:border-white/5">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-brand-blue/10 flex items-center justify-center">
                      <Phone size={16} className="text-brand-blue" />
                    </div>
                    <div>
                      <div className="font-semibold">{q.queueName || q.displayName || queueName}</div>
                      <div className="text-xs opacity-40">{queueName}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {waiting > 0 && (
                      <span className={`text-sm font-bold px-2 py-0.5 rounded-full ${waiting > 5 ? "bg-brand-red/15 text-brand-red animate-pulse" : waiting > 2 ? "bg-brand-orange/15 text-brand-orange" : "bg-brand-blue/15 text-brand-blue"}`}>
                        {waiting} waiting
                      </span>
                    )}
                    <QueueStatusDot waiting={waiting} active={active} />
                    <button onClick={() => toggleHideQueue(queueName)} className="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10 opacity-30 hover:opacity-70 transition-opacity" title="Hide this queue">
                      <EyeOff size={14} />
                    </button>
                  </div>
                </div>

                {/* Queue Stats Grid */}
                <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-2">
                  <QueueStat label="Total Calls" value={totalQ} />
                  <QueueStat label="Answered" value={answered} />
                  <QueueStat label="Abandoned" value={abandoned} alert={abandonRate > 25} />
                  <QueueStat label="Waiting" value={waiting} alert={waiting > 2} critical={waiting > 5} />
                  <QueueStat label="Active" value={active} />
                  <QueueStat label="Available" value={idle} />
                  <QueueStat label="DND" value={dndInQueue} />
                  <QueueStat label="Avg Wait" value={fmtDuration(avgWait)} />
                  <QueueStat label="Max Wait" value={fmtDuration(maxWait)} />
                </div>
              </div>
            );
          })}

          {/* Hidden Queues */}
          {hiddenQueueList.length > 0 && (
            <div className="border border-dashed border-black/10 dark:border-white/10 rounded-xl p-3">
              <div className="text-xs font-medium opacity-40 mb-2">Hidden Queues ({hiddenQueueList.length})</div>
              <div className="flex flex-wrap gap-2">
                {hiddenQueueList.map(([qName, q]) => (
                  <button
                    key={qName}
                    onClick={() => toggleHideQueue(qName)}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
                  >
                    <Eye size={11} />
                    {q.queueName || q.displayName || qName}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Agent Status Grid */}
      {sortedAgents.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <Users size={18} />
            Agents ({sortedAgents.length})
          </h3>
          <div className="glass overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-black/5 dark:bg-white/[0.03]">
                  <th className="table-header">Agent</th>
                  <th className="table-header">Queues</th>
                  <th className="table-header text-center">Status</th>
                  <th className="table-header">Call Info</th>
                </tr>
              </thead>
              <tbody>
                {sortedAgents.map(([ext, agent]) => {
                  const activeCalls = (agent.calls || []).filter(c => talkingStates.includes(c.state?.toLowerCase()));
                  const ringingCalls = (agent.calls || []).filter(c => ringingStates.includes(c.state?.toLowerCase()));
                  const isActive = activeCalls.length > 0;
                  const isRinging = ringingCalls.length > 0;
                  const isDnd = agent.dnd;

                  let statusBadge, statusClass;
                  if (isActive) {
                    statusBadge = "Active";
                    statusClass = "bg-brand-green/15 text-brand-green";
                  } else if (isRinging) {
                    statusBadge = "Ringing";
                    statusClass = "bg-brand-orange/15 text-brand-orange animate-pulse";
                  } else if (isDnd) {
                    statusBadge = "DND";
                    statusClass = "bg-brand-red/15 text-brand-red";
                  } else {
                    statusBadge = "Idle";
                    statusClass = "bg-black/5 dark:bg-white/5 opacity-50";
                  }

                  let callInfo = "—";
                  if (isActive) {
                    const c = activeCalls[0];
                    let remote = c.name || c.remote || c.number || null;
                    let remoteNum = c.number || null;
                    let remoteName = c.name || null;
                    // If BLF has no remote info, look up from call-state data
                    if (!remote) {
                      const matched = (calls || []).find(tc => (tc.extensions || []).some(e => e === ext || e === ext + "*"));
                      if (matched) {
                        // Determine which side is the agent by checking if from/to contains the extension
                        const fromIsAgent = matched.fromNumber === ext || (matched.fromName || "").includes(ext);
                        if (fromIsAgent) {
                          remoteName = matched.toName || null;
                          remoteNum = matched.toNumber || null;
                        } else {
                          remoteName = matched.fromName || null;
                          remoteNum = matched.fromNumber || null;
                        }
                        remote = remoteName || remoteNum || "Unknown";
                      } else {
                        remote = "Unknown";
                      }
                    }
                    callInfo = `Talking to ${remote}`;
                    if (remoteNum && remoteName) callInfo += ` (${remoteNum})`;
                  } else if (isRinging) {
                    const c = ringingCalls[0];
                    let remote = c.name || c.remote || c.number || null;
                    let remoteNum = c.number || null;
                    let remoteName = c.name || null;
                    if (!remote) {
                      const matched = (calls || []).find(tc => (tc.extensions || []).some(e => e === ext || e === ext + "*"));
                      if (matched) {
                        const fromIsAgent = matched.fromNumber === ext || (matched.fromName || "").includes(ext);
                        if (fromIsAgent) {
                          remoteName = matched.toName || null;
                          remoteNum = matched.toNumber || null;
                        } else {
                          remoteName = matched.fromName || null;
                          remoteNum = matched.fromNumber || null;
                        }
                        remote = remoteName || remoteNum || "Unknown";
                      } else {
                        remote = "Unknown";
                      }
                    }
                    callInfo = `Ringing from ${remote}`;
                    if (remoteNum && remoteName) callInfo += ` (${remoteNum})`;
                  }

                  // Queue badges from agent data
                  const agentQueues = agent.queues || [];
                  const loggedIn = agent.loggedIn || {};

                  return (
                    <tr key={ext} className={`hover:bg-black/5 dark:hover:bg-white/[0.03] ${isRinging ? "animate-pulse-subtle" : ""}`}>
                      <td className="table-cell">
                        <div className="flex items-center gap-2">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white ${isActive ? "bg-brand-green" : isDnd ? "bg-brand-red" : "bg-gray-400 dark:bg-gray-600"}`}>
                            {(agent.name || ext).charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-medium text-sm">{agent.name || ext}</div>
                            <div className="text-xs opacity-40">Ext {ext}</div>
                          </div>
                        </div>
                      </td>
                      <td className="table-cell">
                        <div className="flex gap-1 flex-wrap">
                          {agentQueues.map(qName => {
                            const isLoggedIn = loggedIn[qName];
                            const qDisplay = queueStats[qName]?.displayName || queueStats[qName]?.queueName || qName;
                            return (
                              <span key={qName} className={`text-[10px] px-1.5 py-0.5 rounded ${isLoggedIn ? "bg-brand-green/15 text-brand-green" : "bg-black/5 dark:bg-white/5 opacity-40"}`}>
                                {qDisplay} ({qName})
                              </span>
                            );
                          })}
                        </div>
                      </td>
                      <td className="table-cell text-center">
                        <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${statusClass}`}>
                          {statusBadge}
                        </span>
                      </td>
                      <td className="table-cell text-sm opacity-70">{callInfo}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Helper Components ──
function SummaryCard({ icon: Icon, label, value, color, alert, critical }) {
  const borderClass = critical ? "border-brand-red/50 animate-pulse" : alert ? "border-brand-orange/40" : "border-transparent";
  return (
    <div className={`glass-card border ${borderClass} transition-colors`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon size={16} className={color} />
        <span className="text-xs opacity-50 font-medium">{label}</span>
      </div>
      <div className="text-2xl font-light">{value}</div>
    </div>
  );
}

function QueueStat({ label, value, alert, critical }) {
  const bgClass = critical ? "bg-brand-red/10" : alert ? "bg-brand-orange/10" : "bg-black/5 dark:bg-white/5";
  return (
    <div className={`${bgClass} rounded-lg p-2 text-center transition-colors`}>
      <div className="text-sm font-light">{value}</div>
      <div className="text-[10px] opacity-40 font-medium uppercase tracking-wider">{label}</div>
    </div>
  );
}

function QueueStatusDot({ waiting, active }) {
  if (waiting > 5) return <span className="w-2 h-2 rounded-full bg-brand-red animate-pulse" />;
  if (waiting > 2) return <span className="w-2 h-2 rounded-full bg-brand-orange" />;
  if (active > 0) return <span className="w-2 h-2 rounded-full bg-brand-green" />;
  return <span className="w-2 h-2 rounded-full bg-gray-400" />;
}

function fmtDuration(secs) {
  if (!secs || isNaN(secs)) return "00:00";
  secs = Math.floor(secs);
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

// ══════════════════════════════════════════════════
// Main Live Page
// ══════════════════════════════════════════════════
function LiveContent() {
  const { user } = useAuth();
  const isQueueManager = user?.role === "queue_manager";
  const [tab, setTab] = useState("wallboard");

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Radio size={22} className="text-brand-blue" />
          <h1 className="text-2xl font-bold">Live</h1>
        </div>
        <ConnectionBar />
      </div>

      {/* Tabs — hidden for queue_manager who only sees wallboard */}
      {!isQueueManager && (
        <div className="flex gap-1 mb-6 bg-black/5 dark:bg-white/5 rounded-lg p-1 w-fit">
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${tab === "wallboard" ? "bg-white dark:bg-white/10 shadow-sm" : "hover:bg-white/50 dark:hover:bg-white/5"}`}
            onClick={() => setTab("wallboard")}
          >
            <span className="flex items-center gap-1.5">
              <Headphones size={14} />
              Queue Wallboard
            </span>
          </button>
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${tab === "calls" ? "bg-white dark:bg-white/10 shadow-sm" : "hover:bg-white/50 dark:hover:bg-white/5"}`}
            onClick={() => setTab("calls")}
          >
            <span className="flex items-center gap-1.5">
              <PhoneCall size={14} />
              Tenant Calls
            </span>
          </button>
        </div>
      )}

      {/* Tab Content */}
      {tab === "wallboard" ? <QueueWallboardTab /> : <TenantCallsTab />}
    </div>
  );
}

export default function Live() {
  const { activeTenant } = useTenant();
  const { user } = useAuth();
  // For queue_manager/single-tenant users: fall back to their first assigned tenant
  const tenant = activeTenant?.domain
    || (user?.tenants?.length === 1 ? user.tenants[0].domain : null);
  const token = localStorage.getItem("access_token");

  if (!tenant) {
    return (
      <div className="p-6">
        <div className="flex flex-col items-center justify-center py-20 opacity-40">
          <WifiOff size={40} className="mb-3" />
          <p className="text-sm">Select a tenant to view live data</p>
        </div>
      </div>
    );
  }

  if (!token) {
    return (
      <div className="p-6">
        <div className="flex flex-col items-center justify-center py-20 opacity-40">
          <WifiOff size={40} className="mb-3" />
          <p>Not authenticated</p>
        </div>
      </div>
    );
  }

  return (
    <LiveProvider tenant={tenant} token={token}>
      <LiveContent />
    </LiveProvider>
  );
}
