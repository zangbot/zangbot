import { useState, useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import CallPlayer from "../components/CallPlayer";
import {
  Phone, PhoneIncoming, PhoneOutgoing, Clock, User,
  Activity, Play, Pause, MessageSquare, Brain, AlertCircle,
  CheckCircle, XCircle, Loader2, Sun, Moon
} from "lucide-react";

function Badge({ color, children }) {
  const colors = {
    green: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/20",
    red: "bg-red-500/15 text-red-600 dark:text-red-400 border-red-500/20",
    blue: "bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/20",
    orange: "bg-orange-500/15 text-orange-600 dark:text-orange-400 border-orange-500/20",
    purple: "bg-purple-500/15 text-purple-600 dark:text-purple-400 border-purple-500/20",
    gray: "bg-gray-500/15 text-gray-600 dark:text-gray-400 border-gray-500/20",
  };
  return <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${colors[color] || colors.gray}`}>{children}</span>;
}

function AudioPlayer({ url, filename }) {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);

  const toggle = () => {
    if (!audioRef.current) return;
    if (playing) audioRef.current.pause(); else audioRef.current.play();
    setPlaying(!playing);
  };

  const fmtTime = (s) => `${Math.floor(s / 60)}:${Math.floor(s % 60).toString().padStart(2, "0")}`;

  return (
    <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4 mb-2">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium">{filename}</span>
      </div>
      <div className="flex items-center gap-3">
        <audio ref={audioRef} src={url}
          onTimeUpdate={() => setProgress(audioRef.current?.currentTime || 0)}
          onLoadedMetadata={() => setDuration(audioRef.current?.duration || 0)}
          onEnded={() => setPlaying(false)} />
        <button onClick={toggle} className="w-9 h-9 rounded-full bg-brand-blue/20 text-brand-blue flex items-center justify-center hover:bg-brand-blue/30 transition">
          {playing ? <Pause size={16} /> : <Play size={16} className="ml-0.5" />}
        </button>
        <div className="flex-1 h-1.5 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden cursor-pointer"
          onClick={e => { if (audioRef.current && duration) { const rect = e.currentTarget.getBoundingClientRect(); audioRef.current.currentTime = ((e.clientX - rect.left) / rect.width) * duration; } }}>
          <div className="h-full bg-brand-blue rounded-full transition-all" style={{ width: `${duration ? (progress / duration) * 100 : 0}%` }} />
        </div>
        <span className="text-xs opacity-40 tabular-nums min-w-[70px] text-right">{fmtTime(progress)} / {fmtTime(duration)}</span>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color = "blue" }) {
  const colors = {
    blue: "text-brand-blue bg-brand-blue/10",
    green: "text-brand-green bg-brand-green/10",
    red: "text-brand-red bg-brand-red/10",
    orange: "text-brand-orange bg-brand-orange/10",
    purple: "text-brand-purple bg-brand-purple/10",
  };
  return (
    <div className="glass-card">
      <div className="flex items-center gap-2 mb-2">
        <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${colors[color]}`}><Icon size={14} /></div>
        <span className="text-xs opacity-40">{label}</span>
      </div>
      <div className="text-lg font-semibold">{value}</div>
    </div>
  );
}

export default function SharedCall() {
  const { token } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dark, setDark] = useState(false);
  const [origTheme] = useState(() => document.documentElement.classList.contains("dark"));

  useEffect(() => {
    // Default to light mode for external viewers
    document.documentElement.classList.remove("dark");
    return () => {
      // Restore original theme when leaving
      if (origTheme) document.documentElement.classList.add("dark");
    };
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    if (next) document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
  };

  useEffect(() => {
    fetch(`/api/share/${token}`)
      .then(async r => {
        const json = await r.json();
        if (!r.ok) throw new Error(json.error || "Failed to load");
        return json;
      })
      .then(setData)
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [token]);

  if (loading) {
    return (
      <div className="min-h-screen bg-surface-50 dark:bg-surface-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 size={32} className="animate-spin text-brand-blue mx-auto mb-4" />
          <p className="opacity-40">Loading shared call...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-surface-50 dark:bg-surface-900 flex items-center justify-center p-4">
        <div className="glass-card max-w-md w-full text-center">
          <AlertCircle size={48} className="text-brand-red mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Link Unavailable</h2>
          <p className="opacity-50 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  const { call: c, recordings, transcripts, ai_analysis: ai, shared_by, shared_at } = data;

  const fmtDate = (ts) => {
    if (!ts) return "—";
    const d = typeof ts === "number" ? new Date(ts * 1000) : new Date(ts);
    return d.toLocaleString();
  };

  const fmtDuration = (s) => {
    if (!s) return "0s";
    const m = Math.floor(s / 60);
    const sec = Math.round(s % 60);
    return m > 0 ? `${m}m ${sec}s` : `${sec}s`;
  };

  const dirIcon = c.call_direction?.startsWith("inbound") ? PhoneIncoming : c.call_direction?.startsWith("outbound") ? PhoneOutgoing : Phone;
  const dirColor = c.call_direction?.startsWith("inbound") ? "green" : c.call_direction?.startsWith("outbound") ? "blue" : "gray";
  const sentimentColor = ai?.sentiment === "positive" ? "green" : ai?.sentiment === "negative" ? "red" : "orange";

  return (
    <div className="min-h-screen bg-surface-50 dark:bg-surface-900 transition-colors">
      {/* Header */}
      <div className="border-b border-black/5 dark:border-white/[0.06] bg-white/50 dark:bg-white/[0.02]">
        <div className="max-w-4xl mx-auto px-6 py-5 flex items-center justify-between">
          <div>
            <h1 className="text-lg font-semibold flex items-center gap-2">
              <Phone size={20} className="text-brand-blue" />
              Shared Call Detail
            </h1>
            <p className="text-xs opacity-30 mt-1">Shared by {shared_by} on {fmtDate(shared_at)}</p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={toggleTheme} className="p-2 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition" title="Toggle theme">
              {dark ? <Sun size={18} className="opacity-50" /> : <Moon size={18} className="opacity-50" />}
            </button>
            <span className="text-xs opacity-20">Vodia CDR Analytics</span>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8 space-y-6">
        {/* Call Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard icon={dirIcon} label="Direction" value={<Badge color={dirColor}>{c.call_direction}</Badge>} color={dirColor} />
          <StatCard icon={c.is_answered ? CheckCircle : XCircle} label="Status" value={<div className="flex flex-wrap gap-1"><Badge color={c.is_answered ? "green" : "red"}>{c.is_answered ? "Answered" : c.is_abandoned ? "Abandoned" : "Missed"}</Badge>{c.transfer_type === "attended" && <Badge color="purple">Att. Transfer</Badge>}{c.transfer_type === "blind" && <Badge color="blue">Blind Transfer</Badge>}</div>} color={c.is_answered ? "green" : "red"} />
          <StatCard icon={Clock} label="Duration" value={fmtDuration(c.duration_seconds)} />
          <StatCard icon={Activity} label="MOS Score" value={c.avg_mos_score || "N/A"} color={c.avg_mos_score >= 4 ? "green" : c.avg_mos_score >= 3 ? "orange" : "red"} />
        </div>

        {/* Parties */}
        <div className="glass-card">
          <h3 className="text-sm font-semibold opacity-60 mb-4">Call Parties</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="text-xs opacity-30 mb-1">From</div>
              <div className="font-medium">{c.from_name || c.from_number || "Unknown"}</div>
              {c.from_number && c.from_name && <div className="text-sm opacity-40">{c.from_number}</div>}
            </div>
            <div>
              <div className="text-xs opacity-30 mb-1">To</div>
              <div className="font-medium">{c.to_name || c.to_number || "Unknown"}</div>
              {c.to_number && c.to_name && <div className="text-sm opacity-40">{c.to_number}</div>}
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 pt-4 border-t border-black/5 dark:border-white/5">
            <div><div className="text-xs opacity-30">Date</div><div className="text-sm">{fmtDate(c.start)}</div></div>
            <div><div className="text-xs opacity-30">Talk Time</div><div className="text-sm">{fmtDuration(c.talk_seconds)}</div></div>
            <div><div className="text-xs opacity-30">Queue</div><div className="text-sm">{c.answering_queue_name || "—"}</div></div>
            <div><div className="text-xs opacity-30">Agent</div><div className="text-sm">{c.answering_extension_name || "—"}</div></div>
            {c.answer_seconds != null && <div><div className="text-xs opacity-30">Answer Time</div><div className="text-sm">{Math.round(c.answer_seconds)}s</div></div>}
            {c.category && <div><div className="text-xs opacity-30">Category</div><div className="text-sm">{c.category}</div></div>}
            {c.cmc && <div><div className="text-xs opacity-30">CMC</div><div className="text-sm">{c.cmc}</div></div>}
          </div>
          {c.comment && (
            <div className="mt-4 pt-4 border-t border-black/5 dark:border-white/5">
              <div className="text-xs opacity-30 mb-1">Comment</div>
              <div className="text-sm whitespace-pre-wrap break-words">{c.comment}</div>
            </div>
          )}
        </div>

        {/* Recordings */}
        {recordings && recordings.length > 0 && (
          <div className="glass-card">
            <h3 className="text-sm font-semibold opacity-60 mb-4 flex items-center gap-2">
              <Play size={16} /> Recordings ({recordings.length})
            </h3>
            {recordings.map((r, i) => (
              <CallPlayer key={r._id || i} recording={r} />
            ))}
          </div>
        )}

        {/* Transcripts */}
        {transcripts && transcripts.length > 0 && (
          <div className="glass-card">
            <h3 className="text-sm font-semibold opacity-60 mb-4 flex items-center gap-2">
              <MessageSquare size={16} /> Transcript
            </h3>
            {transcripts.map((t, i) => (
              <div key={i} className="space-y-2">
                {t.is_mono === false && t.channel_0_text && (
                  <div className="space-y-2">
                    <div className="bg-brand-blue/5 dark:bg-brand-blue/10 rounded-xl p-4">
                      <div className="text-xs font-medium text-brand-blue mb-1">Caller</div>
                      <p className="text-sm leading-relaxed">{t.channel_0_text}</p>
                    </div>
                    {t.channel_1_text && (
                      <div className="bg-brand-green/5 dark:bg-brand-green/10 rounded-xl p-4">
                        <div className="text-xs font-medium text-brand-green mb-1">Agent</div>
                        <p className="text-sm leading-relaxed">{t.channel_1_text}</p>
                      </div>
                    )}
                  </div>
                )}
                {(t.is_mono !== false || (!t.channel_0_text && !t.channel_1_text)) && t.full_text && (
                  <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4">
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{t.full_text}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* AI Analysis */}
        {ai && (
          <div className="glass-card">
            <h3 className="text-sm font-semibold opacity-60 mb-4 flex items-center gap-2">
              <Brain size={16} /> AI Analysis
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
              {ai.sentiment && (
                <div>
                  <div className="text-xs opacity-30 mb-1">Sentiment</div>
                  <Badge color={sentimentColor}>{ai.sentiment}</Badge>
                </div>
              )}
              {ai.resolution && (
                <div>
                  <div className="text-xs opacity-30 mb-1">Resolution</div>
                  <Badge color={ai.resolution === "resolved" ? "green" : ai.resolution === "unresolved" ? "red" : "orange"}>{ai.resolution}</Badge>
                </div>
              )}
              {ai.caller_mood && (
                <div>
                  <div className="text-xs opacity-30 mb-1">Caller Mood</div>
                  <span className="text-sm">{ai.caller_mood}</span>
                </div>
              )}
            </div>
            {ai.topics?.length > 0 && (
              <div className="mb-4">
                <div className="text-xs opacity-30 mb-2">Topics</div>
                <div className="flex flex-wrap gap-1">{ai.topics.map((t, i) => <Badge key={i} color="purple">{t}</Badge>)}</div>
              </div>
            )}
            {ai.key_phrases?.length > 0 && (
              <div className="mb-4">
                <div className="text-xs opacity-30 mb-2">Key Phrases</div>
                <div className="flex flex-wrap gap-1">{ai.key_phrases.map((p, i) => <Badge key={i} color="blue">{p}</Badge>)}</div>
              </div>
            )}
            {ai.summary && (
              <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4 mb-4">
                <p className="text-sm leading-relaxed">{ai.summary}</p>
              </div>
            )}
            {ai.action_items?.length > 0 && (
              <div>
                <div className="text-xs opacity-30 mb-2">Action Items</div>
                <ul className="text-sm space-y-1">
                  {ai.action_items.map((a, i) => <li key={i} className="flex items-start gap-2"><CheckCircle size={14} className="text-brand-green mt-0.5 flex-shrink-0" />{a}</li>)}
                </ul>
              </div>
            )}
            {ai.agent_performance && (
              <div className="mt-4 pt-4 border-t border-black/5 dark:border-white/5">
                <div className="text-xs opacity-30 mb-1">Agent Performance</div>
                <p className="text-sm">{ai.agent_performance}</p>
              </div>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="text-center text-xs opacity-20 pt-4 pb-8">
          Powered by Vodia CDR Analytics
        </div>
      </div>
    </div>
  );
}
