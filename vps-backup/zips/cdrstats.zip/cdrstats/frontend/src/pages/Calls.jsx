import { fmtDateTime } from "../dateUtils";
import { useState, useEffect, useCallback, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "../api/client";
import { useDateRange } from "../context/DateRangeContext";
import DateFilterBar from "../components/DateFilterBar";
import ExportButton from "../components/ExportButton";
import { useAutoRefresh, RefreshIndicator } from "../components/AutoRefresh";
import { useTenant } from "../context/TenantContext";
import { Search, ChevronLeft, ChevronRight, X, Play, Square, Bug, Mic, Brain, Share2, Copy, Check, MessageSquare, SlidersHorizontal, Filter } from "lucide-react";
import AIAnalysis from "../components/AIAnalysis";
import ComplianceQAPanel from "../components/ComplianceQAPanel";
import CallPlayer from "../components/CallPlayer";

/* ── Debug Panel (Logs + SIP Packets) ────────────── */
function DebugPanel({ call, onClose }) {
  if (!call) return null;
  const c = call.call || call;
  const logs = c.logs || [];
  const trunklegs = c.trunklegs || [];
  const extlegs = c.extensionlegs || [];
  const [tab, setTab] = useState("logs");

  // Extract SIP packets from all legs
  const sipPackets = [];
  [...trunklegs, ...extlegs].forEach((leg, li) => {
    if (leg.packets) {
      const raw = typeof leg.packets === "string" ? leg.packets : JSON.stringify(leg.packets);
      sipPackets.push({ leg: li, type: leg.direction === "I" ? "trunk-in" : leg.direction === "O" ? "trunk-out" : "ext", data: raw });
    }
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="glass w-full max-w-4xl max-h-[85vh] overflow-hidden flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-black/5 dark:border-white/5 flex-shrink-0">
          <div>
            <h3 className="text-lg font-bold flex items-center gap-2"><Bug size={18} className="text-brand-orange" /> Debug — {c.callid}</h3>
            <p className="text-xs opacity-40 mt-1">{c.domain}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-black/10 dark:hover:bg-white/10 transition"><X size={18} className="opacity-60" /></button>
        </div>

        <div className="flex gap-2 px-6 pt-4 flex-shrink-0">
          {[
            { id: "logs", label: `Logs (${logs.length})` },
            { id: "sip", label: `SIP Packets (${sipPackets.length})` },
            { id: "raw", label: "Raw JSON" },
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${tab === t.id ? "bg-brand-blue/15 text-brand-blue" : "opacity-50 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/5"}`}>
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {tab === "logs" && (
            logs.length > 0 ? (
              <div className="font-mono text-xs space-y-1">
                {logs.map((log, i) => (
                  <div key={i} className={`flex gap-3 px-3 py-1.5 rounded-lg ${
                    log.l <= 4 ? "bg-brand-red/10 text-brand-red" :
                    log.l === 5 ? "bg-brand-orange/10 text-brand-orange" :
                    "bg-black/5 dark:bg-white/5 opacity-70"
                  }`}>
                    <span className="opacity-40 flex-shrink-0 w-16">{log.c || "APP"}</span>
                    <span className="flex-1 break-all">{log.m}</span>
                  </div>
                ))}
              </div>
            ) : <div className="text-center opacity-30 py-12">No logs in this CDR</div>
          )}

          {tab === "sip" && (
            sipPackets.length > 0 ? (
              <div className="space-y-4">
                {sipPackets.map((pkt, i) => (
                  <div key={i} className="bg-black/5 dark:bg-white/5 rounded-xl overflow-hidden">
                    <div className="px-4 py-2 text-xs font-semibold opacity-50 border-b border-black/5 dark:border-white/5">
                      Leg {pkt.leg} — {pkt.type}
                    </div>
                    <pre className="px-4 py-3 text-xs font-mono overflow-x-auto whitespace-pre-wrap opacity-70 max-h-96">
                      {pkt.data}
                    </pre>
                  </div>
                ))}
              </div>
            ) : <div className="text-center opacity-30 py-12">No SIP packets in this CDR</div>
          )}

          {tab === "raw" && (
            <pre className="bg-black/5 dark:bg-white/5 rounded-xl px-4 py-3 text-xs font-mono overflow-x-auto whitespace-pre-wrap opacity-70 max-h-[60vh]">
              {JSON.stringify(c, null, 2)}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
}

/* ── Share Call Button ────────────────────────────── */
function ShareCallButton({ call }) {
  const [open, setOpen] = useState(false);
  const [shareUrl, setShareUrl] = useState("");
  const [emailing, setEmailing] = useState(false);
  const [emailTo, setEmailTo] = useState("");
  const [emailNote, setEmailNote] = useState("");
  const [copied, setCopied] = useState(false);
  const [msg, setMsg] = useState(null);
  const [generating, setGenerating] = useState(false);

  const generate = async () => {
    setGenerating(true);
    setMsg(null);
    try {
      const res = await api.post("/api/share", { callid: call.callid, domain: call.domain, system: call.system });
      setShareUrl(res.share_url);
    } catch (err) { setMsg({ type: "err", text: err.message }); }
    finally { setGenerating(false); }
  };

  const copyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const emailLink = async () => {
    if (!emailTo) return;
    setEmailing(true);
    setMsg(null);
    try {
      await api.post("/api/share/email", { share_url: shareUrl, to: emailTo, callid: call.callid, note: emailNote });
      setMsg({ type: "ok", text: "Email sent!" });
      setEmailTo("");
      setEmailNote("");
    } catch (err) { setMsg({ type: "err", text: err.message }); }
    finally { setEmailing(false); }
  };

  if (!open) {
    return <button onClick={() => { setOpen(true); generate(); }} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-brand-indigo/10 text-brand-indigo hover:bg-brand-indigo/20 transition"><Share2 size={13} /> Share</button>;
  }

  return (
    <div className="mt-4 p-4 bg-brand-indigo/5 border border-brand-indigo/10 rounded-xl">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-sm font-semibold flex items-center gap-2"><Share2 size={14} /> Share Call</h4>
        <button onClick={() => setOpen(false)} className="text-xs opacity-40 hover:opacity-100">Close</button>
      </div>
      {msg && <div className={`mb-3 px-3 py-2 rounded-lg text-xs ${msg.type === "ok" ? "bg-brand-green/10 text-brand-green" : "bg-brand-red/10 text-brand-red"}`}>{msg.text}</div>}
      {generating ? (
        <div className="text-center py-4 text-sm opacity-40">Generating link...</div>
      ) : shareUrl ? (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <input className="glass-input flex-1 text-xs font-mono" readOnly value={shareUrl} />
            <button onClick={copyLink} className="btn-primary text-xs flex items-center gap-1.5">{copied ? <><Check size={12} /> Copied</> : <><Copy size={12} /> Copy</>}</button>
          </div>
          <div className="text-xs text-brand-orange/80">One-time link — expires after viewing or 24 hours</div>
          <div className="border-t border-white/5 pt-3">
            <div className="text-xs font-medium mb-2 opacity-60">Email this link</div>
            <div className="flex items-center gap-2">
              <input className="glass-input flex-1 text-xs" placeholder="recipient@email.com" value={emailTo} onChange={e => setEmailTo(e.target.value)} />
              <button onClick={emailLink} disabled={emailing || !emailTo} className="btn-primary text-xs flex items-center gap-1.5 disabled:opacity-50">{emailing ? "Sending..." : "Send"}</button>
            </div>
            <input className="glass-input w-full text-xs mt-2" placeholder="Add a note (optional)" value={emailNote} onChange={e => setEmailNote(e.target.value)} />
          </div>
        </div>
      ) : null}
    </div>
  );
}

/* ── Call Detail Modal ───────────────────────────── */
function CallDetail({ call, onClose, initialTab, autoPlay = false }) {
  const [activeTab, setActiveTab] = useState(initialTab || "detail");
  const [recIdx, setRecIdx] = useState(0);
  const [playTime, setPlayTime] = useState(0);
  if (!call) return null;
  const c = call.call;
  // Zero-byte uploads land here with upload_status "completed"; they break the
  // worker's channel split and give the player an empty file.
  const recs = (call.recordings || []).filter(r => (r.size_bytes || 0) > 0);
  const sel = recs.length > 0 ? recs[Math.min(recIdx, recs.length - 1)] : null;
  const states = c.states || [];
  const stateIcons = { attendant: "📞", acd: "📋", hunt: "🔍", mailbox: "📬", extcall: "☎️", conference: "🎤", ivrnode: "🔢", orbit: "🅿️", caller: "🏢" };
  const reasonLabels = { hc: "Caller hung up", hw: "Hung up waiting", hr: "Hung up ringing", rw: "Wait timeout", rr: "Ring timeout", at: "Attended transfer", bt: "Blind transfer" };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="glass w-full max-w-3xl max-h-[85vh] overflow-y-auto p-0" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-black/5 dark:border-white/5 bg-brand-blue/5 dark:bg-brand-blue/10">
          <div>
            <h3 className="text-lg font-bold">Call Detail</h3>
            <p className="text-xs opacity-40 mt-1">{c.callid}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-black/10 dark:hover:bg-white/10 transition"><X size={20} className="opacity-60" /></button>
        </div>

        {/* Recording player — pinned, persists across tabs, single instance */}
        {sel && (
          <div className="px-6 pt-4">
            {recs.length > 1 && (
              <div className="flex items-center gap-1.5 flex-wrap mb-2">
                <span className="text-[10px] uppercase tracking-wider opacity-30 mr-1">
                  {recs.length} recordings
                </span>
                {recs.map((r, i) => (
                  <button key={r._id || i} onClick={() => { setRecIdx(i); setPlayTime(0); }}
                    title={r.original_filename}
                    className={`text-[11px] px-2.5 py-1 rounded-lg transition ${
                      i === recIdx
                        ? "bg-brand-purple/15 text-brand-purple"
                        : "opacity-40 hover:opacity-80 bg-black/5 dark:bg-white/5"
                    }`}>
                    {i + 1}{r.duration_seconds ? ` \u00B7 ${Math.round(r.duration_seconds)}s` : ""}
                  </button>
                ))}
              </div>
            )}
            <CallPlayer
              key={sel._id || recIdx}
              recording={sel}
              autoPlay={autoPlay}
              onTime={setPlayTime}
              onPlay={() => setActiveTab(t => (t === "transcript" ? t : "transcript"))}
              markers={recs.length === 1
                ? (c.compliance?.violations || [])
                    .filter(v => typeof v.at_seconds === "number")
                    .map(v => ({ at_seconds: v.at_seconds, label: v.name }))
                : []}
            />
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 px-6 pt-4 border-b border-black/5 dark:border-white/5">
          {[
            { id: "detail", label: "Call Detail" },
            { id: "transcript", label: "Transcript", icon: MessageSquare, color: "text-brand-indigo" },
            { id: "ai", label: "AI Analysis", icon: Brain, color: "text-brand-purple" },
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium transition-all border-b-2 -mb-[1px] ${
                activeTab === tab.id
                  ? `${tab.color || "text-brand-blue"} border-current`
                  : "opacity-40 border-transparent hover:opacity-70"
              }`}>
              {tab.icon && <tab.icon size={14} />}
              {tab.label}
              {(tab.id === "ai" || tab.id === "transcript") && c.has_transcript && (
                <span className={`w-1.5 h-1.5 rounded-full ml-1 ${tab.id === "ai" ? "bg-brand-purple" : "bg-brand-indigo"}`} />
              )}
            </button>
          ))}
        </div>

        {/* Transcript Tab — nothing but the words, directly under the player */}
        {activeTab === "transcript" && (
          <div className="p-6">
            <AIAnalysis
              view="transcript"
              callid={c.callid}
              hasRecording={c.has_recording}
              hasTranscript={c.has_transcript}
              selectedRecording={sel}
              currentTime={playTime}
            />
          </div>
        )}

        {/* AI Analysis Tab */}
        {activeTab === "ai" && (
          <div className="p-6">
            <ComplianceQAPanel call={c} />
            <AIAnalysis
              view="analysis"
              callid={c.callid}
              hasRecording={c.has_recording}
              hasTranscript={c.has_transcript}
              selectedRecording={sel}
              currentTime={playTime}
            />
          </div>
        )}

        {/* Detail Tab */}
        {activeTab === "detail" && (<div className="p-6 space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { l: "Direction", v: <div className="flex flex-wrap gap-1">{(c.call_direction || "").split("/").map((d, i) => <span key={i} className={d === "inbound" ? "badge-green" : d === "outbound" ? "badge-blue" : "badge-gray"}>{d}</span>)}</div>, badge: null },
              { l: "Status", v: c.is_answered ? (c.transfer_type === "attended" ? "Answered \u2B50 Att. Transfer" : c.transfer_type === "blind" ? "Answered \u2B50 Blind Transfer" : "Answered") : c.is_abandoned ? "Abandoned" : "Missed", badge: c.is_answered ? "badge-green" : "badge-red" },
              { l: "Duration", v: `${Math.round(c.duration_seconds || 0)}s` },
              { l: "Talk Time", v: `${Math.round(c.talk_seconds || 0)}s` },
              { l: "Routing", v: c.routing_method },
              { l: "MOS", v: c.avg_mos_score || "N/A" },
              { l: "Queue", v: c.answering_queue_name || "—" },
              { l: "Extension", v: c.answering_extension_name || "—" },
              { l: "Answer Time", v: c.answer_seconds != null ? Math.round(c.answer_seconds) + "s" : "—" },
              { l: "Category", v: c.category || "—" },
              { l: "CMC", v: c.cmc || "—" },
            ].map((item, i) => (
              <div key={i} className="bg-black/5 dark:bg-white/5 rounded-xl p-3">
                <div className="text-xs opacity-40 mb-1">{item.l}</div>
                {item.badge ? <span className={item.badge}>{item.v}</span> : <div className="text-sm font-semibold">{item.v}</div>}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4">
              <div className="text-xs opacity-40 mb-2">From</div>
              <div className="text-sm font-medium">{c.from_display_name}</div>
              <div className="text-xs opacity-50">{c.from_number_raw}</div>
            </div>
            <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4">
              <div className="text-xs opacity-40 mb-2">To</div>
              <div className="text-sm font-medium">{c.to_display_name}</div>
              <div className="text-xs opacity-50">{c.to_number_raw}</div>
            </div>
          </div>
          {c.comment && (
            <div className="bg-black/5 dark:bg-white/5 rounded-xl p-4">
              <div className="text-xs opacity-40 mb-2 flex items-center gap-1.5">
                <MessageSquare size={12} /> Comment
              </div>
              <div className="text-sm whitespace-pre-wrap break-words">{c.comment}</div>
            </div>
          )}
          {states.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold mb-3">Call Flow Timeline</h4>
              <div className="space-y-2">
                {states.map((s, i) => (
                  <div key={i} className="flex items-start gap-3 bg-black/5 dark:bg-white/5 rounded-xl p-3">
                    <span className="text-xl mt-0.5">{stateIcons[s.type] || "📞"}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-semibold capitalize">{s.type}</span>
                        {s["account-name"] && <span className="text-xs text-brand-indigo">{s["account-name"]} ({s.account})</span>}
                        {s["extension-name"] && <span className="text-xs text-brand-green">→ {s["extension-name"]} ({s.extension})</span>}
                      </div>
                      <div className="flex gap-3 mt-1 flex-wrap">
                        {parseInt(s.durationivr||0) > 0 && <span className="text-[11px] text-brand-indigo">IVR {(parseInt(s.durationivr)/1000).toFixed(1)}s</span>}
                        {parseInt(s.durationring||0) > 0 && <span className="text-[11px] text-brand-blue">Ring {(parseInt(s.durationring)/1000).toFixed(1)}s</span>}
                        {parseInt(s.durationtalk||0) > 0 && <span className="text-[11px] text-brand-green">Talk {(parseInt(s.durationtalk)/1000).toFixed(1)}s</span>}
                        {parseInt(s.durationhold||0) > 0 && <span className="text-[11px] text-brand-orange">Hold {(parseInt(s.durationhold)/1000).toFixed(1)}s</span>}
                        {s.reason && <span className="text-[11px] opacity-40">{reasonLabels[s.reason] || s.reason}</span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {recs.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold mb-3">Recordings ({recs.length})</h4>
              <div className="space-y-1.5">
                {recs.map((r, i) => (
                  <button key={r._id || i} onClick={() => { setRecIdx(i); setPlayTime(0); }}
                    className={`w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl text-left transition ${
                      i === recIdx
                        ? "bg-brand-purple/10 ring-1 ring-brand-purple/30"
                        : "bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10"
                    }`}>
                    <span className="text-sm truncate">{r.original_filename}</span>
                    <span className="text-[11px] opacity-40 shrink-0 tabular-nums">
                      {r.duration_seconds ? Math.round(r.duration_seconds) + "s \u00B7 " : ""}
                      {(r.size_bytes / 1024).toFixed(0)} KB
                      {r.extension ? " \u00B7 ext " + r.extension : ""}
                    </span>
                  </button>
                ))}
              </div>
              <p className="text-[10px] opacity-25 mt-2">Plays in the bar at the top of this panel.</p>
            </div>
          )}
          <ShareCallButton call={c} />
        </div>)}
      </div>
    </div>
  );
}

/* ── Party Cell (Name + Number) ──────────────────── */
function PartyCell({ displayName, numberRaw, country, countryFlag }) {
  const name = displayName || "";
  const num = numberRaw || "";
  const flag = countryFlag || "";
  const isNameDifferent = name && name !== num;
  return (
    <td className="table-cell">
      {isNameDifferent ? (
        <><div className="text-sm">{flag && <span className="mr-1">{flag}</span>}{name}</div><div className="text-xs opacity-40 tabular-nums">{num}</div></>
      ) : (
        <div className="text-sm tabular-nums">{flag && <span className="mr-1">{flag}</span>}{num || name || "—"}</div>
      )}
    </td>
  );
}

/* -- Column Definitions ---------------------------- */
/* Adding a column is a one-line entry here plus a case in CallCell.
   colSpan is derived from visibleCols.length, so it can never drift. */

const COLS_STORAGE_KEY = "cdrstats:calls:columns";

const COLUMNS = [
  { key: "time",      label: "Time",        def: true },
  { key: "tenant",    label: "Tenant",      def: true, hideWhenTenant: true },
  { key: "from",      label: "From",        def: true },
  { key: "to",        label: "To",          def: true },
  { key: "duration",  label: "Duration",    def: true },
  { key: "answer",    label: "Answer Time", def: false },
  { key: "direction", label: "Direction",   def: true },
  { key: "status",    label: "Status",      def: true },
  { key: "accounts",  label: "Accounts",    def: true },
  { key: "category",  label: "Category",    def: false },
  { key: "cmc",       label: "CMC",         def: false },
  { key: "comment",   label: "Comment",     def: false },
  { key: "rating",    label: "Rating",      def: false },
  { key: "mos",       label: "MOS",         def: true },
  { key: "ai",        label: "AI",          def: true },
  { key: "score",     label: "Score",       def: true },
  { key: "play",      label: "Play",        def: true, center: true },
  { key: "debug",     label: "Debug",       def: true, center: true },
];

const DEFAULT_COL_PREFS = COLUMNS.reduce((acc, c) => { acc[c.key] = c.def; return acc; }, {});

function loadColPrefs() {
  try {
    const raw = window.localStorage.getItem(COLS_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_COL_PREFS };
    const saved = JSON.parse(raw);
    if (!saved || typeof saved !== "object") return { ...DEFAULT_COL_PREFS };
    const merged = { ...DEFAULT_COL_PREFS };
    for (const c of COLUMNS) {
      if (typeof saved[c.key] === "boolean") merged[c.key] = saved[c.key];
    }
    return merged;
  } catch {
    return { ...DEFAULT_COL_PREFS };
  }
}

function saveColPrefs(prefs) {
  try { window.localStorage.setItem(COLS_STORAGE_KEY, JSON.stringify(prefs)); } catch { /* ignore */ }
}

/* -- Column Picker --------------------------------- */
function ColumnPicker({ prefs, onChange, activeTenant }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const options = COLUMNS.filter(c => !(c.hideWhenTenant && activeTenant));
  const hiddenCount = options.filter(c => !prefs[c.key]).length;

  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen(!open)}
        className="glass-select text-sm whitespace-nowrap flex items-center gap-2 opacity-70 hover:opacity-100"
        title="Show or hide table columns">
        <SlidersHorizontal size={14} />
        Columns{hiddenCount > 0 ? " (" + hiddenCount + " hidden)" : ""}
      </button>
      {open && (
        <div className="absolute z-50 right-0 mt-1 bg-white dark:bg-surface-800 border border-black/10 dark:border-white/10 rounded-xl overflow-hidden shadow-2xl shadow-black/30"
          style={{ minWidth: "220px" }}>
          <div className="max-h-80 overflow-y-auto py-1">
            {options.map(col => (
              <label key={col.key}
                className="flex items-center gap-2.5 px-3 py-2 text-sm cursor-pointer hover:bg-black/5 dark:hover:bg-white/5">
                <input type="checkbox" className="accent-brand-blue"
                  checked={!!prefs[col.key]}
                  onChange={() => onChange({ ...prefs, [col.key]: !prefs[col.key] })} />
                <span className={prefs[col.key] ? "" : "opacity-40"}>{col.label}</span>
              </label>
            ))}
          </div>
          <div className="border-t border-black/5 dark:border-white/5 px-3 py-2 flex justify-between">
            <button onClick={() => onChange({ ...DEFAULT_COL_PREFS })}
              className="text-xs opacity-50 hover:opacity-100">Reset</button>
            <button onClick={() => setOpen(false)}
              className="text-xs opacity-50 hover:opacity-100">Done</button>
          </div>
        </div>
      )}
    </div>
  );
}

/* -- Table Cell Renderer --------------------------- */
const ACCOUNT_COLORS = { acd: "badge-red", hunt: "badge-purple", attendant: "badge-blue", mailbox: "badge-orange", extcall: "badge-green", extension: "badge-green", conference: "badge-purple", ivrnode: "badge-blue", orbit: "badge-gray", caller: "badge-gray", trunk: "badge-orange" };
const ACCOUNT_ICONS = { acd: "\u{1F4CB}", hunt: "\u{1F50D}", attendant: "\u{1F4DE}", mailbox: "\u{1F4EC}", extcall: "\u260E\uFE0F", extension: "\u{1F464}", conference: "\u{1F3A4}", ivrnode: "\u{1F522}", orbit: "\u{1F17F}\uFE0F", caller: "\u{1F3E2}", trunk: "\u{1F310}" };

const EmptyCell = () => <span className="opacity-20">{"\u2014"}</span>;

function CallCell({ col, c, timezone, onPlay, onDebug }) {
  switch (col.key) {
    case "time":
      return <td className="table-cell text-xs whitespace-nowrap">{fmtDateTime(c.start, timezone)}</td>;

    case "tenant":
      return <td className="table-cell text-xs opacity-60">{c.domain}</td>;

    case "from":
      return <PartyCell displayName={c.from_display_name} numberRaw={c.from_number_raw} country={c.from_country} countryFlag={c.from_country_flag} />;

    case "to":
      return <PartyCell displayName={c.to_display_name} numberRaw={c.to_number_raw} country={c.to_country} countryFlag={c.to_country_flag} />;

    case "duration":
      return <td className="table-cell tabular-nums">{Math.round(c.talk_seconds || 0)}s</td>;

    case "answer":
      return (
        <td className="table-cell tabular-nums">
          {c.answer_seconds != null ? (
            <span className={c.answer_seconds <= 20 ? "text-brand-green" : c.answer_seconds <= 60 ? "text-brand-orange" : "text-brand-red"}>
              {Math.round(c.answer_seconds)}s
            </span>
          ) : <EmptyCell />}
        </td>
      );

    case "direction":
      return (
        <td className="table-cell">
          <div className="flex flex-wrap gap-1">
            {(c.call_direction || "").split("/").map((d, i) => (
              <span key={i} className={d === "inbound" ? "badge-green" : d === "outbound" ? "badge-blue" : "badge-gray"}>
                {d}
              </span>
            ))}
          </div>
        </td>
      );

    case "status":
      return (
        <td className="table-cell">
          <div className="flex flex-wrap gap-1">
            <span className={c.is_answered ? "badge-green" : c.is_abandoned ? "badge-red" : "badge-gray"}>
              {c.is_answered ? "Answered" : c.is_abandoned ? "Abandoned" : "Missed"}
            </span>
            {c.transfer_type === "attended" && <span className="badge-purple text-[10px] px-2 py-0.5">{"\u{1F500}"} Att. Transfer</span>}
            {c.transfer_type === "blind" && <span className="badge-blue text-[10px] px-2 py-0.5">{"\u{1F500}"} Blind Transfer</span>}
            {c.is_forwarded && <span className="badge-orange text-[10px] px-2 py-0.5">{"\u21AA"} Forwarded</span>}
          </div>
        </td>
      );

    case "accounts":
      return (
        <td className="table-cell">
          <div className="flex flex-wrap gap-1">
            {(c.accounts || []).map((a, idx) => (
              <span key={idx} className={(ACCOUNT_COLORS[a.type] || "badge-gray") + " text-[10px] px-2 py-0.5"}
                title={a.type + ": " + a.number}>
                {ACCOUNT_ICONS[a.type] || "\u{1F4DE}"} {a.name !== a.number ? a.name + " (" + a.number + ")" : a.number}
              </span>
            ))}
            {(!c.accounts || c.accounts.length === 0) && <span className="text-[10px] opacity-30">{c.routing_method || "direct"}</span>}
          </div>
        </td>
      );

    case "category":
      return <td className="table-cell text-xs">{c.category || <EmptyCell />}</td>;

    case "cmc":
      return <td className="table-cell text-xs tabular-nums">{c.cmc || <EmptyCell />}</td>;

    case "comment":
      return (
        <td className="table-cell text-xs">
          <div className="truncate max-w-[220px]" title={c.comment || ""}>
            {c.comment || <EmptyCell />}
          </div>
        </td>
      );

    case "rating":
      return <td className="table-cell text-xs">{c.rating || <EmptyCell />}</td>;

    case "mos":
      return <td className="table-cell tabular-nums">{c.avg_mos_score || "\u2014"}</td>;

    case "ai":
      return (
        <td className="table-cell">
          {c.sentiment ? (
            <span className={"badge text-[10px] px-2 py-0.5 " + (
              c.sentiment === "positive" ? "badge-green" :
              c.sentiment === "negative" ? "badge-red" : "badge-blue"
            )}>{c.sentiment}</span>
          ) : c.has_transcript ? (
            <span className="text-[10px] opacity-20">transcribed</span>
          ) : c.has_recording ? (
            <span className="text-[10px] opacity-15">...</span>
          ) : null}
        </td>
      );

    case "score":
      return (
        <td className="table-cell">
          <div className="flex items-center gap-1.5">
            {c.compliance ? (
              <span title={(c.compliance.violations || []).map(v => v.name).join(", ") || "All rules passed"}
                className={"badge text-[10px] px-2 py-0.5 " + (c.compliance_passed ? "badge-green" : "badge-red")}>
                {c.compliance_passed ? "Pass" : "Fail \u00B7 " + (c.compliance.violations || []).length}
              </span>
            ) : null}
            {c.qa_score != null && (
              <span className="badge-purple text-[10px] px-2 py-0.5" title="AI QA score">QA {c.qa_score}</span>
            )}
          </div>
        </td>
      );

    case "play":
      return (
        <td className="table-cell text-center">
          {c.has_recording ? (
            <button onClick={(e) => onPlay(e, c.callid)}
              className="p-1.5 rounded-lg bg-brand-purple/10 hover:bg-brand-purple/20 transition" title="Play recording">
              <Play size={14} className="text-brand-purple" />
            </button>
          ) : <span className="opacity-20">{"\u2014"}</span>}
        </td>
      );

    case "debug":
      return (
        <td className="table-cell text-center">
          <button onClick={(e) => onDebug(e, c.callid)}
            className="p-1.5 rounded-lg bg-brand-orange/10 hover:bg-brand-orange/20 transition" title="Debug info">
            <Bug size={14} className="text-brand-orange" />
          </button>
        </td>
      );

    default:
      return <td className="table-cell" />;
  }
}

/* ── Main Calls Page ─────────────────────────────── */

export default function Calls() {
  const { domainParam, activeTenant , timezone} = useTenant();
  const { toQueryParams, preset, customFrom, customTo } = useDateRange();
  const [calls, setCalls] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 25, total: 0, pages: 0 });
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState({
    direction: "", answered: "", from_country: "", to_country: "", violations: "",
    queue: "", agent: "", answer_bucket: "", category: "", cmc: "",
    min_duration: "", max_duration: "", min_mos: "", has_recording: "", routing_method: "",
  });
  const [showMore, setShowMore] = useState(false);
  const [queueOptions, setQueueOptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [countryOptions, setCountryOptions] = useState({ from: [], to: [] });
  const [detail, setDetail] = useState(null);
  const [detailTab, setDetailTab] = useState(null);
  const [detailAutoPlay, setDetailAutoPlay] = useState(false);
  const [debugPopup, setDebugPopup] = useState(null);
  const [searchParams, setSearchParams] = useSearchParams();
  const [colPrefs, setColPrefs] = useState(loadColPrefs);

  useEffect(() => { saveColPrefs(colPrefs); }, [colPrefs]);

  const visibleCols = COLUMNS.filter(c => !!colPrefs[c.key] && !(c.hideWhenTenant && activeTenant));

  const MORE_FILTER_KEYS = [
    "queue", "agent", "answer_bucket", "category", "cmc",
    "min_duration", "max_duration", "min_mos", "has_recording", "routing_method",
  ];
  const activeMoreCount = MORE_FILTER_KEYS.filter(k => filters[k]).length;
  const clearMoreFilters = () => setFilters(p => {
    const next = { ...p };
    for (const k of MORE_FILTER_KEYS) next[k] = "";
    return next;
  });

  // Auto-open call detail if ?open=callid is in URL
  // Auto-filter by agent if ?agent=ext is in URL
  useEffect(() => {
    const openCallId = searchParams.get("open");
    const openTab = searchParams.get("tab");
    const agentExt = searchParams.get("agent");

    if (openCallId) {
      api.get(`/api/calls/${encodeURIComponent(openCallId)}`)
        .then(data => {
          setDetail(data);
          if (openTab) setDetailTab(openTab);
        })
        .catch(err => console.error("Failed to open call:", err));
      searchParams.delete("open");
      searchParams.delete("tab");
      setSearchParams(searchParams, { replace: true });
    }

    const dirParam = searchParams.get("direction");
    if (dirParam) {
      setFilters(f => ({ ...f, direction: dirParam }));
      searchParams.delete("direction");
      setSearchParams(searchParams, { replace: true });
    }

    const bucketParam = searchParams.get("answer_bucket");
    if (bucketParam) {
      setFilters(f => ({ ...f, answer_bucket: bucketParam }));
      setShowMore(true);
      searchParams.delete("answer_bucket");
      setSearchParams(searchParams, { replace: true });
    }

    const queueParam = searchParams.get("queue");
    if (queueParam) {
      setFilters(f => ({ ...f, queue: queueParam }));
      setShowMore(true);
      searchParams.delete("queue");
      setSearchParams(searchParams, { replace: true });
    }

    const categoryParam = searchParams.get("category");
    if (categoryParam) {
      setFilters(f => ({ ...f, category: categoryParam }));
      setShowMore(true);
      searchParams.delete("category");
      setSearchParams(searchParams, { replace: true });
    }

    const searchParam = searchParams.get("search");
    if (searchParam) {
      setSearch(searchParam);
      searchParams.delete("search");
      setSearchParams(searchParams, { replace: true });
    }

    if (agentExt) {
      setSearch(agentExt);
      searchParams.delete("agent");
      setSearchParams(searchParams, { replace: true });
    }
  }, []);

  useEffect(() => {
    api.get("/api/stats/queues" + (domainParam ? "?domain=" + encodeURIComponent(domainParam) : ""))
      .then(d => setQueueOptions(d.queues || []))
      .catch(() => setQueueOptions([]));
  }, [domainParam]);

  const loadCalls = useCallback(async (page = 1) => {
    setLoading(true);
    const params = new URLSearchParams({ page, limit: 25 });
    if (search) params.set("search", search);
    if (filters.violations) params.set("violations", "true");
    for (const k of ["queue", "agent", "answer_bucket", "category", "cmc",
                     "min_duration", "max_duration", "min_mos", "routing_method"]) {
      if (filters[k]) params.set(k, filters[k]);
    }
    if (filters.has_recording) params.set("has_recording", filters.has_recording);
    if (filters.direction) params.set("direction", filters.direction);
    if (filters.answered === "att_transfer") {
      params.set("transfer_type", "attended");
    } else if (filters.answered === "blind_transfer") {
      params.set("transfer_type", "blind");
    } else if (filters.answered === "forwarded") {
      params.set("forwarded", "true");
    } else if (filters.answered === "missed") {
      params.set("answered", "false");
      params.set("abandoned", "false");
    } else if (filters.answered === "abandoned") {
      params.set("abandoned", "true");
    } else if (filters.answered) {
      params.set("answered", filters.answered);
    }
    if (filters.from_country) params.set("from_country", filters.from_country);
    if (filters.to_country) params.set("to_country", filters.to_country);
    if (activeTenant) params.set("domain", activeTenant.domain);
    const drp = toQueryParams();
    if (drp) drp.split("&").forEach(p => { const [k,v] = p.split("="); params.set(k, decodeURIComponent(v)); });
    try {
      const data = await api.get(`/api/calls?${params}`);
      setCalls(data.calls || []);
      setPagination(data.pagination || {});
    } catch (err) { console.error(err); }
    setLoading(false);
  }, [search, filters, activeTenant, preset, customFrom, customTo]);

  useEffect(() => { loadCalls(); }, [loadCalls]);

  const autoRefresh = useAutoRefresh(loadCalls, 1800);

  // Load country options for filters
  useEffect(() => {
    const params = new URLSearchParams();
    if (filters.from_country) params.set("from_country", filters.from_country);
    if (filters.to_country) params.set("to_country", filters.to_country);
    if (activeTenant) params.set("domain", activeTenant.domain);
    const drp = toQueryParams();
    if (drp) drp.split("&").forEach(p => { const [k,v] = p.split("="); params.set(k, decodeURIComponent(v)); });
    api.get(`/api/stats/countries-list?${params}`).then(d => {
      setCountryOptions({ from: d.from_countries || [], to: d.to_countries || [] });
    }).catch(() => {});
  }, [activeTenant, preset, customFrom, customTo]);

  const openDetail = async (callid) => {
    try { setDetail(await api.get(`/api/calls/${encodeURIComponent(callid)}`)); } catch (err) { console.error(err); }
  };

  // Play from the table: open the drawer on the transcript view and start
  // playback, so the transcript follows along immediately.
  const openRecordings = async (e, callid) => {
    e.stopPropagation();
    try {
      setDetailTab("transcript");
      setDetailAutoPlay(true);
      setDetail(await api.get(`/api/calls/${encodeURIComponent(callid)}`));
    } catch (err) { console.error(err); }
  };

  const openDebug = async (e, callid) => {
    e.stopPropagation();
    try { setDebugPopup(await api.get(`/api/calls/${encodeURIComponent(callid)}`)); } catch (err) { console.error(err); }
  };


return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Call Records</h2>
          <p className="text-sm opacity-40 mt-1">{pagination.total} total calls{activeTenant ? ` — ${activeTenant.domain}` : ""}</p>
        </div>
        <RefreshIndicator {...autoRefresh} interval={1800} />
        <ExportButton url={`/api/export/calls?${new URLSearchParams(Object.fromEntries([[activeTenant && "domain", activeTenant?.domain], ...Object.entries({search, ...filters}).filter(([,v])=>v), ...toQueryParams().split("&").filter(Boolean).map(p => p.split("="))].filter(([k])=>k))).toString()}`} label="Export CSV" />
      </div>

      <DateFilterBar />

      {/* Filters */}
      {/* relative z-30: .glass uses backdrop-blur, which creates a stacking
          context. Without an explicit z-index here, the table card below is a
          later sibling context and paints over the Columns dropdown no matter
          how high the dropdown's own z-index is. */}
      <div className="glass-card mb-6 relative z-30">
        <div className="flex flex-wrap gap-3 items-end">
          <div className="flex-1 min-w-[200px] relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-30" />
            <input className="glass-input w-full pl-10" placeholder="Search number, name, extension..."
              value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === "Enter" && loadCalls()} />
          </div>
          <select className="glass-select" value={filters.direction}
            onChange={e => setFilters(p => ({ ...p, direction: e.target.value }))}>
            <option value="">All Directions</option>
            <option value="inbound">Inbound</option>
            <option value="outbound">Outbound</option>
            <option value="internal">Internal</option>
          </select>
          <select className="glass-select" value={filters.answered}
            onChange={e => setFilters(p => ({ ...p, answered: e.target.value }))}>
            <option value="">All Status</option>
            <option value="true">Answered</option>
            <option value="false">Not Answered</option>
            <option value="missed">Missed</option>
            <option value="abandoned">Abandoned</option>
            <option value="att_transfer">Attended Transfer</option>
            <option value="blind_transfer">Blind Transfer</option>
            <option value="forwarded">Forwarded</option>
          </select>
          <button onClick={() => setFilters(p => ({ ...p, violations: p.violations ? "" : "true" }))}
            className={"glass-select text-sm whitespace-nowrap " + (filters.violations ? "!bg-brand-red/15 !text-brand-red font-semibold" : "opacity-60")}
            title="Show only calls with compliance violations">
            {filters.violations ? "\u2713 Violations" : "Violations"}
          </button>
          <select className="glass-select" value={filters.from_country}
            onChange={e => setFilters(p => ({ ...p, from_country: e.target.value }))}>
            <option value="">From Country</option>
            {countryOptions.from.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <select className="glass-select" value={filters.to_country}
            onChange={e => setFilters(p => ({ ...p, to_country: e.target.value }))}>
            <option value="">To Country</option>
            {countryOptions.to.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <button className="btn-primary text-sm" onClick={() => loadCalls()}>Search</button>
          <ColumnPicker prefs={colPrefs} onChange={setColPrefs} activeTenant={activeTenant} />
          <button onClick={() => setShowMore(!showMore)}
            className={"glass-select text-sm whitespace-nowrap flex items-center gap-2 " + (activeMoreCount > 0 ? "!bg-brand-blue/15 !text-brand-blue font-semibold" : "opacity-60 hover:opacity-100")}
            title="More filters">
            <Filter size={14} />
            More{activeMoreCount > 0 ? " (" + activeMoreCount + ")" : ""}
          </button>
        </div>

        {showMore && (
          <div className="mt-4 pt-4 border-t border-black/5 dark:border-white/5">
            <div className="flex flex-wrap gap-3 items-end">
              <select className="glass-select" value={filters.queue}
                onChange={e => setFilters(p => ({ ...p, queue: e.target.value }))}>
                <option value="">All Queues</option>
                {/* A deep link from the Queues page can carry several queue
                    ids at once, which matches no single option. Surface it
                    so the control does not look empty while filtering. */}
                {filters.queue && filters.queue.includes(",") && (
                  <option value={filters.queue}>{filters.queue.split(",").length} queues</option>
                )}
                {queueOptions.map(q => (
                  <option key={q.queue} value={q.queue}>{q.name || q.queue}</option>
                ))}
              </select>

              <select className="glass-select" value={filters.answer_bucket}
                onChange={e => setFilters(p => ({ ...p, answer_bucket: e.target.value }))}
                title="Time to answer (answered calls only)">
                <option value="">Any Answer Time</option>
                <option value="le30">Answered {"\u2264"} 30s</option>
                <option value="le60">Answered {"\u2264"} 60s</option>
                <option value="le300">Answered {"\u2264"} 5m</option>
                <option value="gt300">Answered {">"} 5m</option>
                <option disabled>{"\u2500\u2500"}</option>
                <option value="0-10">{"\u2264"} 10s</option>
                <option value="10-20">10 {"\u2013"} 20s</option>
                <option value="20-30">20 {"\u2013"} 30s</option>
                <option value="30-60">30 {"\u2013"} 60s</option>
                <option value="60-120">1 {"\u2013"} 2m</option>
                <option value="120-300">2 {"\u2013"} 5m</option>
                <option value="300-600">5 {"\u2013"} 10m</option>
                <option value="600-900">10 {"\u2013"} 15m</option>
                <option value="900+">{">"} 15m</option>
              </select>

              <select className="glass-select" value={filters.routing_method}
                onChange={e => setFilters(p => ({ ...p, routing_method: e.target.value }))}>
                <option value="">Any Routing</option>
                <option value="acd">Queue (ACD)</option>
                <option value="hunt">Hunt Group</option>
                <option value="attendant">Auto Attendant</option>
                <option value="direct">Direct</option>
                <option value="mailbox">Mailbox</option>
              </select>

              <select className="glass-select" value={filters.has_recording}
                onChange={e => setFilters(p => ({ ...p, has_recording: e.target.value }))}>
                <option value="">Any Recording</option>
                <option value="true">Has Recording</option>
                <option value="false">No Recording</option>
              </select>

              <input className="glass-input w-[130px]" placeholder="Agent ext"
                value={filters.agent}
                onChange={e => setFilters(p => ({ ...p, agent: e.target.value }))}
                onKeyDown={e => e.key === "Enter" && loadCalls()} />

              <input className="glass-input w-[130px]" placeholder="Category"
                value={filters.category}
                onChange={e => setFilters(p => ({ ...p, category: e.target.value }))}
                onKeyDown={e => e.key === "Enter" && loadCalls()} />

              <input className="glass-input w-[110px]" placeholder="CMC"
                value={filters.cmc}
                onChange={e => setFilters(p => ({ ...p, cmc: e.target.value }))}
                onKeyDown={e => e.key === "Enter" && loadCalls()} />

              <div className="flex items-center gap-1.5">
                <input className="glass-input w-[86px]" type="number" min="0" placeholder="Min s"
                  value={filters.min_duration}
                  onChange={e => setFilters(p => ({ ...p, min_duration: e.target.value }))} />
                <span className="opacity-30 text-xs">talk</span>
                <input className="glass-input w-[86px]" type="number" min="0" placeholder="Max s"
                  value={filters.max_duration}
                  onChange={e => setFilters(p => ({ ...p, max_duration: e.target.value }))} />
              </div>

              <select className="glass-select" value={filters.min_mos}
                onChange={e => setFilters(p => ({ ...p, min_mos: e.target.value }))}
                title="Minimum MOS score">
                <option value="">Any MOS</option>
                <option value="4">MOS {"\u2265"} 4.0 (good)</option>
                <option value="3">MOS {"\u2265"} 3.0 (fair)</option>
              </select>

              {activeMoreCount > 0 && (
                <button onClick={clearMoreFilters}
                  className="text-xs opacity-50 hover:opacity-100 underline px-2 py-3">
                  Clear {activeMoreCount}
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Table */}
      <div className="glass overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-black/5 dark:bg-white/[0.03]">
                {visibleCols.map(col => (
                  <th key={col.key} className={"table-header" + (col.center ? " text-center" : "")}>
                    {col.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={visibleCols.length} className="table-cell text-center opacity-30 py-12">Loading...</td></tr>
              ) : calls.length === 0 ? (
                <tr><td colSpan={visibleCols.length} className="table-cell text-center opacity-30 py-12">No calls found</td></tr>
              ) : calls.map(c => (
                <tr key={c._id} onClick={() => openDetail(c.callid)}
                  className="cursor-pointer hover:bg-black/5 dark:hover:bg-white/[0.03] transition">
                  {visibleCols.map(col => (
                    <CallCell key={col.key} col={col} c={c} timezone={timezone}
                      onPlay={openRecordings} onDebug={openDebug} />
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {pagination.pages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-black/5 dark:border-white/5">
            <span className="text-xs opacity-40">Page {pagination.page} of {pagination.pages}</span>
            <div className="flex gap-2">
              <button disabled={pagination.page <= 1} onClick={() => loadCalls(pagination.page - 1)}
                className="btn-secondary text-xs px-3 py-1.5 disabled:opacity-30"><ChevronLeft size={14} /></button>
              <button disabled={pagination.page >= pagination.pages} onClick={() => loadCalls(pagination.page + 1)}
                className="btn-secondary text-xs px-3 py-1.5 disabled:opacity-30"><ChevronRight size={14} /></button>
            </div>
          </div>
        )}
      </div>

      {detail && (
        <CallDetail
          call={detail}
          initialTab={detailTab}
          autoPlay={detailAutoPlay}
          onClose={() => { setDetail(null); setDetailTab(null); setDetailAutoPlay(false); }}
        />
      )}
      {debugPopup && <DebugPanel call={debugPopup} onClose={() => setDebugPopup(null)} />}
    </div>
  );
}
