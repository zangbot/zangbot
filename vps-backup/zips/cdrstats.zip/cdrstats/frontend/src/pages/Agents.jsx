import { useState, useEffect, useCallback } from "react";
import { api } from "../api/client";
import { useTenant } from "../context/TenantContext";
import { useDateRange } from "../context/DateRangeContext";
import { useTheme } from "../context/ThemeContext";
import { useChartColors } from "../chartConfig";
import { useNavigate } from "react-router-dom";
import DateFilterBar from "../components/DateFilterBar";
import ExportButton from "../components/ExportButton";
import { useAutoRefresh, RefreshIndicator } from "../components/AutoRefresh";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Phone, PhoneIncoming, PhoneOutgoing, Users } from "lucide-react";

const fmtTime = (s) => { if (!s) return "0s"; s = Math.round(s); return s < 60 ? s+"s" : Math.floor(s/60)+"m "+s%60+"s"; };

function NumbersTable({ title, icon: Icon, data, color, onRowClick }) {
  if (!data || data.length === 0) return null;
  return (
    <div className="glass overflow-hidden">
      <div className="flex items-center gap-2 px-5 py-3 border-b border-black/5 dark:border-white/5">
        <Icon size={16} className={color} />
        <h3 className="text-sm font-semibold">{title}</h3>
        <span className="text-xs opacity-30 ml-auto">{data.length} numbers</span>
      </div>
      <div className="overflow-x-auto"><table className="w-full"><thead><tr className="bg-black/5 dark:bg-white/[0.03]">
        <th className="table-header">Number</th>
        <th className="table-header text-center">Calls</th>
        <th className="table-header text-center">Answered</th>
        <th className="table-header text-center">Total Talk</th>
        <th className="table-header text-center">Avg Talk</th>
      </tr></thead><tbody>
        {data.map(n => (
          <tr key={n.number} className="hover:bg-black/5 dark:hover:bg-white/[0.03] transition cursor-pointer"
              onClick={() => onRowClick && onRowClick(n.number)}>
            <td className="table-cell">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full ${color.replace("text-", "bg-")}/20 flex items-center justify-center text-xs font-bold ${color}`}>
                  {n.country_flag || <Icon size={14} />}
                </div>
                <div>
                  <div className="text-sm font-medium">{n.name !== n.number ? n.name : (n.e164 || n.number)}</div>
                  <div className="text-xs opacity-40">{n.name !== n.number ? (n.e164 || n.number) : ""}</div>
                </div>
              </div>
            </td>
            <td className="table-cell text-center tabular-nums">{n.count}</td>
            <td className="table-cell text-center tabular-nums">{n.answered}</td>
            <td className="table-cell text-center tabular-nums">{fmtTime(n.total_talk)}</td>
            <td className="table-cell text-center tabular-nums">{fmtTime(n.avg_talk)}</td>
          </tr>
        ))}
      </tbody></table></div>
    </div>
  );
}

export default function Agents() {
  const { domainParam, activeTenant } = useTenant();
  const { toQueryParams, preset, customFrom, customTo } = useDateRange();
  const { dark } = useTheme();
  const cc = useChartColors(dark);
  const [agents, setAgents] = useState([]);
  const [numbers, setNumbers] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("extensions");
  const navigate = useNavigate();

  const loadData = useCallback(async () => {
    setLoading(true);
    const dp = domainParam ? domainParam.slice(1) : "";
    const drp = toQueryParams();
    const q = [dp, drp].filter(Boolean).join("&");
    const qs = q ? "?"+q : "";
    try {
      const [agentsData, numbersData] = await Promise.all([
        api.get("/api/stats/agents"+qs),
        api.get("/api/stats/numbers"+qs),
      ]);
      setAgents(agentsData.agents||[]);
      setNumbers(numbersData);
    } catch(e) { console.error(e); }
    setLoading(false);
  }, [domainParam, preset, customFrom, customTo]);

  useEffect(() => { loadData(); }, [loadData]);

  const autoRefresh = useAutoRefresh(loadData, 1800);

  if (loading) return <div className="opacity-50 text-center py-20 animate-pulse">Loading...</div>;

  const chartData = agents.slice(0,10).map(a => ({ name: a.name, calls: a.total_calls }));
  const exportQs = [domainParam ? domainParam.slice(1) : "", toQueryParams()].filter(Boolean).join("&");

  const tabs = [
    { id: "extensions", label: "Extensions", icon: Users },
    { id: "numbers", label: "Numbers", icon: Phone },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-2xl font-bold">Extension & Number Performance</h2>
          <p className="text-sm opacity-40 mt-1">{activeTenant ? activeTenant.domain : "All Tenants"} — {agents.length} extensions</p>
        </div>
        <RefreshIndicator {...autoRefresh} interval={1800} />
        <ExportButton url={"/api/export/agents?" + exportQs} label="Export Agents" />
      </div>

      <DateFilterBar />

      {/* Tabs */}
      <div className="flex gap-1 mb-6 bg-black/5 dark:bg-white/5 rounded-xl p-1 w-fit">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === t.id ? "bg-white dark:bg-surface-800 shadow-sm" : "opacity-50 hover:opacity-80"
            }`}>
            <t.icon size={15} />{t.label}
          </button>
        ))}
      </div>

      {tab === "extensions" && (
        <>
          {agents.length > 0 && (
            <div className="glass-card mb-6">
              <h3 className="text-lg font-semibold mb-6">Top Extensions</h3>
              <div className="h-72"><ResponsiveContainer><BarChart data={chartData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke={cc.grid} />
                <XAxis type="number" tick={{ fill: cc.tick, fontSize: 11 }} />
                <YAxis type="category" dataKey="name" width={100} tick={{ fill: cc.tick, fontSize: 12 }} />
                <Tooltip contentStyle={cc.tooltip} />
                <Bar dataKey="calls" name="Calls" fill="#5856d6" radius={[0,4,4,0]} />
              </BarChart></ResponsiveContainer></div>
            </div>
          )}

          <div className="glass overflow-hidden">
            <div className="overflow-x-auto"><table className="w-full"><thead><tr className="bg-black/5 dark:bg-white/[0.03]">
              <th className="table-header">Extension</th>
              <th className="table-header text-center">Calls</th>
              <th className="table-header text-center">Inbound</th>
              <th className="table-header text-center">Outbound</th>
              <th className="table-header text-center">Total Talk</th>
              <th className="table-header text-center">Avg Talk</th>
              <th className="table-header text-center">Avg Hold</th>
              <th className="table-header text-center">Avg Handle</th>
              <th className="table-header text-center">MOS</th>
            </tr></thead><tbody>
              {agents.length===0 ? (
                <tr><td colSpan={9} className="table-cell text-center opacity-30 py-12">No agent data</td></tr>
              ) : agents.map(a => (
                <tr key={a.extension} className="hover:bg-black/5 dark:hover:bg-white/[0.03] transition cursor-pointer" onClick={() => navigate(`/calls?agent=${a.extension}`)}>
                  <td className="table-cell">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-brand-indigo/20 flex items-center justify-center text-brand-indigo text-xs font-bold">
                        {(a.name || "?")[0].toUpperCase()}
                      </div>
                      <div>
                        <div className="text-sm font-medium">{a.name}</div>
                        <div className="text-xs opacity-40">Ext {a.extension}</div>
                      </div>
                    </div>
                  </td>
                  <td className="table-cell text-center tabular-nums">{a.total_calls}</td>
                  <td className="table-cell text-center tabular-nums text-brand-green">{a.inbound}</td>
                  <td className="table-cell text-center tabular-nums text-brand-blue">{a.outbound}</td>
                  <td className="table-cell text-center tabular-nums">{fmtTime(a.total_talk)}</td>
                  <td className="table-cell text-center tabular-nums">{fmtTime(a.avg_talk)}</td>
                  <td className="table-cell text-center tabular-nums">{fmtTime(a.avg_hold)}</td>
                  <td className="table-cell text-center tabular-nums">{fmtTime(a.avg_handle_time)}</td>
                  <td className="table-cell text-center">
                    {a.avg_mos ? (
                      <span className={a.avg_mos >= 4 ? "text-brand-green" : a.avg_mos >= 3 ? "text-brand-orange" : "text-brand-red"}>
                        {a.avg_mos}
                      </span>
                    ) : <span className="opacity-30">—</span>}
                  </td>
                </tr>
              ))}
            </tbody></table></div>
          </div>
        </>
      )}

      {tab === "numbers" && numbers && (
        <div className="space-y-6">
          <div className="flex justify-end">
            <ExportButton url={"/api/export/numbers?" + exportQs} label="Export Numbers" />
          </div>
          <NumbersTable title="Top Inbound DIDs (Called Numbers)" icon={PhoneIncoming} data={numbers.inbound_dids} color="text-brand-green"
            onRowClick={(num) => navigate(`/calls?search=${encodeURIComponent(num.replace(/^\+/, ""))}&direction=inbound`)} />
          <NumbersTable title="Top Outbound Numbers Dialed" icon={PhoneOutgoing} data={numbers.outbound_dialed} color="text-brand-blue"
            onRowClick={(num) => navigate(`/calls?search=${encodeURIComponent(num.replace(/^\+/, ""))}&direction=outbound`)} />
          <NumbersTable title="Top Inbound Callers" icon={PhoneIncoming} data={numbers.inbound_callers} color="text-brand-orange"
            onRowClick={(num) => navigate(`/calls?search=${encodeURIComponent(num.replace(/^\+/, ""))}&direction=inbound`)} />
        </div>
      )}
    </div>
  );
}
