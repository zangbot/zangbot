import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Sparkles, Loader2, AlertCircle, Sun, Moon } from "lucide-react";

/* ── Simple markdown renderer ──────────────────── */
function renderMarkdown(md) {
  if (!md) return null;
  const lines = md.split("\n");
  const elements = [];
  let listItems = [];
  let key = 0;

  const flushList = () => {
    if (listItems.length > 0) {
      elements.push(
        <ul key={key++} className="space-y-1.5 my-3 ml-4">
          {listItems.map((li, i) => (
            <li key={i} className="text-sm leading-relaxed opacity-80 flex gap-2">
              <span className="text-blue-500 mt-1.5 shrink-0">•</span>
              <span dangerouslySetInnerHTML={{ __html: bold(li) }} />
            </li>
          ))}
        </ul>
      );
      listItems = [];
    }
  };

  const bold = (t) => t.replace(/\*\*(.+?)\*\*/g, '<strong class="font-semibold">$1</strong>');

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) { flushList(); elements.push(<div key={key++} className="h-2" />); continue; }

    if (trimmed.startsWith("# ")) {
      flushList();
      elements.push(<h1 key={key++} className="text-lg font-bold mt-5 mb-2">{trimmed.slice(2)}</h1>);
    } else if (trimmed.startsWith("## ")) {
      flushList();
      elements.push(<h2 key={key++} className="text-base font-bold mt-5 mb-2 text-blue-600 dark:text-blue-400">{trimmed.slice(3)}</h2>);
    } else if (trimmed.startsWith("### ")) {
      flushList();
      elements.push(<h3 key={key++} className="text-sm font-bold mt-4 mb-1.5 opacity-70">{trimmed.slice(4)}</h3>);
    } else if (/^[-*] /.test(trimmed)) {
      listItems.push(trimmed.replace(/^[-*] /, ""));
    } else if (/^\d+\. /.test(trimmed)) {
      listItems.push(trimmed.replace(/^\d+\. /, ""));
    } else {
      flushList();
      elements.push(<p key={key++} className="text-sm leading-relaxed opacity-80 my-1.5" dangerouslySetInnerHTML={{ __html: bold(trimmed) }} />);
    }
  }
  flushList();
  return elements;
}

export default function SharedBriefing() {
  const { token } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dark, setDark] = useState(false);
  const [origTheme] = useState(() => document.documentElement.classList.contains("dark"));

  useEffect(() => {
    // Default to light mode for external viewers
    document.documentElement.classList.remove("dark");
    return () => {
      // Restore original theme when leaving
      if (origTheme) document.documentElement.classList.add("dark");
    };
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    if (next) document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
  };

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`/api/ai/briefing/share/${token}`);
        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          throw new Error(err.error || `Error ${res.status}`);
        }
        setData(await res.json());
      } catch (e) {
        setError(e.message);
      }
      setLoading(false);
    })();
  }, [token]);

  const contextLabels = { dashboard: "Dashboard", queues: "Queue Performance", insights: "AI Insights" };

  if (loading) {
    return (
      <div className="min-h-screen bg-surface-50 dark:bg-surface-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 size={32} className="animate-spin text-brand-blue mx-auto mb-4" />
          <p className="opacity-40">Loading briefing...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-surface-50 dark:bg-surface-900 flex items-center justify-center p-4">
        <div className="glass-card max-w-md w-full text-center">
          <AlertCircle size={48} className="text-brand-red mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Briefing Unavailable</h2>
          <p className="opacity-50 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface-50 dark:bg-surface-900 transition-colors">
      {/* Header */}
      <div className="border-b border-black/5 dark:border-white/[0.06] bg-white/50 dark:bg-white/[0.02]">
        <div className="max-w-3xl mx-auto px-6 py-5 flex items-center justify-between">
          <div>
            <h1 className="text-lg font-semibold flex items-center gap-2">
              <Sparkles size={20} className="text-purple-500" />
              {contextLabels[data.context] || "Analytics"} Briefing
            </h1>
            <p className="text-xs opacity-30 mt-1">
              Shared by {data.shared_by} • {new Date(data.generated_at).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" })}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={toggleTheme} className="p-2 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition" title="Toggle theme">
              {dark ? <Sun size={18} className="opacity-50" /> : <Moon size={18} className="opacity-50" />}
            </button>
            <span className="text-xs opacity-20">Vodia Analytics</span>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-6 py-8">
        {/* Date range badge */}
        <div className="mb-6">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20">
            {data.date_range}
          </span>
        </div>

        {/* Briefing content */}
        <div className="glass-card">
          {renderMarkdown(data.briefing)}
        </div>

        {/* Footer */}
        <div className="text-center text-xs opacity-20 pt-8 pb-8">
          Powered by Vodia Analytics AI
        </div>
      </div>
    </div>
  );
}
