import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";
import { startRegistration } from "@simplewebauthn/browser";
import { ShieldCheck, Fingerprint, QrCode, Copy, Check, ArrowRight } from "lucide-react";

export default function Setup2FA() {
  const [method, setMethod] = useState(null); // null | "passkey" | "totp"
  const [setup, setSetup] = useState(null);
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const codeRefs = useRef([]);
  const navigate = useNavigate();

  // Check if user already has 2FA — redirect to dashboard
  useEffect(() => {
    api.get("/api/auth/totp/status").then(data => {
      if (data.totp_enabled) navigate("/dashboard");
    }).catch(() => {});
    api.get("/api/auth/me").then(data => {
      if (data.passkey_count > 0) navigate("/dashboard");
    }).catch(() => {});
  }, []);

  const setupPasskey = async () => {
    setError(""); setLoading(true);
    try {
      const options = await api.post("/api/auth/passkey/register-options", {});
      if (options.error) { setError(options.error); setLoading(false); return; }
      const regResponse = await startRegistration({ optionsJSON: options });
      const result = await api.post("/api/auth/passkey/register-verify", regResponse);
      if (result.verified) {
        setSuccess("Passkey registered! Redirecting...");
        setTimeout(() => navigate("/dashboard"), 1500);
      } else {
        setError(result.error || "Registration failed");
      }
    } catch (err) {
      if (err.name === "NotAllowedError") setError("Passkey registration cancelled");
      else setError(err.message);
    }
    setLoading(false);
  };

  const setupTotp = async () => {
    setError(""); setLoading(true);
    try {
      const data = await api.post("/api/auth/totp/setup");
      if (data.error) { setError(data.error); setLoading(false); return; }
      setSetup(data);
      setCode(["", "", "", "", "", ""]);
      setTimeout(() => codeRefs.current[0]?.focus(), 100);
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const handleInput = (index, value) => {
    if (!/^\d*$/.test(value)) return;
    const newCode = [...code];
    newCode[index] = value.slice(-1);
    setCode(newCode);
    if (value && index < 5) codeRefs.current[index + 1]?.focus();
    if (newCode.every(d => d !== "") && newCode.join("").length === 6) verifyCode(newCode.join(""));
  };

  const handleKeyDown = (index, e) => {
    if (e.key === "Backspace" && !code[index] && index > 0) codeRefs.current[index - 1]?.focus();
  };

  const handlePaste = (e) => {
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    if (pasted.length === 6) { setCode(pasted.split("")); verifyCode(pasted); }
  };

  const verifyCode = async (codeStr) => {
    setError(""); setLoading(true);
    try {
      const data = await api.post("/api/auth/totp/enable", { code: codeStr });
      if (data.error) {
        setError(data.error);
        setCode(["", "", "", "", "", ""]);
        setTimeout(() => codeRefs.current[0]?.focus(), 100);
      } else {
        setSuccess("2FA is now active! Redirecting...");
        setTimeout(() => navigate("/dashboard"), 1500);
      }
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const copyKey = () => {
    navigator.clipboard.writeText(setup.manual_key);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-surface-50 dark:bg-surface-900 px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <ShieldCheck size={48} className="mx-auto mb-4 text-brand-blue" />
          <h1 className="text-2xl font-bold tracking-tight">Secure Your Account</h1>
          <p className="text-sm opacity-50 mt-2">Two-factor authentication is required. Choose a method below to protect your account.</p>
        </div>

        {error && <div className="mb-4 p-3 rounded-xl bg-brand-red/10 text-brand-red text-sm">{error}</div>}
        {success && <div className="mb-4 p-3 rounded-xl bg-brand-green/10 text-brand-green text-sm">{success}</div>}

        {!method && !success && (
          <div className="space-y-3">
            <button onClick={() => { setMethod("passkey"); setupPasskey(); }}
              className="w-full glass-card flex items-center gap-4 p-5 hover:border-brand-blue/30 transition cursor-pointer text-left">
              <div className="w-12 h-12 rounded-xl bg-brand-indigo/10 flex items-center justify-center flex-shrink-0">
                <Fingerprint size={24} className="text-brand-indigo" />
              </div>
              <div className="flex-1">
                <div className="text-sm font-semibold">Passkey</div>
                <div className="text-xs opacity-50 mt-0.5">Use fingerprint, face recognition, or a security key. Fastest and most secure.</div>
              </div>
              <ArrowRight size={16} className="opacity-30" />
            </button>

            <button onClick={() => { setMethod("totp"); setupTotp(); }}
              className="w-full glass-card flex items-center gap-4 p-5 hover:border-brand-blue/30 transition cursor-pointer text-left">
              <div className="w-12 h-12 rounded-xl bg-brand-blue/10 flex items-center justify-center flex-shrink-0">
                <QrCode size={24} className="text-brand-blue" />
              </div>
              <div className="flex-1">
                <div className="text-sm font-semibold">Authenticator App</div>
                <div className="text-xs opacity-50 mt-0.5">Use Google Authenticator, Microsoft Authenticator, Authy, or similar app.</div>
              </div>
              <ArrowRight size={16} className="opacity-30" />
            </button>
          </div>
        )}

        {method === "passkey" && !success && (
          <div className="glass-card text-center p-6">
            <Fingerprint size={48} className="mx-auto mb-4 text-brand-indigo animate-pulse" />
            <p className="text-sm opacity-60">Follow your browser's prompt to register a passkey...</p>
            <button onClick={() => { setMethod(null); setError(""); }} className="mt-4 text-sm opacity-50 hover:opacity-80 transition">
              ← Choose a different method
            </button>
          </div>
        )}

        {method === "totp" && setup && !success && (
          <div className="glass-card p-6 space-y-5">
            <div className="text-center">
              <p className="text-sm font-medium mb-3">Scan this QR code with your authenticator app</p>
              <img src={setup.qr} alt="TOTP QR Code" className="mx-auto rounded-xl" style={{ width: 200, height: 200 }} />
            </div>
            <div className="text-center">
              <p className="text-xs opacity-40 mb-1">Or enter this key manually:</p>
              <div className="flex items-center justify-center gap-2">
                <code className="text-xs font-mono bg-black/5 dark:bg-white/5 px-3 py-1.5 rounded-lg select-all">{setup.manual_key}</code>
                <button onClick={copyKey} className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition">
                  {copied ? <Check size={14} className="text-brand-green" /> : <Copy size={14} className="opacity-40" />}
                </button>
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-center mb-3">Enter the 6-digit code to verify</p>
              <div className="flex justify-center gap-2" onPaste={handlePaste}>
                {code.map((digit, i) => (
                  <input key={i} ref={el => codeRefs.current[i] = el}
                    type="text" inputMode="numeric" maxLength={1} value={digit}
                    onChange={e => handleInput(i, e.target.value)}
                    onKeyDown={e => handleKeyDown(i, e)}
                    className="w-11 h-13 text-center text-xl font-mono rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/[0.08] outline-none focus:border-brand-blue transition" />
                ))}
              </div>
            </div>
            <button onClick={() => { setMethod(null); setSetup(null); setError(""); }} className="w-full text-sm opacity-50 hover:opacity-80 transition">
              ← Choose a different method
            </button>
          </div>
        )}

        {method === "totp" && !setup && !success && (
          <div className="glass-card text-center p-6">
            <div className="animate-pulse opacity-50">Loading...</div>
          </div>
        )}
      </div>
    </div>
  );
}
