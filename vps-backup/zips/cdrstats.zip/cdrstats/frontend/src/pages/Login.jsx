import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { api } from "../api/client";
import { startAuthentication } from "@simplewebauthn/browser";
import { Fingerprint, Mail, Lock, ArrowRight, KeyRound, ShieldCheck } from "lucide-react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState("password");
  const [resetToken, setResetToken] = useState("");
  const [totpToken, setTotpToken] = useState("");
  const [passkeyUserId, setPasskeyUserId] = useState("");
  const [totpCode, setTotpCode] = useState(["", "", "", "", "", ""]);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const { login, setUser } = useAuth();
  const navigate = useNavigate();
  useEffect(() => {
    fetch("/api/setup/status")
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (data?.setupRequired) navigate("/setup"); })
      .catch(() => {});
  }, [navigate]);
  const totpRefs = useRef([]);

  const handlePasswordLogin = async (e) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const data = await login(email, password);
      if (data.must_reset_password) {
        setResetToken(data.reset_token); setMode("reset"); setError("");
      } else if (data.requires_2fa) {
        setTotpToken(data.totp_token); setTotpCode(["", "", "", "", "", ""]); setMode("totp"); setError("");
        setTimeout(() => totpRefs.current[0]?.focus(), 100);
      } else if (data.requires_passkey_challenge) {
        setMode("passkey_challenge"); setError(""); setLoading(false);
      } else if (data.requires_2fa_setup) {
        api.setTokens(data.access_token, data.refresh_token);
        setUser(data.user);
        navigate("/setup-2fa");
      } else { navigate("/dashboard"); }
    } catch (err) { setError(err.message); }
    setLoading(false);
  };

  const handleTotpInput = (index, value) => {
    if (!/^\d*$/.test(value)) return;
    const newCode = [...totpCode];
    newCode[index] = value.slice(-1);
    setTotpCode(newCode);
    if (value && index < 5) totpRefs.current[index + 1]?.focus();
    if (newCode.every(d => d !== "") && newCode.join("").length === 6) handleTotpVerify(newCode.join(""));
  };

  const handleTotpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !totpCode[index] && index > 0) totpRefs.current[index - 1]?.focus();
  };

  const handleTotpPaste = (e) => {
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    if (pasted.length === 6) { setTotpCode(pasted.split("")); handleTotpVerify(pasted); }
  };

  const handleTotpVerify = async (code) => {
    setError(""); setLoading(true);
    try {
      const res = await fetch("/api/auth/totp/verify", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ totp_token: totpToken, code }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Invalid code");
        setTotpCode(["", "", "", "", "", ""]);
        setTimeout(() => totpRefs.current[0]?.focus(), 100);
        setLoading(false); return;
      }
      api.setTokens(data.access_token, data.refresh_token);
      window.location.href = "/dashboard";
    } catch (err) { setError(err.message); }
    setLoading(false);
  };

  const handlePasskeyLogin = async () => {
    if (!email) { setError("Enter your email first"); return; }
    setError(""); setLoading(true);
    try {
      const optionsRes = await fetch("/api/auth/passkey/auth-options", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const options = await optionsRes.json();
      if (options.error) { setError(options.error); setLoading(false); return; }
      const authResponse = await startAuthentication({ optionsJSON: options });
      const verifyRes = await fetch("/api/auth/passkey/auth-verify", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: options.user_id, response: authResponse }),
      });
      const result = await verifyRes.json();
      if (!verifyRes.ok) { setError(result.error || "Passkey auth failed"); setLoading(false); return; }
      api.setTokens(result.access_token, result.refresh_token);
      window.location.href = "/dashboard";
    } catch (err) {
      if (err.name === "NotAllowedError") setError("Passkey cancelled");
      else setError(err.message);
    }
    setLoading(false);
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    if (newPassword.length < 8) { setError("Password must be at least 8 characters"); return; }
    if (newPassword !== confirmPassword) { setError("Passwords don't match"); return; }
    setError(""); setLoading(true);
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reset_token: resetToken, new_password: newPassword }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error); setLoading(false); return; }
      api.setTokens(data.access_token, data.refresh_token);
      if (data.requires_2fa_setup) {
        window.location.href = "/setup-2fa";
      } else {
        window.location.href = "/dashboard";
      }
    } catch (err) { setError(err.message); }
    setLoading(false);
  };

  const handlePasskeyChallenge = async () => {
    setLoading(true); setError("");
    try {
      const optionsRes = await fetch("/api/auth/passkey/auth-options", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const options = await optionsRes.json();
      if (options.error) { setError(options.error); setLoading(false); return; }
      const assertion = await startAuthentication({ optionsJSON: options });
      const verifyRes = await fetch("/api/auth/passkey/auth-verify", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: options.user_id, response: assertion }),
      });
      const verifyData = await verifyRes.json();
      if (verifyData.error) { setError(verifyData.error); setLoading(false); return; }
      api.setTokens(verifyData.access_token, verifyData.refresh_token);
      window.location.href = "/dashboard";
    } catch (err) {
      setError(err.name === "NotAllowedError" ? "Passkey verification was cancelled. Tap below to try again." : "Passkey verification failed. Tap below to try again.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-surface-50 dark:bg-surface-900 px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Vodia</h1>
          <p className="text-sm opacity-40 mt-1">Analytics</p>
        </div>
        <div className="glass-card">
          {error && <div className="mb-4 p-3 rounded-xl bg-brand-red/10 text-brand-red text-sm">{error}</div>}

          {mode === "password" && (
            <form onSubmit={handlePasswordLogin} className="space-y-4">
              <div>
                <label className="text-xs opacity-50 mb-1 block">Email</label>
                <div className="relative">
                  <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-30" />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/[0.08] outline-none focus:border-brand-blue text-sm"
                    placeholder="you@company.com" />
                </div>
              </div>
              <div>
                <label className="text-xs opacity-50 mb-1 block">Password</label>
                <div className="relative">
                  <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-30" />
                  <input type="password" value={password} onChange={e => setPassword(e.target.value)} required
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/[0.08] outline-none focus:border-brand-blue text-sm"
                    placeholder="••••••••" />
                </div>
              </div>
              <button type="submit" disabled={loading}
                className="w-full py-2.5 rounded-xl bg-brand-blue text-white text-sm font-medium flex items-center justify-center gap-2 hover:brightness-110 transition disabled:opacity-50">
                {loading ? "Signing in..." : <><ArrowRight size={16} /> Sign In</>}
              </button>
              <button type="button" onClick={handlePasskeyLogin} disabled={loading}
                className="w-full py-2.5 rounded-xl bg-black/5 dark:bg-white/5 text-sm font-medium flex items-center justify-center gap-2 hover:bg-black/10 dark:hover:bg-white/10 transition">
                <Fingerprint size={16} /> Sign in with Passkey
              </button>
            </form>
          )}

          {mode === "totp" && (
            <div className="space-y-4">
              <div className="text-center">
                <ShieldCheck size={32} className="mx-auto mb-3 text-brand-blue" />
                <h3 className="text-lg font-semibold">Two-Factor Authentication</h3>
                <p className="text-sm opacity-50 mt-1">Enter the 6-digit code from your authenticator app</p>
              </div>
              <div className="flex justify-center gap-2" onPaste={handleTotpPaste}>
                {totpCode.map((digit, i) => (
                  <input key={i} ref={el => totpRefs.current[i] = el}
                    type="text" inputMode="numeric" maxLength={1} value={digit}
                    onChange={e => handleTotpInput(i, e.target.value)}
                    onKeyDown={e => handleTotpKeyDown(i, e)}
                    className="w-11 h-13 text-center text-xl font-mono rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/[0.08] outline-none focus:border-brand-blue transition" />
                ))}
              </div>
              <button type="button" onClick={() => { setMode("password"); setError(""); }}
                className="w-full py-2 text-sm opacity-50 hover:opacity-80 transition">
                ← Back to login
              </button>
            </div>
          )}

          {mode === "passkey_challenge" && (
            <div className="space-y-4">
              <div className="text-center">
                <Fingerprint size={32} className="mx-auto mb-3 text-brand-blue" />
                <h3 className="text-lg font-semibold">Verify Your Identity</h3>
                <p className="text-sm opacity-50 mt-1">Use your passkey to complete sign in</p>
              </div>
              <button type="button" onClick={handlePasskeyChallenge} disabled={loading}
                className="w-full py-2.5 rounded-xl bg-brand-blue text-white text-sm font-medium flex items-center justify-center gap-2 hover:brightness-110 transition disabled:opacity-50">
                {loading ? "Verifying..." : <><Fingerprint size={16} /> Tap to Verify</>}
              </button>
              <button type="button" onClick={() => { setMode("password"); setError(""); }}
                className="w-full py-2 text-sm opacity-50 hover:opacity-80 transition">
                ← Back to login
              </button>
            </div>
          )}

          {mode === "reset" && (
            <form onSubmit={handleResetPassword} className="space-y-4">
              <div className="text-center mb-2">
                <KeyRound size={28} className="mx-auto mb-2 text-brand-orange" />
                <h3 className="text-lg font-semibold">Set New Password</h3>
              </div>
              <div>
                <label className="text-xs opacity-50 mb-1 block">New Password</label>
                <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} required minLength={8}
                  className="w-full px-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/[0.08] outline-none focus:border-brand-blue text-sm"
                  placeholder="Min 8 characters" />
              </div>
              <div>
                <label className="text-xs opacity-50 mb-1 block">Confirm Password</label>
                <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required
                  className="w-full px-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/[0.08] outline-none focus:border-brand-blue text-sm"
                  placeholder="Repeat password" />
              </div>
              <button type="submit" disabled={loading}
                className="w-full py-2.5 rounded-xl bg-brand-orange text-white text-sm font-medium hover:brightness-110 transition disabled:opacity-50">
                {loading ? "Saving..." : "Set Password & Sign In"}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
