import TotpSetup from "../components/TotpSetup";
import BriefingSchedules from "../components/BriefingSchedules";
import React from "react";
import { startRegistration } from "@simplewebauthn/browser";
import { useState, useEffect, useMemo, useRef } from "react";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { useTenant } from "../context/TenantContext";
import { Users, Key, Building, Globe, Plus, Trash2, Copy, Check, Fingerprint, Shield, Brain, ToggleLeft, ToggleRight, Mail, Send, Eye, EyeOff, Loader2, Link2, Pencil, HardDrive, Server, X, ClipboardList, RefreshCw, ChevronDown, ChevronRight, Database, CalendarClock } from "lucide-react";

function Tab({ active, onClick, icon: Icon, label }) {
  return (
    <button onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
        active ? "bg-brand-blue/15 text-brand-blue" : "opacity-50 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/5"
      }`}>
      <Icon size={16} /> {label}
    </button>
  );
}

function QueueMultiSelect({ selected, onChange, tenants }) {
  const [open, setOpen] = useState(false);
  const [queues, setQueues] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (tenants.length === 0) { setQueues([]); return; }
    setLoading(true);
    const params = new URLSearchParams();
    tenants.forEach(d => params.append("domain", d));
    api.get("/api/stats/queues?" + params)
      .then(d => setQueues((d.queues || []).map(q => ({ id: String(q.queue), name: q.name || q.queue }))))
      .catch(() => setQueues([]))
      .finally(() => setLoading(false));
  }, [tenants.join(",")]);

  const toggle = (qid) => {
    onChange(selected.includes(qid) ? selected.filter(q => q !== qid) : [...selected, qid]);
  };

  return (
    <div className="relative">
      <label className="block text-xs font-medium opacity-60 mb-1">Queues (for Queue Manager)</label>
      <button type="button" onClick={() => setOpen(!open)}
        className="glass-input w-full text-left flex items-center justify-between">
        <span className={selected.length ? "" : "opacity-40"}>
          {selected.length ? selected.length + " queue" + (selected.length > 1 ? "s" : "") + " selected" : "Select queues"}
        </span>
      </button>
      {open && (
        <div className="absolute z-50 mt-1 w-full glass rounded-xl shadow-lg max-h-48 overflow-y-auto">
          {loading && <div className="px-3 py-2 text-xs opacity-40">Loading queues...</div>}
          {queues.map(q => (
            <label key={q.id} className="flex items-center gap-2 px-3 py-2 hover:bg-brand-blue/10 cursor-pointer text-sm">
              <input type="checkbox" checked={selected.includes(q.id)} onChange={() => toggle(q.id)} className="rounded border-white/20" />
              {q.name} ({q.id})
            </label>
          ))}
          {!loading && queues.length === 0 && <div className="px-3 py-2 text-xs opacity-40">{tenants.length ? "No queues found" : "Select tenants first"}</div>}
        </div>
      )}
    </div>
  );
}

function TenantMultiSelect({ selected, onChange, tenants }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) { setOpen(false); setSearch(""); } };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => {
    if (open && inputRef.current) inputRef.current.focus();
  }, [open]);

  const toggle = (domain) => {
    if (selected.includes(domain)) {
      onChange(selected.filter(d => d !== domain));
    } else {
      onChange([...selected, domain]);
    }
  };

  const filtered = tenants.filter(t =>
    (t.display_name || t.domain).toLowerCase().includes(search.toLowerCase()) ||
    t.domain.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="relative" ref={ref}>
      <button type="button" onClick={() => { setOpen(!open); setSearch(""); }}
        className="glass-input w-full text-left flex items-center justify-between">
        <span className={selected.length > 0 ? "" : "opacity-30"}>
          {selected.length > 0 ? `${selected.length} tenant${selected.length > 1 ? "s" : ""} selected` : "Select tenants..."}
        </span>
        <span className="opacity-30">▾</span>
      </button>
      {selected.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {selected.map(d => (
            <span key={d} className="badge-blue text-[11px] cursor-pointer" onClick={() => toggle(d)}>
              {d} ✕
            </span>
          ))}
        </div>
      )}
      {open && (
        <div className="absolute z-50 bottom-full mb-1 left-0 right-0 bg-white dark:bg-surface-800 border border-black/10 dark:border-white/10 rounded-xl shadow-2xl shadow-black/30 overflow-hidden" style={{ minWidth: "250px" }}>
          <div className="p-2 border-b border-black/5 dark:border-white/5">
            <input ref={inputRef} className="w-full bg-black/5 dark:bg-white/5 rounded-lg px-3 py-2 text-sm outline-none placeholder-black/30 dark:placeholder-white/30"
              placeholder="Search tenants..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <div className="max-h-48 overflow-y-auto">
            {filtered.map(t => (
              <button key={t.domain} type="button" onClick={() => toggle(t.domain)}
                className={`w-full text-left px-3 py-2.5 text-sm transition-all hover:bg-black/5 dark:hover:bg-white/5 border-b border-black/5 dark:border-white/5 flex items-center gap-2 ${
                  selected.includes(t.domain) ? "text-brand-blue" : "opacity-60"
                }`}>
                <span className={`w-4 h-4 rounded border flex items-center justify-center text-[10px] flex-shrink-0 ${
                  selected.includes(t.domain) ? "bg-brand-blue border-brand-blue text-white" : "border-black/20 dark:border-white/20"
                }`}>
                  {selected.includes(t.domain) && "✓"}
                </span>
                <div className="min-w-0">
                  <div className="truncate">{t.display_name || t.domain}</div>
                  <div className="text-[10px] opacity-30 truncate">{t.system}</div>
                </div>
              </button>
            ))}
            {filtered.length === 0 && <div className="px-3 py-4 text-sm opacity-30 text-center">No tenants match</div>}
          </div>
        </div>
      )}
    </div>
  );
}


function UsersTab() {
  const { user: currentUser } = useAuth();
  const { tenants } = useTenant();
  const [users, setUsers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [form, setForm] = useState({ email: "", password: "", role: "viewer", selectedTenants: [], selectedQueues: [] });
  const [error, setError] = useState("");

  const load = () => api.get("/api/users").then(d => setUsers(d.users || [])).catch(console.error);
  useEffect(() => { load(); }, []);

  const startEdit = (u) => {
    setEditingUser(u);
    setForm({
      email: u.email,
      password: "",
      role: u.role,
      selectedTenants: (u.tenants || []).map(t => typeof t === "string" ? t : t.domain),
      selectedQueues: u.queues || [],
    });
    setShowForm(true);
    setError("");
  };

  const cancelForm = () => {
    setShowForm(false);
    setEditingUser(null);
    setForm({ email: "", password: "", role: "viewer", selectedTenants: [], selectedQueues: [] });
    setError("");
  };

  const save = async () => {
    setError("");
    try {
      const tenantObjects = form.selectedTenants.map(domain => {
        const t = tenants.find(tt => tt.domain === domain);
        return { system: t?.system || "default", domain };
      });
      const payload = { role: form.role, tenants: tenantObjects, queues: form.role === "queue_manager" ? form.selectedQueues : [] };

      if (editingUser) {
        if (form.password) payload.password = form.password;
        if (form.email !== editingUser.email) payload.email = form.email;
        await api.put("/api/users/" + editingUser._id, payload);
      } else {
        payload.email = form.email;
        payload.password = form.password;
        await api.post("/api/users", payload);
      }
      cancelForm();
      load();
    } catch (err) { setError(err.message); }
  };

  const deactivate = async (id) => {
    if (!confirm("Deactivate this user?")) return;
    try { await api.del(`/api/users/${id}`); load(); } catch (err) { alert(err.message); }
  };

  const reactivate = async (id) => {
    if (!confirm("Reactivate this user? They will need to reset their password.")) return;
    try { await api.post(`/api/users/${id}/reactivate`); load(); } catch (err) { alert(err.message); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">User Management</h3>
        <button className="btn-primary text-sm flex items-center gap-2" onClick={() => { if (showForm) cancelForm(); else setShowForm(true); }}>
          <Plus size={16} /> New User
        </button>
      </div>
      {showForm && (
        <div className="glass-card mb-6">
          <h4 className="text-sm font-semibold mb-4">{editingUser ? "Edit User: " + editingUser.email : "Create New User"}</h4>
          {error && <div className="bg-brand-red/10 border border-brand-red/20 text-brand-red text-sm px-4 py-3 rounded-xl mb-4">{error}</div>}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input className="glass-input" placeholder="Email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} />
            <input className="glass-input" type="password" placeholder={editingUser ? "Leave blank to keep current" : "Password"} value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} />
            <select className="glass-select" value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))}>
              <option value="viewer">Viewer</option>
              <option value="queue_manager">Queue Manager</option>
              {currentUser?.role === "super_admin" && <option value="admin">Admin</option>}
              {currentUser?.role === "super_admin" && <option value="super_admin">Super Admin</option>}
            </select>
            <TenantMultiSelect selected={form.selectedTenants} onChange={sel => setForm(p => ({ ...p, selectedTenants: sel }))} tenants={tenants} />
            {form.role === "queue_manager" && (
              <QueueMultiSelect selected={form.selectedQueues} onChange={sel => setForm(p => ({ ...p, selectedQueues: sel }))} tenants={form.selectedTenants} />
            )}
          </div>
          <div className="flex justify-end gap-3 mt-4">
            <button className="btn-secondary text-sm" onClick={cancelForm}>Cancel</button>
            <button className="btn-primary text-sm" onClick={save}>{editingUser ? "Save Changes" : "Create User"}</button>
          </div>
        </div>
      )}
      <div className="glass overflow-hidden">
        <table className="w-full">
          <thead><tr className="bg-black/5 dark:bg-white/[0.03]">
            <th className="table-header">Email</th>
            <th className="table-header">Role</th>
            <th className="table-header">Tenants</th>
            <th className="table-header">Created</th>
            <th className="table-header text-center">Status</th>
            <th className="table-header text-center">Actions</th>
          </tr></thead>
          <tbody>
            {users.map(u => (
              <tr key={u._id} className={`hover:bg-black/5 dark:hover:bg-white/[0.03] ${u.active === false ? "opacity-50" : ""}`}>
                <td className="table-cell font-medium">{u.email}</td>
                <td className="table-cell">
                  <span className={u.role === "super_admin" ? "badge-purple" : u.role === "admin" ? "badge-blue" : u.role === "queue_manager" ? "badge-orange" : "badge-gray"}>
                    {u.role?.replace("_", " ")}
                  </span>
                </td>
                <td className="table-cell text-xs opacity-50">
                  {(u.tenants || []).map(t => typeof t === "string" ? t : t.domain).join(", ") || "All"}
                  {u.role === "queue_manager" && u.queues?.length > 0 && (
                    <div className="text-brand-purple mt-0.5">Queues: {u.queues.join(", ")}</div>
                  )}
                </td>
                <td className="table-cell text-xs opacity-40">{new Date(u.created_at).toLocaleDateString()}</td>
                <td className="table-cell text-center">
                  {u.active === false
                    ? <span className="text-xs px-2 py-1 rounded-lg bg-brand-red/10 text-brand-red">Deactivated</span>
                    : <span className="text-xs px-2 py-1 rounded-lg bg-brand-green/10 text-brand-green">Active</span>}
                </td>
                <td className="table-cell text-center">
                  {u.active === false ? (
                    <button onClick={() => reactivate(u._id)} className="p-1.5 rounded-lg hover:bg-brand-green/10 transition text-xs text-brand-green font-medium">Reactivate</button>
                  ) : (
                    <>
                      <button onClick={() => startEdit(u)} className="p-1.5 rounded-lg hover:bg-brand-blue/10 transition mr-1"><Pencil size={14} className="text-brand-blue" /></button>
                      <button onClick={() => deactivate(u._id)} className="p-1.5 rounded-lg hover:bg-brand-red/10 transition"><Trash2 size={14} className="text-brand-red" /></button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function IPWhitelistTab() {
  const [ips, setIps] = useState([]);
  const [newIp, setNewIp] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [loading, setLoading] = useState(true);
  const [expandedIp, setExpandedIp] = useState(null);
  const [editingPbx, setEditingPbx] = useState({});
  const [testResult, setTestResult] = useState(null);
  const [testing, setTesting] = useState(false);
  const [testPassed, setTestPassed] = useState(false);

  // Any field change resets testPassed — forces re-test before save
  const updatePbx = (updater) => {
    setEditingPbx(updater);
    setTestPassed(false);
    setTestResult(null);
  };

  useEffect(() => {
    api.get("/api/admin/whitelist")
      .then(data => { setIps(data.ips || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const saveWhitelist = async (newIps) => {
    try {
      const result = await api.put("/api/admin/whitelist", { ips: newIps });
      if (result.ips) setIps(result.ips);
    } catch (err) {
      alert("Failed to save: " + err.message);
    }
  };

  const addIp = () => {
    const ip = newIp.trim();
    if (!ip) return;
    if (ips.some(e => (typeof e === "string" ? e : e.ip) === ip)) {
      alert("IP already in whitelist");
      return;
    }
    const entry = { ip, label: newLabel.trim() };
    const newIps = [...ips, entry];
    saveWhitelist(newIps);
    setNewIp("");
    setNewLabel("");
  };

  const removeIp = (idx) => {
    const entry = ips[idx];
    const ipStr = typeof entry === "string" ? entry : entry.ip;
    if (!confirm(`Remove ${ipStr} from whitelist?`)) return;
    saveWhitelist(ips.filter((_, i) => i !== idx));
    if (expandedIp === idx) setExpandedIp(null);
  };

  const toggleExpand = (idx) => {
    if (expandedIp === idx) {
      setExpandedIp(null);
      setEditingPbx({});
      setTestResult(null);
    } else {
      const entry = ips[idx];
      setExpandedIp(idx);
      setEditingPbx({
        pbx_url: entry.pbx_url || "",
        pbx_port: entry.pbx_port || 443,
        admin_user: entry.has_admin_user ? "••••••••" : "",
        admin_pass: entry.has_admin_pass ? "••••••••" : "",
        ws_user: entry.ws_user || "admin",
        ws_enabled: entry.ws_enabled || false,
        domains: entry.domains || [],
      });
      setTestResult(null);
      setTestPassed(false);
    }
  };

  const savePbxConfig = async () => {
    if (expandedIp === null) return;
    const updatedIps = ips.map((entry, i) => {
      if (i !== expandedIp) return entry;
      return {
        ...(typeof entry === "string" ? { ip: entry } : entry),
        pbx_url: editingPbx.pbx_url,
        pbx_port: parseInt(editingPbx.pbx_port) || 443,
        admin_user: editingPbx.admin_user,
        admin_pass: editingPbx.admin_pass,
        ws_user: editingPbx.ws_user || "admin",
        ws_enabled: editingPbx.ws_enabled,
        domains: editingPbx.domains,
      };
    });
    await saveWhitelist(updatedIps);
    setExpandedIp(null);
    setEditingPbx({});
  };

  const testConnection = async () => {
    if (expandedIp === null) return;
    const entry = ips[expandedIp];
    setTesting(true);
    setTestResult(null);
    setTestPassed(false);
    try {
      const result = await api.post("/api/admin/whitelist/test-pbx", {
        ip: typeof entry === "string" ? entry : entry.ip,
        pbx_url: editingPbx.pbx_url,
        pbx_port: editingPbx.pbx_port,
        admin_user: editingPbx.admin_user,
        admin_pass: editingPbx.admin_pass,
        ws_user: editingPbx.ws_user,
        domains: editingPbx.domains,
      });
      setTestResult(result);
      if (result.success && result.ip_match) {
        setTestPassed(true);
      }
    } catch (err) {
      setTestResult({ success: false, error: err.message });
    }
    setTesting(false);
  };

  const removeDomain = (domain) => {
    updatePbx(prev => ({
      ...prev,
      domains: prev.domains.filter(d => d !== domain),
    }));
  };

  const addDomain = () => {
    const input = prompt("Enter domain (e.g. sbc.vodia.com):");
    if (!input?.trim()) return;
    const d = input.trim();
    if (editingPbx.domains?.includes(d)) return;
    updatePbx(prev => ({
      ...prev,
      domains: [...(prev.domains || []), d],
    }));
  };

  if (loading) return <div className="p-8 text-center opacity-40">Loading...</div>;

  return (
    <div>
      <div className="flex gap-2 mb-4">
        <input className="glass-input flex-1" placeholder="IP address (e.g. 203.0.113.50)"
          value={newIp} onChange={e => setNewIp(e.target.value)}
          onKeyDown={e => e.key === "Enter" && addIp()} />
        <input className="glass-input w-48" placeholder="Label (e.g. Office PBX)"
          value={newLabel} onChange={e => setNewLabel(e.target.value)}
          onKeyDown={e => e.key === "Enter" && addIp()} />
        <button className="btn-primary px-4" onClick={addIp}>Add</button>
      </div>

      <div className="glass overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-black/5 dark:bg-white/[0.03]">
              <th className="table-header">IP Address</th>
              <th className="table-header">Label</th>
              <th className="table-header text-center">PBX</th>
              <th className="table-header text-center">Domains</th>
              <th className="table-header text-center">Live</th>
              <th className="table-header text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {ips.length === 0 ? (
              <tr><td colSpan={6} className="table-cell text-center opacity-30 py-8">No IPs whitelisted</td></tr>
            ) : ips.map((entry, i) => {
              const ip = typeof entry === "string" ? entry : entry.ip;
              const label = typeof entry === "string" ? "" : (entry.label || "");
              const hasPbx = typeof entry === "object" && !!entry.pbx_url;
              const domainCount = typeof entry === "object" ? (entry.domains || []).length : 0;
              const wsEnabled = typeof entry === "object" && entry.ws_enabled;

              return (
                <React.Fragment key={i}>
                  <tr className={`hover:bg-black/5 dark:hover:bg-white/[0.03] cursor-pointer ${expandedIp === i ? "bg-brand-blue/5" : ""}`}
                      onClick={() => toggleExpand(i)}>
                    <td className="table-cell font-mono text-sm">{ip}</td>
                    <td className="table-cell text-sm opacity-60">{label || "—"}</td>
                    <td className="table-cell text-center">
                      {hasPbx ? (
                        <span className="text-xs bg-brand-green/20 text-brand-green px-2 py-0.5 rounded-full">
                          {entry.pbx_url}
                        </span>
                      ) : (
                        <span className="text-xs opacity-30">Not configured</span>
                      )}
                    </td>
                    <td className="table-cell text-center">
                      {domainCount > 0 ? (
                        <span className="text-xs bg-brand-blue/20 text-brand-blue px-2 py-0.5 rounded-full">
                          {domainCount} domain{domainCount !== 1 ? "s" : ""}
                        </span>
                      ) : (
                        <span className="text-xs opacity-30">—</span>
                      )}
                    </td>
                    <td className="table-cell text-center">
                      {wsEnabled ? (
                        <span className="inline-block w-2 h-2 rounded-full bg-brand-green" title="Live enabled" />
                      ) : (
                        <span className="inline-block w-2 h-2 rounded-full bg-gray-400 dark:bg-gray-600" title="Live disabled" />
                      )}
                    </td>
                    <td className="table-cell text-center" onClick={e => e.stopPropagation()}>
                      <button className="text-brand-red text-xs hover:underline" onClick={() => removeIp(i)}>Remove</button>
                    </td>
                  </tr>

                  {expandedIp === i && (
                    <tr>
                      <td colSpan={6} className="p-0">
                        <div className="bg-black/[0.02] dark:bg-white/[0.02] border-t border-b border-black/5 dark:border-white/5 p-5">
                          <div className="text-sm font-semibold mb-3 opacity-70">PBX Connection Settings</div>

                          <div className="grid grid-cols-3 gap-3 mb-3">
                            <div>
                              <label className="block text-xs opacity-50 mb-1">PBX Hostname</label>
                              <input className="glass-input w-full text-sm" placeholder="pbx.example.com"
                                value={editingPbx.pbx_url || ""}
                                onChange={e => updatePbx(p => ({ ...p, pbx_url: e.target.value }))} />
                            </div>
                            <div>
                              <label className="block text-xs opacity-50 mb-1">Port</label>
                              <input className="glass-input w-full text-sm" type="number" placeholder="443"
                                value={editingPbx.pbx_port || 443}
                                onChange={e => updatePbx(p => ({ ...p, pbx_port: e.target.value }))} />
                            </div>
                            <div>
                              <label className="block text-xs opacity-50 mb-1">WS User</label>
                              <input className="glass-input w-full text-sm" placeholder="admin"
                                value={editingPbx.ws_user || "admin"}
                                onChange={e => updatePbx(p => ({ ...p, ws_user: e.target.value }))} />
                            </div>
                          </div>

                          <div className="grid grid-cols-3 gap-3 mb-3">
                            <div>
                              <label className="block text-xs opacity-50 mb-1">Admin Username</label>
                              <input className="glass-input w-full text-sm" placeholder="admin"
                                value={editingPbx.admin_user || ""}
                                onFocus={e => { if (e.target.value === "••••••••") e.target.value = ""; updatePbx(p => ({ ...p, admin_user: "" })); }}
                                onChange={e => updatePbx(p => ({ ...p, admin_user: e.target.value }))} />
                            </div>
                            <div>
                              <label className="block text-xs opacity-50 mb-1">Admin Password</label>
                              <input className="glass-input w-full text-sm" type="password" placeholder="••••••••"
                                value={editingPbx.admin_pass || ""}
                                onFocus={e => { if (e.target.value === "••••••••") e.target.value = ""; updatePbx(p => ({ ...p, admin_pass: "" })); }}
                                onChange={e => updatePbx(p => ({ ...p, admin_pass: e.target.value }))} />
                            </div>
                            <div className="flex items-end pb-1">
                              <label className="flex items-center gap-2 cursor-pointer text-sm">
                                <input type="checkbox" className="rounded"
                                  checked={editingPbx.ws_enabled || false}
                                  onChange={e => updatePbx(p => ({ ...p, ws_enabled: e.target.checked }))} />
                                Enable Live Features
                              </label>
                            </div>
                          </div>

                          {/* Domains */}
                          <div className="mb-3">
                            <label className="block text-xs opacity-50 mb-1">
                              Domains served by this PBX
                              <span className="ml-1 opacity-50">(auto-populated from CDR traffic)</span>
                            </label>
                            <div className="flex flex-wrap gap-1.5">
                              {(editingPbx.domains || []).map(d => (
                                <span key={d} className="inline-flex items-center gap-1 text-xs bg-brand-blue/10 text-brand-blue px-2 py-1 rounded-full">
                                  {d}
                                  <button className="hover:text-brand-red ml-0.5" onClick={() => removeDomain(d)}>×</button>
                                </span>
                              ))}
                              <button className="text-xs opacity-40 hover:opacity-70 px-2 py-1" onClick={addDomain}>+ Add domain</button>
                            </div>
                          </div>

                          {/* Test result */}
                          {testResult && (
                            <div className={`text-sm p-3 rounded-lg mb-3 ${testResult.success ? "bg-brand-green/10 text-brand-green" : "bg-brand-red/10 text-brand-red"}`}>
                              {testResult.ip_match === false && (
                                <div className="mb-1 font-medium">✗ DNS: {editingPbx.pbx_url} → {testResult.resolved_ip || "unresolvable"} (expected {testResult.expected_ip})</div>
                              )}
                              {testResult.ip_match === true && (
                                <div className="mb-1">✓ DNS: {editingPbx.pbx_url} → {testResult.resolved_ip}</div>
                              )}
                              <div>{testResult.success ? "✓ " : "✗ "}{testResult.message || testResult.error}</div>
                            </div>
                          )}

                          {/* Action buttons */}
                          <div className="flex gap-2">
                            <button className="btn-primary px-4 text-sm disabled:opacity-30 disabled:cursor-not-allowed" onClick={savePbxConfig} disabled={!testPassed} title={!testPassed ? "Test connection must pass before saving" : ""}>Save PBX Config</button>
                            <button className="btn-secondary px-4 text-sm" onClick={testConnection} disabled={testing || !editingPbx.pbx_url}>
                              {testing ? "Testing..." : "Test Connection"}
                            </button>
                            <button className="text-sm opacity-50 hover:opacity-80 px-3" onClick={() => { setExpandedIp(null); setEditingPbx({}); setTestResult(null); setTestPassed(false); }}>
                              Cancel
                            </button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function TenantsTab() {
  const [tenants, setTenants] = useState([]);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState("");
  const [form, setForm] = useState({ default_country: "AU", international_prefix: "0011", show_country_flags: true, timezone: "" });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState(null);
  const [bulkField, setBulkField] = useState("default_country");
  const [bulkCountry, setBulkCountry] = useState("AU");
  const [bulkPrefix, setBulkPrefix] = useState("0011");
  const [bulkFlags, setBulkFlags] = useState(true);
  const [bulkSaving, setBulkSaving] = useState(false);
  const [bulkMsg, setBulkMsg] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState("");
  const [deleteLoading, setDeleteLoading] = useState(false);

  const load = () => api.get("/api/tenants").then(d => setTenants(d.tenants || [])).catch(console.error);
  useEffect(() => { load(); }, []);

  const filtered = tenants.filter(t => !search || (t.domain || "").toLowerCase().includes(search.toLowerCase()));

  const startEdit = (t) => {
    setEditing(t);
    setForm({
      default_country: t.normalization?.default_country || "AU",
      international_prefix: t.normalization?.international_prefix || "0011",
      show_country_flags: t.normalization?.show_country_flags !== false,
      timezone: t.timezone || "",
    });
    setMsg(null);
  };

  const saveSettings = async () => {
    if (!editing) return;
    setSaving(true); setMsg(null);
    try {
      await api.put("/api/tenants/" + editing._id, {
        normalization: {
          default_country: form.default_country.toUpperCase(),
          international_prefix: form.international_prefix,
          show_country_flags: form.show_country_flags,
        },
        timezone: form.timezone || null,
      });
      setMsg({ type: "ok", text: "Saved" });
      setEditing(null);
      load();
    } catch (err) { setMsg({ type: "err", text: err.message }); }
    finally { setSaving(false); }
  };

  const applyBulk = async () => {
    let field, value, label;
    if (bulkField === "default_country") { field = "default_country"; value = bulkCountry; label = bulkCountry; }
    else if (bulkField === "international_prefix") { field = "international_prefix"; value = bulkPrefix; label = bulkPrefix; }
    else { field = "show_country_flags"; value = bulkFlags; label = bulkFlags ? "On" : "Off"; }

    if (!confirm(`Set ${field.replace(/_/g, " ")} to "${label}" for ALL tenants?`)) return;
    setBulkSaving(true); setBulkMsg(null);
    try {
      const res = await api.put("/api/admin/tenants/bulk", { field, value });
      setBulkMsg({ type: "ok", text: res.message });
      load();
    } catch (err) { setBulkMsg({ type: "err", text: err.message }); }
    setBulkSaving(false);
  };

  const deleteTenant = async () => {
    if (!deleting) return;
    setDeleteLoading(true);
    try {
      await api.post("/api/tenants/" + deleting._id + "/delete", { confirm_domain: deleteConfirm });
      setDeleting(null);
      setDeleteConfirm("");
      load();
    } catch (err) { alert(err.response?.data?.error || err.message); }
    setDeleteLoading(false);
  };

  const COUNTRIES = [
    { code: "AU", name: "Australia" }, { code: "US", name: "United States" }, { code: "GB", name: "United Kingdom" },
    { code: "NZ", name: "New Zealand" }, { code: "CA", name: "Canada" }, { code: "DE", name: "Germany" },
    { code: "FR", name: "France" }, { code: "JP", name: "Japan" }, { code: "SG", name: "Singapore" },
    { code: "HK", name: "Hong Kong" }, { code: "IN", name: "India" }, { code: "PH", name: "Philippines" },
    { code: "MY", name: "Malaysia" }, { code: "ID", name: "Indonesia" }, { code: "TH", name: "Thailand" },
    { code: "KR", name: "South Korea" }, { code: "CN", name: "China" }, { code: "TW", name: "Taiwan" },
    { code: "IE", name: "Ireland" }, { code: "IT", name: "Italy" }, { code: "ES", name: "Spain" },
    { code: "BR", name: "Brazil" }, { code: "MX", name: "Mexico" }, { code: "ZA", name: "South Africa" },
    { code: "AE", name: "UAE" }, { code: "IL", name: "Israel" }, { code: "SE", name: "Sweden" },
    { code: "NO", name: "Norway" }, { code: "DK", name: "Denmark" }, { code: "FI", name: "Finland" },
    { code: "NL", name: "Netherlands" }, { code: "BE", name: "Belgium" }, { code: "CH", name: "Switzerland" },
    { code: "AT", name: "Austria" }, { code: "PT", name: "Portugal" }, { code: "PL", name: "Poland" },
  ].sort((a, b) => a.name.localeCompare(b.name));

  const RETENTION_OPTIONS = [
    { label: "Forever", value: 0 }, { label: "30d", value: 30 }, { label: "60d", value: 60 },
    { label: "90d", value: 90 }, { label: "180d", value: 180 }, { label: "1y", value: 365 },
    { label: "2y", value: 730 }, { label: "3y", value: 1095 }, { label: "5y", value: 1825 }, { label: "7y", value: 2555 },
  ];

  const retentionLabel = (days) => {
    if (!days) return "Forever";
    const opt = RETENTION_OPTIONS.find(o => o.value === days);
    return opt ? opt.label : days + "d";
  };

  return (
    <div>
      <h3 className="text-lg font-semibold mb-1">Tenants</h3>
      <p className="text-xs opacity-40 mb-6">Manage per-tenant country, prefix, and flag settings. Tenants are auto-created when PBX systems send CDRs.</p>



      {bulkMsg && <div className={`mb-4 px-4 py-2.5 rounded-xl text-sm ${bulkMsg.type === "ok" ? "bg-brand-green/10 text-brand-green" : "bg-brand-red/10 text-brand-red"}`}>{bulkMsg.text}</div>}

      <div className="mb-4">
        <input className="glass-input w-full md:w-72" placeholder="Search by domain..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="glass-card mb-4">
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-xs font-medium opacity-60">Apply to all:</span>
          <select className="glass-select text-sm py-1.5 px-3" value={bulkField} onChange={e => setBulkField(e.target.value)}>
            <option value="default_country">Country</option>
            <option value="international_prefix">Int. Prefix</option>
            <option value="show_country_flags">Flags</option>
          </select>
          {bulkField === "default_country" && (
            <select className="glass-select text-sm py-1.5 px-3" value={bulkCountry} onChange={e => setBulkCountry(e.target.value)}>
              {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name} ({c.code})</option>)}
            </select>
          )}
          {bulkField === "international_prefix" && (
            <input className="glass-input text-sm py-1.5 px-3 w-32" placeholder="0011" value={bulkPrefix} onChange={e => setBulkPrefix(e.target.value)} />
          )}
          {bulkField === "show_country_flags" && (
            <button onClick={() => setBulkFlags(!bulkFlags)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-medium transition-all ${bulkFlags ? "bg-brand-green/15 text-brand-green" : "bg-black/5 dark:bg-white/5 opacity-50"}`}>
              {bulkFlags ? <><ToggleRight size={16} /> On</> : <><ToggleLeft size={16} /> Off</>}
            </button>
          )}
          <button onClick={applyBulk} disabled={bulkSaving} className="btn-primary text-sm flex items-center gap-2 disabled:opacity-50">
            {bulkSaving ? <Loader2 size={14} className="animate-spin" /> : <Globe size={14} />} Apply to All
          </button>
        </div>
      </div>

      <div className="glass overflow-hidden">
        <table className="w-full">
          <thead><tr className="bg-black/5 dark:bg-white/[0.03]">
            <th className="table-header">Domain</th>
            <th className="table-header">System</th>
            <th className="table-header">Country</th>
              <th className="table-header">Timezone</th>
            <th className="table-header">Prefix</th>
            <th className="table-header text-center">Flags</th>
            <th className="table-header text-center">Retention</th>
            <th className="table-header text-center">Actions</th>
          </tr></thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={7} className="table-cell text-center opacity-30 py-8">{tenants.length === 0 ? "No tenants yet — they are auto-created when PBX systems send CDRs" : "No tenants match your search"}</td></tr>
            ) : filtered.map(t => (
              <React.Fragment key={t._id}>
              <tr className="hover:bg-black/5 dark:hover:bg-white/[0.03]">
                <td className="table-cell font-medium">{t.display_name || t.domain}</td>
                <td className="table-cell text-xs opacity-40 font-mono">{t.system?.slice(0, 12)}...</td>
                <td className="table-cell"><span className="badge-blue">{t.normalization?.default_country || "AU"}</span></td>
                  <td className="table-cell text-xs opacity-40">{t.timezone || "Local"}</td>
                <td className="table-cell text-xs font-mono opacity-60">{t.normalization?.international_prefix || "0011"}</td>
                <td className="table-cell text-center">{t.normalization?.show_country_flags !== false ? <span className="text-brand-green text-xs">On</span> : <span className="opacity-30 text-xs">Off</span>}</td>
                <td className="table-cell text-center"><span className="text-xs opacity-50">{retentionLabel(t.data_retention_days)}</span></td>
                <td className="table-cell text-center">
                  <div className="flex items-center justify-center gap-1">
                    <button onClick={() => startEdit(t)} className="p-1.5 rounded-lg hover:bg-brand-blue/10 transition"><Pencil size={14} className="text-brand-blue" /></button>
                    <button onClick={() => { setDeleting(t); setDeleteConfirm(""); }} className="p-1.5 rounded-lg hover:bg-brand-red/10 transition"><Trash2 size={14} className="text-brand-red" /></button>
                  </div>
                </td>
              </tr>
              {editing?._id === t._id && (
                <tr><td colSpan={7} className="p-0">
                  <div className="bg-brand-blue/5 dark:bg-brand-blue/10 px-4 py-3 border-t border-brand-blue/10">
                    {msg && <div className={`mb-2 px-3 py-1.5 rounded-lg text-xs ${msg.type === "ok" ? "bg-brand-green/10 text-brand-green" : "bg-brand-red/10 text-brand-red"}`}>{msg.text}</div>}
                    <div className="flex items-center gap-3 flex-wrap">
                      <div>
                        <label className="block text-[10px] font-medium opacity-50 mb-1">Country</label>
                        <select className="glass-select text-sm py-1.5 px-2" value={form.default_country} onChange={e => setForm(f => ({ ...f, default_country: e.target.value }))}>
                          {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name} ({c.code})</option>)}
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium opacity-50 mb-1">Prefix</label>
                        <input className="glass-input text-sm py-1.5 px-2 w-24" value={form.international_prefix} onChange={e => setForm(f => ({ ...f, international_prefix: e.target.value }))} />
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium opacity-50 mb-1">Flags</label>
                        <button onClick={() => setForm(f => ({ ...f, show_country_flags: !f.show_country_flags }))}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium transition-all ${form.show_country_flags ? "bg-brand-green/15 text-brand-green" : "bg-black/5 dark:bg-white/5 opacity-50"}`}>
                          {form.show_country_flags ? <><ToggleRight size={16} /> On</> : <><ToggleLeft size={16} /> Off</>}
                        </button>
                      </div>
                      <div>
                        <label className="block text-[10px] font-medium opacity-50 mb-1">Timezone</label>
                        <input
                          list="tz-list"
                          className="glass-input text-sm py-1.5 px-2 w-48"
                          placeholder="Browser local"
                          value={form.timezone}
                          onChange={e => setForm(f => ({ ...f, timezone: e.target.value }))}
                        />
                        <datalist id="tz-list">
                          {Intl.supportedValuesOf("timeZone").map(tz => <option key={tz} value={tz} />)}
                        </datalist>
                      </div>
                      <div className="flex items-end gap-2 ml-auto">
                        <button onClick={saveSettings} disabled={saving} className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-xl bg-brand-blue text-white disabled:opacity-50">
                          {saving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />} Save
                        </button>
                        <button onClick={() => setEditing(null)} className="px-3 py-1.5 text-sm rounded-xl hover:bg-black/5 dark:hover:bg-white/5">Cancel</button>
                      </div>
                    </div>
                  </div>
                </td></tr>
              )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {deleting && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setDeleting(null)} />
          <div className="relative w-full max-w-md bg-white dark:bg-surface-800 rounded-2xl shadow-2xl border border-black/5 dark:border-white/10 overflow-hidden">
            <div className="bg-brand-red/10 p-5 border-b border-brand-red/10">
              <h3 className="text-base font-bold text-brand-red flex items-center gap-2"><Trash2 size={18} /> Delete Tenant</h3>
            </div>
            <div className="p-5 space-y-4">
              <p className="text-sm opacity-70">This will permanently delete <strong>{deleting.display_name || deleting.domain}</strong> and all associated data including:</p>
              <ul className="text-sm opacity-60 space-y-1 ml-4">
                <li>• All call records (CDRs)</li>
                <li>• All recordings</li>
                <li>• All transcripts and AI analysis</li>
                <li>• All share links and briefings</li>
              </ul>
              <div className="bg-brand-red/5 border border-brand-red/20 rounded-xl p-3">
                <p className="text-xs font-medium text-brand-red mb-2">Type the domain to confirm:</p>
                <p className="text-xs font-mono opacity-50 mb-2">{deleting.domain}</p>
                <input
                  className="glass-input w-full font-mono text-sm"
                  placeholder={deleting.domain}
                  value={deleteConfirm}
                  onChange={e => setDeleteConfirm(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && deleteConfirm === deleting.domain && deleteTenant()}
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 p-4 border-t border-black/5 dark:border-white/5">
              <button onClick={() => setDeleting(null)} className="px-4 py-2 text-sm rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition">Cancel</button>
              <button
                onClick={deleteTenant}
                disabled={deleteConfirm !== deleting.domain || deleteLoading}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-xl bg-brand-red text-white disabled:opacity-30 transition"
              >
                {deleteLoading ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                Delete Tenant
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


function PasskeysTab() {
  const [passkeys, setPasskeys] = useState([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const load = () => api.get("/api/auth/passkeys").then(d => setPasskeys(d.passkeys || [])).catch(console.error);
  useEffect(() => { load(); }, []);

  const registerPasskey = async () => {
    setMsg(""); setLoading(true);
    try {
      const options = await api.post("/api/auth/passkey/register-options", {});
      if (options.error) { setMsg(options.error); setLoading(false); return; }
      const regResponse = await startRegistration({ optionsJSON: options });
      const result = await api.post("/api/auth/passkey/register-verify", regResponse);
      if (result.verified) {
        setMsg("Passkey registered successfully!");
        load();
      } else {
        setMsg(result.error || "Registration failed");
      }
    } catch (err) {
      if (err.name === "NotAllowedError") setMsg("Passkey registration cancelled");
      else setMsg(err.message);
    }
    setLoading(false);
  };

  const deletePasskey = async (id) => {
    if (!confirm("Delete this passkey?")) return;
    try { await api.del(`/api/auth/passkeys/${id}`); load(); } catch (err) { alert(err.message); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Your Passkeys</h3>
        <button onClick={registerPasskey} disabled={loading}
          className="btn-primary text-sm flex items-center gap-2 disabled:opacity-50">
          <Fingerprint size={16} /> {loading ? "Registering..." : "Add Passkey"}
        </button>
      </div>

      {msg && (
        <div className={`${msg.includes("success") ? "bg-brand-green/10 border-brand-green/20 text-brand-green" : "bg-brand-red/10 border-brand-red/20 text-brand-red"} border text-sm px-4 py-3 rounded-xl mb-4`}>
          {msg}
        </div>
      )}

      <div className="glass overflow-hidden">
        <table className="w-full">
          <thead><tr className="bg-black/5 dark:bg-white/[0.03]">
            <th className="table-header">Device</th>
            <th className="table-header">Created</th>
            <th className="table-header">Last Used</th>
            <th className="table-header text-center">Actions</th>
          </tr></thead>
          <tbody>
            {passkeys.length === 0 ? (
              <tr><td colSpan={4} className="table-cell text-center opacity-30 py-8">
                <Fingerprint size={32} className="mx-auto mb-3 opacity-20" />
                <div>No passkeys registered yet</div>
                <div className="text-xs mt-1">Passkeys let you sign in with fingerprint, face, or security key</div>
              </td></tr>
            ) : passkeys.map(p => (
              <tr key={p._id} className="hover:bg-black/5 dark:hover:bg-white/[0.03]">
                <td className="table-cell font-medium flex items-center gap-2"><Shield size={16} className="text-brand-indigo" />{p.device_name || "Passkey"}</td>
                <td className="table-cell text-xs opacity-40">{new Date(p.created_at).toLocaleDateString()}</td>
                <td className="table-cell text-xs opacity-40">{p.last_used ? new Date(p.last_used).toLocaleDateString() : "Never"}</td>
                <td className="table-cell text-center">
                  <button onClick={() => deletePasskey(p._id)} className="p-1.5 rounded-lg hover:bg-brand-red/10 transition"><Trash2 size={14} className="text-brand-red" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Two-Factor Authentication */}
      <div className="mt-8">
        <h3 className="text-lg font-semibold mb-4">Two-Factor Authentication</h3>
        <div className="glass-card">
          <TotpSetup />
        </div>
      </div>
    </div>
  );
}


function AISettingsTab() {
  const [tenants, setTenants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState({});
  const [search, setSearch] = useState("");
  const [aiConfig, setAiConfig] = useState({ provider: "openai", model: "gpt-4o-mini", has_key: false, source: "none", endpoint: "" });
  const [providers, setProviders] = useState({});
  const [provider, setProvider] = useState("openai");
  const [aiModel, setAiModel] = useState("gpt-4o-mini");
  const [aiKey, setAiKey] = useState("");
  const [aiEndpoint, setAiEndpoint] = useState("");
  const [customModel, setCustomModel] = useState("");
  const [aiSaving, setAiSaving] = useState(false);
  const [aiTesting, setAiTesting] = useState(false);
  const [aiMsg, setAiMsg] = useState(null);
  const [showKey, setShowKey] = useState(false);

  const load = () => {
    setLoading(true);
    Promise.all([
      api.get("/api/tenants"),
      api.get("/api/settings/ai").catch(() => api.get("/api/settings/openai").then(d => ({
        ai: { provider: "openai", model: d.openai?.model || "gpt-4o-mini", has_key: d.openai?.has_key, source: d.openai?.source, endpoint: "" },
        providers: {},
      }))),
    ]).then(([td, aid]) => {
      setTenants(td.tenants || []);
      if (aid.ai) {
        setAiConfig(aid.ai);
        setProvider(aid.ai.provider || "openai");
        setAiModel(aid.ai.model || "gpt-4o-mini");
        setAiEndpoint(aid.ai.endpoint || "");
      }
      if (aid.providers) setProviders(aid.providers);
    }).catch(console.error).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const currentModels = providers[provider]?.models || [];
  const needsKey = providers[provider]?.needsKey !== false;
  const needsEndpoint = providers[provider]?.needsEndpoint || false;
  const providerName = providers[provider]?.name || provider;

  const saveAI = async () => {
    setAiSaving(true); setAiMsg(null);
    try {
      const payload = { provider, model: aiModel === "custom" ? customModel : aiModel };
      if (aiKey) payload.api_key = aiKey;
      if (aiEndpoint !== undefined) payload.endpoint = aiEndpoint;
      await api.put("/api/settings/ai", payload);
      setAiMsg({ type: "ok", text: "AI settings saved" });
      if (aiKey) { setAiConfig(c => ({ ...c, has_key: true, source: "database" })); setAiKey(""); }
      setAiConfig(c => ({ ...c, provider, model: payload.model, endpoint: aiEndpoint }));
    } catch (err) { setAiMsg({ type: "err", text: err.message }); }
    finally { setAiSaving(false); }
  };

  const testAI = async () => {
    setAiTesting(true); setAiMsg(null);
    try {
      const payload = { provider };
      if (aiKey) payload.api_key = aiKey;
      if (aiModel) payload.model = aiModel === "custom" ? customModel : aiModel;
      if (aiEndpoint) payload.endpoint = aiEndpoint;
      const res = await api.post("/api/settings/ai/test", payload);
      setAiMsg({ type: "ok", text: res.message + (res.response ? ": " + res.response : "") });
    } catch (err) { setAiMsg({ type: "err", text: err.detail || err.message }); }
    finally { setAiTesting(false); }
  };

  const toggleAutoSummarize = async (tenant) => {
    const newVal = !tenant.ai_auto_summarize;
    setSaving(prev => ({ ...prev, [tenant._id]: true }));
    try {
      await api.put(`/api/tenants/${tenant._id}/ai-settings`, { ai_auto_summarize: newVal });
      setTenants(prev => prev.map(t => t._id === tenant._id ? { ...t, ai_auto_summarize: newVal } : t));
    } catch (err) { alert("Failed: " + err.message); }
    setSaving(prev => ({ ...prev, [tenant._id]: false }));
  };

  if (loading) return <div className="opacity-50 text-center py-12 animate-pulse">Loading...</div>;

  const enabledCount = tenants.filter(t => t.ai_auto_summarize).length;
  const filtered = tenants.filter(t => !search || (t.domain || "").toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2"><Brain size={20} className="text-brand-purple" /> AI Settings</h3>
          <p className="text-xs opacity-40 mt-1">Configure AI provider for call summarization and analysis</p>
        </div>
        <div className="text-sm opacity-40">{enabledCount} of {tenants.length} tenants enabled</div>
      </div>

      {/* AI Provider Configuration */}
      <div className="glass-card mb-6">
        <h4 className="text-sm font-semibold mb-3">AI Provider</h4>

        {aiMsg && <div className={`mb-3 px-3 py-2 rounded-lg text-xs ${aiMsg.type === "ok" ? "bg-brand-green/10 text-brand-green" : "bg-brand-red/10 text-brand-red"}`}>{aiMsg.text}</div>}

        <div className="flex gap-2 mb-4 flex-wrap">
          {Object.entries(providers).map(([key, p]) => (
            <button key={key} onClick={() => { setProvider(key); setAiModel(p.defaultModel || p.models?.[0]?.id || ""); setAiKey(""); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${provider === key ? "bg-brand-purple/15 text-brand-purple ring-1 ring-brand-purple/30" : "bg-black/5 dark:bg-white/5 opacity-50 hover:opacity-80"}`}>
              {p.name} {key === "ollama" && <span className="text-[9px] bg-brand-yellow/20 text-brand-yellow px-1.5 py-0.5 rounded-full font-bold">EXPERIMENTAL</span>}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          {needsKey && (
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">API Key {aiConfig.has_key && provider === aiConfig.provider && !aiKey && <span className="text-brand-green ml-1">(set)</span>}</label>
              <div className="relative">
                <input className="glass-input w-full pr-10" type={showKey ? "text" : "password"}
                  placeholder={aiConfig.has_key && provider === aiConfig.provider ? "Leave blank to keep current" : provider === "anthropic" ? "sk-ant-..." : provider === "gemini" ? "AIza..." : "sk-..."}
                  value={aiKey} onChange={e => setAiKey(e.target.value)} />
                <button type="button" onClick={() => setShowKey(!showKey)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 opacity-40 hover:opacity-100">
                  {showKey ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
          )}
          <div>
            <label className="block text-xs font-medium opacity-60 mb-1.5">Model</label>
            <select className="glass-select w-full" value={aiModel} onChange={e => setAiModel(e.target.value)}>
              {currentModels.map(m => <option key={m.id} value={m.id}>{m.name} — {m.desc}</option>)}
            </select>
            {aiModel === "custom" && (
              <input className="glass-input w-full mt-2" placeholder="Enter model name..." value={customModel} onChange={e => setCustomModel(e.target.value)} />
            )}
          </div>
        </div>

        {(needsEndpoint || provider === "openai") && (
          <div className="mb-4">
            <label className="block text-xs font-medium opacity-60 mb-1.5">
              {provider === "ollama" ? "Ollama Server URL" : "Custom Endpoint"} {provider !== "ollama" && <span className="opacity-40">(optional)</span>}
            </label>
            <input className="glass-input w-full" placeholder={provider === "ollama" ? "http://10.0.0.50:11434" : "Leave blank for default"}
              value={aiEndpoint} onChange={e => setAiEndpoint(e.target.value)} />
            {provider === "ollama" && <p className="text-xs opacity-30 mt-1">URL of your Ollama server. Can be a separate VM or local machine.</p>}
            {provider === "openai" && <p className="text-xs opacity-30 mt-1">For OpenAI-compatible APIs (e.g. Azure, local proxies). Leave blank for standard OpenAI.</p>}
          </div>
        )}

        <div className="flex items-center gap-3">
          <button onClick={saveAI} disabled={aiSaving} className="btn-primary text-sm flex items-center gap-2 disabled:opacity-50">
            {aiSaving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />} Save
          </button>
          <button onClick={testAI} disabled={aiTesting} className="btn-secondary text-sm flex items-center gap-2 disabled:opacity-50">
            {aiTesting ? <Loader2 size={14} className="animate-spin" /> : <Brain size={14} />} Test Connection
          </button>
        </div>

        {provider === aiConfig.provider && aiConfig.has_key && (
          <p className="text-xs opacity-30 mt-3">Currently using: {providerName} ({aiConfig.model})</p>
        )}
      </div>

      {/* Per-Tenant Auto-Summarize */}
      <div className="glass-card mb-6">
        <h4 className="text-sm font-semibold mb-3">How it works</h4>
        <div className="space-y-2 text-sm opacity-60">
          <p>When <strong>Auto-Summarize</strong> is enabled for a tenant, every new call recording will automatically be:</p>
          <div className="flex items-start gap-2 pl-4">
            <span className="text-brand-green font-bold">1.</span>
            <span>Transcribed locally using Whisper (always happens, free)</span>
          </div>
          <div className="flex items-start gap-2 pl-4">
            <span className="text-brand-purple font-bold">2.</span>
            <span>Summarized via your configured AI provider — generating sentiment, topics, action items, and resolution status</span>
          </div>
          <p className="text-xs opacity-40 mt-2">Note: Step 2 requires a configured AI provider with valid credentials and will incur API costs (except Ollama).</p>
        </div>
      </div>

      <div className="mb-4">
        <input className="glass-input w-full md:w-72" placeholder="Search by domain..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="glass overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-black/5 dark:bg-white/[0.03]">
              <th className="table-header">Tenant</th>
              <th className="table-header">Domain</th>
              <th className="table-header text-center">Auto-Transcribe</th>
              <th className="table-header text-center">Auto-Summarize (AI)</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={4} className="table-cell text-center opacity-30 py-8">{tenants.length === 0 ? "No tenants found" : "No tenants match your search"}</td></tr>
            ) : filtered.map(t => (
              <tr key={t._id} className="hover:bg-black/5 dark:hover:bg-white/[0.03]">
                <td className="table-cell font-medium">{t.display_name || t.domain}</td>
                <td className="table-cell text-xs opacity-40 font-mono">{t.domain}</td>
                <td className="table-cell text-center">
                  <span className="badge-green text-[10px]">Always On</span>
                </td>
                <td className="table-cell text-center">
                  <button
                    onClick={() => toggleAutoSummarize(t)}
                    disabled={saving[t._id]}
                    className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-medium transition-all ${
                      t.ai_auto_summarize
                        ? "bg-brand-purple/15 text-brand-purple"
                        : "bg-black/5 dark:bg-white/5 opacity-40 hover:opacity-70"
                    }`}>
                    {t.ai_auto_summarize ? <ToggleRight size={18} /> : <ToggleLeft size={18} />}
                    {saving[t._id] ? "Saving..." : t.ai_auto_summarize ? "Enabled" : "Disabled"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}


function RetentionTab() {
  const [tenants, setTenants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState({});
  const [purgeNumber, setPurgeNumber] = useState("");
  const [purging, setPurging] = useState(false);
  const [purgeResult, setPurgeResult] = useState(null);
  const [sweeping, setSweeping] = useState(false);
  const [sweepResult, setSweepResult] = useState(null);
  const [bulkRetention, setBulkRetention] = useState(0);
  const [bulkSaving, setBulkSaving] = useState(false);
  const [bulkMsg, setBulkMsg] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState("");
  const [deleteLoading, setDeleteLoading] = useState(false);

  const applyBulkRetention = async () => {
    if (!confirm(`Set retention to "${bulkRetention === 0 ? "Forever" : bulkRetention + " days"}" for ALL tenants?`)) return;
    setBulkSaving(true); setBulkMsg(null);
    try {
      const res = await api.put("/api/admin/tenants/bulk", { field: "data_retention_days", value: bulkRetention });
      setBulkMsg({ type: "ok", text: res.message });
      load();
    } catch (err) { setBulkMsg({ type: "err", text: err.message }); }
    setBulkSaving(false);
  };

  const load = () => {
    setLoading(true);
    api.get("/api/tenants").then(d => setTenants(d.tenants || [])).catch(console.error).finally(() => setLoading(false));
  };
  useEffect(() => { load(); }, []);

  const filtered = tenants.filter(t => !search || (t.domain || "").toLowerCase().includes(search.toLowerCase()));

  const updateRetention = async (tenant, days) => {
    setSaving(p => ({ ...p, [tenant._id]: true }));
    try {
      await api.put(`/api/tenants/${tenant._id}/retention`, { data_retention_days: days });
      setTenants(p => p.map(t => t._id === tenant._id ? { ...t, data_retention_days: days } : t));
    } catch (err) { alert(err.message); }
    setSaving(p => ({ ...p, [tenant._id]: false }));
  };

  const handlePurge = async () => {
    if (!purgeNumber || purgeNumber.length < 3) return;
    if (!confirm(`This will PERMANENTLY DELETE all call data for number "${purgeNumber}". This cannot be undone. Continue?`)) return;
    setPurging(true); setPurgeResult(null);
    try {
      const result = await api.post("/api/admin/purge-number", { number: purgeNumber });
      setPurgeResult(result);
      setPurgeNumber("");
    } catch (err) { alert(err.message); }
    setPurging(false);
  };

  const handleSweep = async () => {
    if (!confirm("Run retention sweep now? This will delete data older than each tenant's retention policy.")) return;
    setSweeping(true); setSweepResult(null);
    try {
      const result = await api.post("/api/admin/run-retention", {});
      setSweepResult(result);
    } catch (err) { alert(err.message); }
    setSweeping(false);
  };

  if (loading) return <div className="opacity-50 text-center py-12 animate-pulse">Loading...</div>;

  const RETENTION_OPTIONS = [
    { label: "Forever", value: 0 },
    { label: "30 days", value: 30 },
    { label: "60 days", value: 60 },
    { label: "90 days", value: 90 },
    { label: "180 days", value: 180 },
    { label: "1 year", value: 365 },
    { label: "2 years", value: 730 },
    { label: "3 years", value: 1095 },
    { label: "4 years", value: 1460 },
    { label: "5 years", value: 1825 },
    { label: "6 years", value: 2190 },
    { label: "7 years", value: 2555 },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-1">Data Retention</h3>
        <p className="text-xs opacity-40">Auto-delete calls, recordings, and transcripts older than the configured period. Runs daily.</p>
      </div>

      {bulkMsg && <div className={`mb-4 px-4 py-2.5 rounded-xl text-sm ${bulkMsg.type === "ok" ? "bg-brand-green/10 text-brand-green" : "bg-brand-red/10 text-brand-red"}`}>{bulkMsg.text}</div>}

      <div className="glass-card mb-4 flex items-center gap-3 flex-wrap">
        <span className="text-xs font-medium opacity-60">Apply to all:</span>
        <select className="glass-select text-sm py-1.5 px-3" value={bulkRetention} onChange={e => setBulkRetention(parseInt(e.target.value))}>
          {RETENTION_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <button onClick={applyBulkRetention} disabled={bulkSaving} className="btn-primary text-sm flex items-center gap-2 disabled:opacity-50">
          {bulkSaving ? <Loader2 size={14} className="animate-spin" /> : <Globe size={14} />} Apply to All Tenants
        </button>
      </div>

      <div className="mb-4">
        <input className="glass-input w-full md:w-72" placeholder="Search by domain..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="glass overflow-hidden">
        <table className="w-full">
          <thead><tr className="bg-black/5 dark:bg-white/[0.03]">
            <th className="table-header">Tenant</th>
            <th className="table-header">Domain</th>
            <th className="table-header text-center">Retention Period</th>
          </tr></thead>
          <tbody>
            {filtered.map(t => (
              <tr key={t._id} className="hover:bg-black/5 dark:hover:bg-white/[0.03]">
                <td className="table-cell font-medium">{t.display_name || t.domain}</td>
                <td className="table-cell text-xs opacity-40 font-mono">{t.domain}</td>
                <td className="table-cell text-center">
                  <select className="glass-select text-sm py-1.5 px-3"
                    value={t.data_retention_days || 0}
                    disabled={saving[t._id]}
                    onChange={e => updateRetention(t, parseInt(e.target.value))}>
                    {RETENTION_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex gap-3">
        <button onClick={handleSweep} disabled={sweeping}
          className="btn-secondary text-sm flex items-center gap-2">
          {sweeping ? "Running..." : "Run Retention Sweep Now"}
        </button>
      </div>
      {sweepResult && (
        <div className="bg-brand-green/10 border border-brand-green/20 text-brand-green text-sm px-4 py-3 rounded-xl">
          Sweep complete: {sweepResult.total_deleted} calls deleted across {sweepResult.tenants?.length || 0} tenants
        </div>
      )}

      <hr className="border-black/5 dark:border-white/5" />

      <div>
        <h3 className="text-lg font-semibold mb-1 text-brand-red">Data Purge (GDPR)</h3>
        <p className="text-xs opacity-40 mb-4">Permanently delete ALL data associated with a phone number — calls, recordings, transcripts. Cannot be undone.</p>
        <div className="flex gap-2">
          <input className="glass-input flex-1" placeholder="Phone number to purge (e.g. 61299998888)"
            value={purgeNumber} onChange={e => setPurgeNumber(e.target.value)} />
          <button onClick={handlePurge} disabled={purging || purgeNumber.length < 3}
            className="btn-danger text-sm disabled:opacity-30">
            {purging ? "Purging..." : "Purge All Data"}
          </button>
        </div>
        {purgeResult && (
          <div className="bg-brand-red/10 border border-brand-red/20 text-brand-red text-sm px-4 py-3 rounded-xl mt-3">
            Purged: {purgeResult.calls_deleted} calls, {purgeResult.recordings_deleted} recordings, {purgeResult.transcripts_deleted} transcripts, {purgeResult.minio_files_deleted} files
          </div>
        )}
      </div>
    </div>
  );
}


/* ═══ SMTP Tab ═══ */
function SmtpTab() {
  const [form, setForm] = useState({ host: "", port: 587, username: "", password: "", from_address: "", encryption: "starttls" });
  const [hasPassword, setHasPassword] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testTo, setTestTo] = useState("");
  const [msg, setMsg] = useState(null);

  useEffect(() => {
    api.get("/api/settings/smtp").then(d => {
      if (d.smtp) {
        setForm(f => ({ ...f, host: d.smtp.host || "", port: d.smtp.port || 587, username: d.smtp.username || "", from_address: d.smtp.from_address || "", encryption: d.smtp.encryption || "starttls", password: "" }));
        setHasPassword(d.smtp.has_password || false);
      }
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  const save = async () => {
    setSaving(true); setMsg(null);
    try {
      const payload = { ...form, port: parseInt(form.port) || 587 };
      if (!payload.password && hasPassword) delete payload.password;
      const res = await api.put("/api/settings/smtp", payload);
      setMsg({ type: "ok", text: res.message || "Saved" });
      if (form.password) setHasPassword(true);
      setForm(f => ({ ...f, password: "" }));
    } catch (err) { setMsg({ type: "err", text: err.message }); }
    finally { setSaving(false); }
  };

  const test = async () => {
    setTesting(true); setMsg(null);
    try {
      const res = await api.post("/api/settings/smtp/test", { to: testTo || undefined });
      setMsg({ type: "ok", text: res.message });
    } catch (err) { setMsg({ type: "err", text: err.detail || err.message }); }
    finally { setTesting(false); }
  };

  if (loading) return <div className="text-center py-12 opacity-40 animate-pulse">Loading...</div>;

  return (
    <div>
      <div className="mb-6">
        <h3 className="text-lg font-semibold">SMTP Configuration</h3>
        <p className="text-sm opacity-50 mt-1">Configure outgoing email for notifications and shared call links.</p>
      </div>
      {msg && <div className={`mb-4 px-4 py-3 rounded-xl text-sm ${msg.type === "ok" ? "bg-brand-green/10 border border-brand-green/20 text-brand-green" : "bg-brand-red/10 border border-brand-red/20 text-brand-red"}`}>{msg.text}</div>}
      <div className="glass-card">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div><label className="block text-xs font-medium opacity-60 mb-1.5">SMTP Host</label><input className="glass-input w-full" placeholder="smtp.gmail.com" value={form.host} onChange={e => setForm(f => ({ ...f, host: e.target.value }))} /></div>
          <div><label className="block text-xs font-medium opacity-60 mb-1.5">Port</label><input className="glass-input w-full" type="number" placeholder="587" value={form.port} onChange={e => setForm(f => ({ ...f, port: e.target.value }))} /></div>
          <div><label className="block text-xs font-medium opacity-60 mb-1.5">Username</label><input className="glass-input w-full" placeholder="user@example.com" value={form.username} onChange={e => setForm(f => ({ ...f, username: e.target.value }))} /></div>
          <div><label className="block text-xs font-medium opacity-60 mb-1.5">Password {hasPassword && !form.password && <span className="text-brand-green ml-1">(set)</span>}</label><div className="relative"><input className="glass-input w-full pr-10" type={showPass ? "text" : "password"} placeholder={hasPassword ? "Leave blank to keep current" : "Enter password"} value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} /><button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 opacity-40 hover:opacity-100">{showPass ? <EyeOff size={16} /> : <Eye size={16} />}</button></div></div>
          <div><label className="block text-xs font-medium opacity-60 mb-1.5">From Address</label><input className="glass-input w-full" placeholder="noreply@company.com" value={form.from_address} onChange={e => setForm(f => ({ ...f, from_address: e.target.value }))} /></div>
          <div><label className="block text-xs font-medium opacity-60 mb-1.5">Encryption</label><select className="glass-select w-full" value={form.encryption} onChange={e => setForm(f => ({ ...f, encryption: e.target.value }))}><option value="starttls">STARTTLS (port 587)</option><option value="ssl">SSL/TLS (port 465)</option><option value="none">None (not recommended)</option></select></div>
        </div>
        <div className="flex items-center justify-between mt-6 pt-4 border-t border-black/5 dark:border-white/5">
          <button onClick={save} disabled={saving || !form.host} className="btn-primary text-sm flex items-center gap-2 disabled:opacity-50">{saving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />} Save Settings</button>
        </div>
      </div>
      <div className="glass-card mt-6">
        <h4 className="text-sm font-semibold mb-3">Send Test Email</h4>
        <div className="flex items-center gap-3">
          <input className="glass-input flex-1" placeholder="Recipient (blank = your email)" value={testTo} onChange={e => setTestTo(e.target.value)} />
          <button onClick={test} disabled={testing || !form.host} className="btn-primary text-sm flex items-center gap-2 whitespace-nowrap disabled:opacity-50">{testing ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />} Send Test</button>
        </div>
      </div>
    </div>
  );
}


/* ═══ Share Links Tab ═══ */
function ShareLinksTab() {
  const [links, setLinks] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    api.get("/api/share").then(d => setLinks(d.links || [])).catch(console.error).finally(() => setLoading(false));
  };
  useEffect(() => { load(); }, []);

  const revoke = async (id) => {
    if (!confirm("Revoke this share link?")) return;
    try { await api.del(`/api/share/${id}`); load(); } catch (err) { alert(err.message); }
  };

  const copyUrl = (url) => {
    navigator.clipboard.writeText(url);
  };

  return (
    <div>
      <div className="mb-6">
        <h3 className="text-lg font-semibold">Active Share Links</h3>
        <p className="text-sm opacity-50 mt-1">Manage shared call links. Links expire after 24 hours or first view.</p>
      </div>
      <div className="glass overflow-hidden">
        <table className="w-full">
          <thead><tr className="bg-black/5 dark:bg-white/[0.03]">
            <th className="table-header">Call ID</th>
            <th className="table-header">Domain</th>
            <th className="table-header">Shared By</th>
            <th className="table-header">Created</th>
            <th className="table-header">Expires</th>
            <th className="table-header text-center">Viewed</th>
            <th className="table-header text-center">Actions</th>
          </tr></thead>
          <tbody>
            {links.map(l => (
              <tr key={l._id} className="hover:bg-black/5 dark:hover:bg-white/[0.03]">
                <td className="table-cell font-mono text-xs">{l.callid?.slice(0, 20)}...</td>
                <td className="table-cell text-xs opacity-60">{l.domain}</td>
                <td className="table-cell text-xs">{l.created_by}</td>
                <td className="table-cell text-xs opacity-50">{new Date(l.created_at).toLocaleString()}</td>
                <td className="table-cell text-xs opacity-50">{new Date(l.expires_at).toLocaleString()}</td>
                <td className="table-cell text-center">{l.viewed ? <span className="text-brand-green text-xs">Yes</span> : <span className="text-white/30 text-xs">No</span>}</td>
                <td className="table-cell text-center flex items-center justify-center gap-2">
                  <button onClick={() => copyUrl(l.share_url)} title="Copy link" className="opacity-40 hover:opacity-100"><Copy size={14} /></button>
                  <button onClick={() => revoke(l._id)} title="Revoke" className="text-brand-red/60 hover:text-brand-red"><Trash2 size={14} /></button>
                </td>
              </tr>
            ))}
            {links.length === 0 && <tr><td colSpan={7} className="table-cell text-center opacity-30 py-8">{loading ? "Loading..." : "No active share links"}</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}


function StorageTab() {
  const [config, setConfig] = useState({ backend: "minio", endpoint: "", region: "", bucket: "", has_credentials: false, force_path_style: false });
  const [form, setForm] = useState({ backend: "minio", endpoint: "", region: "", bucket: "", access_key: "", secret_key: "", force_path_style: false });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [msg, setMsg] = useState(null);
  const [showSecret, setShowSecret] = useState(false);
  const [counts, setCounts] = useState(null);
  const [usage, setUsage] = useState(null);
  const [usageLoading, setUsageLoading] = useState(false);
  const [usageError, setUsageError] = useState(null);
  const [showTenants, setShowTenants] = useState(false);

  const loadUsage = () => {
    setUsageLoading(true); setUsageError(null);
    api.get("/api/settings/storage/usage")
      .then(d => setUsage(d))
      .catch(err => setUsageError(err.message || "Failed to load"))
      .finally(() => setUsageLoading(false));
  };

  const refreshUsage = async () => {
    setUsageLoading(true); setUsageError(null);
    try {
      await api.post("/api/settings/storage/usage/refresh", {});
      const d = await api.get("/api/settings/storage/usage");
      setUsage(d);
    } catch (err) { setUsageError(err.message); }
    finally { setUsageLoading(false); }
  };

  useEffect(() => { loadUsage(); }, []);

  const fmtSize = (bytes) => {
    if (!bytes || bytes === 0) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return (bytes / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0) + " " + units[i];
  };


  useEffect(() => {
    api.get("/api/settings/storage").then(d => {
      if (d.storage) {
        setConfig(d.storage);
        setForm(f => ({ ...f, backend: d.storage.backend, endpoint: d.storage.endpoint, region: d.storage.region, bucket: d.storage.bucket, force_path_style: d.storage.force_path_style }));
      }
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  const testConnection = async () => {
    if (!form.bucket) { setMsg({ type: "err", text: "Bucket is required" }); return; }
    if (!form.access_key && !config.has_credentials) { setMsg({ type: "err", text: "Access key is required" }); return; }
    if (!form.secret_key && !config.has_credentials) { setMsg({ type: "err", text: "Secret key is required" }); return; }
    setTesting(true); setMsg(null);
    try {
      const payload = { endpoint: form.endpoint, region: form.region, bucket: form.bucket, access_key: form.access_key, secret_key: form.secret_key, force_path_style: form.force_path_style };
      const res = await api.post("/api/settings/storage/test", payload);
      setMsg({ type: "ok", text: res.message || "Connection successful" });
    } catch (err) { setMsg({ type: "err", text: err.message || "Connection failed" }); }
    finally { setTesting(false); }
  };

  const saveConfig = async () => {
    setSaving(true); setMsg(null);
    try {
      const payload = { backend: form.backend, endpoint: form.endpoint, region: form.region, bucket: form.bucket, force_path_style: form.force_path_style };
      if (form.access_key) payload.access_key = form.access_key;
      if (form.secret_key) payload.secret_key = form.secret_key;
      const res = await api.put("/api/settings/storage", payload);
      setMsg({ type: "ok", text: res.message || "Saved" });
      if (res.recording_counts) setCounts(res.recording_counts);
      setConfig(res.storage || config);
      setForm(f => ({ ...f, access_key: "", secret_key: "" }));
    } catch (err) { setMsg({ type: "err", text: err.message || "Save failed" }); }
    finally { setSaving(false); }
  };

  if (loading) return <div className="text-center py-12 opacity-30">Loading...</div>;

  return (
    <div>
      <h3 className="text-lg font-semibold mb-1">Recording Storage</h3>
      <p className="text-xs opacity-40 mb-6">Configure where call recordings are stored</p>

      {/* Storage Usage */}
      <div className="glass-card mb-6">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Database size={16} className="text-brand-blue" />
            <h4 className="text-sm font-semibold">Storage Usage</h4>
            {usage?.cached && <span className="text-[10px] opacity-30 bg-black/5 dark:bg-white/5 px-1.5 py-0.5 rounded">cached</span>}
          </div>
          <button onClick={refreshUsage} disabled={usageLoading} className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition opacity-40 hover:opacity-70 disabled:opacity-20" title="Refresh (clears cache)">
            <RefreshCw size={14} className={usageLoading ? "animate-spin" : ""} />
          </button>
        </div>

        {usageLoading && !usage ? (
          <div className="text-xs opacity-30 py-4 text-center">Calculating storage usage...</div>
        ) : usageError ? (
          <div className="text-xs text-brand-red">{usageError}</div>
        ) : usage ? (
          <div>
            <div className="flex gap-6 mb-3">
              <div>
                <div className="text-2xl font-bold">{fmtSize(usage.total_size)}</div>
                <div className="text-[10px] opacity-30 uppercase tracking-wider">Total Size</div>
              </div>
              <div>
                <div className="text-2xl font-bold">{(usage.total_objects || 0).toLocaleString()}</div>
                <div className="text-[10px] opacity-30 uppercase tracking-wider">Files</div>
              </div>
              <div>
                <div className="text-2xl font-bold capitalize">{usage.active_backend || usage.backend || "—"}</div>
                <div className="text-[10px] opacity-30 uppercase tracking-wider">Active Backend</div>
              </div>
            </div>

            {usage.backends && usage.backends.length > 0 && (
              <div className="flex gap-4 mb-3 pt-2 border-t border-black/5 dark:border-white/5">
                {usage.backends.map((b, i) => (
                  <div key={i} className="text-xs opacity-50">
                    <span className="font-medium capitalize">{b.name}</span>: {fmtSize(b.size)} · {b.objects} files
                  </div>
                ))}
              </div>
            )}

            {usage.errors && usage.errors.length > 0 && (
              <div className="mb-3 text-xs text-brand-red">
                {usage.errors.map((e, i) => <div key={i}>{e.backend}: {e.error}</div>)}
              </div>
            )}

            {usage.tenants && usage.tenants.length > 0 && (
              <div>
                <button onClick={() => setShowTenants(!showTenants)} className="text-xs opacity-40 hover:opacity-70 flex items-center gap-1 transition">
                  {showTenants ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                  {usage.tenants.length} tenant{usage.tenants.length !== 1 ? "s" : ""} with recordings
                </button>
                {showTenants && (
                  <div className="mt-2 space-y-1">
                    {usage.tenants.map((t, i) => (
                      <div key={i} className="flex items-center justify-between text-xs py-1 px-2 rounded bg-black/[0.02] dark:bg-white/[0.02]">
                        <span className="opacity-60">{t.domain} <span className="opacity-30">({t.system})</span></span>
                        <span className="font-mono opacity-50">{fmtSize(t.size)} &middot; {t.objects} files</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {usage.calculated_at && (
              <div className="text-[10px] opacity-20 mt-2">Last calculated: {new Date(usage.calculated_at).toLocaleString()}</div>
            )}
          </div>
        ) : null}
      </div>

      {msg && <div className={`mb-4 px-4 py-2.5 rounded-xl text-sm ${msg.type === "ok" ? "bg-brand-green/10 text-brand-green" : "bg-brand-red/10 text-brand-red"}`}>{msg.text}</div>}

      <div className="glass-card mb-6">
        <label className="block text-xs font-medium opacity-60 mb-2">Storage Backend</label>
        <div className="flex gap-3">
          <button onClick={() => setForm(f => ({ ...f, backend: "minio" }))}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${form.backend === "minio" ? "bg-brand-blue/15 text-brand-blue ring-1 ring-brand-blue/30" : "bg-black/5 dark:bg-white/5 opacity-50 hover:opacity-80"}`}>
            <Server size={16} /> MinIO (Local)
          </button>
          <button onClick={() => setForm(f => ({ ...f, backend: "s3" }))}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${form.backend === "s3" ? "bg-brand-blue/15 text-brand-blue ring-1 ring-brand-blue/30" : "bg-black/5 dark:bg-white/5 opacity-50 hover:opacity-80"}`}>
            <HardDrive size={16} /> S3 / Spaces
          </button>
        </div>
      </div>

      {form.backend === "s3" && (
        <div className="glass-card mb-6">
          <h4 className="text-sm font-semibold mb-4">S3 Configuration</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Endpoint <span className="opacity-40">(optional for AWS)</span></label>
              <input className="glass-input w-full" placeholder="https://nyc3.digitaloceanspaces.com" value={form.endpoint} onChange={e => setForm(f => ({ ...f, endpoint: e.target.value }))} />
              <p className="text-xs opacity-30 mt-1">Required for DigitalOcean Spaces, Backblaze B2, etc. Leave blank for AWS S3.</p>
            </div>
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Region</label>
              <input className="glass-input w-full" placeholder="us-east-1" value={form.region} onChange={e => setForm(f => ({ ...f, region: e.target.value }))} />
            </div>
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Bucket</label>
              <input className="glass-input w-full" placeholder="recordings" value={form.bucket} onChange={e => setForm(f => ({ ...f, bucket: e.target.value }))} />
            </div>
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Path Style</label>
              <button onClick={() => setForm(f => ({ ...f, force_path_style: !f.force_path_style }))}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${form.force_path_style ? "bg-brand-green/15 text-brand-green" : "bg-black/5 dark:bg-white/5 opacity-50"}`}>
                {form.force_path_style ? <><ToggleRight size={18} /> On</> : <><ToggleLeft size={18} /> Off</>}
              </button>
              <p className="text-xs opacity-30 mt-1">Enable for MinIO, DigitalOcean Spaces. Disable for AWS S3.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-black/5 dark:border-white/5">
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Access Key {config.has_credentials && <span className="text-brand-green">(saved)</span>}</label>
              <input className="glass-input w-full font-mono text-sm" placeholder={config.has_credentials ? "••••••••" : "AKIAIOSFODNN7EXAMPLE"} value={form.access_key} onChange={e => setForm(f => ({ ...f, access_key: e.target.value }))} />
            </div>
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Secret Key {config.has_credentials && <span className="text-brand-green">(saved)</span>}</label>
              <div className="relative">
                <input className="glass-input w-full font-mono text-sm pr-10" type={showSecret ? "text" : "password"} placeholder={config.has_credentials ? "••••••••" : "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"} value={form.secret_key} onChange={e => setForm(f => ({ ...f, secret_key: e.target.value }))} />
                <button onClick={() => setShowSecret(!showSecret)} className="absolute right-3 top-1/2 -translate-y-1/2 opacity-40 hover:opacity-70">
                  {showSecret ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 mt-4 pt-4 border-t border-black/5 dark:border-white/5">
            <button onClick={testConnection} disabled={testing} className="btn-secondary text-sm flex items-center gap-2 disabled:opacity-50">
              {testing ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />} Test Connection
            </button>
          </div>
        </div>
      )}

      {form.backend === "minio" && (
        <div className="glass-card mb-6">
          <div className="flex items-center gap-3">
            <Server size={20} className="text-brand-blue" />
            <div>
              <p className="text-sm font-medium">Using local MinIO container</p>
              <p className="text-xs opacity-40">Recordings are stored in the MinIO Docker container. No additional configuration needed.</p>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center gap-3">
        <button onClick={saveConfig} disabled={saving} className="btn-primary text-sm flex items-center gap-2 disabled:opacity-50">
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />} Save Storage Settings
        </button>
      </div>

      {counts && (
        <div className="mt-4 text-xs opacity-40">
          Recordings: {counts.minio} on MinIO, {counts.s3} on S3
        </div>
      )}

      <div className="mt-6 glass-card bg-brand-blue/5">
        <p className="text-xs opacity-50">
          <strong>Note:</strong> Switching backends only affects new recordings. Existing recordings remain accessible on their original storage.
          Both MinIO and S3 recordings can coexist — each recording tracks which backend it lives on.
        </p>
      </div>
    </div>
  );
}



function AuditLogTab() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [category, setCategory] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [expanded, setExpanded] = useState(null);

  const categories = [
    { value: "", label: "All Categories" },
    { value: "auth", label: "Authentication" },
    { value: "users", label: "Users" },
    { value: "tenants", label: "Tenants" },
    { value: "whitelist", label: "IP Whitelist" },
    { value: "settings", label: "Settings" },
    { value: "retention", label: "Retention" },
    { value: "storage", label: "Storage" },
  ];

  const load = (p = page) => {
    setLoading(true);
    const params = new URLSearchParams({ page: p, limit: 50 });
    if (category) params.set("category", category);
    if (dateFrom) params.set("from", new Date(dateFrom).toISOString());
    if (dateTo) params.set("to", new Date(dateTo + "T23:59:59").toISOString());
    api.get("/api/audit?" + params.toString())
      .then(d => { setEvents(d.events || []); setTotal(d.total || 0); setPages(d.pages || 1); setPage(d.page || 1); })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(1); }, [category, dateFrom, dateTo]);

  const actionLabels = {
    login_success: "Login",
    login_failed: "Login Failed",
    totp_verified: "2FA Verified",
    totp_failed: "2FA Failed",
    passkey_verified: "Passkey Verified",
    user_created: "User Created",
    user_updated: "User Updated",
    user_deactivated: "User Deactivated",
    tenant_updated: "Tenant Updated",
    tenant_deleted: "Tenant Deleted",
    whitelist_updated: "Whitelist Updated",
    smtp_saved: "SMTP Saved",
    ai_settings_saved: "AI Settings Saved",
    openai_key_saved: "OpenAI Key Saved",
    storage_config_saved: "Storage Config Saved",
    retention_updated: "Retention Updated",
    gdpr_purge: "GDPR Purge",
    retention_sweep: "Retention Sweep",
  };

  const actionColors = {
    login_success: "text-brand-green",
    login_failed: "text-brand-red",
    totp_failed: "text-brand-red",
    user_deactivated: "text-brand-red",
    tenant_deleted: "text-brand-red",
    gdpr_purge: "text-brand-red",
  };

  const fmtDate = (d) => {
    if (!d) return "";
    const dt = new Date(d);
    return dt.toLocaleDateString(undefined, { month: "short", day: "numeric" }) + " " + dt.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  };

  return (
    <div>
      <h3 className="text-lg font-semibold mb-1">Audit Log</h3>
      <p className="text-xs opacity-40 mb-4">Track logins, changes, and administrative actions. Auto-expires after 1 year.</p>

      <div className="flex flex-wrap gap-3 mb-4">
        <select value={category} onChange={e => setCategory(e.target.value)} className="glass-input text-sm py-1.5 px-3">
          {categories.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
        </select>
        <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="glass-input text-sm py-1.5 px-3" placeholder="From" />
        <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="glass-input text-sm py-1.5 px-3" placeholder="To" />
        <span className="text-xs opacity-30 self-center">{total} events</span>
      </div>

      {loading ? (
        <div className="text-center py-12 opacity-30">Loading...</div>
      ) : events.length === 0 ? (
        <div className="text-center py-12 opacity-30">No audit events found</div>
      ) : (
        <div className="glass overflow-hidden">
          <table className="w-full">
            <thead><tr className="bg-black/5 dark:bg-white/[0.03]">
              <th className="table-header w-8"></th>
              <th className="table-header">Time</th>
              <th className="table-header">Action</th>
              <th className="table-header">User</th>
              <th className="table-header">Target</th>
              <th className="table-header">IP</th>
            </tr></thead>
            <tbody>
              {events.map((e, i) => (
                <React.Fragment key={e._id || i}>
                  <tr className="hover:bg-black/5 dark:hover:bg-white/[0.03] cursor-pointer transition" onClick={() => setExpanded(expanded === i ? null : i)}>
                    <td className="table-cell text-center">
                      {e.details ? (expanded === i ? <ChevronDown size={12} className="opacity-40" /> : <ChevronRight size={12} className="opacity-40" />) : null}
                    </td>
                    <td className="table-cell text-xs opacity-60 whitespace-nowrap">{fmtDate(e.created_at)}</td>
                    <td className={`table-cell text-sm font-medium ${actionColors[e.action] || ""}`}>{actionLabels[e.action] || e.action}</td>
                    <td className="table-cell text-xs opacity-60">{e.actor || "—"}</td>
                    <td className="table-cell text-xs opacity-50 font-mono truncate max-w-[200px]">{e.target || "—"}</td>
                    <td className="table-cell text-xs opacity-30 font-mono">{e.ip || "—"}</td>
                  </tr>
                  {expanded === i && e.details && (
                    <tr>
                      <td colSpan={6} className="px-6 py-3 bg-black/[0.02] dark:bg-white/[0.02]">
                        <pre className="text-xs opacity-50 overflow-auto whitespace-pre-wrap">{JSON.stringify(e.details, null, 2)}</pre>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {pages > 1 && (
        <div className="flex items-center gap-2 mt-4 justify-center">
          <button disabled={page <= 1} onClick={() => load(page - 1)} className="btn-secondary text-xs px-3 py-1 disabled:opacity-30">Prev</button>
          <span className="text-xs opacity-40">Page {page} of {pages}</span>
          <button disabled={page >= pages} onClick={() => load(page + 1)} className="btn-secondary text-xs px-3 py-1 disabled:opacity-30">Next</button>
        </div>
      )}
    </div>
  );
}

export default function Admin() {
  const { user } = useAuth();
  const [tab, setTab] = useState("users");
  const isSuperAdmin = user?.role === "super_admin";

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-2xl font-bold">Administration</h2>
        <p className="text-sm opacity-40 mt-1">Manage users, API keys, and tenants</p>
      </div>
      <div className="flex gap-2 mb-6">
        <Tab active={tab === "users"} onClick={() => setTab("users")} icon={Users} label="Users" />
        {isSuperAdmin && <Tab active={tab === "whitelist"} onClick={() => setTab("whitelist")} icon={Key} label="IP Whitelist" />}
        <Tab active={tab === "tenants"} onClick={() => setTab("tenants")} icon={Building} label="Tenants" />
        <Tab active={tab === "passkeys"} onClick={() => setTab("passkeys")} icon={Fingerprint} label="Passkeys" />
        {isSuperAdmin && <Tab active={tab === "ai"} onClick={() => setTab("ai")} icon={Brain} label="AI Settings" />}
        {isSuperAdmin && <Tab active={tab === "retention"} onClick={() => setTab("retention")} icon={Trash2} label="Retention" />}
        {isSuperAdmin && <Tab active={tab === "smtp"} onClick={() => setTab("smtp")} icon={Mail} label="SMTP" />}
        {isSuperAdmin && <Tab active={tab === "storage"} onClick={() => setTab("storage")} icon={HardDrive} label="Storage" />}
        {isSuperAdmin && <Tab active={tab === "audit"} onClick={() => setTab("audit")} icon={ClipboardList} label="Audit Log" />}
        {isSuperAdmin && <Tab active={tab === "sharelinks"} onClick={() => setTab("sharelinks")} icon={Link2} label="Share Links" />}
        <Tab active={tab === "briefings"} onClick={() => setTab("briefings")} icon={CalendarClock} label="Briefings" />
      </div>
{tab === "users" && <UsersTab />}
      {tab === "whitelist" && isSuperAdmin && <IPWhitelistTab />}
      {tab === "tenants" && <TenantsTab />}
      {tab === "passkeys" && <PasskeysTab />}
      {tab === "smtp" && isSuperAdmin && <SmtpTab />}
      {tab === "sharelinks" && isSuperAdmin && <ShareLinksTab />}
      {tab === "briefings" && <BriefingSchedules />}
      {tab === "ai" && isSuperAdmin && <AISettingsTab />}
      {tab === "retention" && isSuperAdmin && <RetentionTab />}
      {tab === "storage" && isSuperAdmin && <StorageTab />}
      {tab === "audit" && isSuperAdmin && <AuditLogTab />}
    </div>
  );
}
