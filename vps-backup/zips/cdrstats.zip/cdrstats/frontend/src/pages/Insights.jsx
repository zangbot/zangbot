import { fmtDateTime } from "../dateUtils";
import { useState, useEffect, useCallback } from "react";
import { api } from "../api/client";
import BriefingModal from "../components/BriefingModal";
import { useTenant } from "../context/TenantContext";
import { useDateRange } from "../context/DateRangeContext";
import { useTheme } from "../context/ThemeContext";
import { useChartColors } from "../chartConfig";
import DateFilterBar from "../components/DateFilterBar";
import { useAutoRefresh, RefreshIndicator } from "../components/AutoRefresh";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, CartesianGrid, Legend } from "recharts";
import { useNavigate } from "react-router-dom";
import { Brain, Search, TrendingDown, Tag, CheckCircle2, AlertTriangle, Minus, MessageSquare, Phone, Clock, ChevronRight } from "lucide-react";

const C = { green: "#34c759", blue: "#007aff", red: "#ff3b30", orange: "#ff9500", purple: "#af52de", gray: "#636366" };
const SENTIMENT_COLORS = { positive: C.green, neutral: C.blue, negative: C.red };
const RESOLUTION_COLORS = { resolved: C.green, unresolved: C.red, transferred: C.blue, callback_needed: C.orange, unknown: C.gray };

function KPI({ icon: Icon, label, value, sub, color = "blue" }) {
  const c = C[color] || C.blue;
  return (
    <div className="glass-card">
      <div className="flex items-start justify-between mb-3">
        <div className="p-2 rounded-xl" style={{ backgroundColor: c + "15" }}><Icon size={18} style={{ color: c }} /></div>
      </div>
      <div className="text-2xl font-bold tracking-tight tabular-nums" style={{ color: c }}>{value}</div>
      <div className="text-sm font-medium opacity-70 mt-1">{label}</div>
      {sub && <div className="text-xs opacity-40 mt-0.5">{sub}</div>}
    </div>
  );
}

function SentimentBadge({ sentiment, size = "sm" }) {
  const styles = {
    positive: "badge-green",
    neutral: "badge-blue",
    negative: "badge-red",
  };
  const icons = { positive: CheckCircle2, neutral: Minus, negative: AlertTriangle };
  const Ic = icons[sentiment] || Minus;
  return (
    <span className={`${styles[sentiment] || "badge-gray"} ${size === "xs" ? "text-[10px] px-2 py-0.5" : ""}`}>
      <Ic size={size === "xs" ? 10 : 12} className="mr-1" />{sentiment}
    </span>
  );
}

function TranscriptSearch({ domainParam, toQueryParams, navigate, timezone }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const doSearch = async (page = 1) => {
    if (!query || query.length < 2) return;
    setLoading(true);
    setSearched(true);
    try {
      const dp = domainParam ? domainParam.slice(1) : "";
      const drp = toQueryParams();
      const qs = [dp, drp, `q=${encodeURIComponent(query)}`, `page=${page}`].filter(Boolean).join("&");
      const data = await api.get(`/api/ai/search?${qs}`);
      setResults(data.results || []);
      setTotal(data.total || 0);
    } catch (err) { console.error(err); }
    setLoading(false);
  };

  return (
    <div className="glass-card">
      <div className="flex items-center gap-2 mb-4">
        <Search size={18} className="text-brand-purple" />
        <h3 className="text-lg font-semibold">Transcript Search</h3>
      </div>
      <div className="flex gap-2 mb-4">
        <div className="flex-1 relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-30" />
          <input className="glass-input w-full pl-9 text-sm" placeholder="Search transcripts... (e.g. 'cancellation', 'refund', 'complaint')"
            value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === "Enter" && doSearch()} />
        </div>
        <button onClick={() => doSearch()} disabled={loading || query.length < 2}
          className="btn-primary text-sm disabled:opacity-30">
          {loading ? "Searching..." : "Search"}
        </button>
      </div>

      {searched && (
        <div>
          <div className="text-xs opacity-40 mb-3">{total} result{total !== 1 ? "s" : ""} found</div>
          {results.length === 0 ? (
            <div className="text-center py-8 opacity-30 text-sm">No matching transcripts found</div>
          ) : (
            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {results.map((r, i) => (
                <div key={i} className="bg-black/5 dark:bg-white/5 rounded-xl p-4 hover:bg-black/10 dark:hover:bg-white/10 transition cursor-pointer"
                  onClick={() => navigate(`/calls?open=${encodeURIComponent(r.callid)}&tab=ai`)}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono opacity-40">{r.callid?.slice(0, 16)}</span>
                      {r.sentiment && <SentimentBadge sentiment={r.sentiment} size="xs" />}
                    </div>
                    <span className="text-xs opacity-30">{r.call?.start ? fmtDateTime(r.call.start, timezone) : ""}</span>
                  </div>
                  <p className="text-sm opacity-70 line-clamp-2">{r.snippet}</p>
                  {r.summary && <p className="text-xs opacity-40 mt-2 italic">{r.summary}</p>}
                  <div className="flex items-center gap-3 mt-2 text-[10px] opacity-30">
                    {r.call?.answering_extension_name && <span>Ext: {r.call.answering_extension_name}{r.call?.answering_extension ? " (" + r.call.answering_extension + ")" : ""}</span>}
                    {r.call?.answering_queue_name && <span>Queue: {r.call.answering_queue_name}</span>}
                    {r.domain && <span>{r.domain}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function Insights() {
  const { timezone, domainParam, activeTenant } = useTenant();
  const { toQueryParams, preset, customFrom, customTo } = useDateRange();
  const { dark } = useTheme();
  const cc = useChartColors(dark);
  const [insights, setInsights] = useState(null);
  const [trend, setTrend] = useState([]);
  const [negativeCalls, setNegativeCalls] = useState([]);
  const [topics, setTopics] = useState([]);
  const [resolution, setResolution] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const buildQs = useCallback(() => {
    const dp = domainParam ? domainParam.slice(1) : "";
    const drp = toQueryParams();
    const q = [dp, drp].filter(Boolean).join("&");
    return q ? "?" + q : "";
  }, [domainParam, toQueryParams]);

  const loadData = useCallback(async () => {
    setLoading(true);
    const qs = buildQs();
    try {
      const [ins, tr, neg, top, res] = await Promise.all([
        api.get("/api/ai/insights" + qs),
        api.get("/api/ai/sentiment-trend" + qs),
        api.get("/api/ai/negative-calls" + qs + (qs ? "&" : "?") + "limit=10"),
        api.get("/api/ai/topics" + qs),
        api.get("/api/ai/resolution" + qs),
      ]);
      setInsights(ins); setTrend(tr.trend || []);
      setNegativeCalls(neg.calls || []); setTopics(top.topics || []);
      setResolution(res.resolution || []);
    } catch (e) { console.error(e); }
    setLoading(false);
  }, [buildQs]);

  useEffect(() => { loadData(); }, [loadData]);
  const autoRefresh = useAutoRefresh(loadData, 1800);

  const ttStyle = cc.tooltip;
  const ins = insights || {};
  const sentimentData = ins.sentiment ? [
    { name: "Positive", value: ins.sentiment.positive, fill: C.green },
    { name: "Neutral", value: ins.sentiment.neutral, fill: C.blue },
    { name: "Negative", value: ins.sentiment.negative, fill: C.red },
  ].filter(d => d.value > 0) : [];

  const resolutionData = resolution.map(r => ({
    name: r.status?.replace("_", " ") || "unknown",
    value: r.count,
    fill: RESOLUTION_COLORS[r.status] || C.gray,
  }));

  const topicSentimentColors = { positive: C.green, neutral: C.blue, negative: C.red };

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2"><Brain size={24} className="text-brand-purple" /> AI Insights</h2>
          <p className="text-sm opacity-40 mt-1">{activeTenant ? activeTenant.domain : "All Tenants"}</p>
        </div>
        <div className="flex items-center gap-2">
          <BriefingModal context="insights" buildQs={buildQs} />
          <RefreshIndicator {...autoRefresh} interval={1800} />
        </div>
      </div>

      <DateFilterBar />

      {loading ? <div className="opacity-50 text-center py-20 animate-pulse">Loading insights...</div> : <>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPI icon={Phone} label="Total Calls" value={ins.total_calls || 0} color="blue" />
        <KPI icon={MessageSquare} label="Transcribed" value={ins.total_transcribed || 0} sub={ins.total_calls > 0 ? Math.round((ins.total_transcribed || 0) / ins.total_calls * 100) + "% of calls" : ""} color="purple" />
        <KPI icon={Brain} label="AI Analyzed" value={ins.total_analyzed || 0} sub={ins.total_transcribed > 0 ? Math.round((ins.total_analyzed || 0) / ins.total_transcribed * 100) + "% of transcribed" : ""} color="green" />
        <KPI icon={AlertTriangle} label="Negative Calls" value={ins.sentiment?.negative || 0} sub={ins.total_analyzed > 0 ? Math.round((ins.sentiment?.negative || 0) / ins.total_analyzed * 100) + "%" : ""} color="red" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Sentiment Distribution */}
        <div className="glass-card">
          <h3 className="text-lg font-semibold mb-4">Sentiment Distribution</h3>
          {sentimentData.length > 0 ? (
            <div className="h-64"><ResponsiveContainer><PieChart>
              <Pie data={sentimentData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" paddingAngle={3}
                label={({ name, value }) => name + " (" + value + ")"}>
                {sentimentData.map((d, i) => <Cell key={i} fill={d.fill} />)}
              </Pie>
              <Tooltip contentStyle={ttStyle} />
            </PieChart></ResponsiveContainer></div>
          ) : (
            <div className="h-64 flex items-center justify-center opacity-30 text-sm">No sentiment data yet</div>
          )}
        </div>

        {/* Resolution Breakdown */}
        <div className="glass-card">
          <h3 className="text-lg font-semibold mb-4">Resolution Rate</h3>
          {resolutionData.length > 0 ? (
            <div className="h-64"><ResponsiveContainer><PieChart>
              <Pie data={resolutionData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" paddingAngle={3}
                label={({ name, value }) => name + " (" + value + ")"}>
                {resolutionData.map((d, i) => <Cell key={i} fill={d.fill} />)}
              </Pie>
              <Tooltip contentStyle={ttStyle} />
            </PieChart></ResponsiveContainer></div>
          ) : (
            <div className="h-64 flex items-center justify-center opacity-30 text-sm">No resolution data yet</div>
          )}
        </div>
      </div>

      {/* Sentiment Trend */}
      <div className="glass-card mb-6">
        <h3 className="text-lg font-semibold mb-4">Sentiment Trend</h3>
        {trend.length > 0 ? (
          <div className="h-72"><ResponsiveContainer><BarChart data={trend}>
            <CartesianGrid strokeDasharray="3 3" stroke={cc.grid} />
            <XAxis dataKey="date" tick={{ fill: cc.tick, fontSize: 10 }} />
            <YAxis tick={{ fill: cc.tick, fontSize: 11 }} />
            <Tooltip contentStyle={ttStyle} />
            <Legend />
            <Bar dataKey="positive" name="Positive" stackId="a" fill={C.green} />
            <Bar dataKey="neutral" name="Neutral" stackId="a" fill={C.blue} />
            <Bar dataKey="negative" name="Negative" stackId="a" fill={C.red} radius={[4,4,0,0]} />
          </BarChart></ResponsiveContainer></div>
        ) : (
          <div className="h-72 flex items-center justify-center opacity-30 text-sm">No trend data yet</div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Top Topics */}
        <div className="glass-card">
          <div className="flex items-center gap-2 mb-4">
            <Tag size={18} className="text-brand-blue" />
            <h3 className="text-lg font-semibold">Top Topics</h3>
          </div>
          {topics.length > 0 ? (
            <div className="space-y-2 max-h-[350px] overflow-y-auto">
              {topics.map((t, i) => (
                <div key={i} className="flex items-center justify-between bg-black/5 dark:bg-white/5 rounded-xl px-4 py-3">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium capitalize">{t.topic}</span>
                    <SentimentBadge sentiment={t.avg_sentiment} size="xs" />
                  </div>
                  <span className="text-sm font-bold tabular-nums opacity-60">{t.count}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-12 text-center opacity-30 text-sm">No topics yet — summarize some calls first</div>
          )}
        </div>

        {/* Recent Negative Calls */}
        <div className="glass-card">
          <div className="flex items-center gap-2 mb-4">
            <TrendingDown size={18} className="text-brand-red" />
            <h3 className="text-lg font-semibold">Recent Negative Calls</h3>
          </div>
          {negativeCalls.length > 0 ? (
            <div className="space-y-2 max-h-[350px] overflow-y-auto">
              {negativeCalls.map((c, i) => (
                <div key={i} className="bg-brand-red/5 border border-brand-red/10 rounded-xl px-4 py-3 cursor-pointer hover:bg-brand-red/10 transition"
                  onClick={() => navigate(`/calls?open=${encodeURIComponent(c.callid)}&tab=ai`)}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium">{c.from_display_name || c.from_number_raw || "Unknown"}</span>
                    <span className="text-[10px] opacity-30">{c.start ? fmtDateTime(c.start, timezone) : ""}</span>
                  </div>
                  {c.summary_text && <p className="text-xs opacity-50 line-clamp-2 mb-1">{c.summary_text}</p>}
                  <div className="flex items-center gap-2 text-[10px] opacity-30">
                    {c.answering_extension_name && <span>Ext: {c.answering_extension_name}{c.answering_extension ? " (" + c.answering_extension + ")" : ""}</span>}
                    {c.answering_queue_name && <span>Queue: {c.answering_queue_name}</span>}
                    {c.caller_mood && <span className="text-brand-red">Mood: {c.caller_mood}</span>}
                    {c.resolution && <span>Resolution: {c.resolution}</span>}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-12 text-center opacity-30 text-sm">No negative calls found</div>
          )}
        </div>
      </div>

      {/* Transcript Search */}
      <TranscriptSearch domainParam={domainParam} toQueryParams={toQueryParams} navigate={navigate} timezone={timezone} />

      </>}
    </div>
  );
}
