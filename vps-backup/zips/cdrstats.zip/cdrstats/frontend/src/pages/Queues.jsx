import { useState, useEffect, useRef, useCallback } from "react";
import { api } from "../api/client";
import BriefingModal from "../components/BriefingModal";
import { useTenant } from "../context/TenantContext";
import { useDateRange } from "../context/DateRangeContext";
import { useTheme } from "../context/ThemeContext";
import { useChartColors } from "../chartConfig";
import { useNavigate } from "react-router-dom";
import DateFilterBar from "../components/DateFilterBar";
import { shiftHourlyToLocal, getTimezoneLabel } from "../tzUtils";
import ExportButton from "../components/ExportButton";
import { useAutoRefresh, RefreshIndicator } from "../components/AutoRefresh";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend, Line, ComposedChart } from "recharts";
import { Phone, Zap, Moon as MoonIcon, User, Clock, Search, ChevronDown, X, Check } from "lucide-react";

const C = { blue: "#007aff", green: "#34c759", red: "#ff3b30", orange: "#ff9500", purple: "#af52de", gray: "#636366" };
const fmtTime = (s) => { if (!s) return "0s"; s = Math.round(s); return s < 60 ? s+"s" : Math.floor(s/60)+"m "+s%60+"s"; };

/* Queue selection is remembered per tenant. Keying by domain matters:
   restoring one tenant's queue ids under another would filter everything
   out with no visible cause. Stored as ids, not objects, so the selection
   can be restored before /api/stats/queues has returned. */
const QUEUE_SEL_KEY = "cdrstats:queues:selected";

function loadQueueSel(domainKey) {
  try {
    const raw = window.localStorage.getItem(QUEUE_SEL_KEY);
    if (!raw) return [];
    const saved = JSON.parse(raw);
    if (!saved || typeof saved !== "object") return [];
    const list = saved[domainKey || "__all__"];
    return Array.isArray(list) ? list.filter(v => typeof v === "string") : [];
  } catch {
    return [];
  }
}

function saveQueueSel(domainKey, ids) {
  try {
    const raw = window.localStorage.getItem(QUEUE_SEL_KEY);
    let saved = {};
    try { saved = raw ? (JSON.parse(raw) || {}) : {}; } catch { saved = {}; }
    if (ids.length > 0) saved[domainKey || "__all__"] = ids;
    else delete saved[domainKey || "__all__"];
    window.localStorage.setItem(QUEUE_SEL_KEY, JSON.stringify(saved));
  } catch { /* ignore */ }
}

function KPI({ icon: Icon, label, value, sub, color = "blue" }) {
  const c = C[color] || C.blue;
  return (
    <div className="glass-card">
      <div className="flex items-start justify-between mb-3">
        <div className="p-2 rounded-xl" style={{ backgroundColor: c + "15" }}><Icon size={18} style={{ color: c }} /></div>
      </div>
      <div className="text-2xl font-bold tracking-tight tabular-nums" style={{ color: c }}>{value}</div>
      <div className="text-sm font-medium opacity-70 mt-1">{label}</div>
      {sub && <div className="text-xs opacity-40 mt-0.5">{sub}</div>}
    </div>
  );
}

/* Cumulative GoS cells for the Queue Performance table.
   Full nine-bucket detail lives in the chart above. */
function GosCells({ summary }) {
  if (!summary) {
    return (<>
      {[0, 1, 2, 3].map(i => (
        <td key={i} className="table-cell text-center"><span className="opacity-30">-</span></td>
      ))}
    </>);
  }
  const cell = (pct, good) => (
    <span className={pct >= good ? "text-brand-green" : pct >= good - 20 ? "text-brand-orange" : "text-brand-red"}>{pct}%</span>
  );
  return (<>
    <td className="table-cell text-center tabular-nums">{cell(summary.within_30s_pct, 80)}</td>
    <td className="table-cell text-center tabular-nums">{cell(summary.within_60s_pct, 90)}</td>
    <td className="table-cell text-center tabular-nums">{cell(summary.within_300s_pct, 95)}</td>
    <td className="table-cell text-center tabular-nums">
      {summary.over_300s > 0
        ? <span className="text-brand-red">{summary.over_300s_pct}%</span>
        : <span className="opacity-30">-</span>}
    </td>
  </>);
}

/* Counts drive the bars; the rates that actually matter live here.
   "Which categories abandon most" is more useful than "which is biggest". */
function CategoryTooltip({ active, payload }) {
  if (!active || !payload || payload.length === 0) return null;
  const d = payload[0].payload;
  const Row = ({ l, v }) => (
    <div className="flex justify-between gap-6">
      <span className="opacity-50">{l}</span>
      <span className="tabular-nums">{v}</span>
    </div>
  );
  return (
    <div className="glass px-3 py-2 text-xs" style={{ minWidth: "170px" }}>
      <div className="font-semibold mb-1.5 break-words">{d.category}</div>
      <Row l="Calls" v={d.count} />
      <Row l="Answered" v={d.answered_pct + "%"} />
      <Row l="Abandoned" v={d.abandoned_pct + "%"} />
      <Row l="Avg talk" v={fmtTime(d.avg_talk_seconds)} />
      {d.is_other
        ? <div className="opacity-40 mt-1.5">{d.merged_count} smaller categories</div>
        : <div className="opacity-40 mt-1.5">Click to view these calls</div>}
    </div>
  );
}

function QueueFilter({ queues, selectedIds, onChange }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const ref = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) { setOpen(false); setSearch(""); } };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => { if (open && inputRef.current) inputRef.current.focus(); }, [open]);

  const filtered = queues.filter(q => (q.name || q.queue).toLowerCase().includes(search.toLowerCase()));

  const sel = new Set(selectedIds);
  const known = new Set(queues.map(q => q.queue));
  /* A remembered queue with no calls in the current range is absent from
     `queues`, so it would filter silently with no way to clear it. List it
     explicitly instead. */
  const orphans = selectedIds.filter(id => !known.has(id));

  const toggle = (id) => onChange(sel.has(id) ? selectedIds.filter(x => x !== id) : [...selectedIds, id]);

  const label = selectedIds.length === 0
    ? "All Queues"
    : selectedIds.length === 1
      ? ((queues.find(q => q.queue === selectedIds[0]) || {}).name || selectedIds[0])
      : selectedIds.length + " queues";

  const Box = ({ on }) => (
    <span className={"shrink-0 w-4 h-4 rounded border flex items-center justify-center transition-all "
      + (on ? "bg-brand-blue border-brand-blue" : "border-black/20 dark:border-white/20")}>
      {on && <Check size={11} className="text-white" strokeWidth={3} />}
    </span>
  );

  return (
    <div className="relative" ref={ref}>
      <button onClick={() => { setOpen(!open); setSearch(""); }}
        className="flex items-center gap-2 px-4 py-2 rounded-xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/[0.08] hover:bg-black/10 dark:hover:bg-white/10 transition-all text-sm">
        <Phone size={14} className="text-brand-blue" />
        <span className="opacity-80">{label}</span>
        {selectedIds.length > 0 && <span onClick={(e) => { e.stopPropagation(); onChange([]); }} className="opacity-40 hover:opacity-100 ml-1"><X size={12} /></span>}
        <ChevronDown size={14} className={"opacity-40 transition-transform " + (open ? "rotate-180" : "")} />
      </button>
      {open && (
        <div className="absolute z-50 mt-1 left-0 bg-white dark:bg-surface-800 border border-black/10 dark:border-white/10 rounded-xl overflow-hidden shadow-2xl shadow-black/30" style={{ minWidth: "250px" }}>
          <div className="p-2 border-b border-black/5 dark:border-white/5">
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 opacity-30" />
              <input ref={inputRef} className="w-full bg-black/5 dark:bg-white/5 rounded-lg pl-8 pr-3 py-2 text-sm outline-none placeholder-black/30 dark:placeholder-white/30"
                placeholder="Search queues..." value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto">
            <button onClick={() => { onChange([]); setSearch(""); }}
              className={"w-full text-left px-3 py-2.5 text-sm transition-all hover:bg-black/5 dark:hover:bg-white/5 " + (selectedIds.length === 0 ? "text-brand-blue bg-brand-blue/10" : "opacity-60")}>
              All Queues
            </button>
            {orphans.map(id => (
              <button key={"orphan-" + id} onClick={() => toggle(id)}
                className="w-full text-left px-3 py-2.5 text-sm transition-all hover:bg-black/5 dark:hover:bg-white/5 border-t border-black/5 dark:border-white/5 text-brand-blue bg-brand-blue/10">
                <div className="flex items-center gap-2">
                  <Box on={true} />
                  <div className="min-w-0">
                    <div className="truncate">{id}</div>
                    <div className="text-[10px] opacity-30">no calls in this range</div>
                  </div>
                </div>
              </button>
            ))}
            {filtered.map(q => (
              <button key={q.queue} onClick={() => toggle(q.queue)}
                className={"w-full text-left px-3 py-2.5 text-sm transition-all hover:bg-black/5 dark:hover:bg-white/5 border-t border-black/5 dark:border-white/5 " + (sel.has(q.queue) ? "text-brand-blue bg-brand-blue/10" : "opacity-60")}>
                <div className="flex items-center gap-2">
                  <Box on={sel.has(q.queue)} />
                  <div className="min-w-0">
                    <div className="truncate">{q.name}</div>
                    <div className="text-[10px] opacity-30">{q.queue} - {q.total_calls} calls</div>
                  </div>
                </div>
              </button>
            ))}
            {filtered.length === 0 && <div className="px-3 py-4 text-sm opacity-30 text-center">No queues match</div>}
          </div>
        </div>
      )}
    </div>
  );
}

export default function Queues() {
  const { domainParam, activeTenant , timezone} = useTenant();
  const { toQueryParams, preset, customFrom, customTo } = useDateRange();
  const { dark } = useTheme();
  const cc = useChartColors(dark);
  const [allQueues, setAllQueues] = useState([]);
  const [selectedIds, setSelectedIds] = useState(() => loadQueueSel(domainParam));
  const [hourly, setHourly] = useState([]);
  const [queueAgents, setQueueAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [excludeOutbound, setExcludeOutbound] = useState(false);
  const [gosQueues, setGosQueues] = useState([]);
  const [gosLabels, setGosLabels] = useState([]);
  const [cats, setCats] = useState(null);
  const [gosSla, setGosSla] = useState(null);
  const navigate = useNavigate();

  /* Declared above loadData because its dependency array reads
     selQueueParam during render. */
  const selQueueParam = selectedIds.join(",");
  const selKeys = new Set(selectedIds);
  const isSingle = selectedIds.length === 1;

  const applySelection = useCallback((ids) => {
    setSelectedIds(ids);
    saveQueueSel(domainParam, ids);
  }, [domainParam]);

  /* Switching tenant swaps in that tenant's remembered selection. Writes go
     through applySelection rather than an effect, so this cannot race with a
     save and clobber the incoming domain's stored list. */
  useEffect(() => { setSelectedIds(loadQueueSel(domainParam)); }, [domainParam]);

  const buildQs = useCallback((extra) => {
    const dp = domainParam ? domainParam.slice(1) : "";
    const drp = toQueryParams();
    const parts = [dp, drp, extra || ""].filter(Boolean);
    return parts.length > 0 ? "?" + parts.join("&") : "";
  }, [domainParam, toQueryParams]);

  const loadData = useCallback(async () => {
    setLoading(true);
    const qs = buildQs();
    const queueFilter = selQueueParam ? "queue=" + encodeURIComponent(selQueueParam) : "";
    const filteredQs = buildQs(queueFilter);
    try {
      const dirParam = excludeOutbound ? "direction=inbound" : "";
      const addDir = (url) => dirParam ? url + (url.includes("?") ? "&" : "?") + dirParam : url;
      const [qd, hr, ag, gs, ct] = await Promise.all([
        api.get(addDir("/api/stats/queues" + qs)),
        api.get("/api/stats/hourly-detailed" + filteredQs + (filteredQs.includes("?") ? "&" : "?") + "queues_only=true"),
        api.get(addDir("/api/stats/queue-agents" + filteredQs)),
        api.get(addDir("/api/stats/gos-by-queue" + qs)),
        api.get(addDir("/api/stats/categories" + filteredQs)),
      ]);
      setAllQueues(qd.queues || []);
      setHourly(shiftHourlyToLocal(hr.hourly || [], timezone));
      setQueueAgents(ag.agents || []);
      setGosQueues(gs.queues || []);
      setGosLabels(gs.bucket_labels || []);
      setGosSla(gs.sla || null);
      setCats(ct || null);
    } catch(e) { console.error(e); }
    setLoading(false);
  }, [buildQs, selQueueParam, excludeOutbound]);

  useEffect(() => { loadData(); }, [loadData]);

  const autoRefresh = useAutoRefresh(loadData, 1800);

  const displayQueues = selectedIds.length > 0 ? allQueues.filter(q => selKeys.has(q.queue)) : allQueues;
  const selLabel = selectedIds.length === 0
    ? ""
    : isSingle
      ? ((allQueues.find(q => q.queue === selectedIds[0]) || {}).name || selectedIds[0])
      : selectedIds.length + " queues";
  const selSuffix = selLabel ? " - " + selLabel : "";
  const totalQCalls = displayQueues.reduce((s, q) => s + q.total_calls, 0);
  const totalAnswered = displayQueues.reduce((s, q) => s + q.answered, 0);
  const totalAbandoned = displayQueues.reduce((s, q) => s + q.abandoned, 0);
  const maxH = hourly.reduce((a, b) => b.total > a.total ? b : a, { total: 0, label: "N/A" });
  const nonZero = hourly.filter(h => h.total > 0);
  const minH = nonZero.length > 0 ? nonZero.reduce((a, b) => b.total < a.total ? b : a) : { label: "N/A" };
  const topByCalls = queueAgents[0] || {};
  const topByTalk = [...queueAgents].sort((a, b) => (b.total_talk||0) - (a.total_talk||0))[0] || {};
  const gosByQueue = new Map(gosQueues.map(g => [g.queue, g]));
  const gosScope = selectedIds.length > 0 ? gosQueues.filter(g => selKeys.has(g.queue)) : gosQueues;
  const gosCounts = gosLabels.map((lb, i) => ({
    key: lb.key,
    label: lb.label,
    count: gosScope.reduce((s, g) => s + ((g.buckets && g.buckets[i]) ? g.buckets[i].count : 0), 0),
  }));
  const gosScored = gosCounts.reduce((s, b) => s + b.count, 0);
  let gosRunning = 0;
  const gosChart = gosCounts.map(b => {
    gosRunning += b.count;
    return {
      ...b,
      cumulative_pct: gosScored > 0 ? Math.round((gosRunning / gosScored) * 10000) / 100 : 0,
    };
  });
  /* Tiles reuse the cumulative counts the API already computed per queue,
     summed across whatever is in scope. */
  const gosSum = (k) => gosScope.reduce((s, g) => s + ((g.summary && g.summary[k]) || 0), 0);
  const gosPct = (n) => (gosScored > 0 ? Math.round((n / gosScored) * 10000) / 100 : 0);
  const gosW30 = gosSum("within_30s");
  const gosW60 = gosSum("within_60s");
  const gosW300 = gosSum("within_300s");
  const gosOver = Math.max(0, gosScored - gosW300);

  /* The headline follows sla.target_seconds rather than the fixed 30s tile,
     so a tenant with a custom target still reads correctly. bucket_labels
     carries max_seconds for exactly this. */
  const gosTargetSecs = gosSla && gosSla.target_seconds > 0 ? gosSla.target_seconds : 30;
  const gosTargetPct = gosSla && gosSla.target_pct > 0 ? gosSla.target_pct : 80;
  const gosWithinTarget = gosCounts.reduce((s, b, i) => {
    const max = gosLabels[i] ? gosLabels[i].max_seconds : null;
    return max != null && max <= gosTargetSecs ? s + b.count : s;
  }, 0);
  const gosAchieved = gosPct(gosWithinTarget);

  const exportQs = buildQs().slice(1);

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-2xl font-bold">Queue Analytics</h2>
          <p className="text-sm opacity-40 mt-1">{activeTenant ? activeTenant.domain : "All Tenants"}{selSuffix}</p>
        </div>
        <div className="flex items-center gap-3">
          <RefreshIndicator {...autoRefresh} interval={1800} />
          <BriefingModal context="queues" buildQs={buildQs} selectedQueue={selQueueParam || undefined} />
          <ExportButton url={"/api/export/queues?" + exportQs} label="Export Queues" />
          <QueueFilter queues={allQueues} selectedIds={selectedIds} onChange={applySelection} />
        </div>
      </div>

      <DateFilterBar />

      {loading ? <div className="opacity-50 text-center py-20 animate-pulse">Loading...</div> : <>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <KPI icon={Phone} label="Total Queue Calls" value={totalQCalls} color="blue" />
        <KPI icon={Phone} label="Answered" value={totalAnswered} sub={(() => { const i = displayQueues.reduce((s, q) => s + (q.inbound || 0), 0); const o = displayQueues.reduce((s, q) => s + (q.outbound || 0), 0); return i || o ? i + " in / " + o + " out" : ""; })()}  color="green" />
        <KPI icon={Phone} label="Abandoned" value={totalAbandoned} sub={totalQCalls > 0 ? Math.round(totalAbandoned/totalQCalls*100) + "%" : ""} color="red" />
        <KPI icon={Clock} label="Avg Speed of Answer" value={displayQueues.length > 0 ? Math.round(displayQueues.reduce((s,q) => s+q.avg_speed_of_answer,0)/displayQueues.length) + "s" : "N/A"} color="orange" />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPI icon={Zap} label="Busiest Hour" value={maxH.label} sub={maxH.total + " calls"} color="blue" />
        <KPI icon={MoonIcon} label="Quietest Hour" value={minH.label} sub={minH.total > 0 ? minH.total + " calls" : ""} color="gray" />
        <KPI icon={User} label="Top Agent (Calls)" value={topByCalls.name ? topByCalls.name + " (" + topByCalls.extension + ")" : "N/A"} sub={topByCalls.total_calls ? topByCalls.total_calls + " calls" : ""} color="blue" />
        <KPI icon={User} label="Top Agent (Talk)" value={topByTalk.name ? topByTalk.name + " (" + topByTalk.extension + ")" : "N/A"} sub={topByTalk.total_talk ? fmtTime(topByTalk.total_talk) : ""} color="purple" />
      </div>

      <div className="glass-card mb-6">
        <h3 className="text-lg font-semibold mb-4">Hourly Call Volume{selSuffix} <span className="text-xs font-normal opacity-40">({getTimezoneLabel(timezone)})</span></h3>
        <div className="h-64"><ResponsiveContainer><BarChart data={hourly}>
          <CartesianGrid strokeDasharray="3 3" stroke={cc.grid} />
          <XAxis dataKey="label" tick={{ fill: cc.tick, fontSize: 10 }} interval={1} />
          <YAxis tick={{ fill: cc.tick, fontSize: 11 }} />
          <Tooltip contentStyle={cc.tooltip} /><Legend />
          <Bar dataKey="inbound" name="Inbound" stackId="a" fill={C.green} />
          <Bar dataKey="outbound" name="Outbound" stackId="a" fill={C.blue} />
          <Bar dataKey="internal" name="Internal" stackId="a" fill={C.gray} />
          <Bar dataKey="abandoned" name="Abandoned" stackId="b" fill={C.red} radius={[4,4,0,0]} />
        </BarChart></ResponsiveContainer></div>
      </div>

      {!isSingle && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-6">
          {displayQueues.map(q => (
            <div key={q.queue} className="glass-card cursor-pointer hover:border-brand-blue/30 transition-all" onClick={() => applySelection([q.queue])}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">{q.name}</h3>
                <span className="text-xs opacity-40">{q.queue}</span>
              </div>
              <div className="grid grid-cols-3 gap-3 mb-3">
                <div className="text-center"><div className="text-2xl font-bold text-brand-blue">{q.total_calls}</div><div className="text-[11px] opacity-40">Total</div></div>
                <div className="text-center"><div className="text-2xl font-bold text-brand-green">{q.answered}</div><div className="text-[11px] opacity-40">Answered</div></div>
                <div className="text-center"><div className="text-2xl font-bold text-brand-red">{q.abandoned}</div><div className="text-[11px] opacity-40">Abandoned</div></div>
              </div>
              {q.total_calls > 0 && (
                <div className="h-4 rounded-full overflow-hidden flex bg-black/5 dark:bg-white/5 mb-4">
                  <div className="h-full bg-brand-green" style={{width: `${(q.answered / q.total_calls * 100)}%`}} />
                  <div className="h-full bg-brand-red" style={{width: `${(q.abandoned / q.total_calls * 100)}%`}} />
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-black/5 dark:bg-white/5 rounded-xl p-3 text-center">
                  <div className="text-sm font-bold" style={{color:q.answer_rate>=80?"#34c759":q.answer_rate>=60?"#ff9500":"#ff3b30"}}>{q.answer_rate}%</div>
                  <div className="text-[11px] opacity-40">Answer Rate</div>
                </div>
                <div className="bg-black/5 dark:bg-white/5 rounded-xl p-3 text-center">
                  <div className="text-sm font-bold text-brand-orange">{q.avg_speed_of_answer}s</div>
                  <div className="text-[11px] opacity-40">Avg Speed</div>
                </div>
              </div>
            </div>
          ))}
          {displayQueues.length === 0 && <div className="col-span-3 text-center opacity-30 py-12">No queue data</div>}
        </div>
      )}

      {gosScored > 0 && (
        <div className="glass-card mb-6">
          <div className="flex items-start justify-between mb-4 flex-wrap gap-3">
            <div>
              <h3 className="text-lg font-semibold">Grade of Service{selSuffix}</h3>
              <p className="text-xs opacity-40 mt-0.5">Answered queue calls by time to answer ({gosScored} measured)</p>
            </div>
            <div className="text-right">
              <div className={"text-2xl font-bold tabular-nums " + (gosAchieved >= gosTargetPct ? "text-brand-green" : "text-brand-red")}>
                {gosAchieved}%
              </div>
              <div className="text-[11px] opacity-40">
                answered in {gosTargetSecs}s (target {gosTargetPct}%)
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            {[
              { l: "Within 30s", v: gosPct(gosW30),  n: gosW30,  c: C.green },
              { l: "Within 60s", v: gosPct(gosW60),  n: gosW60,  c: C.blue },
              { l: "Within 5m",  v: gosPct(gosW300), n: gosW300, c: C.orange },
              { l: "Over 5m",    v: gosPct(gosOver), n: gosOver, c: C.red },
            ].map((s, i) => (
              <div key={i} className="bg-black/5 dark:bg-white/5 rounded-xl p-3">
                <div className="text-lg font-bold tabular-nums" style={{ color: s.c }}>{s.v}%</div>
                <div className="text-[11px] opacity-40">{s.l} <span className="opacity-60">({s.n})</span></div>
              </div>
            ))}
          </div>

          <div className="h-72"><ResponsiveContainer><ComposedChart data={gosChart}>
            <CartesianGrid strokeDasharray="3 3" stroke={cc.grid} />
            <XAxis dataKey="label" tick={{ fill: cc.tick, fontSize: 10 }} />
            <YAxis yAxisId="left" tick={{ fill: cc.tick, fontSize: 11 }} />
            <YAxis yAxisId="right" orientation="right" domain={[0, 100]} unit="%"
              tick={{ fill: cc.tick, fontSize: 11 }} />
            <Tooltip contentStyle={cc.tooltip}
              formatter={(v, n) => (n === "Cumulative" ? [v + "%", "Answered by this point"] : [v + " calls", "In this band"])} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Bar yAxisId="left" dataKey="count" name="Answered" fill={C.purple} radius={[4,4,0,0]}
              cursor="pointer"
              onClick={(d) => {
                if (d && d.key) {
                  navigate("/calls?answer_bucket=" + encodeURIComponent(d.key)
                    + (selQueueParam ? "&queue=" + encodeURIComponent(selQueueParam) : ""));
                }
              }} />
            <Line yAxisId="right" type="monotone" dataKey="cumulative_pct" name="Cumulative"
              stroke={C.green} strokeWidth={2} dot={{ r: 3 }} />
          </ComposedChart></ResponsiveContainer></div>
        </div>
      )}

      {/* Card is hidden entirely unless this tenant has ever categorised a
          queue call (cats.available), which is evaluated without the date
          filter so the card does not flicker as the range changes. */}
      {cats && cats.available && (
        <div className="glass-card mb-6">
          <div className="mb-4">
            <h3 className="text-lg font-semibold">Call Categories{selSuffix}</h3>
            <p className="text-xs opacity-40 mt-1">
              {cats.categorised > 0
                ? cats.distinct_count + (cats.distinct_count === 1 ? " category" : " categories") + " across " + cats.categorised + (cats.categorised === 1 ? " call" : " calls")
                : "No categorised calls in this period"}
              {cats.uncategorised > 0 ? " \u00B7 " + cats.uncategorised + " uncategorised" : ""}
            </p>
          </div>

          {cats.categorised > 0 ? (
            <div style={{ height: Math.max(180, cats.categories.length * 38 + 44) }}>
              <ResponsiveContainer>
                <BarChart data={cats.categories} layout="vertical"
                  margin={{ left: 4, right: 28, top: 4, bottom: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={cc.grid} horizontal={false} />
                  <XAxis type="number" allowDecimals={false} tick={{ fill: cc.tick, fontSize: 11 }} />
                  <YAxis type="category" dataKey="category" width={160} interval={0}
                    tick={{ fill: cc.tick, fontSize: 11 }} />
                  <Tooltip content={<CategoryTooltip />} />
                  <Bar dataKey="count" name="Calls" fill={C.blue} radius={[0, 4, 4, 0]}
                    cursor="pointer"
                    onClick={(d) => {
                      if (d && d.category && !d.is_other) {
                        navigate("/calls?category=" + encodeURIComponent(d.category)
                          + (selQueueParam ? "&queue=" + encodeURIComponent(selQueueParam) : ""));
                      }
                    }} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="py-10 text-center text-sm opacity-30">
              This tenant uses call categories, but none were set in this period.
            </div>
          )}
        </div>
      )}

      <div className="glass overflow-hidden mb-6">
        <div className="px-6 py-4 border-b border-black/5 dark:border-white/5 flex items-center justify-between">
          <h3 className="text-lg font-semibold">Queue Performance</h3>
          <button onClick={() => setExcludeOutbound(!excludeOutbound)}
            className={"px-3 py-1 rounded-full text-xs font-medium transition-all " + (excludeOutbound ? "bg-brand-blue text-white" : "bg-black/5 dark:bg-white/5 opacity-50 hover:opacity-80")}>
            {excludeOutbound ? "Inbound Only" : "All Directions"}
          </button>
        </div>
        <div className="overflow-x-auto"><table className="w-full"><thead><tr className="bg-black/5 dark:bg-white/[0.03]">
          <th className="table-header">Queue</th><th className="table-header text-center">Calls</th><th className="table-header text-center">Answer %</th>
          <th className="table-header text-center">Abandon %</th>
          <th className="table-header text-center" title="Average wait across all queue calls, including abandoned">Avg SOA</th>
          <th className="table-header text-center" title="Average time to answer, answered calls only">Avg Answer</th>
          <th className="table-header text-center">Max Wait</th>
          <th className="table-header text-center" title="Answered within 30 seconds">{"\u2264"}30s</th>
          <th className="table-header text-center" title="Answered within 60 seconds">{"\u2264"}60s</th>
          <th className="table-header text-center" title="Answered within 5 minutes">{"\u2264"}5m</th>
          <th className="table-header text-center" title="Answered after more than 5 minutes">{"\u003E"}5m</th>
          <th className="table-header text-center">Avg Talk</th><th className="table-header text-center">Agents</th><th className="table-header text-center">MOS</th>
        </tr></thead><tbody>
          {displayQueues.map(q => (
            <tr key={q.queue} className={"hover:bg-black/5 dark:hover:bg-white/[0.03] cursor-pointer " + (selKeys.has(q.queue) ? "bg-brand-blue/5" : "")}
              onClick={() => applySelection(selKeys.has(q.queue) ? selectedIds.filter(x => x !== q.queue) : [...selectedIds, q.queue])}>
              <td className="table-cell font-medium">{q.name}</td>
              <td className="table-cell text-center tabular-nums">{q.total_calls}</td>
              <td className="table-cell text-center"><span className={q.answer_rate>=80?"text-brand-green":q.answer_rate>=60?"text-brand-orange":"text-brand-red"}>{q.answer_rate}%</span></td>
              <td className="table-cell text-center"><span className={q.abandon_rate<=10?"text-brand-green":q.abandon_rate<=20?"text-brand-orange":"text-brand-red"}>{q.abandon_rate}%</span></td>
              <td className="table-cell text-center tabular-nums">{q.avg_speed_of_answer}s</td>
              <td className="table-cell text-center tabular-nums">
                {q.avg_answer_seconds != null ? q.avg_answer_seconds + "s" : <span className="opacity-30">-</span>}
              </td>
              <td className="table-cell text-center tabular-nums">{q.max_wait}s</td>
              <GosCells summary={(gosByQueue.get(q.queue) || {}).summary} />
              <td className="table-cell text-center tabular-nums">{q.avg_talk}s</td>
              <td className="table-cell text-center tabular-nums">{q.agent_count}</td>
              <td className="table-cell text-center">{q.avg_mos ? (
                <span className={q.avg_mos>=4?"text-brand-green":q.avg_mos>=3?"text-brand-orange":"text-brand-red"}>{q.avg_mos}</span>
              ) : <span className="opacity-30">-</span>}</td>
            </tr>
          ))}
          {displayQueues.length===0 && <tr><td colSpan={14} className="table-cell text-center opacity-30 py-8">No queue data</td></tr>}
        </tbody></table></div>
      </div>

      <div className="glass overflow-hidden">
        <div className="px-6 py-4 border-b border-black/5 dark:border-white/5">
          <h3 className="text-lg font-semibold">Agent Performance{selSuffix || " (All Queues)"}</h3>
        </div>
        <div className="overflow-x-auto"><table className="w-full"><thead><tr className="bg-black/5 dark:bg-white/[0.03]">
          <th className="table-header">Agent</th>
          {!isSingle && <th className="table-header">Queue</th>}
          <th className="table-header text-center">Calls</th>
          <th className="table-header text-center">Total Talk</th>
          <th className="table-header text-center">Avg Talk</th>
          <th className="table-header text-center">Avg Hold</th>
          <th className="table-header text-center">Avg Ring</th>
          <th className="table-header text-center">Avg Handle</th>
          <th className="table-header text-center">MOS</th>
        </tr></thead><tbody>
          {queueAgents.length === 0 ? (
            <tr><td colSpan={isSingle ? 8 : 9} className="table-cell text-center opacity-30 py-8">No agent data for this queue</td></tr>
          ) : queueAgents.map((a, i) => (
            <tr key={a.extension + "-" + a.queue + "-" + i} className="hover:bg-black/5 dark:hover:bg-white/[0.03] cursor-pointer" onClick={() => navigate(`/calls?agent=${a.extension}`)}>
              <td className="table-cell">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-brand-indigo/20 flex items-center justify-center text-brand-indigo text-xs font-bold">{(a.name || "?")[0].toUpperCase()}</div>
                  <div><div className="text-sm font-medium">{a.name}</div><div className="text-xs opacity-40">Ext {a.extension}</div></div>
                </div>
              </td>
              {!isSingle && <td className="table-cell text-xs">{a.queue_name} <span className="opacity-30">({a.queue})</span></td>}
              <td className="table-cell text-center tabular-nums">{a.total_calls}</td>
              <td className="table-cell text-center tabular-nums">{fmtTime(a.total_talk)}</td>
              <td className="table-cell text-center tabular-nums">{fmtTime(a.avg_talk)}</td>
              <td className="table-cell text-center tabular-nums">{fmtTime(a.avg_hold)}</td>
              <td className="table-cell text-center tabular-nums">{fmtTime(a.avg_ring)}</td>
              <td className="table-cell text-center tabular-nums">{fmtTime(a.avg_handle_time)}</td>
              <td className="table-cell text-center">{a.avg_mos ? (
                <span className={a.avg_mos>=4?"text-brand-green":a.avg_mos>=3?"text-brand-orange":"text-brand-red"}>{a.avg_mos}</span>
              ) : <span className="opacity-30">-</span>}</td>
            </tr>
          ))}
        </tbody></table></div>
      </div>

      </>}
    </div>
  );
}
