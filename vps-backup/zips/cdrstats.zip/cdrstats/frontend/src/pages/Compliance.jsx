import { useState, useEffect, useCallback } from "react";
import { api } from "../api/client";
import { useTenant } from "../context/TenantContext";
import { useAuth } from "../context/AuthContext";
import { useDateRange } from "../context/DateRangeContext";
import DateFilterBar from "../components/DateFilterBar";
import { useAutoRefresh, RefreshIndicator } from "../components/AutoRefresh";
import { useNavigate } from "react-router-dom";
import {
  ShieldCheck, AlertTriangle, Award, ScanLine,
  Plus, Trash2, Save, RefreshCw, CheckCircle2, XCircle, Pencil,
} from "lucide-react";

const SEV_COLORS = { low: "text-brand-blue", medium: "text-brand-yellow", high: "text-brand-orange", critical: "text-brand-red" };

function KPI({ icon: Icon, label, value, sub, color = "blue" }) {
  return (
    <div className="glass-card">
      <div className="flex items-center gap-2 mb-1 opacity-50 text-xs"><Icon size={14} className={`text-brand-${color}`} /> {label}</div>
      <div className="text-2xl font-bold">{value ?? "—"}</div>
      {sub && <div className="text-[11px] opacity-40 mt-0.5">{sub}</div>}
    </div>
  );
}

function Msg({ msg }) {
  if (!msg) return null;
  return <div className={`text-sm px-4 py-2.5 rounded-xl mb-4 ${msg.ok ? "bg-brand-green/10 text-brand-green" : "bg-brand-red/10 text-brand-red"}`}>{msg.text}</div>;
}

// -- Overview ------------------------------------------

function OverviewTab({ qs, canManage, timezone, navigate }) {
  const [stats, setStats] = useState(null);
  const [violations, setViolations] = useState([]);
  const [leaders, setLeaders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reevalMsg, setReevalMsg] = useState(null);
  const [reevalBusy, setReevalBusy] = useState(false);
  const [includeQa, setIncludeQa] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [s, v, l] = await Promise.all([
        api.get("/api/compliance/stats" + qs),
        api.get("/api/compliance/violations" + qs + (qs ? "&" : "?") + "limit=10"),
        api.get("/api/compliance/qa/leaderboard" + qs),
      ]);
      setStats(s); setViolations(v.calls || []); setLeaders(l.agents || []);
    } catch (e) { console.error(e); }
    setLoading(false);
  }, [qs]);

  useEffect(() => { load(); }, [load]);

  const autoRefresh = useAutoRefresh(load, 1800);

  const fmtTs = (s) => {
    if (!s) return "";
    try { return new Date(s * 1000).toLocaleString(undefined, { timeZone: timezone || undefined, month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }); }
    catch { return new Date(s * 1000).toLocaleString(); }
  };

  const handleReevaluate = async () => {
    if (!confirm("Queue re-evaluation of transcribed calls in the current date range? Runs throttled in the background." + (includeQa ? " QA scoring uses AI tokens per call." : ""))) return;
    setReevalBusy(true); setReevalMsg(null);
    try {
      const params = new URLSearchParams(qs.replace(/^\?/, ""));
      const body = { include_qa: includeQa };
      if (params.get("domain")) body.domain = params.get("domain");
      if (params.get("start_from")) body.start_from = params.get("start_from");
      if (params.get("start_to")) body.start_to = params.get("start_to");
      const r = await api.post("/api/compliance/reevaluate", body);
      setReevalMsg({ ok: true, text: r.message });
    } catch (e) { setReevalMsg({ ok: false, text: e.message }); }
    setReevalBusy(false);
  };

  const runQa = async (c) => {
    try { const r = await api.post("/api/compliance/qa/" + encodeURIComponent(c.callid), {}); setReevalMsg({ ok: true, text: r.message + " — refresh in ~30s to see the score" }); }
    catch (e) { setReevalMsg({ ok: false, text: e.message }); }
  };

  if (loading) return <div className="opacity-50 text-center py-20 animate-pulse">Loading compliance data...</div>;
  const s = stats?.summary || {};
  const qa = stats?.qa || {};

  return (
    <div>
      <div className="flex justify-end -mt-2 mb-2"><RefreshIndicator {...autoRefresh} interval={1800} /></div>
      <Msg msg={reevalMsg} />
      {s.unevaluated > 0 && (
        <div className="text-sm px-4 py-2.5 rounded-xl mb-4 bg-brand-yellow/10 text-brand-yellow">
          {s.unevaluated} call{s.unevaluated === 1 ? "" : "s"} had AI-mode rules that could not be evaluated (AI provider unavailable or invalid response). Check Admin → AI Settings and worker logs, then use Re-evaluate Range below.
        </div>
      )}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KPI icon={ShieldCheck} label="Calls Evaluated" value={s.evaluated || 0} color="blue" />
        <KPI icon={CheckCircle2} label="Pass Rate" value={s.pass_rate != null ? s.pass_rate + "%" : "—"} sub={"Avg score: " + (s.avg_score ?? "—")} color="green" />
        <KPI icon={AlertTriangle} label="Violations" value={s.violations || 0} color="red" />
        <KPI icon={Award} label="QA Scored" value={qa.scored || 0} sub={qa.avg_score != null ? "Avg QA: " + qa.avg_score : ""} color="purple" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="glass-card">
          <h3 className="text-lg font-semibold mb-4">Violations by Rule</h3>
          {(stats?.by_rule || []).length === 0 ? <div className="opacity-30 text-sm py-6 text-center">No violations in range 🎉</div> : (
            <div className="space-y-2">
              {stats.by_rule.map((r, i) => (
                <div key={i} className="flex items-center justify-between text-sm py-1.5 border-b border-black/5 dark:border-white/5 last:border-0">
                  <span className="truncate">{r.name}</span>
                  <span className="flex items-center gap-3 shrink-0">
                    <span className={`text-[10px] uppercase font-bold ${SEV_COLORS[r.severity] || ""}`}>{r.severity}</span>
                    <span className="font-semibold">{r.count}</span>
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="glass-card">
          <h3 className="text-lg font-semibold mb-4">Agent QA Leaderboard</h3>
          {leaders.length === 0 ? <div className="opacity-30 text-sm py-6 text-center">No QA-scored calls yet. Enable sampling in the QA Settings tab.</div> : (
            <div className="space-y-2">
              {leaders.map((a, i) => (
                <div key={a.extension} className="flex items-center justify-between text-sm py-1.5 border-b border-black/5 dark:border-white/5 last:border-0">
                  <span className="truncate">{i + 1}. {a.name || a.extension} <span className="opacity-30 text-xs">({a.extension})</span></span>
                  <span className="flex items-center gap-3 shrink-0">
                    <span className="opacity-40 text-xs">{a.scored} calls</span>
                    <span className={`font-bold ${a.avg_score >= 80 ? "text-brand-green" : a.avg_score >= 60 ? "text-brand-yellow" : "text-brand-red"}`}>{a.avg_score}</span>
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="glass-card mb-6">
        <h3 className="text-lg font-semibold mb-4">Recent Violating Calls</h3>
        {violations.length === 0 ? <div className="opacity-30 text-sm py-6 text-center">No violating calls in range</div> : (
          <div className="space-y-3">
            {violations.map(c => (
              <div key={c.callid} onClick={() => navigate("/calls?open=" + encodeURIComponent(c.callid) + "&tab=ai")}
                className="p-3 rounded-xl bg-black/[0.03] dark:bg-white/[0.03] cursor-pointer hover:bg-black/[0.06] dark:hover:bg-white/[0.06] transition-colors">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{c.from_display_name || c.from_number_raw || "Unknown"} → {c.answering_extension_name || "N/A"}{c.answering_queue_name ? " (" + c.answering_queue_name + ")" : ""}</span>
                  <span className="flex items-center gap-3">
                    <span className="text-xs opacity-40">{fmtTs(c.start)}</span>
                    {c.qa_score != null && <span className="text-xs font-bold text-brand-purple">QA {c.qa_score}</span>}
                    <span className="text-xs font-bold text-brand-red">Score {c.compliance_score}</span>
                    {canManage && <button onClick={(e) => { e.stopPropagation(); runQa(c); }} className="opacity-40 hover:opacity-100" title="Run QA scoring on this call"><Award size={13} /></button>}
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {(c.compliance?.violations || []).map((v, i) => (
                    <span key={i} className={`text-[10px] px-2 py-0.5 rounded-full bg-black/5 dark:bg-white/5 ${SEV_COLORS[v.severity] || ""}`} title={v.evidence || ""}>{v.name}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {canManage && (
        <div className="glass-card">
          <h3 className="text-lg font-semibold mb-1">Re-evaluate Historical Calls</h3>
          <p className="text-xs opacity-40 mb-3">Queues throttled background jobs to apply current rules to transcribed calls in the selected date range and tenant (max 5,000 per run).</p>
          <div className="flex items-center gap-4 flex-wrap">
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={includeQa} onChange={e => setIncludeQa(e.target.checked)} /> Also run QA scoring (uses AI tokens)</label>
            <button onClick={handleReevaluate} disabled={reevalBusy} className="btn-secondary text-sm flex items-center gap-2 disabled:opacity-30"><RefreshCw size={14} /> {reevalBusy ? "Queuing..." : "Re-evaluate Range"}</button>
          </div>
        </div>
      )}
    </div>
  );
}

// -- Rules ---------------------------------------------

const EMPTY_RULE = { name: "", type: "required_phrase", match_mode: "contains", pattern: "", ai_description: "", channel: "any", window_seconds: 0, severity: "medium", direction: "any", scope: "tenant", enabled: true };

function RulesTab({ activeTenant, canManage, isSuper }) {
  const [rules, setRules] = useState([]);
  const [form, setForm] = useState(null);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const domainQ = activeTenant ? "?domain=" + encodeURIComponent(activeTenant.domain) : "";

  const load = useCallback(() => {
    api.get("/api/compliance/rules" + domainQ).then(d => setRules(d.rules || [])).catch(console.error);
  }, [domainQ]);
  useEffect(() => { load(); }, [load]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const save = async () => {
    setBusy(true); setMsg(null);
    try {
      const body = { ...form, domain: activeTenant?.domain };
      if (form._id) await api.put("/api/compliance/rules/" + form._id, body);
      else await api.post("/api/compliance/rules", body);
      setMsg({ ok: true, text: form._id ? "Rule updated" : "Rule created" });
      setForm(null); load();
    } catch (e) { setMsg({ ok: false, text: e.message }); }
    setBusy(false);
  };

  const remove = async (r) => {
    if (!confirm('Delete rule "' + r.name + '"?')) return;
    try { await api.del("/api/compliance/rules/" + r._id); load(); } catch (e) { setMsg({ ok: false, text: e.message }); }
  };

  const toggle = async (r) => {
    try { await api.put("/api/compliance/rules/" + r._id, { ...r, enabled: r.enabled === false, domain: activeTenant?.domain }); load(); }
    catch (e) { setMsg({ ok: false, text: e.message }); }
  };

  const [presetBusy, setPresetBusy] = useState(false);
  const addPreset = async (pack, label) => {
    if (!activeTenant) return;
    if (!confirm('Add the "' + label + '" preset rules to ' + activeTenant.domain + '? Rules with matching names are skipped.')) return;
    setPresetBusy(true);
    try { const r = await api.post("/api/compliance/rules/preset", { pack, domain: activeTenant.domain }); setMsg({ ok: true, text: r.message }); load(); }
    catch (e) { setMsg({ ok: false, text: e.message }); }
    setPresetBusy(false);
  };

  return (
    <div>
      <Msg msg={msg} />
      <div className="flex items-center justify-between mb-4">
        <p className="text-xs opacity-40">Rules apply to new transcriptions automatically{activeTenant ? " for " + activeTenant.domain : ""}. Use Re-evaluate on the Overview tab for historical calls.</p>
        {canManage && !form && (
          <button onClick={() => setForm({ ...EMPTY_RULE })} className="btn-primary text-sm flex items-center gap-2"><Plus size={14} /> New Rule</button>
        )}
      </div>

      {canManage && !form && (
        <div className="flex items-center gap-2 mb-4 flex-wrap text-xs">
          <span className="opacity-40">Preset packs:</span>
          {[["general", "General Customer Service"], ["collections", "Collections / FDCPA"], ["payments", "Payments / PCI"]].map(([k, lbl]) => (
            <button key={k} onClick={() => addPreset(k, lbl)} disabled={!activeTenant || presetBusy} className="btn-secondary text-xs disabled:opacity-30">{lbl}</button>
          ))}
          {!activeTenant && <span className="opacity-30">— select a tenant to seed presets</span>}
        </div>
      )}

      {form && (
        <div className="glass-card mb-6">
          <h3 className="text-lg font-semibold mb-4">{form._id ? "Edit Rule" : "New Rule"}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Rule Name</label>
              <input className="glass-input w-full" placeholder="e.g. Recorded-line disclosure" value={form.name} onChange={e => set("name", e.target.value)} />
            </div>
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Type</label>
              <select className="glass-select w-full" value={form.type} onChange={e => set("type", e.target.value)}>
                <option value="required_phrase">Required phrase (must be said)</option>
                <option value="prohibited_phrase">Prohibited phrase (must NOT be said)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Match Mode</label>
              <select className="glass-select w-full" value={form.match_mode} onChange={e => set("match_mode", e.target.value)}>
                <option value="contains">Contains (case-insensitive)</option>
                <option value="regex">Regex</option>
                <option value="ai">AI paraphrase (uses tokens)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Severity</label>
              <select className="glass-select w-full" value={form.severity} onChange={e => set("severity", e.target.value)}>
                <option value="low">Low (-5)</option><option value="medium">Medium (-15)</option>
                <option value="high">High (-30)</option><option value="critical">Critical (-100)</option>
              </select>
            </div>
            {form.match_mode !== "ai" ? (
              <div className="md:col-span-2">
                <label className="block text-xs font-medium opacity-60 mb-1.5">{form.match_mode === "regex" ? "Regex Pattern" : "Phrase"}</label>
                <input className="glass-input w-full" placeholder={form.match_mode === "regex" ? "this call (is|may be) recorded" : "this call is recorded"} value={form.pattern} onChange={e => set("pattern", e.target.value)} />
              </div>
            ) : (
              <div className="md:col-span-2">
                <label className="block text-xs font-medium opacity-60 mb-1.5">Describe what must (not) be communicated</label>
                <input className="glass-input w-full" placeholder="The agent informs the caller that the call is being recorded" value={form.ai_description} onChange={e => set("ai_description", e.target.value)} />
              </div>
            )}
            {form.type === "required_phrase" && (
              <div>
                <label className="block text-xs font-medium opacity-60 mb-1.5">Within first N seconds (0 = anywhere)</label>
                <input type="number" min="0" max="3600" className="glass-input w-full" value={form.window_seconds} onChange={e => set("window_seconds", e.target.value)} />
              </div>
            )}
            <div>
              <label className="block text-xs font-medium opacity-60 mb-1.5">Direction</label>
              <select className="glass-select w-full" value={form.direction} onChange={e => set("direction", e.target.value)}>
                <option value="any">Any</option><option value="inbound">Inbound</option>
                <option value="outbound">Outbound</option><option value="internal">Internal</option>
              </select>
            </div>
            {isSuper && !form._id && (
              <div>
                <label className="block text-xs font-medium opacity-60 mb-1.5">Scope</label>
                <select className="glass-select w-full" value={form.scope} onChange={e => set("scope", e.target.value)}>
                  <option value="tenant">This tenant only</option>
                  <option value="global">Global (all tenants)</option>
                </select>
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <button onClick={save} disabled={busy} className="btn-primary text-sm flex items-center gap-2 disabled:opacity-30"><Save size={14} /> {busy ? "Saving..." : "Save Rule"}</button>
            <button onClick={() => setForm(null)} className="btn-secondary text-sm">Cancel</button>
          </div>
        </div>
      )}

      <div className="glass-card">
        {rules.length === 0 ? <div className="opacity-30 text-sm py-10 text-center">No compliance rules yet.{canManage ? " Create your first rule to start monitoring." : ""}</div> : (
          <div className="space-y-2">
            {rules.map(r => (
              <div key={r._id} className={`flex items-center justify-between p-3 rounded-xl bg-black/[0.03] dark:bg-white/[0.03] ${r.enabled === false ? "opacity-40" : ""}`}>
                <div className="min-w-0">
                  <div className="text-sm font-medium flex items-center gap-2">
                    {r.type === "prohibited_phrase" ? <XCircle size={14} className="text-brand-red shrink-0" /> : <CheckCircle2 size={14} className="text-brand-green shrink-0" />}
                    <span className="truncate">{r.name}</span>
                    {r.scope === "global" && <span className="text-[9px] bg-brand-purple/15 text-brand-purple px-1.5 py-0.5 rounded-full font-bold shrink-0">GLOBAL</span>}
                    {r.match_mode === "ai" && <span className="text-[9px] bg-brand-blue/15 text-brand-blue px-1.5 py-0.5 rounded-full font-bold shrink-0">AI</span>}
                  </div>
                  <div className="text-xs opacity-40 truncate mt-0.5">
                    {r.match_mode === "ai" ? r.ai_description : '"' + r.pattern + '"'}
                    {r.window_seconds > 0 ? " • first " + r.window_seconds + "s" : ""}
                    {r.direction !== "any" ? " • " + r.direction : ""}
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0 ml-3">
                  <span className={`text-[10px] uppercase font-bold ${SEV_COLORS[r.severity] || ""}`}>{r.severity}</span>
                  {canManage && <>
                    <button onClick={() => toggle(r)} className="text-xs opacity-50 hover:opacity-100">{r.enabled === false ? "Enable" : "Disable"}</button>
                    <button onClick={() => setForm({ ...EMPTY_RULE, ...r })} className="opacity-40 hover:opacity-100"><Pencil size={14} /></button>
                    <button onClick={() => remove(r)} className="text-brand-red opacity-40 hover:opacity-100"><Trash2 size={14} /></button>
                  </>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// -- Redaction settings --------------------------------

function RedactionTab({ activeTenant, canManage }) {
  const [cfg, setCfg] = useState(null);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const domainQ = activeTenant ? "?domain=" + encodeURIComponent(activeTenant.domain) : "";

  useEffect(() => {
    api.get("/api/compliance/settings" + domainQ).then(d => setCfg(d.settings.redaction)).catch(console.error);
  }, [domainQ]);

  const save = async () => {
    setBusy(true); setMsg(null);
    try {
      await api.put("/api/compliance/settings", { domain: activeTenant?.domain, redaction: cfg });
      setMsg({ ok: true, text: "Redaction settings saved — applies to new transcriptions" });
    } catch (e) { setMsg({ ok: false, text: e.message }); }
    setBusy(false);
  };

  if (!cfg) return <div className="opacity-50 text-center py-10 animate-pulse">Loading...</div>;

  const CATS = [
    { key: "card", label: "Credit/debit card numbers (Luhn-validated)" },
    { key: "cvv", label: "CVV / security codes (in context)" },
    { key: "ssn", label: "Social Security Numbers (US)" },
    { key: "email", label: "Email addresses" },
    { key: "dob", label: "Dates of birth (in context)" },
  ];

  return (
    <div className="glass-card max-w-2xl">
      <Msg msg={msg} />
      <h3 className="text-lg font-semibold mb-1">PII / PCI Transcript Redaction</h3>
      <p className="text-xs opacity-40 mb-4">Sensitive data is stripped from transcripts <strong>before storage</strong> — originals are never kept (destructive by design). Applies to new transcriptions{activeTenant ? " for " + activeTenant.domain : " (global default)"}. Audio recordings are not modified.</p>

      <label className="flex items-center gap-3 mb-4">
        <input type="checkbox" checked={!!cfg.enabled} onChange={e => setCfg({ ...cfg, enabled: e.target.checked })} disabled={!canManage} />
        <span className="text-sm font-medium">Enable redaction</span>
      </label>

      <div className="space-y-2 mb-5 pl-1">
        {CATS.map(c => (
          <label key={c.key} className={`flex items-center gap-3 text-sm ${!cfg.enabled ? "opacity-40" : ""}`}>
            <input type="checkbox" checked={!!cfg.categories?.[c.key]} disabled={!cfg.enabled || !canManage}
              onChange={e => setCfg({ ...cfg, categories: { ...cfg.categories, [c.key]: e.target.checked } })} />
            {c.label}
          </label>
        ))}
      </div>

      <div className="mb-5">
        <label className="block text-xs font-medium opacity-60 mb-1.5">Strict digit redaction — redact ANY run of N+ digits (0 = off)</label>
        <input type="number" min="0" max="30" className="glass-input w-32" value={cfg.strict_digits ?? 0}
          onChange={e => setCfg({ ...cfg, strict_digits: e.target.value })} disabled={!cfg.enabled || !canManage} />
        <p className="text-[11px] opacity-30 mt-1.5 max-w-md">Catches card numbers mangled by speech-to-text (e.g. a 16-digit card transcribed as 12 digits) that fail checksum validation. Recommended: 12. Trade-off: order/account references of that length are also redacted; at 10 or below, most phone numbers are too.</p>
      </div>

      {canManage && <button onClick={save} disabled={busy} className="btn-primary text-sm flex items-center gap-2 disabled:opacity-30"><Save size={14} /> {busy ? "Saving..." : "Save"}</button>}
    </div>
  );
}

// -- QA settings ---------------------------------------

const FALLBACK_RUBRIC = [
  { key: "greeting", label: "Greeting & Introduction", weight: 15 },
  { key: "listening", label: "Listening & Empathy", weight: 20 },
  { key: "professionalism", label: "Professionalism & Tone", weight: 15 },
  { key: "knowledge", label: "Knowledge & Accuracy", weight: 15 },
  { key: "resolution", label: "Resolution Effectiveness", weight: 25 },
  { key: "closing", label: "Call Closing", weight: 10 },
];

function QATab({ activeTenant, canManage }) {
  const [qa, setQa] = useState(null);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const domainQ = activeTenant ? "?domain=" + encodeURIComponent(activeTenant.domain) : "";

  useEffect(() => {
    api.get("/api/compliance/settings" + domainQ).then(d => {
      const q = d.settings.qa || {};
      setQa({ sampling_pct: q.sampling_pct ?? 20, rubric: (q.rubric && q.rubric.length) ? q.rubric : FALLBACK_RUBRIC });
    }).catch(console.error);
  }, [domainQ]);

  const save = async () => {
    setBusy(true); setMsg(null);
    try {
      await api.put("/api/compliance/settings", { domain: activeTenant?.domain, qa });
      setMsg({ ok: true, text: "QA settings saved" });
    } catch (e) { setMsg({ ok: false, text: e.message }); }
    setBusy(false);
  };

  if (!qa) return <div className="opacity-50 text-center py-10 animate-pulse">Loading...</div>;
  const totalWeight = qa.rubric.reduce((s, r) => s + (parseInt(r.weight) || 0), 0);

  return (
    <div className="glass-card max-w-2xl">
      <Msg msg={msg} />
      <h3 className="text-lg font-semibold mb-1">Agent QA Scorecards</h3>
      <p className="text-xs opacity-40 mb-4">AI scores a random sample of transcribed calls against your rubric (0–100 weighted). Each scored call uses one AI request — the sampling % controls token spend.{activeTenant ? " Editing settings for " + activeTenant.domain + " (overrides the global default)." : " Editing the GLOBAL default — applies to all tenants unless a tenant overrides it."}</p>

      <div className="mb-5">
        <label className="block text-xs font-medium opacity-60 mb-1.5">Auto-QA sampling percentage (0 = off)</label>
        <input type="number" min="0" max="100" className="glass-input w-32" value={qa.sampling_pct}
          onChange={e => setQa({ ...qa, sampling_pct: e.target.value })} disabled={!canManage} />
      </div>

      <h4 className="text-sm font-semibold mb-2">Rubric <span className={`text-xs font-normal ${totalWeight === 100 ? "opacity-40" : "text-brand-yellow"}`}>(weights total {totalWeight}{totalWeight !== 100 ? " — 100 recommended" : ""})</span></h4>
      <div className="space-y-2 mb-4">
        {qa.rubric.map((r, i) => (
          <div key={i} className="flex gap-2 items-center">
            <input className="glass-input flex-1 text-sm py-1.5" value={r.label}
              onChange={e => setQa({ ...qa, rubric: qa.rubric.map((x, j) => j === i ? { ...x, label: e.target.value } : x) })} disabled={!canManage} />
            <input type="number" min="1" max="100" className="glass-input w-20 text-sm py-1.5" value={r.weight}
              onChange={e => setQa({ ...qa, rubric: qa.rubric.map((x, j) => j === i ? { ...x, weight: e.target.value } : x) })} disabled={!canManage} />
            {canManage && <button onClick={() => setQa({ ...qa, rubric: qa.rubric.filter((_, j) => j !== i) })} className="text-brand-red opacity-40 hover:opacity-100"><Trash2 size={14} /></button>}
          </div>
        ))}
      </div>
      {canManage && (
        <div className="flex gap-2">
          <button onClick={() => setQa({ ...qa, rubric: [...qa.rubric, { key: "cat_" + qa.rubric.length, label: "", weight: 10 }] })} className="btn-secondary text-sm flex items-center gap-2"><Plus size={14} /> Category</button>
          <button onClick={save} disabled={busy} className="btn-primary text-sm flex items-center gap-2 disabled:opacity-30"><Save size={14} /> {busy ? "Saving..." : "Save"}</button>
        </div>
      )}
    </div>
  );
}

// -- Page ----------------------------------------------

function Tab({ active, onClick, icon: Icon, label }) {
  return (
    <button onClick={onClick} className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${active ? "bg-brand-blue/15 text-brand-blue" : "opacity-50 hover:opacity-80"}`}>
      <Icon size={15} /> {label}
    </button>
  );
}

export default function Compliance() {
  const { activeTenant, domainParam, timezone } = useTenant();
  const { user } = useAuth();
  const { toQueryParams } = useDateRange();
  const [tab, setTab] = useState("overview");
  const navigate = useNavigate();
  const canManage = ["super_admin", "admin"].includes(user?.role);
  const isSuper = user?.role === "super_admin";

  const dp = domainParam ? domainParam.slice(1) : "";
  const drp = toQueryParams();
  const q = [dp, drp].filter(Boolean).join("&");
  const qs = q ? "?" + q : "";

  return (
    <div>
      <div className="mb-2">
        <h2 className="text-2xl font-bold flex items-center gap-2"><ShieldCheck size={24} className="text-brand-blue" /> Compliance & QA</h2>
        <p className="text-sm opacity-40 mt-1">{activeTenant ? activeTenant.domain : "All Tenants"}</p>
      </div>

      <DateFilterBar />

      <div className="flex gap-2 mb-6 flex-wrap">
        <Tab active={tab === "overview"} onClick={() => setTab("overview")} icon={ShieldCheck} label="Overview" />
        <Tab active={tab === "rules"} onClick={() => setTab("rules")} icon={AlertTriangle} label="Rules" />
        {canManage && <Tab active={tab === "redaction"} onClick={() => setTab("redaction")} icon={ScanLine} label="Redaction" />}
        {canManage && <Tab active={tab === "qa"} onClick={() => setTab("qa")} icon={Award} label="QA Settings" />}
      </div>

      {tab === "overview" && <OverviewTab qs={qs} canManage={canManage} timezone={timezone} navigate={navigate} />}
      {tab === "rules" && <RulesTab activeTenant={activeTenant} canManage={canManage} isSuper={isSuper} />}
      {tab === "redaction" && canManage && <RedactionTab activeTenant={activeTenant} canManage={canManage} />}
      {tab === "qa" && canManage && <QATab activeTenant={activeTenant} canManage={canManage} />}
    </div>
  );
}
