import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

const API = '/api/setup';

export default function Setup() {
  const [step, setStep] = useState('loading'); // loading | form | complete
  const [publicIp, setPublicIp] = useState('');
  const [domain, setDomain] = useState('');
  const [email, setEmail] = useState('');
  const [dnsStatus, setDnsStatus] = useState(null); // null | checking | valid | invalid
  const [dnsError, setDnsError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [credentials, setCredentials] = useState(null);
  const [countdown, setCountdown] = useState(120);
  const [error, setError] = useState('');
  const countdownRef = useRef(null);
  const navigate = useNavigate();

  // Check if setup is required
  useEffect(() => {
    fetch(`${API}/status`)
      .then(r => {
        if (r.status === 404) {
          navigate('/login');
          return null;
        }
        return r.json();
      })
      .then(data => {
        if (!data) return;
        if (!data.setupRequired) {
          navigate('/login');
          return;
        }
        setPublicIp(data.publicIp);
        setStep('form');
      })
      .catch(() => {
        setError('Could not connect to the server. Please try again.');
        setStep('form');
      });
  }, [navigate]);

  // Countdown after completion
  useEffect(() => {
    if (step !== 'complete') return;
    countdownRef.current = setInterval(() => {
      setCountdown(c => {
        if (c <= 1) {
          clearInterval(countdownRef.current);
          if (credentials?.url) {
            window.location.href = credentials.url;
          }
          return 0;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(countdownRef.current);
  }, [step, credentials]);

  const checkDns = async () => {
    if (!domain.trim()) return;
    setDnsStatus('checking');
    setDnsError('');
    try {
      const res = await fetch(`${API}/check-dns`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: domain.trim() }),
      });
      const data = await res.json();
      if (data.valid) {
        setDnsStatus('valid');
      } else {
        setDnsStatus('invalid');
        setDnsError(data.error || 'DNS check failed');
      }
    } catch {
      setDnsStatus('invalid');
      setDnsError('Could not verify DNS. Check your connection.');
    }
  };

  const handleComplete = async () => {
    if (!domain.trim() || !email.trim()) return;
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch(`${API}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain: domain.trim(), email: email.trim() }),
      });
      const data = await res.json();
      if (data.success) {
        setCredentials(data.credentials);
        setStep('complete');
      } else {
        setError(data.error || 'Setup failed. Please try again.');
      }
    } catch {
      setError('Connection error. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  // Reset DNS status when domain changes
  useEffect(() => {
    setDnsStatus(null);
    setDnsError('');
  }, [domain]);

  const canComplete = domain.trim() && email.trim() && dnsStatus === 'valid';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {/* Logo / Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-600 mb-4">
            <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-white">Vodia Analytics</h1>
          <p className="text-slate-400 mt-1">Initial Setup</p>
        </div>

        {/* Card */}
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl shadow-2xl backdrop-blur-sm">
          {step === 'loading' && (
            <div className="p-8 text-center">
              <div className="animate-spin w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full mx-auto" />
              <p className="text-slate-400 mt-4">Checking setup status...</p>
            </div>
          )}

          {step === 'form' && (
            <div className="p-8">
              <h2 className="text-lg font-semibold text-white mb-1">Configure Your Instance</h2>
              <p className="text-slate-400 text-sm mb-6">
                Point a domain to this server{publicIp ? ` (${publicIp})` : ''} and enter your admin details.
              </p>

              {error && (
                <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
                  {error}
                </div>
              )}

              {/* Domain */}
              <div className="mb-5">
                <label className="block text-sm font-medium text-slate-300 mb-1.5">
                  Domain Name
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={domain}
                    onChange={e => setDomain(e.target.value)}
                    placeholder="analytics.yourcompany.com"
                    className="flex-1 px-3 py-2.5 bg-slate-900/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <button
                    onClick={checkDns}
                    disabled={!domain.trim() || dnsStatus === 'checking'}
                    className="px-4 py-2.5 bg-slate-700 hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap"
                  >
                    {dnsStatus === 'checking' ? (
                      <span className="flex items-center gap-2">
                        <span className="animate-spin w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full" />
                        Checking
                      </span>
                    ) : 'Verify DNS'}
                  </button>
                </div>

                {/* DNS feedback */}
                {dnsStatus === 'valid' && (
                  <p className="mt-2 text-sm text-emerald-400 flex items-center gap-1.5">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                    DNS verified — domain points to this server
                  </p>
                )}
                {dnsStatus === 'invalid' && (
                  <p className="mt-2 text-sm text-amber-400 flex items-center gap-1.5">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01M12 2a10 10 0 100 20 10 10 0 000-20z" />
                    </svg>
                    {dnsError}
                  </p>
                )}

                {publicIp && dnsStatus !== 'valid' && dnsStatus !== 'checking' && (
                  <p className="mt-2 text-xs text-slate-500">
                    Create a DNS A record pointing to <span className="font-mono text-slate-400">{publicIp}</span>
                  </p>
                )}
              </div>

              {/* Email */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-300 mb-1.5">
                  Admin Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="you@yourcompany.com"
                  className="w-full px-3 py-2.5 bg-slate-900/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <p className="mt-1.5 text-xs text-slate-500">This will be your login username</p>
              </div>

              {/* Submit */}
              <button
                onClick={handleComplete}
                disabled={!canComplete || submitting}
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 disabled:text-slate-500 disabled:cursor-not-allowed text-white font-semibold rounded-lg transition-colors text-sm"
              >
                {submitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                    Setting up...
                  </span>
                ) : 'Complete Setup'}
              </button>
            </div>
          )}

          {step === 'complete' && credentials && (
            <div className="p-8">
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-emerald-500/10 mb-3">
                  <svg className="w-6 h-6 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h2 className="text-lg font-semibold text-white">Setup Complete</h2>
                <p className="text-slate-400 text-sm mt-1">Save your credentials below — the password cannot be recovered.</p>
              </div>

              {/* Credentials box */}
              <div className="bg-slate-900/70 border border-slate-600 rounded-xl p-5 mb-6 font-mono text-sm space-y-3">
                <div>
                  <span className="text-slate-500">URL</span>
                  <p className="text-blue-400">{credentials.url}</p>
                </div>
                <div>
                  <span className="text-slate-500">Email</span>
                  <p className="text-white">{credentials.email}</p>
                </div>
                <div>
                  <span className="text-slate-500">Password</span>
                  <p className="text-amber-400">{credentials.password}</p>
                </div>
              </div>

              {/* Restart notice */}
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 text-center">
                <p className="text-blue-300 text-sm">
                  The system is restarting with your new domain.
                </p>
                <p className="text-blue-200 text-sm font-semibold mt-1">
                  Redirecting in {countdown} seconds...
                </p>
                <p className="text-slate-500 text-xs mt-2">
                  Bookmark <span className="text-blue-400">{credentials.url}</span> and log in after restart.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <p className="text-center text-slate-600 text-xs mt-6">
          Vodia Analytics — Powered by Vodia Networks
        </p>
      </div>
    </div>
  );
}
