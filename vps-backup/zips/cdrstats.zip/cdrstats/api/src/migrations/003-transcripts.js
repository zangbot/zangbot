export default {
  version: 3,
  name: "transcripts-and-ai",
  async up(db) {
    const colls = (await db.listCollections().toArray()).map(c => c.name);
    if (!colls.includes("transcripts")) await db.createCollection("transcripts");

    const ensure = async (col, spec, opts) => {
      const existing = (await db.collection(col).indexes()).map(i => i.name);
      if (!existing.includes(opts.name)) await db.collection(col).createIndex(spec, opts);
    };

    await ensure("transcripts", { callid: 1, system: 1, domain: 1 }, { unique: true, name: "idx_transcript_call" });
    await ensure("transcripts", { domain: 1, created_at: -1 }, { name: "idx_transcript_domain" });
    await ensure("transcripts", { "summary.sentiment": 1 }, { name: "idx_transcript_sentiment", sparse: true });
    await ensure("transcripts", { "summary.topics": 1 }, { name: "idx_topics", sparse: true });
    await ensure("transcripts", { "summary.resolution": 1 }, { name: "idx_resolution", sparse: true });

    // Text index for transcript search
    await ensure("transcripts",
      { full_text: "text", channel_0_text: "text", channel_1_text: "text" },
      { name: "idx_transcript_text", default_language: "english" }
    );

    // AI fields on calls
    await db.collection("calls").updateMany(
      { has_transcript: { $exists: false } },
      { $set: { has_transcript: false, has_summary: false, sentiment: null } }
    );

    await ensure("calls", { sentiment: 1, start: -1 }, { name: "idx_sentiment_start", sparse: true });
  },
};
