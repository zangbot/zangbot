/**
 * Migration 006: Backfill transfer_type from logs + trunk accounts
 */
export default {
  version: 6,
  name: "transfer-trunk-accounts",
  async up(db) {
    // Fix transfer_type using logs
    const cursor = db.collection("calls").find({
      transfer_type: "none",
      "logs.m": { $regex: /transfer/i },
    });

    let fixedTransfers = 0;
    while (await cursor.hasNext()) {
      const call = await cursor.next();
      const logs = call.logs || [];
      let newType = "none";
      for (const log of logs) {
        const msg = (log.m || "").toLowerCase();
        if (msg.includes("attended transfer")) { newType = "attended"; break; }
        if (msg.includes("blind transfer")) { newType = "blind"; break; }
      }
      if (newType !== "none") {
        await db.collection("calls").updateOne(
          { _id: call._id },
          { $set: { transfer_type: newType } }
        );
        fixedTransfers++;
      }
    }
    if (fixedTransfers > 0) console.log(`  Fixed transfer_type on ${fixedTransfers} calls`);

    // Add trunk remote parties to accounts
    const trunkCursor = db.collection("calls").find({
      "trunklegs.remoteparty": { $exists: true },
    });

    let fixedAccounts = 0;
    while (await trunkCursor.hasNext()) {
      const call = await trunkCursor.next();
      const accounts = call.accounts || [];
      const seen = new Set(accounts.map(a => a.type + ":" + a.number));
      let changed = false;

      for (const leg of (call.trunklegs || [])) {
        if (leg.remoteparty) {
          const key = "trunk:" + leg.remoteparty;
          if (!seen.has(key)) {
            seen.add(key);
            let remoteName = leg.remoteparty;
            const paiMatch = (leg.packets || "").match(/P-Asserted-Identity:\s*"([^"]+)"/);
            if (paiMatch) remoteName = paiMatch[1];
            accounts.push({ number: leg.remoteparty, name: remoteName, type: "trunk" });
            changed = true;
          }
        }
      }

      if (changed) {
        const accounts_search = accounts.map(a => [a.name, a.number].join(" ")).join(" ");
        await db.collection("calls").updateOne(
          { _id: call._id },
          { $set: { accounts, accounts_search } }
        );
        fixedAccounts++;
      }
    }
    if (fixedAccounts > 0) console.log(`  Added trunk accounts to ${fixedAccounts} calls`);
  },
};
