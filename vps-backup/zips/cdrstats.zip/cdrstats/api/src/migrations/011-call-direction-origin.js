/**
 * Migration 002: Add call_direction_origin field
 *
 * Backfills call_direction_origin on all existing docs by splitting
 * call_direction on "/" and taking the first part.
 * Creates index on call_direction_origin for query performance.
 */
export default {
  version: 11,
  name: "call-direction-origin",

  async up(db) {
    const calls = db.collection("calls");

    // Backfill: derive origin from existing call_direction
    // "inbound" → "inbound", "inbound/outbound" → "inbound", etc.
    // Only touches docs missing the field (idempotent)
    const result = await calls.updateMany(
      { call_direction_origin: { $exists: false } },
      [
        {
          $set: {
            call_direction_origin: {
              $arrayElemAt: [{ $split: ["$call_direction", "/"] }, 0],
            },
          },
        },
      ]
    );
    console.log(`  Backfilled call_direction_origin on ${result.modifiedCount} docs`);

    // Create index (matches the pattern from 001)
    const existing = (await calls.indexes()).map(i => i.name);
    if (!existing.includes("idx_domain_direction_origin")) {
      await calls.createIndex(
        { domain: 1, call_direction_origin: 1, is_answered: 1, start: -1 },
        { name: "idx_domain_direction_origin" }
      );
      console.log("  Created idx_domain_direction_origin index");
    }
  },
};
