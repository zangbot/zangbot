/**
 * Migration 009: Add storage_backend field to existing recordings
 * All existing recordings are MinIO-based, so backfill with "minio"
 */
export default {
  version: 9,
  name: "009-storage-backend",
  async up(db) {
    const result = await db.collection("recordings").updateMany(
      { storage_backend: { $exists: false } },
      { $set: { storage_backend: "minio" } }
    );
    console.log(`  Migration 009: Set storage_backend="minio" on ${result.modifiedCount} recordings`);
  },
};
