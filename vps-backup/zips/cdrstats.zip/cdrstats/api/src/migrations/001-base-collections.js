/**
 * Migration 001: Base collections, indexes, and schema
 * Covers: calls, recordings, tenants, users, api_keys, country_prefixes
 */
export default {
  version: 1,
  name: "base-collections",

  async up(db) {
    // ── Calls ───────────────────────────────────────
    const colls = (await db.listCollections().toArray()).map(c => c.name);

    if (!colls.includes("calls")) await db.createCollection("calls");

    const callIndexes = (await db.collection("calls").indexes()).map(i => i.name);
    const ensure = async (col, spec, opts) => {
      const existing = (await db.collection(col).indexes()).map(i => i.name);
      if (!existing.includes(opts.name)) {
        await db.collection(col).createIndex(spec, opts);
      }
    };

    await ensure("calls", { system: 1, domain: 1, start: -1 }, { name: "idx_system_domain_start" });
    await ensure("calls", { domain: 1, start: -1 }, { name: "idx_domain_start" });
    await ensure("calls", { system: 1, domain: 1, callid: 1 }, { unique: true, name: "idx_dedup" });
    await ensure("calls", { answering_queue: 1, start: -1 }, { name: "idx_queue_start" });
    await ensure("calls", { from_number_e164: 1 }, { name: "idx_from_e164" });
    await ensure("calls", { to_number_e164: 1 }, { name: "idx_to_e164" });
    await ensure("calls", { domain: 1, call_direction: 1, is_answered: 1, start: -1 }, { name: "idx_domain_direction_answered" });
    await ensure("calls", { domain: 1, answering_extension: 1, start: -1 }, { name: "idx_domain_agent_start" });

    // ── Recordings ──────────────────────────────────
    if (!colls.includes("recordings")) await db.createCollection("recordings");
    await ensure("recordings", { system: 1, domain: 1, callid: 1 }, { name: "idx_rec_call" });
    await ensure("recordings", { domain: 1, created_at: -1 }, { name: "idx_rec_domain_date" });
    await ensure("recordings", { upload_status: 1 }, { name: "idx_rec_upload_status" });

    // ── Tenants ─────────────────────────────────────
    if (!colls.includes("tenants")) await db.createCollection("tenants");
    await ensure("tenants", { system: 1, domain: 1 }, { unique: true, name: "idx_tenant_unique" });
    await ensure("tenants", { api_key_hash: 1 }, { name: "idx_tenant_apikey" });

    // ── Users ───────────────────────────────────────
    if (!colls.includes("users")) await db.createCollection("users");
    await ensure("users", { email: 1 }, { unique: true, name: "idx_user_email" });

    // ── API Keys ────────────────────────────────────
    if (!colls.includes("api_keys")) await db.createCollection("api_keys");
    await ensure("api_keys", { key_hash: 1 }, { unique: true, name: "idx_apikey_hash" });
    await ensure("api_keys", { system: 1 }, { name: "idx_apikey_system" });

    // ── Country Prefixes ────────────────────────────
    if (!colls.includes("country_prefixes")) await db.createCollection("country_prefixes");
    await ensure("country_prefixes", { prefix: 1 }, { unique: true, name: "idx_prefix" });
    await ensure("country_prefixes", { country_code: 1 }, { name: "idx_country_code" });
  },
};
