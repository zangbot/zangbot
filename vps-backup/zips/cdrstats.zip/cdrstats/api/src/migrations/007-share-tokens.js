/**
 * Create share_tokens collection with TTL and token index.
 */
export async function up(db) {
  // Unique index on token for fast lookups
  await db.collection("share_tokens").createIndex(
    { token: 1 },
    { unique: true, name: "idx_share_token" }
  );

  // TTL index — MongoDB auto-deletes expired docs
  await db.collection("share_tokens").createIndex(
    { expires_at: 1 },
    { expireAfterSeconds: 0, name: "idx_share_ttl" }
  );

  // Index for listing by creator
  await db.collection("share_tokens").createIndex(
    { created_by: 1, created_at: -1 },
    { name: "idx_share_creator" }
  );
}
