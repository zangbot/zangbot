/**
 * Migration 020 - Grade of Service + call metadata
 *
 * Indexes only. The answer_seconds backfill is deliberately NOT run here:
 * runMigrations() executes on API startup and throws on failure, so a long
 * updateMany over the full calls collection could stop the API from booting.
 * Run scripts/backfill-answer-seconds.js manually instead.
 */

export default {
  async up(db) {
    const ensure = async (col, spec, opts) => {
      const existing = (await db.collection(col).indexes()).map(i => i.name);
      if (!existing.includes(opts.name)) {
        await db.collection(col).createIndex(spec, opts);
      }
    };

    await ensure("calls", { answer_seconds: 1 }, { name: "calls_answer_seconds", sparse: true });
    await ensure("calls", { domain: 1, answering_queue: 1, is_answered: 1, answer_seconds: 1 }, { name: "calls_gos_queue" });
    await ensure("calls", { cmc: 1 }, { name: "calls_cmc", sparse: true });
    await ensure("calls", { category: 1 }, { name: "calls_category", sparse: true });
  },
};
