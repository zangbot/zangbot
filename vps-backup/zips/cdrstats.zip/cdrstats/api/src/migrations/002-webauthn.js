export default {
  version: 2,
  name: "webauthn-credentials",
  async up(db) {
    const colls = (await db.listCollections().toArray()).map(c => c.name);
    if (!colls.includes("webauthn_credentials")) await db.createCollection("webauthn_credentials");

    const ensure = async (col, spec, opts) => {
      const existing = (await db.collection(col).indexes()).map(i => i.name);
      if (!existing.includes(opts.name)) await db.collection(col).createIndex(spec, opts);
    };

    await ensure("webauthn_credentials", { user_id: 1 }, { name: "idx_wac_user" });
    await ensure("webauthn_credentials", { credential_id: 1 }, { unique: true, name: "idx_wac_cred" });
  },
};
