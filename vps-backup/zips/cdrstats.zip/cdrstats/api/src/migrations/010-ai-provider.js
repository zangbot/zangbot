/**
 * Migration 010: Migrate OpenAI settings to ai_provider format
 * Preserves existing encrypted API key and model selection
 */
export default {
  version: 10,
  name: "010-ai-provider",
  async up(db) {
    // Check if legacy openai settings exist
    const legacy = await db.collection("settings").findOne({ key: "openai" });
    const existing = await db.collection("settings").findOne({ key: "ai_provider" });

    if (legacy?.value && !existing) {
      const newValue = {
        provider: "openai",
        model: legacy.value.model || "gpt-4o-mini",
        api_key_encrypted: legacy.value.api_key_encrypted || null,
        endpoint: "",
        migrated_from: "openai",
        updated_at: new Date(),
      };

      await db.collection("settings").insertOne({
        key: "ai_provider",
        value: newValue,
      });

      console.log("  Migration 010: Migrated OpenAI settings to ai_provider format");
    } else if (existing) {
      console.log("  Migration 010: ai_provider already exists — skipping");
    } else {
      console.log("  Migration 010: No OpenAI settings to migrate");
    }
  },
};
