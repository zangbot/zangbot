export default {
  version: 4,
  name: "settings-and-retention",
  async up(db) {
    const colls = (await db.listCollections().toArray()).map(c => c.name);
    if (!colls.includes("settings")) await db.createCollection("settings");

    // Seed IP whitelist from env if not exists
    const existing = await db.collection("settings").findOne({ key: "ip_whitelist" });
    if (!existing) {
      const raw = process.env.CDR_WHITELIST_IPS || "";
      const ips = raw.split(",").map(s => s.trim()).filter(Boolean);
      await db.collection("settings").insertOne({
        key: "ip_whitelist",
        ips,
        updated_at: new Date(),
        updated_by: "system",
      });
    }

    // Retention + AI fields on tenants
    await db.collection("tenants").updateMany(
      { data_retention_days: { $exists: false } },
      { $set: { data_retention_days: 0, ai_auto_summarize: false } }
    );

    // Password fields on users
    await db.collection("users").updateMany(
      { password_expires_at: { $exists: false } },
      { $set: { password_expires_at: null, must_reset_password: false, passkey_count: 0 } }
    );
  },
};
