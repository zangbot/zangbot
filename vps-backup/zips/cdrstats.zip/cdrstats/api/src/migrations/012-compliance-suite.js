/**
 * Migration 012 — Compliance Suite
 * Indexes for compliance rules/settings, call compliance/QA scores,
 * and briefing schedules.
 */

export default {
  async up(db) {
    await db.collection("compliance_rules").createIndex({ system: 1, domain: 1 }, { name: "rules_tenant" });
    await db.collection("compliance_rules").createIndex({ scope: 1 }, { name: "rules_scope" });
    await db.collection("compliance_settings").createIndex({ system: 1, domain: 1 }, { name: "csettings_tenant" });
    await db.collection("calls").createIndex({ compliance_score: 1 }, { name: "calls_compliance_score", sparse: true });
    await db.collection("calls").createIndex({ compliance_passed: 1, start: -1 }, { name: "calls_compliance_passed", sparse: true });
    await db.collection("calls").createIndex({ qa_score: 1 }, { name: "calls_qa_score", sparse: true });
    await db.collection("briefing_schedules").createIndex({ enabled: 1, next_run_at: 1 }, { name: "sched_due" });
  },
};
