/**
 * Migration 005: Backfill accounts array on existing calls
 * and add index for accounts_search.
 */
export default {
  version: 5,
  name: "accounts-field",
  async up(db) {
    const ensure = async (col, spec, opts) => {
      const existing = (await db.collection(col).indexes()).map(i => i.name);
      if (!existing.includes(opts.name)) await db.collection(col).createIndex(spec, opts);
    };

    // Index for accounts search
    await ensure("calls", { accounts_search: 1 }, { name: "idx_accounts_search", sparse: true });

    // Backfill accounts from states on existing calls
    const cursor = db.collection("calls").find(
      { accounts: { $exists: false }, states: { $exists: true, $ne: [] } }
    );

    let updated = 0;
    while (await cursor.hasNext()) {
      const call = await cursor.next();
      const states = call.states || [];
      const seen = new Set();
      const accounts = [];

      for (const state of states) {
        const type = (state.type || "").toLowerCase();
        if (state.account) {
          const key = type + ":" + state.account;
          if (!seen.has(key)) {
            seen.add(key);
            accounts.push({ number: state.account, name: state["account-name"] || state.account, type });
          }
        }
        if (state.extension) {
          const key = "ext:" + state.extension;
          if (!seen.has(key)) {
            seen.add(key);
            accounts.push({ number: state.extension, name: state["extension-name"] || state.extension, type: "extension" });
          }
        }
      }

      const accounts_search = accounts.map(a => [a.name, a.number].join(" ")).join(" ");

      await db.collection("calls").updateOne(
        { _id: call._id },
        { $set: { accounts, accounts_search } }
      );
      updated++;
    }

    if (updated > 0) {
      console.log(`  Backfilled accounts on ${updated} calls`);
    }
  },
};
