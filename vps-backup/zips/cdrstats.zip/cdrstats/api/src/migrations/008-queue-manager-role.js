export async function up(db) {
  await db.collection("users").updateMany(
    { queues: { $exists: false } },
    { $set: { queues: [] } }
  );
  await db.collection("users").createIndex(
    { role: 1, queues: 1 },
    { name: "idx_users_role_queues" }
  );
}
