/**
 * Migration 21: hot/cold split -- call_details, retention TTLs, indexes
 *
 * Measured on a 959,038-document production collection:
 *   avg doc 33,038 bytes; extensionlegs+trunklegs+logs = 96% of that.
 *   Collection 24.7 GB against a 5.3 GB WiredTiger cache.
 *   A query WITH a working index took 5,969ms for 32,495 documents,
 *   because 32,495 x 33 KB = 1.07 GB had to come off disk.
 *
 * Splitting the cold payload out takes `calls` to ~1.3 GB, which fits
 * in cache several times over.
 *
 * Indexes added to `calls`:
 *   idx_callid      -- /api/calls/:id falls back to a { callid } lookup
 *                      for every non-ObjectId callid. Was COLLSCAN,
 *                      47,303ms -> 0ms.
 *   idx_start       -- every dashboard aggregation matches on `start`
 *                      alone. No existing index had start as its leading
 *                      field, so all 8 tiles collection-scanned.
 *   idx_has_trunk_leg
 *
 * TTL: expires_at + expireAfterSeconds 0. Documents with NO expires_at
 * field are never expired, which is how "keep forever" tenants work.
 *
 * Idempotent -- safe where indexes were already built by hand.
 */
export default {
  version: 21,
  name: "hot-cold-split",

  async up(db) {
    const ensure = async (col, spec, opts) => {
      const existing = (await db.collection(col).indexes()).map(i => i.name);
      if (!existing.includes(opts.name)) {
        await db.collection(col).createIndex(spec, opts);
      }
    };

    const colls = (await db.listCollections().toArray()).map(c => c.name);
    if (!colls.includes("call_details")) await db.createCollection("call_details");

    await ensure("call_details", { system: 1, domain: 1, callid: 1 },
      { unique: true, name: "idx_details_call" });
    await ensure("call_details", { callid: 1 }, { name: "idx_details_callid" });
    await ensure("call_details", { expires_at: 1 },
      { expireAfterSeconds: 0, name: "idx_details_ttl" });

    await ensure("calls", { callid: 1 }, { name: "idx_callid" });
    await ensure("calls", { start: -1 }, { name: "idx_start" });
    await ensure("calls", { has_trunk_leg: 1, start: -1 },
      { name: "idx_has_trunk_leg", sparse: true });
    await ensure("calls", { expires_at: 1 },
      { expireAfterSeconds: 0, name: "idx_calls_ttl" });
  },
};
