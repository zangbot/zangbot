/**
 * Shared constants and field mappings
 */

// Valid call directions
export const CALL_DIRECTIONS = ["inbound", "outbound", "internal"];

// Valid routing methods (derived from states[].type)
export const ROUTING_METHODS = [
  "acd",
  "hunt",
  "attendant",
  "mailbox",
  "conference",
  "ivrnode",
  "orbit",
  "direct",
];

// Transfer types
export const TRANSFER_TYPES = ["attended", "blind", "none"];

// Abandon reason code mapping
export const ABANDON_REASONS = {
  hw: "Hung up while waiting",
  hr: "Hung up while ringing",
  rw: "Wait timeout",
  rr: "Ring timeout",
};

// Trunkleg direction mapping
export const TRUNK_DIRECTIONS = {
  I: "inbound",
  O: "outbound",
};

// Required top-level CDR fields
export const REQUIRED_CDR_FIELDS = ["system", "domain", "callid"];
