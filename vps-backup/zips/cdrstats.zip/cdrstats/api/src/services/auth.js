/**
 * API Key Authentication
 *
 * Vodia sends webhooks to: webcdr http://API_KEY@your-server/cdr
 * The API key arrives as HTTP Basic Auth username (no password).
 * Keys are stored hashed (SHA-256) in the api_keys collection.
 * Resolved keys are cached in Redis (TTL 5 min).
 */

import { createHash } from "crypto";

const CACHE_TTL = 300;
const CACHE_PREFIX = "apikey:";

export function hashApiKey(key) {
  return createHash("sha256").update(key).digest("hex");
}

export function extractApiKey(request) {
  const authHeader = request.headers.authorization;
  if (authHeader) {
    if (authHeader.startsWith("Basic ")) {
      try {
        const decoded = Buffer.from(authHeader.slice(6), "base64").toString();
        const key = decoded.split(":")[0];
        if (key) return key;
      } catch {
        // Malformed base64
      }
    }

    if (authHeader.startsWith("Bearer ")) {
      return authHeader.slice(7).trim() || null;
    }
  }

  if (request.query?.api_key) {
    return request.query.api_key;
  }

  return null;
}

export async function validateApiKey(key, db, redis) {
  if (!key) return null;

  const keyHash = hashApiKey(key);
  const cacheKey = CACHE_PREFIX + keyHash;

  try {
    const cached = await redis.get(cacheKey);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (parsed === null) return null;
      return parsed;
    }
  } catch {
    // Redis failure — fall through to DB
  }

  const apiKey = await db.collection("api_keys").findOne({
    key_hash: keyHash,
    active: { $ne: false },
  });

  if (!apiKey) {
    try {
      await redis.set(cacheKey, "null", "EX", 60);
    } catch { /* ignore */ }
    return null;
  }

  const result = {
    system: apiKey.system,
    label: apiKey.label || apiKey.system,
    tenants: apiKey.tenants || [],
  };

  try {
    await redis.set(cacheKey, JSON.stringify(result), "EX", CACHE_TTL);
  } catch { /* ignore */ }

  return result;
}
