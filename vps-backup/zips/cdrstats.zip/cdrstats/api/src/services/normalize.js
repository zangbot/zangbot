/**
 * Number Normalisation — libphonenumber
 * Parses numbers, detects country, E.164 format, number type.
 * Falls back gracefully — never breaks ingest if parsing fails.
 */

import libphonenumber from "google-libphonenumber";

const phoneUtil = libphonenumber.PhoneNumberUtil.getInstance();
const PNF = libphonenumber.PhoneNumberFormat;
const PNT = libphonenumber.PhoneNumberType;

const TYPE_MAP = {
  [PNT.MOBILE]: "MOBILE",
  [PNT.FIXED_LINE]: "FIXED_LINE",
  [PNT.FIXED_LINE_OR_MOBILE]: "FIXED_LINE_OR_MOBILE",
  [PNT.TOLL_FREE]: "TOLL_FREE",
  [PNT.PREMIUM_RATE]: "PREMIUM_RATE",
  [PNT.SHARED_COST]: "SHARED_COST",
  [PNT.VOIP]: "VOIP",
  [PNT.PERSONAL_NUMBER]: "PERSONAL_NUMBER",
  [PNT.PAGER]: "PAGER",
  [PNT.UAN]: "UAN",
  [PNT.VOICEMAIL]: "VOICEMAIL",
  [PNT.SHORT_CODE]: "SHORT_CODE",
};

// Country code to flag emoji
function countryToFlag(cc) {
  if (!cc || cc.length !== 2) return "";
  return String.fromCodePoint(...[...cc.toUpperCase()].map(c => 0x1F1E6 + c.charCodeAt(0) - 65));
}

export const DEFAULT_CONFIG = {
  default_country: "AU",
  trunk_prefix: "0",
  international_prefix: "0011",
  internal_ranges: [{ start: 100, end: 99999 }],
  special_numbers: [],
  show_country_flags: true,
};

/**
 * Strip international dialing prefix from a number.
 * e.g. "001144207946xxxx" with prefix "0011" → "+44207946xxxx"
 */
function stripIntlPrefix(number, prefix) {
  if (!prefix || !number) return number;
  // Handle common prefixes: 00, 011, 0011
  const prefixes = [prefix];
  if (!prefixes.includes("00")) prefixes.push("00");
  if (!prefixes.includes("011")) prefixes.push("011");
  
  for (const p of prefixes) {
    if (number.startsWith(p) && number.length > p.length + 4) {
      return "+" + number.slice(p.length);
    }
  }
  return number;
}

/**
 * Try to parse a number with libphonenumber.
 * Returns { e164, country, type, flag } or null on failure.
 */
function tryParse(number, defaultCountry) {
  try {
    const parsed = phoneUtil.parse(number, defaultCountry || undefined);
    if (!phoneUtil.isValidNumber(parsed) && !phoneUtil.isPossibleNumber(parsed)) {
      return null;
    }
    
    const regionCode = phoneUtil.getRegionCodeForNumber(parsed);
    const numberType = phoneUtil.getNumberType(parsed);
    
    return {
      e164: phoneUtil.format(parsed, PNF.E164),
      country: regionCode || null,
      type: TYPE_MAP[numberType] || "UNKNOWN",
      flag: countryToFlag(regionCode),
    };
  } catch {
    return null;
  }
}

export function normalizeNumber(rawNumber, config = DEFAULT_CONFIG) {
  const result = {
    raw: rawNumber || "",
    e164: null,
    type: "UNKNOWN",
    country: null,
    country_flag: "",
    is_internal: false,
    special_label: null,
  };

  if (!rawNumber || typeof rawNumber !== "string") return result;

  const number = rawNumber.trim();
  if (!number) return result;

  // 1. Check internal ranges
  const clean = number.replace(/\D/g, "");
  const num = parseInt(clean, 10);
  if (!isNaN(num)) {
    for (const range of (config.internal_ranges || [])) {
      if (num >= range.start && num <= range.end) {
        result.is_internal = true;
        result.type = "INTERNAL";
        return result;
      }
    }
  }

  // 2. Check special numbers
  for (const special of (config.special_numbers || [])) {
    if (number === special.number || clean === special.number) {
      result.special_label = special.label || special.number;
      result.type = "SPECIAL";
      return result;
    }
  }

  const defaultCountry = config.default_country || "AU";
  const intlPrefix = config.international_prefix || "0011";

  // 3. Number already has + prefix — parse directly (no hint needed)
  if (number.startsWith("+")) {
    const parsed = tryParse(number, null);
    if (parsed) {
      result.e164 = parsed.e164;
      result.country = parsed.country;
      result.country_flag = parsed.flag;
      result.type = parsed.type;
      return result;
    }
  }

  // 4. Strip international prefix and try
  const stripped = stripIntlPrefix(clean, intlPrefix);
  if (stripped !== clean && stripped.startsWith("+")) {
    const parsed = tryParse(stripped, null);
    if (parsed) {
      result.e164 = parsed.e164;
      result.country = parsed.country;
      result.country_flag = parsed.flag;
      result.type = parsed.type;
      return result;
    }
  }

  // 5. Try with default country hint (handles local format like 0433337285)
  const parsed = tryParse(number, defaultCountry);
  if (parsed) {
    result.e164 = parsed.e164;
    result.country = parsed.country;
    result.country_flag = parsed.flag;
    result.type = parsed.type;
    return result;
  }

  // 6. Try with + prefix added (in case it's missing)
  if (!number.startsWith("+") && clean.length >= 7) {
    const withPlus = tryParse("+" + clean, null);
    if (withPlus) {
      result.e164 = withPlus.e164;
      result.country = withPlus.country;
      result.country_flag = withPlus.flag;
      result.type = withPlus.type;
      return result;
    }
  }

  // 7. Nothing worked — return raw with UNKNOWN
  result.raw = number;
  return result;
}
