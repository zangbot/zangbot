/**
 * Database Migration Runner
 *
 * Runs numbered migrations on API startup.
 * Each migration runs exactly once — tracked in _migrations collection.
 *
 * Usage: await runMigrations(db, logger);
 */

import { readdirSync } from "fs";
import { pathToFileURL } from "url";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const MIGRATIONS_DIR = join(__dirname, "..", "migrations");

export async function runMigrations(db, logger) {
  // Ensure _migrations collection exists
  const collections = await db.listCollections({ name: "_migrations" }).toArray();
  if (collections.length === 0) {
    await db.createCollection("_migrations");
  }

  // Load all migration files
  let files;
  try {
    files = readdirSync(MIGRATIONS_DIR)
      .filter(f => f.endsWith(".js") && /^\d{3}-/.test(f))
      .sort();
  } catch {
    logger.info("No migrations directory found — skipping");
    return;
  }

  if (files.length === 0) {
    logger.info("No migration files found");
    return;
  }

  // Get already-applied migrations
  const applied = await db.collection("_migrations")
    .find({}, { projection: { version: 1 } })
    .toArray();
  const appliedVersions = new Set(applied.map(m => m.version));

  let ranCount = 0;

  for (const file of files) {
    const version = parseInt(file.split("-")[0]);
    const name = file.replace(/^\d{3}-/, "").replace(/\.js$/, "");

    if (appliedVersions.has(version)) {
      continue; // Already applied
    }

    logger.info({ version, name, file }, "Running migration");

    try {
      const mod = await import(pathToFileURL(join(MIGRATIONS_DIR, file)).href);
      const migration = mod.default || mod;

      if (typeof migration.up !== "function") {
        logger.error({ file }, "Migration missing up() function — skipping");
        continue;
      }

      await migration.up(db);

      // Mark as applied
      await db.collection("_migrations").insertOne({
        version,
        name,
        file,
        applied_at: new Date(),
      });

      logger.info({ version, name }, "Migration applied successfully");
      ranCount++;

    } catch (err) {
      logger.error({ version, name, err: err.message }, "Migration FAILED");
      throw new Error(`Migration ${version}-${name} failed: ${err.message}`);
    }
  }

  if (ranCount > 0) {
    logger.info({ total: ranCount }, "Migrations complete");
  } else {
    logger.info("Database up to date — no new migrations");
  }
}
