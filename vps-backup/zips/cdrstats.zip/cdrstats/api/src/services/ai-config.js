/**
 * AI Config Service — Backward Compatible Wrapper
 * Delegates to ai-provider.js for multi-provider support
 */
import { getAIKey, getAIModel, getAIConfig } from "./ai-provider.js";

export { getAIKey as getOpenAIKey, getAIModel as getOpenAIModel, getAIConfig };
