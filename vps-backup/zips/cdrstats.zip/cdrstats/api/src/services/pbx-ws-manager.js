/**
 * PBX WebSocket Manager — per-domain sockets edition
 *
 * One connection object per PBX (per whitelisted IP), holding one WebSocket
 * PER TENANT DOMAIN. Sockets are lazy: a domain's socket is only opened while
 * a frontend client is actually watching that domain, and is closed (after a
 * grace period) when the last client leaves.
 *
 * Why per-domain: a Vodia user-scoped session only receives domain-calls /
 * wallboard / blf events for its OWN domain. A single socket authenticated as
 * an agent in domain A never sees call events for domain B, which silently
 * broke Tenant Calls on multi-domain whitelist entries.
 *
 * Per-domain identity: a queue agent extension if the domain has one (needed
 * for wallboard events), otherwise the domain admin (domain-calls still
 * arrives for admin).
 *
 * Liveness: quiet domains can legitimately go hours with zero messages, so
 * silence is NEVER treated as failure. The 30s heartbeat sends
 * avoid-disconnect + a ws ping and checks transport readyState only.
 *
 * Architecture:
 *   PBX (1 WS per watched domain) → Manager → Frontend clients (per domain)
 */

import WebSocket from "ws";
import https from "https";
import crypto from "crypto";

// ── AES-256-GCM decrypt (same as whitelist.js) ──
function getEncryptionKey() {
  const KEY_ENV = process.env.SMTP_ENCRYPTION_KEY || process.env.JWT_SECRET;
  return crypto.createHash("sha256").update(KEY_ENV).digest();
}

function decrypt(encrypted) {
  try {
    if (!encrypted) return null;
    const key = getEncryptionKey();
    const [ivHex, tagHex, data] = encrypted.split(":");
    if (!ivHex || !tagHex || !data) return null;
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(ivHex, "hex"));
    decipher.setAuthTag(Buffer.from(tagHex, "hex"));
    let dec = decipher.update(data, "hex", "utf8");
    dec += decipher.final("utf8");
    return dec;
  } catch { return null; }
}

// ── HTTPS request helper ──
function pbxRequest(hostname, port, path, method, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const postData = body ? JSON.stringify(body) : null;
    const opts = {
      hostname, port: port || 443, path, method,
      headers: {
        "Content-Type": "application/json",
        ...(postData && { "Content-Length": Buffer.byteLength(postData) }),
        ...headers,
      },
      rejectUnauthorized: false,
      timeout: 10000,
    };

    const req = https.request(opts, (res) => {
      let data = "";
      const cookies = res.headers["set-cookie"];
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(data), cookies }); }
        catch { resolve({ status: res.statusCode, data, cookies }); }
      });
    });

    req.on("error", reject);
    req.on("timeout", () => { req.destroy(); reject(new Error("timeout")); });
    if (postData) req.write(postData);
    req.end();
  });
}

class PbxWsManager {
  constructor(db, redis, log) {
    this.db = db;
    this.redis = redis;
    this.log = log || console;

    // Map<ip, PbxConnection>
    this.connections = new Map();

    // Grace period before disconnecting an idle domain socket (ms)
    this.graceMs = 60_000;
  }

  // ── Get or create a PBX connection + domain socket for a given domain ──
  async getConnectionForDomain(domain) {
    // Find which whitelist entry serves this domain
    const entry = await this._findEntryForDomain(domain);
    if (!entry) return null;
    if (!entry.ws_enabled) return null;

    const ip = entry.ip;
    let conn = this.connections.get(ip);

    if (!conn) {
      conn = this._createConnection(entry);
      this.connections.set(ip, conn);
    }

    // Lazy per-domain socket: create the record on first demand
    let sock = conn.sockets.get(domain);
    if (!sock) {
      sock = this._createSocket(domain);
      conn.sockets.set(domain, sock);
    }

    // Cancel any pending grace-period disconnect for this domain
    if (sock.graceTimer) {
      clearTimeout(sock.graceTimer);
      sock.graceTimer = null;
    }

    // If not connected, initiate connection for this domain only
    if (sock.state === "disconnected" || sock.state === "error") {
      this._connectDomain(conn, domain);
    }

    return conn;
  }

  // ── Register a frontend client for a specific domain ──
  addClient(conn, domain, clientWs) {
    if (!conn.clients.has(domain)) {
      conn.clients.set(domain, new Set());
    }
    conn.clients.get(domain).add(clientWs);

    // Send current state snapshot immediately
    const state = conn.domainState.get(domain);
    if (state) {
      this._sendToClient(clientWs, { type: "snapshot", ...this._buildSnapshot(domain, conn) });
    }

    // Send this domain's connection state
    const sock = conn.sockets.get(domain);
    this._sendToClient(clientWs, { type: "connection-state", state: sock ? sock.state : "disconnected" });

    this.log.info({ ip: conn.config.ip, domain, clients: conn.clients.get(domain).size }, "Live client added");
  }

  // ── Remove a frontend client ──
  removeClient(conn, domain, clientWs) {
    const domainClients = conn.clients.get(domain);
    if (domainClients) {
      domainClients.delete(clientWs);
      if (domainClients.size === 0) {
        conn.clients.delete(domain);
      }
    }

    this.log.info({ ip: conn.config.ip, domain }, "Live client removed");

    // Per-domain grace: no clients left on this domain → close its socket after grace
    if (!conn.clients.has(domain)) {
      const sock = conn.sockets.get(domain);
      if (sock) {
        this.log.info({ ip: conn.config.ip, domain }, "No clients remaining for domain, starting grace period");
        if (sock.graceTimer) clearTimeout(sock.graceTimer);
        sock.graceTimer = setTimeout(() => {
          this._disconnectDomain(conn, domain, "no clients");
        }, this.graceMs);
      }
    }
  }

  // ── Build snapshot of current state for a domain ──
  _buildSnapshot(domain, conn) {
    const ds = conn.domainState.get(domain) || {};
    return {
      calls: ds.calls || [],
      accounts: ds.accounts || [],
      queueStats: ds.queueStats ? Object.fromEntries(ds.queueStats) : {},
      queueList: ds.queueList || [],
      agentStatus: ds.agentStatus ? Object.fromEntries(ds.agentStatus) : {},
    };
  }

  // ── Create connection object (transport lives in per-domain sockets) ──
  _createConnection(entry) {
    return {
      config: {
        ip: entry.ip,
        pbx_url: entry.pbx_url,
        pbx_port: entry.pbx_port || 443,
        ws_user: entry.ws_user || "admin",
        admin_user: decrypt(entry.admin_user_encrypted),
        admin_pass: decrypt(entry.admin_pass_encrypted),
        domains: entry.domains || [],
      },
      sockets: new Map(),      // domain -> per-domain socket record
      domainState: new Map(),  // domain -> live state
      clients: new Map(),      // domain -> Set<frontend ws>
    };
  }

  // ── Create a per-domain socket record (not yet connected) ──
  _createSocket(domain) {
    return {
      domain,
      ws: null,
      state: "disconnected",
      sessionCookie: null,
      wsExtension: null,
      lastEvent: null,
      reconnectAttempts: 0,
      reconnectTimer: null,
      heartbeatTimer: null,
      graceTimer: null,
      queueRefreshTimer: null,
    };
  }

  // ── Full per-domain connection flow: pick identity → auth → WS → subscribe ──
  async _connectDomain(conn, domain) {
    const sock = conn.sockets.get(domain);
    if (!sock) return;
    if (sock.state === "connecting" || sock.state === "connected") return;
    sock.state = "connecting";
    this._broadcastConnectionState(conn, domain);

    try {
      const { pbx_url, pbx_port, admin_user, admin_pass } = conn.config;
      const authHeader = "Basic " + Buffer.from(`${admin_user}:${admin_pass}`).toString("base64");
      const encDomain = encodeURIComponent(domain);

      // Pick the WS identity for THIS domain: a queue agent if one exists
      // (wallboard events require an agent), otherwise the domain admin
      // (domain-calls still arrives for admin).
      let wsExtension = null;
      try {
        const acdRes = await pbxRequest(pbx_url, pbx_port,
          `/rest/domain/${encDomain}/acds`, "GET", null,
          { Authorization: authHeader }
        );
        if (acdRes.status === 200 && Array.isArray(acdRes.data)) {
          for (const queue of acdRes.data) {
            const agents = queue.all_agents || queue.agents || [];
            if (agents.length > 0) {
              wsExtension = agents[0];
              this.log.info({ ext: wsExtension, domain, queue: queue.name }, "Selected agent extension for domain WS connection");
              break;
            }
          }
        }
      } catch {}

      // No queue agents → use a DOMAIN ADMIN session ({admin:true, domain}).
      // Verified on the fleet: domain-calls delivers the full call lifecycle
      // (extension + acd calls) on a domain-admin session. No account lookup
      // needed; works on zero-extension domains. Note: wallboard event pushes
      // do NOT arrive on admin sessions, which is why domains WITH queue
      // agents keep the agent-extension identity above.
      const isAdminSession = !wsExtension;
      if (isAdminSession) {
        wsExtension = "admin";
        this.log.info({ domain }, "No queue agents in domain, using domain-admin session");
      }

      sock.wsExtension = wsExtension;
      sock.isAdminSession = isAdminSession;

      // Step 1: Create third-party session IN THIS DOMAIN (agent identity or domain admin)
      this.log.info({ pbx: pbx_url, ext: wsExtension, admin: isAdminSession, domain }, "PBX auth step 1 — creating session");

      const step1Body = isAdminSession
        ? { name: "3rd", admin: true, domain }
        : { name: "3rd", username: wsExtension, domain };
      const step1 = await pbxRequest(pbx_url, pbx_port, "/rest/system/session", "POST",
        step1Body,
        { Authorization: authHeader }
      );

      if (step1.status !== 200 || !step1.data) {
        throw new Error(`Auth failed (HTTP ${step1.status})`);
      }

      const sessionId = typeof step1.data === "string" ? step1.data : JSON.stringify(step1.data);
      const cookieFromStep1 = step1.cookies?.map(c => c.split(";")[0]).join("; ") || "";

      // Step 2: Activate session
      this.log.info({ pbx: pbx_url, domain }, "PBX auth step 2 — activating session");

      const step2 = await pbxRequest(pbx_url, pbx_port, "/rest/system/session", "POST",
        { name: "session", value: sessionId },
        { Cookie: cookieFromStep1 }
      );

      sock.sessionCookie = [
        cookieFromStep1,
        ...(step2.cookies || []).map(c => c.split(";")[0]),
      ].filter(Boolean).join("; ");

      // Step 3: Open WebSocket scoped to this domain
      const wsUrl = `wss://${pbx_url}:${pbx_port}/websocket?domain=${encDomain}&user=${encodeURIComponent(wsExtension)}`;

      this.log.info({ pbx: pbx_url, domain, url: wsUrl }, "PBX opening WebSocket");

      sock.ws = new WebSocket(wsUrl, {
        headers: { Cookie: sock.sessionCookie },
        rejectUnauthorized: false,
      });

      sock.ws.on("open", () => {
        this.log.info({ pbx: pbx_url, domain, ext: wsExtension }, "PBX WebSocket connected for domain");
        sock.state = "connected";
        sock.reconnectAttempts = 0;
        this._broadcastConnectionState(conn, domain);

        // Send avoid-disconnect immediately
        this._sendToPbx(conn, domain, { action: "avoid-disconnect" });

        // Subscribe to domain-calls for live call state (scoped to this domain)
        this._sendToPbx(conn, domain, { action: "domain-calls", subscribe: true });

        // Heartbeat doubles as liveness probe. Quiet domains legitimately go
        // hours without messages, so we NEVER reconnect on silence — only on
        // transport state.
        sock.heartbeatTimer = setInterval(() => {
          if (!sock.ws || sock.ws.readyState !== WebSocket.OPEN) {
            this.log.warn({ pbx: pbx_url, domain }, "Heartbeat found socket not OPEN, forcing reconnect");
            this._handleDisconnect(conn, domain);
            return;
          }
          this._sendToPbx(conn, domain, { action: "avoid-disconnect" });
          try { sock.ws.ping(); } catch {}
        }, 30_000);

        // Discover queues, subscribe wallboard + BLF for this domain
        this._discoverAndSubscribeDomain(conn, domain);

        // Refresh queue discovery periodically (pick up new queues/agents)
        sock.queueRefreshTimer = setInterval(() => {
          this._discoverAndSubscribeDomain(conn, domain);
        }, 5 * 60_000);
      });

      sock.ws.on("message", (raw) => {
        try {
          const msg = JSON.parse(raw.toString());
          sock.lastEvent = new Date();
          this._handlePbxMessage(conn, domain, msg);
        } catch (err) {
          this.log.warn({ domain, err: err.message }, "Failed to parse PBX WS message");
        }
      });

      sock.ws.on("close", (code, reason) => {
        this.log.warn({ pbx: pbx_url, domain, code, reason: reason?.toString() }, "PBX WebSocket closed");
        this._handleDisconnect(conn, domain);
      });

      sock.ws.on("error", (err) => {
        this.log.error({ pbx: pbx_url, domain, err: err.message }, "PBX WebSocket error");
        // onclose will fire after this
      });

    } catch (err) {
      this.log.error({ pbx: conn.config.pbx_url, domain, err: err.message }, "PBX connection failed");
      sock.state = "error";
      this._broadcastConnectionState(conn, domain);
      this._scheduleReconnect(conn, domain);
    }
  }

  // ── Back-compat wrapper (used by ws-live refresh-queues): refresh all
  //    currently-connected domain sockets on this PBX connection ──
  async _discoverAndSubscribe(conn) {
    for (const [domain, sock] of conn.sockets) {
      if (sock.state === "connected") {
        await this._discoverAndSubscribeDomain(conn, domain);
      }
    }
  }

  // ── Discover queues for ONE domain and subscribe its socket ──
  async _discoverAndSubscribeDomain(conn, domain) {
    const { pbx_url, pbx_port, admin_user, admin_pass } = conn.config;
    const sock = conn.sockets.get(domain);
    if (!sock) return;
    const authHeader = "Basic " + Buffer.from(`${admin_user}:${admin_pass}`).toString("base64");

    try {
      // Initialize domain state if needed
      if (!conn.domainState.has(domain)) {
        conn.domainState.set(domain, {
          calls: [],
          accounts: [],
          queueStats: new Map(),
          queueList: [],
          agentStatus: new Map(),
        });
      }
      const ds = conn.domainState.get(domain);

      const encDomain = encodeURIComponent(domain);

      // Fetch queues + agents in one call: GET /rest/domain/{domain}/acds
      this.log.info({ domain }, "Discovering queues via /rest/domain/acds");

      const acdRes = await pbxRequest(pbx_url, pbx_port,
        `/rest/domain/${encDomain}/acds`, "GET", null,
        { Authorization: authHeader }
      );

      const queueNames = [];
      const allExtensions = new Set();
      const nameFetches = [];

      if (acdRes.status === 200 && Array.isArray(acdRes.data)) {
        const queues = acdRes.data;
        ds.queueList = queues;

        this.log.info({ domain, queues: queues.length }, "Discovered queues");

        for (const queue of queues) {
          const queueName = queue.name;
          const displayName = queue.display || queueName;
          queueNames.push(queueName);

          // Store queue stats with display name and initial data
          if (!ds.queueStats.has(queueName)) {
            ds.queueStats.set(queueName, {});
          }
          const qs = ds.queueStats.get(queueName);
          qs.displayName = displayName;
          qs.queueLength = queue.calls || 0;
          qs.agentsActive = queue.agents || [];
          qs.allAgents = queue.all_agents || [];
          qs.agentsIdle = [];
          qs.agentsBusy = [];
          qs.curWaitTime = 0;
          qs.stats = qs.stats || {};

          // Process agents from the acds response (all_agents includes all, agents = logged in)
          const agentExts = queue.all_agents || queue.agents || [];
          for (const ext of agentExts) {
            allExtensions.add(ext);

            if (!ds.agentStatus.has(ext)) {
              ds.agentStatus.set(ext, { dnd: false, calls: [], registered: false, name: ext, queues: [] });
            }
            const agentInfo = ds.agentStatus.get(ext);
            if (!agentInfo.queues) agentInfo.queues = [];
            if (!agentInfo.queues.includes(queueName)) agentInfo.queues.push(queueName);

            // Track login status from agents vs all_agents
            const loggedInAgents = queue.agents || [];
            agentInfo.loggedIn = agentInfo.loggedIn || {};
            agentInfo.loggedIn[queueName] = loggedInAgents.includes(ext);

            // Defer the cosmetic display-name fetch off the critical path
            nameFetches.push({ ext, queueName });
          }
        }
      } else {
        this.log.warn({ domain, status: acdRes.status, data: acdRes.data }, "Failed to fetch queues from PBX");
      }

      // Subscribe FIRST — live data must not wait on cosmetic name fetches
      if (queueNames.length > 0) {
        this._sendToPbx(conn, domain, { action: "wallboard", queues: queueNames });
        this.log.info({ domain, queues: queueNames.length, names: queueNames }, "Subscribed to wallboard queues");
      }

      // Subscribe to BLF for all agent extensions + this socket's identity
      // Admin sessions have no watchable identity of their own; only
      // subscribe BLF when there are real agent extensions to watch.
      if (!sock.isAdminSession) {
        allExtensions.add(sock.wsExtension || conn.config.ws_user);
      }
      if (allExtensions.size > 0) {
        this._sendToPbx(conn, domain, { action: "blf", add: Array.from(allExtensions) });
        this.log.info({ domain, extensions: allExtensions.size }, "Subscribed to BLF for agent extensions");
      }

      // Broadcast initial queue state to any connected clients
      for (const [queueName, qData] of ds.queueStats) {
        this._broadcastToDomain(conn, domain, {
          type: "wallboard",
          queue: queueName,
          queueName: qData.displayName || queueName,
          data: qData,
        });
      }

      // Also broadcast initial agent status
      for (const [ext, agent] of ds.agentStatus) {
        this._broadcastToDomain(conn, domain, {
          type: "blf",
          user: ext,
          name: agent.name,
          dnd: agent.dnd,
          calls: agent.calls || [],
          registered: agent.registered,
          queues: agent.queues || [],
          loggedIn: agent.loggedIn || {},
        });
      }

      // Deferred, concurrency-bounded agent display-name fetch
      this._fetchAgentNames(conn, domain, nameFetches).catch(() => {});
    } catch (err) {
      this.log.error({ domain, err: err.message }, "Failed to discover queues for domain");
    }
  }

  // ── Deferred agent display-name fetch (bounded concurrency) ──
  async _fetchAgentNames(conn, domain, nameFetches, concurrency = 3) {
    if (!nameFetches || nameFetches.length === 0) return;
    const { pbx_url, pbx_port, admin_user, admin_pass } = conn.config;
    const authHeader = "Basic " + Buffer.from(`${admin_user}:${admin_pass}`).toString("base64");
    const encDomain = encodeURIComponent(domain);
    const ds = conn.domainState.get(domain);
    if (!ds) return;

    const jobs = [...nameFetches];
    const worker = async () => {
      while (jobs.length > 0) {
        const job = jobs.shift();
        if (!job) return;
        const { ext, queueName } = job;
        try {
          const loginRes = await pbxRequest(pbx_url, pbx_port,
            `/rest/domain/${encDomain}/account/${encodeURIComponent(ext)}/acd_login?group=${encodeURIComponent(queueName)}`, "GET", null,
            { Authorization: authHeader }
          );
          if (loginRes.status === 200 && loginRes.data?.name) {
            const agentInfo = ds.agentStatus.get(ext);
            if (agentInfo && agentInfo.name !== loginRes.data.name) {
              agentInfo.name = loginRes.data.name;
              // Push the resolved name to clients so labels fill in shortly after load
              this._broadcastToDomain(conn, domain, {
                type: "blf",
                user: ext,
                name: agentInfo.name,
                dnd: agentInfo.dnd,
                calls: agentInfo.calls || [],
                registered: agentInfo.registered,
                queues: agentInfo.queues || [],
                loggedIn: agentInfo.loggedIn || {},
              });
            }
          }
        } catch {}
      }
    };
    await Promise.all(Array.from({ length: Math.min(concurrency, jobs.length) }, worker));
  }

  // ── Handle incoming PBX WebSocket messages (socket is domain-scoped) ──
  _handlePbxMessage(conn, domain, msg) {
    const action = msg.action;
    const ds = conn.domainState.get(domain);

    if (action === "call-state" && msg.calls) {
      // This socket belongs to one domain. Keep a domain filter as a safety
      // net in case the PBX tags calls for other domains on this session.
      const calls = (msg.calls || [])
        .filter(c => !c.domain || c.domain === domain)
        .map(call => ({
          id: call.id,
          callType: call.type,
          fromName: call["from-name"],
          fromNumber: call["from-number"],
          toName: call["to-name"],
          toNumber: call["to-number"],
          start: call.start,
          connect: call.connect,
          state: call.state,
          extensions: call.extension || [],
          trunks: call.trunk || [],
          domain: call.domain || domain,
          rec: call.rec,
          account: call.account,
          priority: call.priority,
        }));

      if (ds) {
        ds.calls = calls;
        // Derive live queue state from active calls (also clears on empty)
        this._deriveQueueStateFromCalls(conn, domain, calls);
      }
      this._broadcastToDomain(conn, domain, { type: "call-state", calls });
    }

    else if (action === "domain-state") {
      // domain-state gives accounts status for this socket's domain
      const accounts = msg.accounts || [];
      if (ds) {
        ds.accounts = accounts;
        this._broadcastToDomain(conn, domain, { type: "domain-state", accounts });
      }
    }

    else if (action === "wallboard" && msg.queue) {
      // wallboard update for a specific queue in this domain
      if (!ds) return;
      const knownQueues = new Set();
      for (const q of (ds.queueList || [])) {
        knownQueues.add(typeof q === "string" ? q : q.name);
      }
      for (const qName of ds.queueStats.keys()) {
        knownQueues.add(qName);
      }
      if (knownQueues.has(msg.queue)) {
        this._fetchQueueStats(conn, domain, msg.queue);
      }
    }

    else if (action === "blf" && msg.user) {
      if (msg.calls && msg.calls.length > 0) {
        this.log.info({ domain, user: msg.user, calls: JSON.stringify(msg.calls) }, "BLF call data received");
      }
      if (!ds) return;
      const agentInfo = ds.agentStatus.get(msg.user);
      if (!agentInfo) return;

      // Update DND status
      if ("dnd" in msg) {
        agentInfo.dnd = msg.dnd && (msg.dnd.active === true || msg.dnd === true);
      }

      // Update call info
      // BLF calls use: state, direction, name, number (on early/alerting)
      // On confirmed: only state is sent, name/number disappear
      // We preserve the last known remote party info
      if ("calls" in msg) {
        const newCalls = (msg.calls || []).map(call => {
          const remote = call.name || call.number || call.remote || null;
          return {
            state: call.state || "unknown",
            remote: remote,
            name: call.name || null,
            number: call.number || null,
            duration: call.duration || 0,
            direction: call.direction || "unknown",
          };
        });

        // If new call has no remote info but previous call did, preserve it
        // (happens when state changes from "early" to "confirmed")
        if (newCalls.length > 0 && !newCalls[0].remote && agentInfo.calls?.length > 0) {
          const prev = agentInfo.calls[0];
          if (prev.remote) {
            newCalls[0].remote = prev.remote;
            newCalls[0].name = prev.name;
            newCalls[0].number = prev.number;
          }
        }

        // If still no remote info, try to enrich from call-state data
        // (direct calls skip early/alerting so BLF never gets caller details)
        if (newCalls.length > 0 && !newCalls[0].remote && ds.calls?.length > 0) {
          const agentExt = msg.user;
          const matchedCall = ds.calls.find(c =>
            (c.extensions || []).some(e => e === agentExt || e === agentExt + "*")
          );
          if (matchedCall) {
            const remote = matchedCall.fromName || matchedCall.fromNumber || matchedCall.toName || matchedCall.toNumber;
            if (remote) {
              newCalls[0].remote = remote;
              newCalls[0].name = matchedCall.fromName || matchedCall.toName || null;
              newCalls[0].number = matchedCall.fromNumber || matchedCall.toNumber || null;
            }
          }
        }

        agentInfo.calls = newCalls;
      }

      // Update registered status
      if ("registered" in msg) {
        agentInfo.registered = msg.registered;
      }

      this._broadcastToDomain(conn, domain, {
        type: "blf",
        user: msg.user,
        name: agentInfo.name,
        dnd: agentInfo.dnd,
        calls: agentInfo.calls,
        registered: agentInfo.registered,
        queues: agentInfo.queues || [],
        loggedIn: agentInfo.loggedIn || {},
      });
    }
  }

  // ── Derive live queue state from call-state events ──
  // Instead of polling REST, we use the real-time call data we already have
  _deriveQueueStateFromCalls(conn, domain, calls) {
    const ds = conn.domainState.get(domain);
    if (!ds) return;

    // Group calls by queue (account field = queue number)
    const queueCalls = new Map();
    for (const call of calls) {
      if (call.account && ds.queueStats.has(call.account)) {
        if (!queueCalls.has(call.account)) queueCalls.set(call.account, []);
        queueCalls.get(call.account).push(call);
      }
    }

    // Update each known queue
    for (const [queueName, qs] of ds.queueStats) {
      const qCalls = (queueCalls.get(queueName) || []).filter(c => {
        // Skip terminal states — call is over, not waiting or active
        const s = (c.state || "").toLowerCase();
        if (s === "disconnected" || s === "terminated" || s === "released" || s === "idle") {
          return false;
        }
        return true;
      });

      // Categorize calls:
      // - Waiting: in queue, no agent assigned yet (no extensions, not connected)
      // - Active: agent is handling it (ringing with extension, connected, or confirmed)
      // Note: transitional states where connected/confirmed has empty exts = still active, NOT waiting
      const waitingCalls = qCalls.filter(c => {
        // Never count connected/confirmed as waiting
        if (c.state === "connected" || c.state === "confirmed") return false;
        // Alerting with no extensions is a teardown artifact — not a real waiting call
        // A genuinely waiting call has state "early" or no state, not "alerting"
        if (c.state === "alerting" && (c.extensions || []).filter(e => e && !e.endsWith("*")).length === 0) return false;
        const exts = (c.extensions || []).filter(e => e && !e.endsWith("*"));
        return exts.length === 0;
      });

      const activeCalls = qCalls.filter(c => {
        // Connected/confirmed = always active
        if (c.state === "connected" || c.state === "confirmed") return true;
        // Alerting/ringing WITH an agent extension assigned = active
        const exts = (c.extensions || []).filter(e => e && !e.endsWith("*"));
        return exts.length > 0;
      });

      // Get active agent extensions from connected calls
      const activeAgentExts = new Set();
      for (const call of activeCalls) {
        for (const ext of (call.extensions || [])) {
          activeAgentExts.add(ext.replace("*", "")); // remove * suffix
        }
      }

      // Get all agent extensions for this queue
      const allAgentExts = qs.allAgents || [];

      // Agents on active calls in this queue
      const agentsActive = Array.from(activeAgentExts);

      // Idle = in allAgents but not active and not DND
      const agentsIdle = allAgentExts.filter(ext => {
        if (activeAgentExts.has(ext)) return false;
        const agentInfo = ds.agentStatus.get(ext);
        if (agentInfo?.dnd) return false;
        return true;
      });

      // DND agents
      const agentsDnd = allAgentExts.filter(ext => {
        const agentInfo = ds.agentStatus.get(ext);
        return agentInfo?.dnd === true;
      });

      // Update the live fields (preserve stats from REST fetches)
      qs.liveQueueLength = waitingCalls.length;
      qs.liveAgentsActive = agentsActive;
      qs.liveAgentsIdle = agentsIdle;
      qs.liveAgentsDnd = agentsDnd;
      qs.liveActiveCalls = activeCalls.length;

      // Broadcast updated queue data
      this._broadcastToDomain(conn, domain, {
        type: "wallboard",
        queue: queueName,
        queueName: qs.displayName || queueName,
        data: {
          ...qs,
          queueLength: waitingCalls.length,
          agentsActive: agentsActive,
          agentsIdle: agentsIdle,
          agentsDnd: agentsDnd,
          activeCalls: activeCalls.length,
        },
      });
    }
  }

  // ── Fetch queue stats + calls for a specific queue (this domain's session) ──
  async _fetchQueueStats(conn, domain, queueName) {
    const { pbx_url, pbx_port, admin_user, admin_pass } = conn.config;
    const authHeader = "Basic " + Buffer.from(`${admin_user}:${admin_pass}`).toString("base64");
    // Use THIS DOMAIN's socket identity and session cookie
    const sock = conn.sockets.get(domain);
    const encUser = encodeURIComponent(sock?.wsExtension || conn.config.ws_user);
    const encDomain = encodeURIComponent(domain);

    try {
      // Use the same endpoints the Vodia wallboard uses, with session cookie + Basic auth fallback
      const headers = sock?.sessionCookie
        ? { Cookie: sock.sessionCookie, Authorization: authHeader }
        : { Authorization: authHeader };

      const [callsRes, statsRes] = await Promise.all([
        pbxRequest(pbx_url, pbx_port,
          `/rest/user/${encUser}@${encDomain}/acdinfo?info=calls&group=${encodeURIComponent(queueName)}&number=10`,
          "GET", null, headers),
        pbxRequest(pbx_url, pbx_port,
          `/rest/user/${encUser}@${encDomain}/acdinfo?info=stats&group=${encodeURIComponent(queueName)}`,
          "GET", null, headers),
      ]);

      const ds = conn.domainState.get(domain);
      if (!ds) return;

      const existing = ds.queueStats.get(queueName) || {};
      const calls = callsRes.status === 200 ? callsRes.data : {};
      const stats = statsRes.status === 200 ? statsRes.data : {};

      const queueData = {
        displayName: existing.displayName || queueName,
        queueLength: calls["queue-length"] || 0,
        curWaitTime: calls["cur-wait-time"] || 0,
        agentsActive: calls["agents-active"] || [],
        agentsIdle: calls["agents-idle"] || [],
        agentsBusy: calls["agents-busy"] || [],
        allAgents: existing.allAgents || [],
        stats: {
          calls: stats.calls || 0,
          connected: stats.connected || 0,
          "calls-abandoned": stats["calls-abandoned"] || 0,
          durationwait: stats.durationwait || 0,
          num_wait: stats.num_wait || 0,
          max_wait: stats.max_wait || 0,
          durationring: stats.durationring || 0,
          num_ring: stats.num_ring || 0,
        },
      };

      ds.queueStats.set(queueName, queueData);

      this._broadcastToDomain(conn, domain, {
        type: "wallboard",
        queue: queueName,
        queueName: queueData.displayName,
        data: queueData,
      });
    } catch (err) {
      this.log.warn({ domain, queue: queueName, err: err.message }, "Failed to fetch queue stats");
    }
  }

  // ── Handle PBX disconnect for one domain socket ──
  _handleDisconnect(conn, domain) {
    const sock = conn.sockets.get(domain);
    if (!sock) return;

    this._cleanupSockTimers(sock);
    if (sock.ws) {
      try { sock.ws.terminate ? sock.ws.terminate() : sock.ws.close(); } catch {}
    }
    sock.ws = null;
    sock.state = "disconnected";
    this._broadcastConnectionState(conn, domain);

    // Reconnect only if this domain still has active clients;
    // otherwise clean up the socket record entirely
    const domainClients = conn.clients.get(domain);
    if (domainClients && domainClients.size > 0) {
      this._scheduleReconnect(conn, domain);
    } else {
      this._disconnectDomain(conn, domain, "closed with no clients");
    }
  }

  // ── Reconnect one domain socket with exponential backoff ──
  _scheduleReconnect(conn, domain) {
    const sock = conn.sockets.get(domain);
    if (!sock) return;

    const delay = Math.min(2000 * Math.pow(2, sock.reconnectAttempts), 60_000);
    sock.reconnectAttempts++;

    this.log.info({ pbx: conn.config.pbx_url, domain, delay, attempt: sock.reconnectAttempts }, "Scheduling PBX reconnect");

    sock.reconnectTimer = setTimeout(() => {
      this._connectDomain(conn, domain);
    }, delay);
  }

  // ── Disconnect one domain socket and clean up its state ──
  _disconnectDomain(conn, domain, reason) {
    const sock = conn.sockets.get(domain);
    if (!sock) return;

    this.log.info({ pbx: conn.config.pbx_url, domain, reason }, "Disconnecting domain socket from PBX");
    this._cleanupSockTimers(sock);
    if (sock.graceTimer) { clearTimeout(sock.graceTimer); sock.graceTimer = null; }

    if (sock.ws) {
      try { sock.ws.close(); } catch {}
      sock.ws = null;
    }

    sock.state = "disconnected";
    conn.sockets.delete(domain);
    conn.domainState.delete(domain);

    // If no domain sockets remain on this PBX, drop the connection object
    if (conn.sockets.size === 0) {
      this.connections.delete(conn.config.ip);
    }
  }

  // ── Clean up a socket's timers (grace timer handled separately) ──
  _cleanupSockTimers(sock) {
    if (sock.heartbeatTimer) { clearInterval(sock.heartbeatTimer); sock.heartbeatTimer = null; }
    if (sock.reconnectTimer) { clearTimeout(sock.reconnectTimer); sock.reconnectTimer = null; }
    if (sock.queueRefreshTimer) { clearInterval(sock.queueRefreshTimer); sock.queueRefreshTimer = null; }
  }

  // ── Send message to one domain's PBX WebSocket ──
  _sendToPbx(conn, domain, msg) {
    try {
      const sock = conn.sockets.get(domain);
      if (sock?.ws && sock.ws.readyState === WebSocket.OPEN) {
        sock.ws.send(JSON.stringify(msg));
      }
    } catch (err) {
      this.log.warn({ domain, err: err.message }, "Failed to send to PBX WS");
    }
  }

  // ── Send message to a single frontend client ──
  _sendToClient(ws, msg) {
    try {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(msg));
      }
    } catch {}
  }

  // ── Broadcast to all clients watching a specific domain ──
  _broadcastToDomain(conn, domain, msg) {
    const clients = conn.clients.get(domain);
    if (!clients || clients.size === 0) return;

    const payload = JSON.stringify(msg);
    for (const ws of clients) {
      try {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(payload);
        }
      } catch {}
    }
  }

  // ── Broadcast this domain's connection state to its clients ──
  _broadcastConnectionState(conn, domain) {
    const sock = conn.sockets.get(domain);
    const msg = { type: "connection-state", state: sock ? sock.state : "disconnected" };
    const clients = conn.clients.get(domain);
    if (!clients) return;
    for (const ws of clients) {
      this._sendToClient(ws, msg);
    }
  }

  // ── Find whitelist entry for a domain ──
  async _findEntryForDomain(domain) {
    const doc = await this.db.collection("settings").findOne({ key: "ip_whitelist" });
    if (!doc?.ips) return null;

    for (const entry of doc.ips) {
      if (typeof entry !== "object") continue;
      if ((entry.domains || []).includes(domain)) return entry;
    }
    return null;
  }

  // ── Shutdown all connections ──
  shutdown() {
    this.log.info("Shutting down PBX WebSocket Manager");
    for (const [, conn] of this.connections) {
      for (const domain of Array.from(conn.sockets.keys())) {
        this._disconnectDomain(conn, domain, "shutdown");
      }
    }
    this.connections.clear();
  }
}

export default PbxWsManager;
