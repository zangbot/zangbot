/**
 * Storage Service — Dual Backend (MinIO + S3)
 *
 * Reads config from MongoDB settings collection, falls back to .env MinIO defaults.
 * Each recording stores which backend it lives on (storage_backend field).
 * Supports: local MinIO container, AWS S3, DigitalOcean Spaces, Backblaze B2, etc.
 */

import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand, HeadObjectCommand, ListBucketsCommand, ListObjectsV2Command } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

// ── Cached clients ────────────────────────────────────────────
let minioS3Client = null;
let externalS3Client = null;
let cachedConfig = null;
let configLoadedAt = 0;
const CONFIG_TTL = 30_000; // refresh from DB every 30s

// ── Encryption helpers (same as mailer.js) ────────────────────
import crypto from "crypto";

function getEncryptionKey() {
  const KEY_ENV = process.env.SMTP_ENCRYPTION_KEY || process.env.JWT_SECRET;
  return crypto.createHash("sha256").update(KEY_ENV).digest();
}

function encrypt(text) {
  const key = getEncryptionKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  let enc = cipher.update(text, "utf8", "hex");
  enc += cipher.final("hex");
  const tag = cipher.getAuthTag().toString("hex");
  return iv.toString("hex") + ":" + tag + ":" + enc;
}

function decrypt(encrypted) {
  try {
    const key = getEncryptionKey();
    const [ivHex, tagHex, data] = encrypted.split(":");
    if (!ivHex || !tagHex || !data) return null;
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(ivHex, "hex"));
    decipher.setAuthTag(Buffer.from(tagHex, "hex"));
    let dec = decipher.update(data, "hex", "utf8");
    dec += decipher.final("utf8");
    return dec;
  } catch { return null; }
}

export { encrypt as encryptStorageField, decrypt as decryptStorageField };

// ── Build MinIO S3 client (always available as fallback) ──────
function getMinioClient() {
  if (minioS3Client) return minioS3Client;

  const endpoint = process.env.MINIO_ENDPOINT || "minio";
  const port = parseInt(process.env.MINIO_PORT || "9000", 10);

  minioS3Client = new S3Client({
    endpoint: `http://${endpoint}:${port}`,
    region: "us-east-1",
    credentials: {
      accessKeyId: process.env.MINIO_ACCESS_KEY || "vodia",
      secretAccessKey: process.env.MINIO_SECRET_KEY || "changeme123",
    },
    forcePathStyle: true,
  });
  return minioS3Client;
}

// ── Build external S3 client from DB config ───────────────────
function buildExternalClient(config) {
  const params = {
    region: config.region || "us-east-1",
    credentials: {
      accessKeyId: config.access_key,
      secretAccessKey: config.secret_key,
    },
    forcePathStyle: !!config.force_path_style,
  };
  if (config.endpoint) {
    params.endpoint = config.endpoint;
  }
  return new S3Client(params);
}

// ── Load config from DB (cached) ──────────────────────────────
let _db = null;

export function setStorageDb(db) {
  _db = db;
}

async function loadConfig() {
  if (!_db) return null;
  if (cachedConfig && Date.now() - configLoadedAt < CONFIG_TTL) return cachedConfig;

  try {
    const doc = await _db.collection("settings").findOne({ key: "storage" });
    if (doc?.value) {
      const cfg = { ...doc.value };
      // Decrypt secrets
      if (cfg.access_key_encrypted) cfg.access_key = decrypt(cfg.access_key_encrypted);
      if (cfg.secret_key_encrypted) cfg.secret_key = decrypt(cfg.secret_key_encrypted);
      cachedConfig = cfg;
      configLoadedAt = Date.now();
      return cfg;
    }
  } catch { /* fall through */ }

  cachedConfig = null;
  configLoadedAt = Date.now();
  return null;
}

// Force refresh (called after saving new config)
export function clearStorageConfigCache() {
  cachedConfig = null;
  configLoadedAt = 0;
  externalS3Client = null;
}

// ── Get the current active backend name ───────────────────────
export async function getCurrentBackend() {
  const cfg = await loadConfig();
  return cfg?.backend === "s3" ? "s3" : "minio";
}

// ── Get S3 client for a specific backend ──────────────────────
async function getClientForBackend(backend) {
  if (backend === "s3") {
    const cfg = await loadConfig();
    if (!cfg || !cfg.access_key || !cfg.secret_key) {
      throw new Error("S3 not configured — missing credentials");
    }
    if (!externalS3Client) {
      externalS3Client = buildExternalClient(cfg);
    }
    return { client: externalS3Client, bucket: cfg.bucket || "recordings" };
  }
  // Default: MinIO
  return { client: getMinioClient(), bucket: process.env.MINIO_BUCKET || "recordings" };
}

// ── Get client for a specific recording (checks its storage_backend) ──
async function getClientForRecording(recording) {
  const backend = recording?.storage_backend || "minio";
  return getClientForBackend(backend);
}

// ── Public: init (called once on API startup) ─────────────────
export function initStorage() {
  // Pre-warm MinIO client
  getMinioClient();
  return minioS3Client;
}

// ── Legacy compat — used by retention route ───────────────────
export function getClient() {
  return getMinioClient();
}

export function getBucket() {
  return process.env.MINIO_BUCKET || "recordings";
}

// ── Build object key ──────────────────────────────────────────
export function buildObjectKey(system, domain, callid, filename) {
  const safe = filename.replace(/^.*[/\\]/, "").replace(/[^a-zA-Z0-9._-]/g, "_");
  return `${system}/${domain}/${callid}/${safe}`;
}

// ── Upload recording to current active backend ────────────────
export async function uploadRecording(objectKey, data, size, contentType) {
  const backend = await getCurrentBackend();
  const { client, bucket } = await getClientForBackend(backend);

  const cmd = new PutObjectCommand({
    Bucket: bucket,
    Key: objectKey,
    Body: data,
    ContentType: contentType || "audio/wav",
    ContentLength: size,
  });

  const result = await client.send(cmd);

  return {
    etag: result.ETag || null,
    versionId: result.VersionId || null,
    bucket,
    key: objectKey,
    storage_backend: backend,
  };
}

// ── Get presigned URL for a recording ─────────────────────────
export async function getPresignedUrl(objectKey, expirySeconds = 3600, backend = "minio") {
  const { client, bucket } = await getClientForBackend(backend);
  const cmd = new GetObjectCommand({ Bucket: bucket, Key: objectKey });
  return getSignedUrl(client, cmd, { expiresIn: expirySeconds });
}

// ── Stream object (for proxied playback) ──────────────────────
// ── Ranged read (HTTP 206 playback / seeking) ─────────────────
// rangeHeader is the raw "bytes=start-end" value. Returns the S3 response so
// the caller can mirror ContentLength / ContentRange onto the reply.
export async function getObjectRange(objectKey, backend = "minio", rangeHeader = null) {
  const { client, bucket } = await getClientForBackend(backend);
  const cmd = new GetObjectCommand({
    Bucket: bucket,
    Key: objectKey,
    ...(rangeHeader ? { Range: rangeHeader } : {}),
  });
  const response = await client.send(cmd);
  return {
    body: response.Body,
    contentLength: response.ContentLength ?? null,
    contentRange: response.ContentRange ?? null,
    contentType: response.ContentType ?? null,
  };
}

export async function getObjectStream(objectKey, backend = "minio") {
  const { client, bucket } = await getClientForBackend(backend);
  const cmd = new GetObjectCommand({ Bucket: bucket, Key: objectKey });
  const response = await client.send(cmd);
  return response.Body;
}

// ── Check object exists ───────────────────────────────────────
export async function objectExists(objectKey, backend = "minio") {
  const { client, bucket } = await getClientForBackend(backend);
  try {
    await client.send(new HeadObjectCommand({ Bucket: bucket, Key: objectKey }));
    return true;
  } catch (err) {
    if (err.name === "NotFound" || err.$metadata?.httpStatusCode === 404) return false;
    throw err;
  }
}

// ── Delete recording ──────────────────────────────────────────
export async function deleteRecording(objectKey, backend = "minio") {
  const { client, bucket } = await getClientForBackend(backend);
  await client.send(new DeleteObjectCommand({ Bucket: bucket, Key: objectKey }));
}

// ── Test S3 connection (used by settings route) ───────────────
export async function testS3Connection(config) {
  const testClient = buildExternalClient(config);
  const bucket = config.bucket || "recordings";

  // Try to list buckets to verify credentials
  try {
    await testClient.send(new ListBucketsCommand({}));
  } catch (err) {
    throw new Error(`Authentication failed: ${err.message}`);
  }

  // Try to put a tiny test object in the bucket
  const testKey = `_connection_test_${Date.now()}`;
  try {
    await testClient.send(new PutObjectCommand({
      Bucket: bucket,
      Key: testKey,
      Body: "test",
      ContentType: "text/plain",
    }));
  } catch (err) {
    throw new Error(`Bucket "${bucket}" write failed: ${err.message}`);
  }

  // Clean up test object
  try {
    await testClient.send(new DeleteObjectCommand({ Bucket: bucket, Key: testKey }));
  } catch { /* non-critical */ }

  return { ok: true };
}

// ── Storage Usage Stats ───────────────────────────────────────
async function listBucketUsage(client, bucket) {
  let totalSize = 0;
  let totalObjects = 0;
  const tenants = {};
  let continuationToken;

  do {
    const params = { Bucket: bucket, MaxKeys: 1000 };
    if (continuationToken) params.ContinuationToken = continuationToken;

    const response = await client.send(new ListObjectsV2Command(params));
    const contents = response.Contents || [];

    for (const obj of contents) {
      const size = obj.Size || 0;
      totalSize += size;
      totalObjects++;

      const parts = (obj.Key || "").split("/");
      if (parts.length >= 2) {
        const tenantKey = `${parts[0]}/${parts[1]}`;
        if (!tenants[tenantKey]) tenants[tenantKey] = { size: 0, objects: 0 };
        tenants[tenantKey].size += size;
        tenants[tenantKey].objects++;
      }
    }

    continuationToken = response.IsTruncated ? response.NextContinuationToken : null;
  } while (continuationToken);

  return { totalSize, totalObjects, tenants };
}

export async function getStorageUsage() {
  const config = await loadConfig();
  const activeBackend = config?.backend || "minio";
  const backends = [];
  const errors = [];

  // Always scan MinIO (local)
  try {
    const minioClient = getMinioClient();
    const minioBucket = process.env.MINIO_BUCKET || "recordings";
    const minioUsage = await listBucketUsage(minioClient, minioBucket);
    backends.push({ name: "minio", bucket: minioBucket, ...minioUsage });
  } catch (err) {
    errors.push({ backend: "minio", error: err.message });
  }

  // Scan S3 if configured
  if (config?.access_key && config?.secret_key) {
    try {
      const s3Bucket = config.bucket || "recordings";
      let s3Client = buildExternalClient(config);
      let s3Usage;
      try {
        s3Usage = await listBucketUsage(s3Client, s3Bucket);
      } catch (firstErr) {
        // DO Spaces: endpoint may include bucket as subdomain (e.g. bucket.region.digitaloceanspaces.com)
        // Try stripping bucket from endpoint and using base region endpoint
        if (config.endpoint && config.endpoint.includes(s3Bucket + ".")) {
          const baseEndpoint = config.endpoint.replace(s3Bucket + ".", "");
          const fallbackConfig = { ...config, endpoint: baseEndpoint };
          const fallbackClient = buildExternalClient(fallbackConfig);
          s3Usage = await listBucketUsage(fallbackClient, s3Bucket);
        } else {
          throw firstErr;
        }
      }
      backends.push({ name: "s3", bucket: s3Bucket, ...s3Usage });
    } catch (err) {
      errors.push({ backend: "s3", error: err.message });
    }
  }

  // Merge tenant data across backends
  const mergedTenants = {};
  let totalSize = 0;
  let totalObjects = 0;

  for (const b of backends) {
    totalSize += b.totalSize;
    totalObjects += b.totalObjects;
    for (const [key, v] of Object.entries(b.tenants)) {
      if (!mergedTenants[key]) mergedTenants[key] = { size: 0, objects: 0 };
      mergedTenants[key].size += v.size;
      mergedTenants[key].objects += v.objects;
    }
  }

  const tenantList = Object.entries(mergedTenants)
    .map(([key, v]) => {
      const [system, domain] = key.split("/");
      return { system, domain, size: v.size, objects: v.objects };
    })
    .sort((a, b) => b.size - a.size);

  return {
    active_backend: activeBackend,
    backends: backends.map(b => ({ name: b.name, bucket: b.bucket, size: b.totalSize, objects: b.totalObjects })),
    errors: errors.length > 0 ? errors : undefined,
    total_size: totalSize,
    total_objects: totalObjects,
    tenants: tenantList,
    calculated_at: new Date().toISOString(),
  };
}
