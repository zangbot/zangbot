/**
 * WebAuthn / Passkey Service
 */

import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} from "@simplewebauthn/server";

const RP_NAME = process.env.RP_NAME || "Vodia CDR Analytics";
const RP_ID = process.env.RP_ID || process.env.DOMAIN || "localhost";
const ORIGIN = process.env.RP_ORIGIN || `https://${RP_ID}`;

export async function generateRegOptions(user, existingCreds) {
  const options = await generateRegistrationOptions({
    rpName: RP_NAME,
    rpID: RP_ID,
    userID: new TextEncoder().encode(user._id.toString()),
    userName: user.email,
    userDisplayName: user.email.split("@")[0],
    attestationType: "none",
    excludeCredentials: existingCreds.map(c => ({
      id: c.credential_id,
      transports: c.transports || [],
    })),
    authenticatorSelection: {
      residentKey: "preferred",
      userVerification: "preferred",
    },
  });
  return options;
}

export async function verifyRegResponse(response, expectedChallenge) {
  return verifyRegistrationResponse({
    response,
    expectedChallenge,
    expectedOrigin: ORIGIN,
    expectedRPID: RP_ID,
  });
}

export async function generateAuthOptions(allowCredentials) {
  const options = await generateAuthenticationOptions({
    rpID: RP_ID,
    allowCredentials: allowCredentials.map(c => ({
      id: c.credential_id,
      transports: c.transports || [],
    })),
    userVerification: "preferred",
  });
  return options;
}

export async function verifyAuthResponse(response, expectedChallenge, credential) {
  return verifyAuthenticationResponse({
    response,
    expectedChallenge,
    expectedOrigin: ORIGIN,
    expectedRPID: RP_ID,
    credential: {
      id: credential.credential_id,
      publicKey: Buffer.from(credential.public_key, "base64"),
      counter: credential.counter,
    },
  });
}
