/**
 * TOTP 2FA Service
 */
import { TOTP, Secret } from "otpauth";
import QRCode from "qrcode";
import { encryptPassword, decryptPassword } from "./mailer.js";

const ISSUER = "Vodia Analytics";

export async function generateTotpSecret(email) {
  const totp = new TOTP({
    issuer: ISSUER,
    label: email,
    algorithm: "SHA1",
    digits: 6,
    period: 30,
    secret: new Secret({ size: 20 }),
  });
  const uri = totp.toString();
  const qrDataUrl = await QRCode.toDataURL(uri);
  return { secret: totp.secret.base32, uri, qrDataUrl };
}

export function verifyTotpCode(secret, code) {
  const totp = new TOTP({
    issuer: ISSUER,
    algorithm: "SHA1",
    digits: 6,
    period: 30,
    secret: Secret.fromBase32(secret),
  });
  const delta = totp.validate({ token: code, window: 1 });
  return delta !== null;
}

export function encryptTotpSecret(secret) {
  return encryptPassword(secret);
}

export function decryptTotpSecret(encrypted) {
  return decryptPassword(encrypted);
}
