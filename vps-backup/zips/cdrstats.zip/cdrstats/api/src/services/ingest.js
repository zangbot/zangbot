/**
 * CDR Ingest Pipeline
 *
 * Processes a raw Vodia CDR payload into a fully enriched document
 * and upserts to MongoDB.
 */

import { extractNumber, extractDisplayName } from "./sip-parser.js";
import { normalizeNumber, DEFAULT_CONFIG } from "./normalize.js";
import { calculateAvgMos } from "./mos-parser.js";
import { parseStates } from "./states-parser.js";
import { REQUIRED_CDR_FIELDS } from "../models/schemas.js";

export const RETENTION_DEFAULTS = {
  retention_days_calls: 365,
  retention_days_details: 90,
  store_logs: false,
};

/**
 * Tenant config: normalization + retention + logging preferences.
 *
 * Cache key is tenant_cfg: (not tenant_norm:) because the cached shape
 * changed -- reusing the old prefix would deserialise stale-shape
 * entries for up to 10 minutes after deploy.
 */
async function getTenantConfig(system, domain, db, redis) {
  const cacheKey = `tenant_cfg:${system}:${domain}`;

  try {
    const cached = await redis.get(cacheKey);
    if (cached) return JSON.parse(cached);
  } catch { /* fall through */ }

  const tenant = await db.collection("tenants").findOne(
    { system, domain },
    { projection: { normalization: 1, retention: 1 } }
  );

  const config = {
    normalization: tenant?.normalization || DEFAULT_CONFIG,
    retention: { ...RETENTION_DEFAULTS, ...(tenant?.retention || {}) },
  };

  try {
    await redis.set(cacheKey, JSON.stringify(config), "EX", 600);
  } catch { /* ignore */ }

  return config;
}

/**
 * Absolute expiry for a document, or null to keep forever.
 * A null/0/absent retention value means "never expires" -- the TTL
 * index skips documents with no expires_at field.
 */
function computeExpiry(days) {
  if (days === null || days === undefined) return null;
  const n = Number(days);
  if (!Number.isFinite(n) || n <= 0) return null;
  return new Date(Date.now() + n * 86400 * 1000);
}

function deriveCallDirection(trunklegs) {
  if (!Array.isArray(trunklegs) || trunklegs.length === 0) return "internal";

  for (const leg of trunklegs) {
    const dir = leg.direction?.toUpperCase();
    if (dir === "I") return "inbound";
    if (dir === "O") return "outbound";
  }

  return "internal";
}

/**
 * Refine call direction into compound form when a transfer occurred.
 * Only modifies the result when transfer_type is set — leaves
 * existing "inbound", "outbound", "internal" classifications untouched.
 *
 * Produces: "inbound/outbound", "inbound/internal"
 */
function refineCallDirection(baseDirection, trunklegs, transferType) {
  if (!transferType || transferType === "none") return baseDirection;

  const legs = Array.isArray(trunklegs) ? trunklegs : [];
  const hasInbound  = legs.some(l => l.direction?.toUpperCase() === "I");
  const hasOutbound = legs.some(l => l.direction?.toUpperCase() === "O");

  // Inbound call that was transferred back out via trunk
  if (hasInbound && hasOutbound) return "inbound/outbound";

  // Inbound call transferred to another internal extension
  if (hasInbound && !hasOutbound) return "inbound/internal";

  // No trunklegs but transfer detected — CDR was classified "internal"
  // because the inbound trunk wasn't in this record's trunklegs array.
  // The call still originated externally (attendant/ACD flow confirms this).
  if (baseDirection === "internal" && !hasInbound && !hasOutbound) {
    return "inbound/internal";
  }

  return baseDirection;
}

function computeDurations(cdr) {
  const start = parseFloat(cdr.start) || 0;
  const connect = parseFloat(cdr.connect) || 0;
  const end = parseFloat(cdr.end) || 0;

  const duration_seconds = end > start
    ? Math.round((end - start) * 100) / 100
    : 0;

  // Prefer talk time from states array (accurate for inbound/queue calls)
  let talk_seconds = 0;
  if (Array.isArray(cdr.states) && cdr.states.length > 0) {
    const stateTalk = cdr.states.reduce((sum, s) => sum + parseInt(s.durationtalk || 0), 0);
    if (stateTalk > 0) {
      talk_seconds = Math.round(stateTalk / 1000 * 100) / 100;
    }
  }
  // Fall back to end - connect if states had no talk time
  if (talk_seconds === 0 && connect > 0 && end > connect) {
    talk_seconds = Math.round((end - connect) * 100) / 100;
  }

  const ring_seconds = connect > 0 && connect > start
    ? Math.round((connect - start) * 100) / 100
    : 0;

  return { duration_seconds, talk_seconds, ring_seconds };
}

/**
 * Time-to-answer, for Grade of Service reporting.
 *
 * Null for unanswered calls. The wait time of an abandoned call already lives
 * in queue_wait_seconds, and folding the two together would corrupt GoS.
 *
 * ACD calls prefer queue_wait_seconds (ring + IVR summed across acd states,
 * so a call that overflowed queue A into queue B reports total caller wait).
 * Everything else falls back to ring_seconds (connect - start).
 */
function computeAnswerSeconds(isAnswered, stateFields, durations) {
  if (!isAnswered) return null;
  const queueWait = stateFields.queue_wait_seconds;
  if (stateFields.routing_method === "acd" && queueWait > 0) return queueWait;
  const ring = durations.ring_seconds;
  return ring > 0 ? ring : 0;
}

export function validateCdr(cdr) {
  const missing = REQUIRED_CDR_FIELDS.filter((f) => !cdr[f]);
  if (missing.length > 0) {
    return { valid: false, error: `Missing required fields: ${missing.join(", ")}` };
  }
  return { valid: true };
}

export async function processCdr(cdr, system, db, redis) {
  const tenantCfg = await getTenantConfig(system, cdr.domain, db, redis);
  const normConfig = tenantCfg.normalization;
  const retention = tenantCfg.retention;

  const fromRaw = extractNumber(cdr.from);
  const toRaw = extractNumber(cdr.to);
  const fromDisplayName = extractDisplayName(cdr.from);
  const toDisplayName = extractDisplayName(cdr.to);

  const fromNorm = normalizeNumber(fromRaw, normConfig);
  const toNorm = normalizeNumber(toRaw, normConfig);

  const stateFields = parseStates(cdr.states, cdr.logs, cdr.trunklegs, cdr.extensionlegs);
  const durations = computeDurations(cdr);
  const call_direction_base = deriveCallDirection(cdr.trunklegs);
  const avg_mos_score = calculateAvgMos(cdr.trunklegs);
  const call_direction = refineCallDirection(call_direction_base, cdr.trunklegs, stateFields.transfer_type);
  const call_direction_origin = call_direction.split("/")[0];

  const is_abandoned = cdr.abandoned === true || cdr.abandoned === "true";
  const is_answered = durations.talk_seconds > 0 && !is_abandoned;
  const has_recording = Array.isArray(cdr.recordings) && cdr.recordings.length > 0;
  const answer_seconds = computeAnswerSeconds(is_answered, stateFields, durations);

  const doc = {
    system,
    domain: cdr.domain,
    callid: cdr.callid,

    version: cdr.version,
    from_raw: cdr.from,
    to_raw: cdr.to,
    start: parseFloat(cdr.start) || null,
    connect: parseFloat(cdr.connect) || null,
    end: parseFloat(cdr.end) || null,
    category: cdr.category || null,
    rating: cdr.rating || null,
    cmc: cdr.cmc || null,
    comment: cdr.comment ? String(cdr.comment).slice(0, 2000) : null,

    states: cdr.states || [],
    has_trunk_leg: Array.isArray(cdr.trunklegs) && cdr.trunklegs.length > 0,

    ...durations,
    call_direction,
    call_direction_origin,
    is_answered,
    is_abandoned,
    has_recording,
    abandoned_available: cdr.available || null,

    from_number_raw: fromRaw,
    from_number_e164: fromNorm.e164,
    from_number_type: fromNorm.type,
    from_country: fromNorm.country,
    from_country_flag: fromNorm.country_flag || "",
    from_is_internal: fromNorm.is_internal,
    from_display_name: fromDisplayName,
    from_special_label: fromNorm.special_label,

    to_number_raw: toRaw,
    to_number_e164: toNorm.e164,
    to_number_type: toNorm.type,
    to_country: toNorm.country,
    to_country_flag: toNorm.country_flag || "",
    to_is_internal: toNorm.is_internal,
    to_display_name: toDisplayName,
    to_special_label: toNorm.special_label,

    ...stateFields,

    avg_mos_score,
    answer_seconds,

    ingested_at: new Date(),
  };

  const callsExpiry = computeExpiry(retention.retention_days_calls);
  if (callsExpiry) doc.expires_at = callsExpiry;

  // Cold payload -- stripped by upsertCdr and written to call_details.
  // Non-enumerable so it never leaks into a $set or a JSON response.
  Object.defineProperty(doc, "__details", {
    value: {
      trunklegs: cdr.trunklegs || [],
      extensionlegs: cdr.extensionlegs || [],
      recordings_raw: cdr.recordings || [],
      logs: retention.store_logs ? (cdr.logs || []) : [],
      logs_stored: !!retention.store_logs,
      expires_at: computeExpiry(retention.retention_days_details),
    },
    enumerable: false,
    writable: true,
    configurable: true,
  });

  return doc;
}

export async function upsertCdr(doc, db) {
  const filter = {
    system: doc.system,
    domain: doc.domain,
    callid: doc.callid,
  };

  const details = doc.__details;

  // Cold payload first. If the hot write then fails, the detail row is
  // orphaned and the TTL reaps it. The reverse order would leave a call
  // with no legs and no way to recover them.
  if (details) {
    const detailDoc = {
      system: doc.system,
      domain: doc.domain,
      callid: doc.callid,
      trunklegs: details.trunklegs,
      extensionlegs: details.extensionlegs,
      recordings_raw: details.recordings_raw,
      logs: details.logs,
      logs_stored: details.logs_stored,
    };
    const update = { $set: detailDoc, $setOnInsert: { created_at: new Date() } };
    if (details.expires_at) update.$set.expires_at = details.expires_at;
    else update.$unset = { expires_at: "" };

    try {
      await db.collection("call_details").updateOne(filter, update, { upsert: true });
    } catch (err) {
      // Never fail the CDR over the cold write -- the call itself,
      // which is what every dashboard reads, still lands.
      if (err.code !== 11000) {
        console.error("[ingest] call_details write failed:", err.message);
      }
    }
  }

  const hotUpdate = {
    $set: doc,
    $setOnInsert: { created_at: new Date() },
  };
  if (!doc.expires_at) hotUpdate.$unset = { expires_at: "" };

  return db.collection("calls").updateOne(filter, hotUpdate, { upsert: true });
}

export async function ensureTenant(system, domain, db) {
  await db.collection("tenants").updateOne(
    { system, domain },
    {
      $setOnInsert: {
        system,
        domain,
        display_name: domain,
        normalization: DEFAULT_CONFIG,
        created_at: new Date(),
      },
    },
    { upsert: true }
  );
}

export function buildUploadResponse(cdr, request) {
  if (!Array.isArray(cdr.recordings) || cdr.recordings.length === 0) {
    return [];
  }

  const proto = request.headers["x-forwarded-proto"] || request.protocol || "http";
  const host = request.headers["x-forwarded-host"] || request.headers.host;
  const baseUrl = `${proto}://${host}`;

  return cdr.recordings.map((rec) => {
    // Use recording ID if available, otherwise extract basename
    const filename = rec.id
      ? String(rec.id) + ".wav"
      : (rec.file || "unknown.wav").replace(/^.*[\/]/, "");

    return {
      file: rec.file,
      url: `${baseUrl}/upload/${cdr.system}/${cdr.domain}/${cdr.callid}/${filename}`,
    };
  });
}
