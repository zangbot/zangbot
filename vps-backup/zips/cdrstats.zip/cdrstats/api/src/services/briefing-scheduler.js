/**
 * Briefing Scheduler — runs inside the API process.
 *
 * Checks briefing_schedules every 5 minutes for due schedules, generates the
 * briefing via the same collectors/prompts as POST /api/ai/briefing, and
 * emails recipients via the configured SMTP. Redis NX lock makes it safe if
 * multiple API replicas ever run.
 */

import {
  collectDashboardData, collectQueuesData, collectInsightsData,
  buildDashboardPrompt, buildQueuesPrompt, buildInsightsPrompt,
} from "../routes/briefing.js";
import { chatCompletion } from "./ai-provider.js";
import { sendMail } from "./mailer.js";

const TICK_MS = 5 * 60 * 1000;
const RANGE_DAYS = { last_24h: 1, last_7d: 7, last_30d: 30 };
const CONTEXT_LABELS = { dashboard: "Dashboard", queues: "Queue Performance", insights: "AI Insights" };

let started = false;

export function computeNextRun(schedule, from = new Date()) {
  const tz = schedule.timezone || "UTC";
  const targetHour = Number.isInteger(schedule.hour) ? schedule.hour : 8;
  const start = new Date(from.getTime());
  start.setUTCMinutes(0, 0, 0);

  let fmt;
  try {
    fmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour12: false, hour: "numeric", weekday: "short", day: "numeric" });
  } catch {
    fmt = new Intl.DateTimeFormat("en-US", { timeZone: "UTC", hour12: false, hour: "numeric", weekday: "short", day: "numeric" });
  }
  const DOWS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  for (let i = 1; i <= 24 * 45; i++) {
    const cand = new Date(start.getTime() + i * 3600 * 1000);
    const parts = fmt.formatToParts(cand);
    const get = (t) => parts.find(p => p.type === t)?.value;
    const h = parseInt(get("hour")) % 24;
    if (h !== targetHour) continue;
    if (schedule.frequency === "weekly") {
      if (DOWS.indexOf(get("weekday")) !== (schedule.day_of_week ?? 1)) continue;
    } else if (schedule.frequency === "monthly") {
      if (parseInt(get("day")) !== (schedule.day_of_month || 1)) continue;
    }
    return cand;
  }
  return new Date(from.getTime() + 24 * 3600 * 1000);
}

function mdToHtml(briefing) {
  return briefing
    .replace(/^### (.+)$/gm, '<h3 style="color:#1a1a1a;margin:20px 0 8px 0;font-size:15px;">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 style="color:#1a1a1a;margin:24px 0 10px 0;font-size:17px;">$1</h2>')
    .replace(/^# (.+)$/gm, '<h1 style="color:#1a1a1a;margin:24px 0 12px 0;font-size:20px;">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/^- (.+)$/gm, '<li style="margin:4px 0;color:#333;">$1</li>')
    .replace(/(<li.*<\/li>\n?)+/g, '<ul style="padding-left:20px;margin:8px 0;">$&</ul>')
    .replace(/\n\n/g, '<br/><br/>')
    .replace(/\n/g, '<br/>');
}

export async function runScheduleNow(db, sched, log) {
  const days = RANGE_DAYS[sched.range] || 1;
  const nowEpoch = Date.now() / 1000;
  const filter = { start: { $gte: nowEpoch - days * 86400, $lte: nowEpoch } };
  if (sched.domain) filter.domain = sched.domain;

  const fmtD = (e) => new Date(e * 1000).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  const dateRange = fmtD(filter.start.$gte) + " — " + fmtD(filter.start.$lte);

  let data, prompt;
  switch (sched.context) {
    case "queues":
      data = await collectQueuesData(db, filter, sched.queue || null);
      prompt = buildQueuesPrompt(data, dateRange);
      break;
    case "insights":
      data = await collectInsightsData(db, filter);
      prompt = buildInsightsPrompt(data, dateRange);
      break;
    default:
      data = await collectDashboardData(db, filter);
      prompt = buildDashboardPrompt(data, dateRange);
  }

  const messages = [
    { role: "system", content: "You are a professional telecommunications analyst. Write clear, data-driven briefings. Format with markdown headings and bullet points." },
    { role: "user", content: prompt },
  ];
  const briefing = await chatCompletion(db, messages, { maxTokens: 2000, temperature: 0.4 });

  await db.collection("briefings").insertOne({
    context: sched.context, filters: { domain: sched.domain || null, range: sched.range },
    date_range: dateRange, briefing, raw_data: data,
    generated_at: new Date(), generated_by: "scheduler:" + (sched.created_by || "system"),
    domain: sched.domain || "all", schedule_id: sched._id,
  });

  const label = CONTEXT_LABELS[sched.context] || "Analytics";
  const recipients = Array.isArray(sched.recipients) ? sched.recipients.filter(Boolean) : [];
  let sent = 0;
  for (const to of recipients) {
    try {
      await sendMail(db, {
        to,
        subject: label + " Briefing — " + dateRange,
        html: `
          <div style="font-family:-apple-system,BlinkMacSystemFont,sans-serif;max-width:640px;margin:0 auto;padding:32px;">
            <div style="background:linear-gradient(135deg,#007aff 0%,#5856d6 100%);border-radius:16px;padding:32px;color:white;margin-bottom:24px;">
              <h2 style="margin:0 0 8px 0;font-size:20px;">📊 ${label} Briefing</h2>
              <p style="margin:0;opacity:0.9;font-size:14px;">${dateRange} • Scheduled ${sched.frequency || "daily"} briefing${sched.domain ? " • " + sched.domain : ""}</p>
            </div>
            <div style="color:#333;font-size:14px;line-height:1.7;">${mdToHtml(briefing)}</div>
            <hr style="border:none;border-top:1px solid #e5e5e5;margin:32px 0 16px 0;"/>
            <p style="color:#999;font-size:11px;text-align:center;">Generated automatically by Vodia Analytics AI</p>
          </div>
        `,
      });
      sent++;
    } catch (err) {
      log?.error({ schedule: String(sched._id), to, err: err.message }, "Scheduled briefing email failed");
    }
  }
  return { sent, recipients: recipients.length };
}

async function tick(db, redis, log) {
  const now = new Date();
  let due;
  try {
    due = await db.collection("briefing_schedules")
      .find({ enabled: { $ne: false }, next_run_at: { $lte: now } })
      .limit(10).toArray();
  } catch (err) {
    log?.error(err, "Briefing scheduler query failed");
    return;
  }

  for (const sched of due) {
    const lockKey = "briefing_sched:" + String(sched._id);
    let locked;
    try { locked = await redis.set(lockKey, "1", "EX", 600, "NX"); } catch { locked = null; }
    if (!locked) continue;

    const nextRun = computeNextRun(sched, now);
    try {
      log?.info({ schedule: String(sched._id), context: sched.context }, "Running scheduled briefing");
      const result = await runScheduleNow(db, sched, log);
      await db.collection("briefing_schedules").updateOne(
        { _id: sched._id },
        { $set: { last_run_at: now, last_status: "ok — emailed " + result.sent + "/" + result.recipients, next_run_at: nextRun } }
      );
    } catch (err) {
      log?.error({ schedule: String(sched._id), err: err.message }, "Scheduled briefing failed");
      await db.collection("briefing_schedules").updateOne(
        { _id: sched._id },
        { $set: { last_run_at: now, last_status: "error: " + err.message.slice(0, 200), next_run_at: nextRun } }
      ).catch(() => {});
    }
  }
}

export function startBriefingScheduler(db, redis, log) {
  if (started) return;
  started = true;
  setTimeout(() => tick(db, redis, log).catch(e => log?.error(e, "Scheduler tick failed")), 30 * 1000);
  setInterval(() => tick(db, redis, log).catch(e => log?.error(e, "Scheduler tick failed")), TICK_MS);
  log?.info("Briefing scheduler started (5-minute tick)");
}
