/**
 * States Parser
 *
 * Vodia CDR states[] contains the full call flow history.
 *
 * Reason codes:
 *   hc = hung up by callee, hw = hung up while waiting
 *   hr = hung up while ringing, rw = wait timeout
 *   rr = ring timeout, at = attended transfer, bt = blind transfer
 */

export function deriveRoutingMethod(states) {
  if (!Array.isArray(states) || states.length === 0) return "direct";

  const types = new Set(states.map((s) => s.type?.toLowerCase()));

  if (types.has("acd")) return "acd";
  if (types.has("hunt")) return "hunt";
  if (types.has("attendant")) return "attendant";
  if (types.has("mailbox")) return "mailbox";
  if (types.has("conference")) return "conference";
  if (types.has("ivrnode")) return "ivrnode";
  if (types.has("orbit")) return "orbit";

  return "direct";
}

export function deriveTransferType(states, logs, extensionlegs, trunklegs) {
  if (!Array.isArray(states)) states = [];

  // Check states reason codes first
  for (const state of states) {
    if (state.reason === "at") return "attended";
    if (state.reason === "bt") return "blind";
  }

  // Fallback: check logs for transfer messages
  if (Array.isArray(logs)) {
    for (const log of logs) {
      const msg = (log.m || log.message || "").toLowerCase();
      if (msg.includes("attended transfer")) return "attended";
      if (msg.includes("blind transfer")) return "blind";
      if (msg.includes("rest api transfer")) return "blind";
    }
  }

  // Check extension leg SIP packets for REFER (blind transfer)
  if (Array.isArray(extensionlegs)) {
    for (const leg of extensionlegs) {
      const packets = leg.packets || "";
      if (packets.includes("REFER ") && packets.includes("Refer-To:")) {
        // REFER with Refer-To header = transfer
        // If there's a consultation leg (another ext leg overlapping), it's attended
        // Otherwise it's blind
        const referToMatch = packets.match(/Refer-To:\s*<?sip:([^@>\s]+)/i);
        if (referToMatch) {
          // Check if there are multiple extension legs (consultation = attended)
          const extLegCount = extensionlegs.filter(l => l.extension === leg.extension).length;
          if (extLegCount > 1) return "attended";
          return "blind";
        }
      }
    }
  }

  return "none";
}

export function deriveAnsweringExtension(states) {
  if (!Array.isArray(states)) return { extension: null, name: null };

  const priority = ["acd", "hunt", "extcall", "attendant", "caller"];

  for (const type of priority) {
    for (const state of states) {
      if (
        state.type?.toLowerCase() === type &&
        state.extension &&
        parseInt(state.durationtalk || 0) > 0
      ) {
        return {
          extension: state.extension,
          name: state["extension-name"] || state.extension,
        };
      }
    }
  }

  for (const state of states) {
    if (state.extension && parseInt(state.durationtalk || 0) > 0) {
      return {
        extension: state.extension,
        name: state["extension-name"] || state.extension,
      };
    }
  }

  return { extension: null, name: null };
}

export function deriveQueue(states) {
  if (!Array.isArray(states)) return { queue: null, name: null };

  for (const state of states) {
    if (state.type?.toLowerCase() === "acd" && state.account) {
      return {
        queue: state.account,
        name: state["account-name"] || state.account,
      };
    }
  }

  return { queue: null, name: null };
}

export function deriveTimings(states) {
  const timings = {
    ivr_time_ms: 0,
    ring_time_ms: 0,
    talk_time_ms: 0,
    hold_time_ms: 0,
    queue_wait_ms: 0,
  };

  if (!Array.isArray(states)) return toSeconds(timings);

  for (const state of states) {
    const ivr = parseInt(state.durationivr || 0);
    const ring = parseInt(state.durationring || 0);
    const talk = parseInt(state.durationtalk || 0);
    const hold = parseInt(state.durationhold || 0);

    timings.ivr_time_ms += ivr;
    timings.ring_time_ms += ring;
    timings.talk_time_ms += talk;
    timings.hold_time_ms += hold;

    if (state.type?.toLowerCase() === "acd") {
      timings.queue_wait_ms += ring + ivr;
    }
  }

  return toSeconds(timings);
}

function toSeconds(timings) {
  return {
    ivr_time_seconds: Math.round(timings.ivr_time_ms / 1000 * 100) / 100,
    ring_time_seconds: Math.round(timings.ring_time_ms / 1000 * 100) / 100,
    hold_time_seconds: Math.round(timings.hold_time_ms / 1000 * 100) / 100,
    queue_wait_seconds: Math.round(timings.queue_wait_ms / 1000 * 100) / 100,
  };
}


/**
 * Extract a flat searchable accounts array from states.
 * Each entry: { number, name, type }
 * Also returns a joined string for text search.
 */
export function extractAccounts(states, trunklegs) {
  if (!Array.isArray(states)) states = [];

  const seen = new Set();
  const accounts = [];

  for (const state of states) {
    const type = (state.type || "").toLowerCase();

    // Account (queue, IVR, attendant, etc)
    if (state.account) {
      const key = type + ":" + state.account;
      if (!seen.has(key)) {
        seen.add(key);
        accounts.push({
          number: state.account,
          name: state["account-name"] || state.account,
          type,
        });
      }
    }

    // Extension (agent)
    if (state.extension) {
      const key = "ext:" + state.extension;
      if (!seen.has(key)) {
        seen.add(key);
        accounts.push({
          number: state.extension,
          name: state["extension-name"] || state.extension,
          type: "extension",
        });
      }
    }
  }

  // Add trunk remote parties (external numbers called/transferred to)
  if (Array.isArray(trunklegs)) {
    for (const leg of trunklegs) {
      if (leg.remoteparty) {
        const key = "trunk:" + leg.remoteparty;
        if (!seen.has(key)) {
          seen.add(key);
          // Try to get name from P-Asserted-Identity in quality/packets
          let remoteName = leg.remoteparty;
          const paiMatch = (leg.packets || "").match(/P-Asserted-Identity:\s*"([^"]+)"/);
          if (paiMatch) remoteName = paiMatch[1];
          accounts.push({
            number: leg.remoteparty,
            name: remoteName,
            type: "trunk",
          });
        }
      }
    }
  }

  // Build a searchable string
  const accounts_search = accounts
    .map(a => [a.name, a.number].filter(Boolean).join(" "))
    .join(" ");

  return { accounts, accounts_search };
}


/**
 * Detect call forwarding from logs and trunklegs.
 * Looks for:
 *   - Log: "[Call Handler] Redirect to +61132221 (reason=unconditional)"
 *   - SIP Diversion header in trunkleg packets
 * Returns { is_forwarded, forward_reason, forward_from, forward_to }
 */
function deriveForwarding(states, logs, trunklegs) {
  const result = {
    is_forwarded: false,
    forward_reason: null,
    forward_from: null,
    forward_to: null,
  };

  // 1. Check logs for Redirect messages
  if (Array.isArray(logs)) {
    for (const log of logs) {
      const msg = log.m || log.message || "";
      // Pattern: "[Call Handler] Redirect to +61132221 (reason=unconditional)"
      const redirectMatch = msg.match(/Redirect to ([^\s(]+)\s*\(reason=([^)]+)\)/i);
      if (redirectMatch) {
        result.is_forwarded = true;
        result.forward_to = redirectMatch[1];
        result.forward_reason = redirectMatch[2];
        break;
      }
      // Pattern: "[ACD 400] Night service is active. Send calls to +61132221"
      const nightActiveMatch = msg.match(/Night service is active\.\s*Send calls to ([^\s]+)/i);
      if (nightActiveMatch) {
        result.is_forwarded = true;
        result.forward_to = nightActiveMatch[1];
        result.forward_reason = "night_service";
        break;
      }
      // Pattern: "[Attendant 100] Goto night service +61132221"
      const gotoNightMatch = msg.match(/Goto night service ([^\s]+)/i);
      if (gotoNightMatch) {
        result.is_forwarded = true;
        result.forward_to = gotoNightMatch[1];
        result.forward_reason = "night_service";
        break;
      }
      // Pattern: "[RG 301] Night service" (no number — get it from next "Dial number" log)
      if (msg.match(/Night service$/i) || msg.match(/^\[.*\] Night service$/i)) {
        result.is_forwarded = true;
        result.forward_reason = "night_service";
        // Don't break — continue scanning for "Dial number" to get the target
      }
      // Pattern: "Dial number +61132221 from user 301" — captures forward_to when Night service had no number
      if (result.is_forwarded && !result.forward_to) {
        const dialMatch = msg.match(/Dial number ([^\s]+) from user/i);
        if (dialMatch) {
          result.forward_to = dialMatch[1];
          break;
        }
      }
      // Pattern: Overflow/Failover forwarding  
      const overflowMatch = msg.match(/(?:Overflow|Forward(?:ing)?|Failover)\s+(?:call\s+)?to\s+([^\s,]+)/i);
      if (overflowMatch && !result.is_forwarded) {
        result.is_forwarded = true;
        result.forward_to = overflowMatch[1];
        result.forward_reason = msg.toLowerCase().includes("overflow") ? "overflow" : msg.toLowerCase().includes("failover") ? "failover" : "forward";
        break;
      }
      // Also check for simpler redirect patterns
      const simpleRedirect = msg.match(/Redirect(?:ing)? (?:call )?to ([^\s,]+)/i);
      if (simpleRedirect && !result.is_forwarded) {
        result.is_forwarded = true;
        result.forward_to = simpleRedirect[1];
      }
    }
  }

  // 2. Check trunkleg SIP packets for Diversion header
  if (Array.isArray(trunklegs)) {
    for (const leg of trunklegs) {
      const packets = leg.packets || "";
      // Pattern: Diversion: "V70 Trunk" <sip:511@domain>;reason=unconditional
      const diversionMatch = packets.match(/Diversion:\s*(?:"[^"]*"\s*)?<sip:([^@>]+)@[^>]+>(?:;reason=([^\s\r\n,;]+))?/i);
      if (diversionMatch) {
        result.is_forwarded = true;
        result.forward_from = diversionMatch[1]; // original extension/number
        if (diversionMatch[2] && !result.forward_reason) {
          result.forward_reason = diversionMatch[2];
        }
        // The forward_to is the final_to_dialed or remoteparty on outbound leg
        if (leg.direction === "O" && !result.forward_to) {
          // Extract number from final_to_dialed: sip:+61132221@domain;user=phone
          const dialedMatch = (leg.final_to_dialed || "").match(/sip:([^@;]+)/);
          if (dialedMatch) result.forward_to = dialedMatch[1];
          if (!result.forward_to) result.forward_to = leg.remoteparty || null;
        }
        break;
      }
    }
  }

  // 3. Check if ACD forwarded to external (night service, overflow)
  if (!result.forward_from && result.is_forwarded && Array.isArray(states)) {
    for (let i = 0; i < states.length; i++) {
      const s = states[i];
      // If we have an extcall state preceded by an acd/attendant, the forward came from that queue/aa
      if (s.type === "extcall" && i > 0) {
        const prev = states[i - 1];
        if (prev.type === "acd" || prev.type === "attendant") {
          result.forward_from = prev.account || prev["account-name"] || null;
        }
      }
    }
  }

  // 4. Check states for forwarding hints — unconditional forward shows as extcall with redirect in logs
  if (!result.is_forwarded && Array.isArray(states)) {
    for (const state of states) {
      if (state.type === "extcall" && state.reason === "unconditional") {
        result.is_forwarded = true;
        result.forward_reason = "unconditional";
        result.forward_from = state.account || null;
        break;
      }
    }
  }

  return result;
}

export function parseStates(states, logs, trunklegs, extensionlegs) {
  const routing = deriveRoutingMethod(states);
  const transfer = deriveTransferType(states, logs, extensionlegs, trunklegs);
  const agent = deriveAnsweringExtension(states);
  const queue = deriveQueue(states);
  const timings = deriveTimings(states);

  const { accounts, accounts_search } = extractAccounts(states, trunklegs);

  const forwarding = deriveForwarding(states, logs, trunklegs);

  return {
    routing_method: routing,
    transfer_type: transfer,
    is_forwarded: forwarding.is_forwarded,
    forward_reason: forwarding.forward_reason,
    forward_from: forwarding.forward_from,
    forward_to: forwarding.forward_to,
    answering_extension: agent.extension,
    answering_extension_name: agent.name,
    answering_queue: queue.queue,
    answering_queue_name: queue.name,
    accounts,
    accounts_search,
    ...timings,
  };
}
