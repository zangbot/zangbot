/**
 * AI Provider Service — Multi-Provider Chat Completion
 *
 * Supports: OpenAI, Anthropic Claude, Google Gemini, Ollama
 * Loads config from MongoDB settings, falls back to .env
 * Provides unified chatCompletion(db, messages, options) interface
 */

import { decryptPassword } from "./mailer.js";

// ── Provider Definitions ──────────────────────────────────────

export const PROVIDERS = {
  openai: {
    name: "OpenAI",
    models: [
      { id: "gpt-5.4-mini", name: "GPT-5.4 Mini", desc: "Fast, affordable" },
      { id: "gpt-5.4", name: "GPT-5.4", desc: "Affordable flagship" },
      { id: "gpt-5.5", name: "GPT-5.5", desc: "Most capable" },
    ],
    defaultModel: "gpt-5.4-mini",
    needsKey: true,
    needsEndpoint: false,
  },
  anthropic: {
    name: "Anthropic Claude",
    models: [
      { id: "claude-opus-4-8", name: "Claude Opus 4.8", desc: "Most capable" },
      { id: "claude-sonnet-4-6", name: "Claude Sonnet 4.6", desc: "Best balance" },
      { id: "claude-haiku-4-5-20251001", name: "Claude Haiku 4.5", desc: "Fast, affordable" },
    ],
    defaultModel: "claude-sonnet-4-6",
    needsKey: true,
    needsEndpoint: false,
  },
  gemini: {
    name: "Google Gemini",
    models: [
      { id: "gemini-3.5-flash", name: "Gemini 3.5 Flash", desc: "Most intelligent" },
      { id: "gemini-3.1-flash-lite", name: "Gemini 3.1 Flash-Lite", desc: "Fastest, low cost" },
      { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash", desc: "Stable fallback" },
      { id: "gemini-2.5-pro", name: "Gemini 2.5 Pro", desc: "Stable, high quality" },
    ],
    defaultModel: "gemini-3.5-flash",
    needsKey: true,
    needsEndpoint: false,
  },
  ollama: {
    name: "Ollama (Self-Hosted)",
    models: [
      { id: "llama3", name: "Llama 3", desc: "General purpose" },
      { id: "mistral", name: "Mistral", desc: "Fast, capable" },
      { id: "gemma2", name: "Gemma 2", desc: "Google open model" },
      { id: "phi3", name: "Phi-3", desc: "Microsoft compact" },
      { id: "custom", name: "Custom model", desc: "Enter model name" },
    ],
    defaultModel: "llama3",
    needsKey: false,
    needsEndpoint: true,
  },
};

// ── Load AI Config from DB ────────────────────────────────────

export async function getAIConfig(db) {
  // Try new ai_provider key first
  const doc = await db.collection("settings").findOne({ key: "ai_provider" });
  if (doc?.value) {
    const cfg = { ...doc.value };
    if (cfg.api_key_encrypted) {
      cfg.api_key = decryptPassword(cfg.api_key_encrypted);
    }
    return cfg;
  }

  // Fall back to legacy openai key
  const legacy = await db.collection("settings").findOne({ key: "openai" });
  if (legacy?.value) {
    const cfg = {
      provider: "openai",
      model: legacy.value.model || "gpt-4o-mini",
    };
    if (legacy.value.api_key_encrypted) {
      cfg.api_key = decryptPassword(legacy.value.api_key_encrypted);
    }
    return cfg;
  }

  // Fall back to env
  const envKey = process.env.OPENAI_API_KEY || "";
  if (envKey && envKey !== "sk-PASTE-YOUR-KEY-HERE") {
    return {
      provider: "openai",
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      api_key: envKey,
    };
  }

  return { provider: "openai", model: "gpt-4o-mini", api_key: null };
}

export async function getAIKey(db) {
  const cfg = await getAIConfig(db);
  return cfg.api_key || null;
}

export async function getAIModel(db) {
  const cfg = await getAIConfig(db);
  return cfg.model || PROVIDERS[cfg.provider]?.defaultModel || "gpt-4o-mini";
}

// ── Chat Completion — Unified Interface ───────────────────────

export async function chatCompletion(db, messages, options = {}) {
  const config = await getAIConfig(db);
  const provider = config.provider || "openai";
  const model = options.model || config.model || PROVIDERS[provider]?.defaultModel;
  const apiKey = config.api_key;
  const endpoint = config.endpoint || "";
  const maxTokens = options.maxTokens || 1500;
  const temperature = options.temperature ?? 0.3;

  if (PROVIDERS[provider]?.needsKey && !apiKey) {
    throw new Error(`${PROVIDERS[provider]?.name || provider} API key not configured. Add it in Admin → AI Settings.`);
  }

  if (provider === "ollama" && !endpoint) {
    throw new Error("Ollama endpoint URL not configured. Add it in Admin → AI Settings.");
  }

  switch (provider) {
    case "openai":
      return callOpenAI(apiKey, model, messages, maxTokens, temperature, endpoint);
    case "anthropic":
      return callAnthropic(apiKey, model, messages, maxTokens, temperature);
    case "gemini":
      return callGemini(apiKey, model, messages, maxTokens, temperature);
    case "ollama":
      return callOllama(endpoint, model, messages, maxTokens, temperature);
    default:
      throw new Error(`Unknown AI provider: ${provider}`);
  }
}

// ── OpenAI ────────────────────────────────────────────────────

/* ── OPENAI_PARAM_CONTRACT_V1 ──────────────────────────────────
 * The gpt-5.x / o-series models replaced `max_tokens` with
 * `max_completion_tokens` and reject any non-default `temperature`.
 * Older models and most OpenAI-COMPATIBLE servers (LM Studio, vLLM,
 * LiteLLM, Azure) still require `max_tokens` and accept `temperature`.
 *
 * We seed a request shape from the model name, then adapt per-parameter
 * on a 400 that names the offending field, and memoise what worked so the
 * negotiation cost is paid once per model per process.
 * ───────────────────────────────────────────────────────────── */

const OPENAI_MODERN_MODEL_RE = /^(?:gpt-5|gpt-6|o[1-9])/i;

// `${endpoint||"openai"}::${model}` → { tokenParam, sendTemperature }
const openaiParamShapeCache = new Map();

function openaiDefaultShape(model, customEndpoint) {
  // Only guess "modern" for api.openai.com. Compatible servers keep legacy.
  const modern = !customEndpoint && OPENAI_MODERN_MODEL_RE.test(String(model || ""));
  return modern
    ? { tokenParam: "max_completion_tokens", sendTemperature: false }
    : { tokenParam: "max_tokens", sendTemperature: true };
}

function openaiBuildBody(model, messages, maxTokens, temperature, shape) {
  const body = { model, messages };
  body[shape.tokenParam] = maxTokens;
  if (shape.sendTemperature) body.temperature = temperature;
  return body;
}

// Returns an adjusted shape if the 400 is a parameter complaint, else null.
function openaiAdaptShape(shape, status, errBody) {
  if (status !== 400) return null;
  const t = String(errBody || "");
  if (!/unsupported_parameter|unsupported_value|unknown_parameter|is not supported with this model|does not support/i.test(t)) {
    return null;
  }

  const next = { tokenParam: shape.tokenParam, sendTemperature: shape.sendTemperature };
  let changed = false;

  // Order matters: "Use 'max_completion_tokens' instead" contains both names.
  if (shape.tokenParam === "max_tokens" && /max_tokens/.test(t)) {
    next.tokenParam = "max_completion_tokens";
    changed = true;
  } else if (shape.tokenParam === "max_completion_tokens" && /max_completion_tokens/.test(t)) {
    next.tokenParam = "max_tokens";
    changed = true;
  }

  if (shape.sendTemperature && /temperature/.test(t)) {
    next.sendTemperature = false;
    changed = true;
  }

  return changed ? next : null;
}

async function callOpenAI(apiKey, model, messages, maxTokens, temperature, customEndpoint) {
  const url = customEndpoint
    ? `${customEndpoint.replace(/\/+$/, "")}/v1/chat/completions`
    : "https://api.openai.com/v1/chat/completions";

  const cacheKey = `${customEndpoint || "openai"}::${model}`;
  let shape = openaiParamShapeCache.get(cacheKey) || openaiDefaultShape(model, customEndpoint);

  // 3 attempts = up to 2 parameter flips (token param, then temperature).
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify(openaiBuildBody(model, messages, maxTokens, temperature, shape)),
    });

    if (!res.ok) {
      const errBody = await res.text();
      const next = openaiAdaptShape(shape, res.status, errBody);
      if (next && attempt < 2) {
        shape = next;
        continue;
      }
      throw new Error(`OpenAI API error ${res.status}: ${errBody.slice(0, 300)}`);
    }

    openaiParamShapeCache.set(cacheKey, shape);

    const data = await res.json();
    const choice = data.choices?.[0];
    const content = choice?.message?.content || "";

    // Reasoning models spend the budget before emitting output. Without this
    // the caller gets "" and fails later with a misleading JSON parse error.
    if (!content && choice?.finish_reason === "length") {
      throw new Error(
        `OpenAI returned no content: the ${shape.tokenParam} budget (${maxTokens}) was consumed by reasoning before any output was produced. Raise the token budget or select a non-reasoning model.`
      );
    }

    return content;
  }

  throw new Error("OpenAI API error: could not negotiate a supported request format");
}
/* ── end OPENAI_PARAM_CONTRACT_V1 ─────────────────────────── */

// ── Anthropic Claude ──────────────────────────────────────────

async function callAnthropic(apiKey, model, messages, maxTokens, temperature) {
  // Claude uses a different message format: system goes in a separate field
  let systemMsg = "";
  const claudeMessages = [];

  for (const msg of messages) {
    if (msg.role === "system") {
      systemMsg += (systemMsg ? "\n" : "") + msg.content;
    } else {
      claudeMessages.push({ role: msg.role, content: msg.content });
    }
  }

  const body = {
    model,
    max_tokens: maxTokens,
    messages: claudeMessages,
  };
  if (systemMsg) body.system = systemMsg;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errBody = await res.text();
    throw new Error(`Anthropic API error ${res.status}: ${errBody.slice(0, 300)}`);
  }

  const data = await res.json();
  return data.content?.map(b => b.type === "text" ? b.text : "").join("") || "";
}

// ── Google Gemini ─────────────────────────────────────────────

async function callGemini(apiKey, model, messages, maxTokens, temperature) {
  // Gemini uses contents array with parts
  const contents = [];
  let systemInstruction = "";

  for (const msg of messages) {
    if (msg.role === "system") {
      systemInstruction += (systemInstruction ? "\n" : "") + msg.content;
    } else {
      contents.push({
        role: msg.role === "assistant" ? "model" : "user",
        parts: [{ text: msg.content }],
      });
    }
  }

  const body = {
    contents,
    generationConfig: {
      maxOutputTokens: maxTokens,
      temperature,
    },
  };
  if (systemInstruction) {
    body.systemInstruction = { parts: [{ text: systemInstruction }] };
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errBody = await res.text();
    throw new Error(`Gemini API error ${res.status}: ${errBody.slice(0, 300)}`);
  }

  const data = await res.json();
  return data.candidates?.[0]?.content?.parts?.map(p => p.text).join("") || "";
}

// ── Ollama ────────────────────────────────────────────────────

async function callOllama(endpoint, model, messages, maxTokens, temperature) {
  const url = `${endpoint.replace(/\/+$/, "")}/api/chat`;

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      messages,
      stream: false,
      options: { temperature, num_predict: maxTokens },
    }),
  });

  if (!res.ok) {
    const errBody = await res.text();
    throw new Error(`Ollama error ${res.status}: ${errBody.slice(0, 300)}`);
  }

  const data = await res.json();
  return data.message?.content || "";
}

// ── Test Connection ───────────────────────────────────────────

export async function testAIConnection(config) {
  const { provider, api_key, model, endpoint } = config;

  const testMessages = [
    { role: "user", content: "Say OK" },
  ];

  switch (provider) {
    case "openai":
      // OPENAI_PARAM_CONTRACT_V1: budget must clear reasoning overhead, or a
      // reasoning model burns it all internally and returns an empty string.
      return { response: await callOpenAI(api_key, model || PROVIDERS.openai.defaultModel, testMessages, 256, 0, endpoint) };
    case "anthropic":
      return { response: await callAnthropic(api_key, model || PROVIDERS.anthropic.defaultModel, testMessages, 10, 0) };
    case "gemini":
      return { response: await callGemini(api_key, model || PROVIDERS.gemini.defaultModel, testMessages, 5, 0) };
    case "ollama":
      return { response: await callOllama(endpoint, model || PROVIDERS.ollama.defaultModel, testMessages, 5, 0) };
    default:
      throw new Error(`Unknown provider: ${provider}`);
  }
}