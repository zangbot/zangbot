/**
 * SIP URI Parser
 * Extracts number and display name from Vodia CDR from/to fields.
 */

const SIP_URI_RE = /^(?:"([^"]*)")?\s*<?sip:([^@>]+)@([^>;]+)>?/i;
const BARE_SIP_RE = /^sip:([^@>]+)/i;

function cleanNumber(num) {
  if (!num) return "";
  // Strip outer parentheses, angle brackets, whitespace
  return num.replace(/^[(<\s]+|[)>\s]+$/g, "").trim();
}

export function parseSipUri(raw) {
  const result = { displayName: "", user: "", host: "", raw: raw || "" };
  if (!raw || typeof raw !== "string") return result;
  raw = raw.trim();

  const m = raw.match(SIP_URI_RE);
  if (m) {
    result.displayName = (m[1] || "").trim();
    result.user = cleanNumber(m[2] || "");
    result.host = (m[3] || "").trim();
    return result;
  }

  const bare = raw.match(BARE_SIP_RE);
  if (bare) {
    result.user = cleanNumber(bare[1] || "");
    return result;
  }

  result.user = cleanNumber(raw.replace(/[<>]/g, ""));
  return result;
}

export function extractNumber(raw) {
  return parseSipUri(raw).user;
}

export function extractDisplayName(raw) {
  const parsed = parseSipUri(raw);
  return parsed.displayName || parsed.user;
}
