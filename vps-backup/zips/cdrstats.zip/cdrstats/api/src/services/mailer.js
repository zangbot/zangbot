/**
 * Mailer Service
 *
 * Loads SMTP config from the settings collection,
 * decrypts password, and sends emails via nodemailer.
 */

import nodemailer from "nodemailer";
import crypto from "crypto";

const ALGO = "aes-256-gcm";
const KEY_ENV = process.env.SMTP_ENCRYPTION_KEY || process.env.JWT_SECRET;

function getKey() {
  return crypto.createHash("sha256").update(KEY_ENV).digest();
}

export function encryptPassword(plaintext) {
  if (!plaintext) return null;
  const key = getKey();
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ALGO, key, iv);
  let encrypted = cipher.update(plaintext, "utf8", "hex");
  encrypted += cipher.final("hex");
  const tag = cipher.getAuthTag().toString("hex");
  return `${iv.toString("hex")}:${tag}:${encrypted}`;
}

export function decryptPassword(blob) {
  if (!blob) return null;
  const [ivHex, tagHex, data] = blob.split(":");
  if (!ivHex || !tagHex || !data) return null;
  const key = getKey();
  const decipher = crypto.createDecipheriv(ALGO, key, Buffer.from(ivHex, "hex"));
  decipher.setAuthTag(Buffer.from(tagHex, "hex"));
  let decrypted = decipher.update(data, "hex", "utf8");
  decrypted += decipher.final("utf8");
  return decrypted;
}

/**
 * Load SMTP config from settings collection.
 */
export async function getSmtpConfig(db) {
  const doc = await db.collection("settings").findOne({ key: "smtp" });
  if (!doc) return null;
  return doc.value;
}

/**
 * Create a nodemailer transporter from DB config.
 */
export async function createTransporter(db) {
  const config = await getSmtpConfig(db);
  if (!config || !config.host) return null;

  const password = decryptPassword(config.password_encrypted);

  const opts = {
    host: config.host,
    port: config.port || 587,
    secure: config.encryption === "ssl", // true for 465
  };

  if (config.username || password) {
    opts.auth = {};
    if (config.username) opts.auth.user = config.username;
    if (password) opts.auth.pass = password;
  }

  // STARTTLS (port 587) — nodemailer does this by default when secure=false
  if (config.encryption === "none") {
    opts.tls = { rejectUnauthorized: false };
  }

  return nodemailer.createTransport(opts);
}

/**
 * Send an email using DB-stored SMTP config.
 */
export async function sendMail(db, { to, subject, html, text }) {
  const config = await getSmtpConfig(db);
  if (!config || !config.host) {
    throw new Error("SMTP not configured. Go to Admin → SMTP to set it up.");
  }

  const transporter = await createTransporter(db);
  if (!transporter) throw new Error("Failed to create mail transporter");

  const from = config.from_address || config.username || "noreply@example.com";

  const info = await transporter.sendMail({
    from,
    to,
    subject,
    html,
    text: text || subject,
  });

  return info;
}
