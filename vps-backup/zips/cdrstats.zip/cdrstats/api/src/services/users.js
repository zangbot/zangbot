import bcrypt from "bcrypt";

const SALT_ROUNDS = 12;
const PASSWORD_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

export const ROLES = {
  SUPER_ADMIN: "super_admin",
  ADMIN: "admin",
  QUEUE_MANAGER: "queue_manager",
  VIEWER: "viewer",
};

const VALID_ROLES = Object.values(ROLES);

export async function hashPassword(password) {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function comparePassword(password, hash) {
  return bcrypt.compare(password, hash);
}

export async function createUser(db, { email, password, role, tenants, pbx_servers, queues }) {
  if (!email || !password) throw new Error("Email and password are required");
  if (!VALID_ROLES.includes(role)) throw new Error(`Invalid role: ${role}`);

  const existing = await db.collection("users").findOne({ email: email.toLowerCase() });
  if (existing && existing.active) throw new Error("User with this email already exists");
  if (existing && !existing.active) {
    // Reactivate deactivated user with new settings
    const password_hash = await hashPassword(password);
    await db.collection("users").updateOne(
      { _id: existing._id },
      {
        $set: {
          password_hash,
          role,
          tenants: tenants || [],
          pbx_servers: pbx_servers || [],
          queues: role === "queue_manager" ? (queues || []) : [],
          active: true,
          must_reset_password: role !== ROLES.SUPER_ADMIN,
          password_expires_at: role === ROLES.SUPER_ADMIN ? null : new Date(Date.now() + PASSWORD_EXPIRY_MS),
          totp_enabled: false,
          totp_secret: null,
          totp_pending_secret: null,
          passkey_count: 0,
          updated_at: new Date(),
        },
        $unset: { deactivated_at: "" },
      }
    );
    // Clear old passkeys
    await db.collection("webauthn_credentials").deleteMany({ user_id: existing._id.toString() });
    return { ...existing, active: true, role, password_hash: undefined };
  }

  const password_hash = await hashPassword(password);
  const isSuperAdmin = role === ROLES.SUPER_ADMIN;

  const doc = {
    email: email.toLowerCase(),
    password_hash,
    role,
    tenants: tenants || [],
    pbx_servers: pbx_servers || [],
    queues: queues || [],
    active: true,
    // Super admins don't expire, others must reset within 24h
    must_reset_password: !isSuperAdmin,
    password_expires_at: isSuperAdmin ? null : new Date(Date.now() + PASSWORD_EXPIRY_MS),
    passkey_count: 0,
    created_at: new Date(),
    updated_at: new Date(),
  };

  const result = await db.collection("users").insertOne(doc);
  return { ...doc, _id: result.insertedId, password_hash: undefined };
}

export async function authenticateUser(db, email, password) {
  if (!email || !password) return null;

  const user = await db.collection("users").findOne({
    email: email.toLowerCase(),
    active: { $ne: false },
  });

  if (!user) return null;

  const valid = await comparePassword(password, user.password_hash);
  if (!valid) return null;

  const { password_hash, ...safeUser } = user;

  // Check password expiry (not for super_admin)
  if (user.role !== ROLES.SUPER_ADMIN && user.password_expires_at) {
    if (new Date() > new Date(user.password_expires_at)) {
      safeUser.password_expired = true;
    }
  }

  if (user.must_reset_password) {
    safeUser.must_reset_password = true;
  }

  return safeUser;
}

export async function getUserById(db, userId) {
  const { ObjectId } = await import("mongodb");
  let id;
  try { id = new ObjectId(userId); } catch { return null; }
  return db.collection("users").findOne({ _id: id }, { projection: { password_hash: 0 } });
}

export async function resetPassword(db, userId, newPassword) {
  const { ObjectId } = await import("mongodb");
  const id = new ObjectId(userId);
  const password_hash = await hashPassword(newPassword);
  await db.collection("users").updateOne({ _id: id }, {
    $set: {
      password_hash,
      must_reset_password: false,
      password_expires_at: null,
      updated_at: new Date(),
    },
  });
}

export async function seedSuperAdmin(db) {
  const count = await db.collection("users").countDocuments();
  if (count > 0) return null;

  const email = process.env.ADMIN_EMAIL || "admin@example.com";
  const password = process.env.ADMIN_PASSWORD || "changeme";

  return createUser(db, {
    email, password, role: ROLES.SUPER_ADMIN, tenants: [], pbx_servers: [],
  });
}
