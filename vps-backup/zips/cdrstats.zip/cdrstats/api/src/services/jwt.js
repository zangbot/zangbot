/**
 * JWT Token Service
 *
 * Issues and verifies JWT tokens for user authentication.
 * Tokens contain: userId, email, role, tenants[], pbx_servers[]
 */

import jwt from "jsonwebtoken";

const SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
const ACCESS_TTL = "8h";
const REFRESH_TTL = "7d";

/**
 * Sign an access token.
 */
export function signAccessToken(payload) {
  return jwt.sign(
    {
      userId: payload.userId,
      email: payload.email,
      role: payload.role,
      tenants: payload.tenants || [],
      pbx_servers: payload.pbx_servers || [],
      queues: payload.queues || [],
      ...(payload.totp_pending && { totp_pending: true }),
      ...(payload.reset_only && { reset_only: true }),
    },
    SECRET,
    { expiresIn: payload.totp_pending ? "5m" : ACCESS_TTL }
  );
}

/**
 * Sign a refresh token (longer-lived, minimal payload).
 */
export function signRefreshToken(userId) {
  return jwt.sign({ userId, type: "refresh" }, SECRET, {
    expiresIn: REFRESH_TTL,
  });
}

/**
 * Verify and decode a token.
 * @returns {object} Decoded payload
 * @throws {jwt.JsonWebTokenError|jwt.TokenExpiredError}
 */
export function verifyToken(token) {
  return jwt.verify(token, SECRET);
}
