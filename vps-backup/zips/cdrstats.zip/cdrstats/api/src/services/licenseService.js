import { isCloudMode, getCurrentPlan, GRACE_PERIOD_DAYS, PLANS } from "../config/plans.js";

const REDIS_KEY = "license:extension_count";
const REDIS_GRACE_KEY = "license:grace_started_at";
const CACHE_TTL = 900;

async function countUniqueExtensions(db) {
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const result = await db.collection("calls").aggregate([
    { $match: { created_at: { $gte: thirtyDaysAgo } } },
    { $unwind: "$extensionlegs" },
    { $group: { _id: { domain: "$domain", extension: "$extensionlegs.extension" } } },
    { $count: "total" },
  ]).toArray();
  return result[0]?.total || 0;
}

async function getExtensionCount(db, redis) {
  const cached = await redis.get(REDIS_KEY);
  if (cached !== null) return parseInt(cached, 10);
  const count = await countUniqueExtensions(db);
  await redis.set(REDIS_KEY, count, "EX", CACHE_TTL);
  return count;
}

export async function getLicenseStatus(db, redis) {
  if (!isCloudMode()) return null;

  //const plan = getCurrentPlan();
  // Check for remote plan from license server first, fallback to .env
const remoteLicense = await db.collection("settings").findOne({ key: "license_remote" });
const planCode = remoteLicense?.plan || process.env.LICENSE_PLAN || "";
const plan = PLANS[planCode] || null;
  if (!plan) {
    return { error: true, message: `Invalid LICENSE_PLAN: ${process.env.LICENSE_PLAN || "(not set)"}` };
  }

  const extensionCount = await getExtensionCount(db, redis);
  const overLimit = extensionCount > plan.limit;

  let graceStartedAt = null;
  let graceExpired = false;
  let daysRemaining = null;

  if (overLimit) {
    const graceStr = await redis.get(REDIS_GRACE_KEY);
    if (graceStr) {
      graceStartedAt = new Date(graceStr);
    } else {
      graceStartedAt = new Date();
      await redis.set(REDIS_GRACE_KEY, graceStartedAt.toISOString());
      await db.collection("settings").updateOne(
        { key: "license_grace" },
        { $set: { key: "license_grace", started_at: graceStartedAt, updated_at: new Date() } },
        { upsert: true }
      );
    }
    const elapsed = Date.now() - graceStartedAt.getTime();
    const graceDurationMs = GRACE_PERIOD_DAYS * 24 * 60 * 60 * 1000;
    graceExpired = elapsed >= graceDurationMs;
    daysRemaining = graceExpired ? 0 : Math.ceil((graceDurationMs - elapsed) / (24 * 60 * 60 * 1000));
  } else {
    await redis.del(REDIS_GRACE_KEY);
    await db.collection("settings").deleteOne({ key: "license_grace" });
  }

  return {
    mode: "cloud",
    plan: planCode,
    planName: plan.name,
    limit: plan.limit,
    extensionCount,
    overLimit,
    graceStartedAt: graceStartedAt?.toISOString() || null,
    graceExpired,
    daysRemaining,
    locked: overLimit && graceExpired,
  };
}

export async function restoreGraceFromDb(db, redis) {
  if (!isCloudMode()) return;
  const existing = await redis.get(REDIS_GRACE_KEY);
  if (existing) return;
  const doc = await db.collection("settings").findOne({ key: "license_grace" });
  if (doc?.started_at) {
    await redis.set(REDIS_GRACE_KEY, doc.started_at.toISOString());
  }
}

export async function refreshExtensionCount(db, redis) {
  if (!isCloudMode()) return;
  const count = await countUniqueExtensions(db);
  await redis.set(REDIS_KEY, count, "EX", CACHE_TTL);
  return count;
}

/**
 * Poll the license server for plan updates.
 * Called on startup and every 24 hours.
 * Uses public IP to identify this instance.
 */

const LICENSE_SERVER = "https://portal.vodia-teams.com";
const POLL_INTERVAL_MS = 24 * 60 * 60 * 1000; // 24 hours

export async function pollLicenseServer(db, redis, log) {
  if (!isCloudMode()) return;

  try {
    // Get this instance's public IP
    const ipRes = await fetch("https://api.ipify.org?format=json");
    if (!ipRes.ok) {
      log.error("Failed to get public IP: %d", ipRes.status);
      return;
    }
    const { ip } = await ipRes.json();

    log.info("Polling license server for IP: %s", ip);

    const res = await fetch(`${LICENSE_SERVER}/api/license/check?ip=${ip}`);

    if (res.status === 404) {
      log.warn("No license found on server for IP %s — using .env fallback", ip);
      return;
    }

    if (!res.ok) {
      log.error("License server returned %d", res.status);
      return;
    }

    const data = await res.json();
    // { plan: "ext_50", status: "active", provider: "digitalocean", uuid: "..." }

    // Store in MongoDB so getLicenseStatus reads it
    await db.collection("settings").updateOne(
      { key: "license_remote" },
      {
        $set: {
          key: "license_remote",
          plan: data.plan,
          status: data.status,
          provider: data.provider,
          uuid: data.uuid,
          last_checked: new Date(),
          updated_at: new Date(),
        },
      },
      { upsert: true }
    );

    // Clear cached extension count so it re-evaluates against new plan
    await redis.del(REDIS_KEY);

    log.info("License updated from server: plan=%s status=%s", data.plan, data.status);

    if (data.status === "suspended") {
      log.warn("Instance is SUSPENDED by provider");
    }
  } catch (err) {
    log.error("Failed to poll license server: %s", err.message);
  }
}

/**
 * Start the 24-hour polling loop.
 * Polls immediately on startup, then every 24 hours.
 */
export function startLicensePolling(db, redis, log) {
  if (!isCloudMode()) return;

  // Poll immediately
  pollLicenseServer(db, redis, log);

  // Then every 24 hours
  setInterval(() => pollLicenseServer(db, redis, log), POLL_INTERVAL_MS);

  log.info("License polling started (every 24h)");
}
