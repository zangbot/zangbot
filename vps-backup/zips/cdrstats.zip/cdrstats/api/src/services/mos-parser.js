/**
 * MOS Score Parser
 *
 * Extracts MOSLQ/MOSCQ from VQSessionReport text in trunklegs[].quality
 * Also handles the integer mos field (x10 scaled).
 */

const MOSLQ_RE = /MOSLQ[=:](\d+\.?\d*)/gi;
const MOSCQ_RE = /MOSCQ[=:](\d+\.?\d*)/gi;

export function parseMosFromQuality(qualityReport) {
  const result = { moslq: [], moscq: [], all: [] };
  if (!qualityReport || typeof qualityReport !== "string") return result;

  let match;

  MOSLQ_RE.lastIndex = 0;
  while ((match = MOSLQ_RE.exec(qualityReport)) !== null) {
    const val = parseFloat(match[1]);
    if (!isNaN(val) && val > 0 && val <= 5.0) {
      result.moslq.push(val);
      result.all.push(val);
    }
  }

  MOSCQ_RE.lastIndex = 0;
  while ((match = MOSCQ_RE.exec(qualityReport)) !== null) {
    const val = parseFloat(match[1]);
    if (!isNaN(val) && val > 0 && val <= 5.0) {
      result.moscq.push(val);
      result.all.push(val);
    }
  }

  return result;
}

export function calculateAvgMos(trunklegs) {
  if (!Array.isArray(trunklegs) || trunklegs.length === 0) return null;

  const scores = [];

  for (const leg of trunklegs) {
    if (leg.quality) {
      const parsed = parseMosFromQuality(leg.quality);
      scores.push(...parsed.all);
    }

    if (typeof leg.mos === "number" && leg.mos > 0) {
      scores.push(leg.mos / 10);
    }
  }

  if (scores.length === 0) return null;

  const sum = scores.reduce((a, b) => a + b, 0);
  return Math.round((sum / scores.length) * 100) / 100;
}
