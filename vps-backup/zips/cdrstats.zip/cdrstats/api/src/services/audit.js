/**
 * Audit Log Service
 *
 * Lightweight audit trail for login events and system changes.
 * Stores events in `audit_logs` MongoDB collection with TTL cleanup.
 *
 * Usage:
 *   import { logAudit, initAuditIndexes } from "../services/audit.js";
 *   await logAudit(db, { actor, action, category, target, details, ip });
 */

export const AUDIT = {
  AUTH: "auth",
  USERS: "users",
  TENANTS: "tenants",
  WHITELIST: "whitelist",
  SETTINGS: "settings",
  RETENTION: "retention",
  STORAGE: "storage",
};

/**
 * Log an audit event. Fire-and-forget — never throws.
 */
export async function logAudit(db, event) {
  try {
    await db.collection("audit_logs").insertOne({
      action: event.action,
      category: event.category || "general",
      actor: event.actor || "system",
      actor_id: event.actor_id || null,
      target: event.target || null,
      details: event.details || null,
      ip: event.ip || null,
      created_at: new Date(),
    });
  } catch (err) {
    console.error("[audit] Failed to log:", err.message);
  }
}

/**
 * Create TTL + query indexes. Safe to call repeatedly.
 */
export async function initAuditIndexes(db, ttlDays = 365) {
  try {
    const col = db.collection("audit_logs");
    await col.createIndex({ created_at: 1 }, { expireAfterSeconds: ttlDays * 24 * 60 * 60, name: "audit_ttl" });
    await col.createIndex({ category: 1, created_at: -1 }, { name: "audit_cat_date" });
    await col.createIndex({ actor: 1, created_at: -1 }, { name: "audit_actor_date" });
    await col.createIndex({ action: 1, created_at: -1 }, { name: "audit_action_date" });
  } catch (err) {
    console.error("[audit] Index creation failed:", err.message);
  }
}
