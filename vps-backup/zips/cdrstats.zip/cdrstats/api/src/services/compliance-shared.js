/**
 * Compliance settings loader (API side).
 * Mirrors worker/src/redactor.js getComplianceSettings — keep in sync.
 */

export const DEFAULT_COMPLIANCE_SETTINGS = {
  redaction: {
    enabled: false,
    categories: { card: true, cvv: true, ssn: false, email: false, dob: false },
    strict_digits: 0,
  },
  qa: {
    sampling_pct: 20,
    rubric: [],
  },
};

export async function getComplianceSettings(db, system, domain) {
  const merged = JSON.parse(JSON.stringify(DEFAULT_COMPLIANCE_SETTINGS));
  try {
    const globalDoc = await db.collection("compliance_settings").findOne({ system: null, domain: null });
    const tenantDoc = (system != null || domain != null)
      ? await db.collection("compliance_settings").findOne({ system, domain })
      : null;
    for (const doc of [globalDoc, tenantDoc]) {
      if (!doc) continue;
      if (doc.redaction) {
        if (doc.redaction.enabled != null) merged.redaction.enabled = !!doc.redaction.enabled;
        if (doc.redaction.categories) Object.assign(merged.redaction.categories, doc.redaction.categories);
        if (doc.redaction.strict_digits != null) merged.redaction.strict_digits = Math.max(0, Math.min(30, parseInt(doc.redaction.strict_digits) || 0));
      }
      if (doc.qa) {
        if (doc.qa.sampling_pct != null) merged.qa.sampling_pct = Math.max(0, Math.min(100, Number(doc.qa.sampling_pct) || 0));
        if (Array.isArray(doc.qa.rubric) && doc.qa.rubric.length > 0) merged.qa.rubric = doc.qa.rubric;
      }
    }
  } catch { /* defaults */ }
  return merged;
}
