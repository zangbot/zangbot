/**
 * Health Check Route
 */

export default async function healthRoutes(app) {
  app.get("/health", async () => {
    const mongoOk = app.mongo?.topology?.isConnected?.() !== false;
    const redisOk = app.redis?.status === "ready";

    return {
      status: mongoOk && redisOk ? "ok" : "degraded",
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      services: {
        mongo: mongoOk ? "connected" : "disconnected",
        redis: redisOk ? "connected" : "disconnected",
      },
    };
  });

  app.get("/api", async () => ({
    name: "Vodia CDR Analytics Platform",
    version: "1.0.0",
    layer: 2,
  }));
}
