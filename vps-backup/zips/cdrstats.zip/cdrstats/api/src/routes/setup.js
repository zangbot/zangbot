import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'fs';
import { resolve } from 'path';
import dns from 'dns';
import { promisify } from 'util';

const dnsResolve = promisify(dns.resolve4);

export default async function setupRoutes(app) {
  // ── Gate: all setup routes disabled once setup is complete ──
  const isSetupRequired = () => {
    return process.env.SETUP_COMPLETE !== 'true';
  };

  // ── GET /api/setup/status ──────────────────────────────────
  app.get('/api/setup/status', async (req, reply) => {
    if (!isSetupRequired()) {
      return reply.code(404).send({ error: 'Not found' });
    }

    let publicIp = '';
    try {
      const resp = await fetch('https://api.ipify.org');
      publicIp = await resp.text();
    } catch (e) {
      try {
        const resp = await fetch('https://ifconfig.me');
        publicIp = await resp.text();
      } catch (_) {}
    }

    return reply.send({
      setupRequired: true,
      publicIp: publicIp.trim(),
    });
  });

  // ── POST /api/setup/check-dns ──────────────────────────────
  app.post('/api/setup/check-dns', async (req, reply) => {
    if (!isSetupRequired()) {
      return reply.code(404).send({ error: 'Not found' });
    }

    const { domain } = req.body || {};
    if (!domain || typeof domain !== 'string') {
      return reply.code(400).send({ error: 'Domain is required' });
    }

    // Basic domain validation
    const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
    if (!domainRegex.test(domain)) {
      return reply.send({ valid: false, error: 'Invalid domain format' });
    }

    // Get public IP
    let publicIp = '';
    try {
      const resp = await fetch('https://api.ipify.org');
      publicIp = (await resp.text()).trim();
    } catch (_) {}

    if (!publicIp) {
      return reply.send({ valid: false, error: 'Could not determine server IP' });
    }

    // Resolve domain
    try {
      const addresses = await dnsResolve(domain);
      if (addresses.includes(publicIp)) {
        return reply.send({ valid: true, domainIp: addresses[0], serverIp: publicIp });
      } else {
        return reply.send({
          valid: false,
          error: `Domain resolves to ${addresses[0]} but this server is ${publicIp}`,
          domainIp: addresses[0],
          serverIp: publicIp,
        });
      }
    } catch (err) {
      return reply.send({
        valid: false,
        error: `Domain does not resolve: ${err.code || err.message}`,
        serverIp: publicIp,
      });
    }
  });

  // ── POST /api/setup/complete ───────────────────────────────
  app.post('/api/setup/complete', async (req, reply) => {
    if (!isSetupRequired()) {
      return reply.code(404).send({ error: 'Not found' });
    }

    const { domain, email } = req.body || {};
    if (!domain || !email) {
      return reply.code(400).send({ error: 'Domain and email are required' });
    }

    // Basic email validation
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return reply.code(400).send({ error: 'Invalid email format' });
    }

    // Generate random password
    const crypto = await import('crypto');
    const password = crypto.randomBytes(16).toString('base64url').slice(0, 20);

    // Write the flag file to the shared setup volume
    const setupDir = resolve('/app/setup');
    if (!existsSync(setupDir)) {
      mkdirSync(setupDir, { recursive: true });
    }

    const completeData = {
      domain,
      email,
      password,
      completedAt: new Date().toISOString(),
    };

    writeFileSync(
      resolve(setupDir, 'complete.json'),
      JSON.stringify(completeData, null, 2)
    );

    app.log.info({ domain, email }, 'Setup complete — flag file written, waiting for host watcher to restart');

    return reply.send({
      success: true,
      message: 'Setup complete. The system will restart with your new domain in approximately 2 minutes.',
      credentials: {
        url: `https://${domain}`,
        email,
        password,
      },
    });
  });
}
