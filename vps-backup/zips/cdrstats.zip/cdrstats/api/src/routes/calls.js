/**
 * Call Query Routes
 *
 * GET /api/calls       — Paginated search with filters
 * GET /api/calls/:id   — Full call detail
 */

import { requireAuth } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";
import { buildPlayUrl } from "./upload.js";

/**
 * Time to answer as an aggregation expression, for $expr filtering.
 * Same formula as computeAnswerSeconds() in services/ingest.js, and as
 * ANSWER_CALC in routes/stats.js. Keep the three in step.
 */
const ANSWER_CALC_EXPR = {
  $ifNull: [
    "$answer_seconds",
    {
      $cond: [
        { $ne: ["$is_answered", true] },
        null,
        {
          $let: {
            vars: {
              qw: { $ifNull: ["$queue_wait_seconds", 0] },
              cn: { $ifNull: ["$connect", 0] },
              st: { $ifNull: ["$start", 0] },
            },
            in: {
              $cond: [
                { $and: [{ $eq: ["$routing_method", "acd"] }, { $gt: ["$$qw", 0] }] },
                "$$qw",
                {
                  $cond: [
                    { $and: [{ $gt: ["$$cn", 0] }, { $gt: ["$$cn", "$$st"] }] },
                    { $round: [{ $subtract: ["$$cn", "$$st"] }, 2] },
                    0,
                  ],
                },
              ],
            },
          },
        },
      ],
    },
  ],
};

/** Bucket keys must match GOS_BUCKETS in routes/stats.js. */
const ANSWER_BUCKET_RANGES = {
  "0-10":    { min: 0,   max: 10 },
  "10-20":   { min: 10,  max: 20 },
  "20-30":   { min: 20,  max: 30 },
  "30-60":   { min: 30,  max: 60 },
  "60-120":  { min: 60,  max: 120 },
  "120-300": { min: 120, max: 300 },
  "300-600": { min: 300, max: 600 },
  "600-900": { min: 600, max: 900 },
  "900+":    { min: 900, max: null },
  // convenience roll-ups, matching the cumulative table columns.
  // le20 is kept so older bookmarked URLs still resolve; le30 is the
  // roll-up that matches the current SLA target.
  "le20":    { min: 0,   max: 20 },
  "le30":    { min: 0,   max: 30 },
  "le60":    { min: 0,   max: 60 },
  "le300":   { min: 0,   max: 300 },
  "gt300":   { min: 300, max: null },
};

/**
 * Plain-JS twin of ANSWER_CALC_EXPR, for decorating list rows so the
 * Answer Time column populates on historical calls too.
 */
function answerSecondsFor(call) {
  if (call.answer_seconds != null) return call.answer_seconds;
  if (call.is_answered !== true) return null;
  const qw = call.queue_wait_seconds != null ? call.queue_wait_seconds : 0;
  if (call.routing_method === "acd" && qw > 0) return qw;
  const cn = call.connect != null ? call.connect : 0;
  const st = call.start != null ? call.start : 0;
  return (cn > 0 && cn > st) ? Math.round((cn - st) * 100) / 100 : 0;
}

export default async function callRoutes(app) {
  const { db } = app;

  // ── Search / List Calls ─────────────────────────────
  app.get("/api/calls", {
    preHandler: requireAuth,
  }, async (request) => {
    const scopeFilter = buildTenantFilter(request);
    const {
      page = 1,
      limit = 50,
      sort_by = "start",
      sort_order = "desc",
      direction,
      answered,
      abandoned,
      has_recording,
      from_number,
      to_number,
      extension,
      queue,
      domain,
      system,
      category,
      min_duration,
      max_duration,
      min_mos,
      max_mos,
      routing_method,
      transfer_type,
      start_from,
      start_to,
      search,
    } = request.query;

    const filter = { ...scopeFilter };

    // Direction filter
    if (direction && ["inbound", "outbound", "internal"].includes(direction)) {
      filter.call_direction_origin = direction;
    }

    // Answered / Abandoned
    if (answered === "true") filter.is_answered = true;
    if (answered === "false") filter.is_answered = false;
    if (abandoned === "true") filter.is_abandoned = true;
    if (abandoned === "false") filter.is_abandoned = false;

    // Has recording
    if (has_recording === "true") filter.has_recording = true;
    if (has_recording === "false") filter.has_recording = false;

    // Compliance violations filter
    if (request.query.violations === "true") filter.compliance_passed = false;

    // Number search (partial match on E.164 or raw)
    if (from_number) {
      filter.$or = filter.$or || [];
      filter.$or.push(
        { from_number_e164: { $regex: from_number, $options: "i" } },
        { from_number_raw: { $regex: from_number, $options: "i" } },
        { from_display_name: { $regex: from_number, $options: "i" } }
      );
    }

    if (to_number) {
      const toOr = [
        { to_number_e164: { $regex: to_number, $options: "i" } },
        { to_number_raw: { $regex: to_number, $options: "i" } },
        { to_display_name: { $regex: to_number, $options: "i" } },
      ];
      if (filter.$or) {
        // Combine with AND
        filter.$and = filter.$and || [];
        filter.$and.push({ $or: filter.$or });
        filter.$and.push({ $or: toOr });
        delete filter.$or;
      } else {
        filter.$or = toOr;
      }
    }

    // Extension (answering agent)
    if (extension) {
      filter.$or = filter.$or || [];
      filter.$or.push(
        { answering_extension: extension },
        { answering_extension_name: { $regex: extension, $options: "i" } }
      );
    }

    // Queue. Accepts a comma-separated list from the Queues page
    // multi-select. This used to be applied twice - an $or here plus an
    // exact match further down - and the exact match always won, so the
    // answering_queue_name regex never actually matched anything.
    if (queue) {
      const qList = String(queue).split(",").map((s) => s.trim()).filter(Boolean);
      if (qList.length > 0) {
        filter.answering_queue = qList.length > 1 ? { $in: qList } : qList[0];
      }
    }

    // Domain / System overrides (super_admin can narrow)
    if (domain) filter.domain = domain;
    if (system) filter.system = system;

    // Category
    if (category) filter.category = category;

    // Client Matter Code - exact match (short numeric codes collide badly
    // with fuzzy number search, so this deliberately gets its own param)
    if (request.query.cmc) filter.cmc = request.query.cmc;

    // Agent (queue is handled above)
    if (request.query.agent) filter.answering_extension = request.query.agent;

    // Answer time (Grade of Service) bucket.
    //
    // Evaluated with $expr against the same formula the stats endpoints use,
    // so this works on historical calls that predate the answer_seconds
    // field. Answered calls only - an unanswered call has no answer time.
    if (request.query.answer_bucket) {
      const b = ANSWER_BUCKET_RANGES[request.query.answer_bucket];
      if (b) {
        filter.is_answered = true;
        const conds = [{ $ne: [ANSWER_CALC_EXPR, null] }];
        if (b.min != null) conds.push({ $gte: [ANSWER_CALC_EXPR, b.min] });
        if (b.max != null) conds.push({ $lt: [ANSWER_CALC_EXPR, b.max] });
        filter.$expr = { $and: conds };
      }
    }

    // Duration range
    if (min_duration) filter.duration_seconds = { ...filter.duration_seconds, $gte: parseFloat(min_duration) };
    if (max_duration) filter.duration_seconds = { ...filter.duration_seconds, $lte: parseFloat(max_duration) };

    // MOS score range
    if (min_mos) filter.avg_mos_score = { ...filter.avg_mos_score, $gte: parseFloat(min_mos) };
    if (max_mos) filter.avg_mos_score = { ...filter.avg_mos_score, $lte: parseFloat(max_mos) };

    // Routing method
    if (routing_method) filter.routing_method = routing_method;

    // Transfer type
    if (transfer_type) filter.transfer_type = transfer_type;
    if (request.query.forwarded === "true") filter.is_forwarded = true;
    if (request.query.abandoned === "true") filter.is_abandoned = true;
    if (request.query.abandoned === "false") filter.is_abandoned = { $ne: true };
    if (request.query.from_country) filter.from_country = request.query.from_country;
    if (request.query.to_country) filter.to_country = request.query.to_country;

    // Date range (Unix timestamps or ISO strings)
    if (start_from || start_to) {
      filter.start = {};
      if (start_from) {
        const from = isNaN(start_from) ? new Date(start_from).getTime() / 1000 : parseFloat(start_from);
        filter.start.$gte = from;
      }
      if (start_to) {
        const to = isNaN(start_to) ? new Date(start_to).getTime() / 1000 : parseFloat(start_to);
        filter.start.$lte = to;
      }
    }

    // Full text search across multiple fields
    if (search) {
      filter.$or = [
        { from_number_raw: { $regex: search, $options: "i" } },
        { from_number_e164: { $regex: search, $options: "i" } },
        { from_display_name: { $regex: search, $options: "i" } },
        { to_number_raw: { $regex: search, $options: "i" } },
        { to_number_e164: { $regex: search, $options: "i" } },
        { to_display_name: { $regex: search, $options: "i" } },
        { answering_extension: { $regex: search, $options: "i" } },
        { answering_extension_name: { $regex: search, $options: "i" } },
        { accounts_search: { $regex: search, $options: "i" } },
        { answering_queue_name: { $regex: search, $options: "i" } },
        { callid: { $regex: search, $options: "i" } },
        { comment: { $regex: search, $options: "i" } },
        { category: { $regex: search, $options: "i" } },
      ];
    }

    // Pagination
    const pageNum = Math.max(1, parseInt(page));
    const pageSize = Math.min(200, Math.max(1, parseInt(limit)));
    const skip = (pageNum - 1) * pageSize;

    // Sort
    const sortField = ["start", "duration_seconds", "talk_seconds", "avg_mos_score", "answer_seconds", "ingested_at"]
      .includes(sort_by) ? sort_by : "start";
    const sortDir = sort_order === "asc" ? 1 : -1;

    // Projection — exclude heavy arrays for list view
    const projection = {
      logs: 0,
      trunklegs: 0,
      extensionlegs: 0,
      recordings_raw: 0,
    };

    const [calls, total] = await Promise.all([
      db.collection("calls")
        .find(filter, { projection })
        .sort({ [sortField]: sortDir })
        .skip(skip)
        .limit(pageSize)
        .toArray(),
      db.collection("calls").countDocuments(filter),
    ]);

    return {
      calls: calls.map(c => (
        c.answer_seconds != null ? c : { ...c, answer_seconds: answerSecondsFor(c) }
      )),
      pagination: {
        page: pageNum,
        limit: pageSize,
        total,
        pages: Math.ceil(total / pageSize),
      },
    };
  });

  // ── Get Call Detail ─────────────────────────────────
  app.get("/api/calls/:id", {
    preHandler: requireAuth,
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    const scopeFilter = buildTenantFilter(request);

    let filter;
    try {
      filter = { _id: new ObjectId(request.params.id), ...scopeFilter };
    } catch {
      // Try by callid instead of _id
      filter = { callid: request.params.id, ...scopeFilter };
    }

    const call = await db.collection("calls").findOne(filter);
    if (!call) {
      return reply.code(404).send({ error: "Call not found" });
    }

    // Attach recordings
    const recordings = await db.collection("recordings")
      .find({
        system: call.system,
        domain: call.domain,
        callid: call.callid,
        upload_status: "completed",
      })
      .toArray();

    // Cold payload lives in call_details. Fall back to the inline fields
    // for calls not yet migrated -- this is what makes the backfill
    // zero-downtime, and it is kept permanently so migration order and
    // partial migrations are both safe.
    let detail = null;
    try {
      detail = await db.collection("call_details").findOne({
        system: call.system,
        domain: call.domain,
        callid: call.callid,
      });
    } catch { /* fall through to inline */ }

    const cold = detail || {};
    const legs = {
      trunklegs: cold.trunklegs || call.trunklegs || [],
      extensionlegs: cold.extensionlegs || call.extensionlegs || [],
      recordings_raw: cold.recordings_raw || call.recordings_raw || [],
      logs: cold.logs || call.logs || [],
      logs_stored: detail ? cold.logs_stored !== false : undefined,
    };

    const base = call.answer_seconds != null
      ? call
      : { ...call, answer_seconds: answerSecondsFor(call) };

    // Playback is token-gated; mint a signed short-lived URL per recording
    return {
      call: { ...base, ...legs },
      recordings: recordings.map((r) => ({ ...r, play_url: buildPlayUrl(r._id) })),
    };
  });
}
