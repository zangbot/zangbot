import { logAudit, AUDIT } from "../services/audit.js";
/**
 * Data Retention Routes
 *
 * PUT  /api/tenants/:id/retention   — Set retention policy
 * POST /api/admin/purge-number      — GDPR-style purge by phone number
 * POST /api/admin/run-retention     — Manually trigger retention sweep
 */

import { requireAuth, requireRole } from "../middleware/authenticate.js";

export default async function retentionRoutes(app) {
  const { db } = app;

  // ── Set retention policy per tenant ─────────────────
  app.put("/api/tenants/:id/retention", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try { id = new ObjectId(request.params.id); } catch { return reply.code(400).send({ error: "Invalid ID" }); }

    const { data_retention_days } = request.body || {};
    const days = parseInt(data_retention_days);

    if (isNaN(days) || days < 0) {
      return reply.code(400).send({ error: "data_retention_days must be 0 (forever) or a positive number" });
    }

    await db.collection("tenants").updateOne(
      { _id: id },
      { $set: { data_retention_days: days, updated_at: new Date() } }
    );

    logAudit(db, { action: "retention_updated", category: AUDIT.RETENTION, actor: request.user.email, actor_id: request.user.userId, target: request.params.id, ip: request.ip, details: { data_retention_days: days } });
    return { message: "Retention policy updated", data_retention_days: days };
  });

  // ── GDPR-style purge by phone number ────────────────
  app.post("/api/admin/purge-number", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { number } = request.body || {};
    if (!number || number.length < 3) {
      return reply.code(400).send({ error: "Phone number required (min 3 chars)" });
    }

    app.log.info({ number, by: request.user.email }, "GDPR purge initiated");
    logAudit(db, { action: "gdpr_purge", category: AUDIT.RETENTION, actor: request.user.email, actor_id: request.user.userId, ip: request.ip, details: { number } });

    // Find all calls matching this number
    const calls = await db.collection("calls").find({
      $or: [
        { from_number_raw: { $regex: number, $options: "i" } },
        { from_number_e164: { $regex: number, $options: "i" } },
        { to_number_raw: { $regex: number, $options: "i" } },
        { to_number_e164: { $regex: number, $options: "i" } },
      ],
    }, { projection: { callid: 1, system: 1, domain: 1, recording_keys: 1 } }).toArray();

    const callids = calls.map(c => c.callid);
    const recordingKeys = calls.flatMap(c => c.recording_keys || []);

    // Delete recordings from MinIO
    let minioDeleted = 0;
    if (recordingKeys.length > 0) {
      try {
        const { deleteRecording } = await import("../services/storage.js");
        // Look up per-recording backend
        const recs = await db.collection("recordings").find(
          { callid: { $in: callids } }, { projection: { storage_key: 1, storage_backend: 1 } }
        ).toArray();
        const backendMap = {};
        for (const r of recs) { if (r.storage_key) backendMap[r.storage_key] = r.storage_backend || "minio"; }
        for (const key of recordingKeys) {
          try {
            await deleteRecording(key, backendMap[key] || "minio");
            minioDeleted++;
          } catch { /* ignore missing */ }
        }
      } catch (err) {
        app.log.error(err, "Failed to delete some MinIO objects");
      }
    }

    // Delete from MongoDB
    const recResult = await db.collection("recordings").deleteMany({ callid: { $in: callids } });
    const transResult = await db.collection("transcripts").deleteMany({ callid: { $in: callids } });
    const callResult = await db.collection("calls").deleteMany({ callid: { $in: callids } });

    const result = {
      number,
      calls_deleted: callResult.deletedCount,
      recordings_deleted: recResult.deletedCount,
      transcripts_deleted: transResult.deletedCount,
      minio_files_deleted: minioDeleted,
    };

    app.log.info(result, "GDPR purge completed");
    return result;
  });

  // ── Manual retention sweep ──────────────────────────
  app.post("/api/admin/run-retention", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    logAudit(db, { action: "retention_sweep", category: AUDIT.RETENTION, actor: request.user.email, actor_id: request.user.userId, ip: request.ip });
    const result = await runRetentionSweep(db, app.log);
    return result;
  });
}

/**
 * Run retention sweep — deletes data older than tenant's retention policy.
 * Called by cron job or manual trigger.
 */
export async function runRetentionSweep(db, logger) {
  const tenants = await db.collection("tenants")
    .find({ data_retention_days: { $gt: 0 } })
    .toArray();

  if (tenants.length === 0) {
    logger.info("No tenants with retention policy — skipping");
    return { message: "No retention policies configured", deleted: 0 };
  }

  let totalDeleted = 0;
  const results = [];

  for (const tenant of tenants) {
    const cutoffDate = new Date(Date.now() - tenant.data_retention_days * 24 * 60 * 60 * 1000);
    const cutoffEpoch = cutoffDate.getTime() / 1000;

    const filter = {
      system: tenant.system,
      domain: tenant.domain,
      start: { $lt: cutoffEpoch },
    };

    // Find calls to delete (for recording cleanup)
    const expiredCalls = await db.collection("calls").find(
      filter,
      { projection: { callid: 1, recording_keys: 1 } }
    ).toArray();

    if (expiredCalls.length === 0) continue;

    const callids = expiredCalls.map(c => c.callid);
    const recordingKeys = expiredCalls.flatMap(c => c.recording_keys || []);

    // Delete MinIO recordings
    let minioDeleted = 0;
    if (recordingKeys.length > 0) {
      try {
        const { deleteRecording } = await import("../services/storage.js");
        const recs2 = await db.collection("recordings").find(
          { callid: { $in: callids } }, { projection: { storage_key: 1, storage_backend: 1 } }
        ).toArray();
        const bMap = {};
        for (const r of recs2) { if (r.storage_key) bMap[r.storage_key] = r.storage_backend || "minio"; }
        for (const key of recordingKeys) {
          try { await deleteRecording(key, bMap[key] || "minio"); minioDeleted++; } catch { }
        }
      } catch { }
    }

    // Delete from MongoDB
    const recDel = await db.collection("recordings").deleteMany({ callid: { $in: callids } });
    const transDel = await db.collection("transcripts").deleteMany({ callid: { $in: callids } });
    const callDel = await db.collection("calls").deleteMany(filter);

    const tenantResult = {
      tenant: tenant.domain,
      retention_days: tenant.data_retention_days,
      cutoff: cutoffDate.toISOString(),
      calls_deleted: callDel.deletedCount,
      recordings_deleted: recDel.deletedCount,
      transcripts_deleted: transDel.deletedCount,
      minio_deleted: minioDeleted,
    };

    results.push(tenantResult);
    totalDeleted += callDel.deletedCount;
    logger.info(tenantResult, "Retention sweep for tenant");
  }

  return { message: "Retention sweep complete", total_deleted: totalDeleted, tenants: results };
}
