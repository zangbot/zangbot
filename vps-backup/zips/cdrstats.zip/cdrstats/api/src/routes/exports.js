import { requireAuth } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";

export default async function exportRoutes(app) {
  const { db } = app;

  // Export calls as CSV
  app.get("/api/export/calls", { preHandler: requireAuth }, async (request, reply) => {
    const scopeFilter = buildTenantFilter(request);
    const { start_from, start_to, direction, answered, search, domain } = request.query;

    const filter = { ...scopeFilter };
    if (domain) filter.domain = domain;
    if (direction) filter.call_direction_origin = direction;
    if (answered === "true") filter.is_answered = true;
    if (answered === "false") filter.is_answered = false;
    if (start_from || start_to) {
      filter.start = {};
      if (start_from) filter.start.$gte = parseFloat(start_from);
      if (start_to) filter.start.$lte = parseFloat(start_to);
    }
    if (search) {
      filter.$or = [
        { from_number_raw: { $regex: search, $options: "i" } },
        { from_display_name: { $regex: search, $options: "i" } },
        { to_number_raw: { $regex: search, $options: "i" } },
        { to_display_name: { $regex: search, $options: "i" } },
        { answering_extension_name: { $regex: search, $options: "i" } },
      ];
    }

    const calls = await db.collection("calls")
      .find(filter, { projection: { logs: 0, trunklegs: 0, extensionlegs: 0, recordings_raw: 0 } })
      .sort({ start: -1 }).limit(10000).toArray();

    const header = "Date/Time,From Name,From Number,To Name,To Number,Duration (s),Talk Time (s),Answer Time (s),Direction,Status,Routing,Queue,Agent,MOS,Category,CMC,Rating,Comment,Domain,Call ID\n";
    const rows = calls.map(c => {
      const dt = c.start ? new Date(c.start * 1000).toISOString() : "";
      const status = c.is_answered ? "Answered" : c.is_abandoned ? "Abandoned" : "Missed";
      return [dt, c.from_display_name, c.from_number_raw, c.to_display_name, c.to_number_raw,
        Math.round(c.duration_seconds || 0), Math.round(c.talk_seconds || 0),
        c.answer_seconds != null ? Math.round(c.answer_seconds) : "",
        c.call_direction, status, c.routing_method, c.answering_queue_name || "",
        c.answering_extension_name || "", c.avg_mos_score || "",
        c.category || "", c.cmc || "", c.rating || "", c.comment || "",
        c.domain, c.callid
      ].map(f => `"${(f ?? "").toString().replace(/"/g, '""')}"`).join(",");
    }).join("\n");

    reply.header("Content-Type", "text/csv");
    reply.header("Content-Disposition", `attachment; filename="calls-export-${Date.now()}.csv"`);
    return header + rows;
  });

  // Export agents as CSV
  app.get("/api/export/agents", { preHandler: requireAuth }, async (request, reply) => {
    const scopeFilter = buildTenantFilter(request);
    const { start_from, start_to, domain } = request.query;
    const filter = { ...scopeFilter, answering_extension: { $ne: null } };
    if (domain) filter.domain = domain;
    if (start_from || start_to) {
      filter.start = {};
      if (start_from) filter.start.$gte = parseFloat(start_from);
      if (start_to) filter.start.$lte = parseFloat(start_to);
    }

    const pipeline = [
      { $match: filter },
      { $group: {
        _id: { ext: "$answering_extension", name: "$answering_extension_name" },
        calls: { $sum: 1 }, inbound: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "inbound"] }, 1, 0] } },
        outbound: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "outbound"] }, 1, 0] } },
        total_talk: { $sum: "$talk_seconds" }, avg_talk: { $avg: "$talk_seconds" },
        avg_hold: { $avg: "$hold_time_seconds" }, avg_mos: { $avg: "$avg_mos_score" },
      }},
      { $sort: { calls: -1 } },
    ];

    const agents = await db.collection("calls").aggregate(pipeline).toArray();
    const header = "Agent,Extension,Calls,Inbound,Outbound,Total Talk (s),Avg Talk (s),Avg Hold (s),MOS\n";
    const rows = agents.map(a =>
      [a._id.name, a._id.ext, a.calls, a.inbound, a.outbound,
        Math.round(a.total_talk), Math.round(a.avg_talk || 0), Math.round(a.avg_hold || 0), a.avg_mos?.toFixed(2) || ""
      ].map(f => `"${f}"`).join(",")
    ).join("\n");

    reply.header("Content-Type", "text/csv");
    reply.header("Content-Disposition", `attachment; filename="agents-export-${Date.now()}.csv"`);
    return header + rows;
  });

  // Export queues as CSV
  app.get("/api/export/queues", { preHandler: requireAuth }, async (request, reply) => {
    const scopeFilter = buildTenantFilter(request);
    const { start_from, start_to, domain } = request.query;
    const filter = { ...scopeFilter, answering_queue: { $ne: null } };
    if (domain) filter.domain = domain;
    if (start_from || start_to) {
      filter.start = {};
      if (start_from) filter.start.$gte = parseFloat(start_from);
      if (start_to) filter.start.$lte = parseFloat(start_to);
    }

    const pipeline = [
      { $match: filter },
      { $group: {
        _id: { q: "$answering_queue", name: "$answering_queue_name" },
        calls: { $sum: 1 }, answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
        abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
        avg_wait: { $avg: "$queue_wait_seconds" }, avg_talk: { $avg: "$talk_seconds" },
        avg_mos: { $avg: "$avg_mos_score" },
      }},
      { $sort: { calls: -1 } },
    ];

    const queues = await db.collection("calls").aggregate(pipeline).toArray();
    const header = "Queue,ID,Calls,Answered,Abandoned,Abandon %,Avg Wait (s),Avg Talk (s),MOS\n";
    const rows = queues.map(q => {
      const rate = q.calls > 0 ? Math.round(q.abandoned / q.calls * 100) : 0;
      return [q._id.name, q._id.q, q.calls, q.answered, q.abandoned, rate,
        Math.round(q.avg_wait || 0), Math.round(q.avg_talk || 0), q.avg_mos?.toFixed(2) || ""
      ].map(f => `"${f}"`).join(",");
    }).join("\n");

    reply.header("Content-Type", "text/csv");
    reply.header("Content-Disposition", `attachment; filename="queues-export-${Date.now()}.csv"`);
    return header + rows;
  });

  app.get("/api/export/numbers", { preHandler: requireAuth }, async (request, reply) => {
    const scopeFilter = buildTenantFilter(request);
    const { start_from, start_to, domain } = request.query;
    const filter = {
      ...scopeFilter,
      $or: [
        { has_trunk_leg: true },
        { has_trunk_leg: { $exists: false }, "trunklegs.0": { $exists: true } },
      ],
    };
    if (domain) filter.domain = domain;
    if (start_from) filter.start = { ...(filter.start || {}), $gte: parseFloat(start_from) };
    if (start_to) filter.start = { ...(filter.start || {}), $lte: parseFloat(start_to) };
    const calls = db.collection("calls");

    const inboundDids = await calls.aggregate([
      { $match: { ...filter, call_direction_origin: "inbound", to_is_internal: false } },
      { $group: { _id: "$to_number_raw", count: { $sum: 1 }, name: { $first: "$to_display_name" }, answered: { $sum: { $cond: ["$is_answered", 1, 0] } }, total_talk: { $sum: "$talk_seconds" } } },
      { $match: { _id: { $ne: null } } },
      { $sort: { count: -1 } },
    ]).toArray();

    const outboundDialed = await calls.aggregate([
      { $match: { ...filter, call_direction_origin: "outbound", to_is_internal: false } },
      { $group: { _id: "$to_number_raw", count: { $sum: 1 }, name: { $first: "$to_display_name" }, answered: { $sum: { $cond: ["$is_answered", 1, 0] } }, total_talk: { $sum: "$talk_seconds" } } },
      { $match: { _id: { $ne: null } } },
      { $sort: { count: -1 } },
    ]).toArray();

    const inboundCallers = await calls.aggregate([
      { $match: { ...filter, call_direction_origin: "inbound", from_is_internal: false } },
      { $group: { _id: "$from_number_raw", count: { $sum: 1 }, name: { $first: "$from_display_name" }, answered: { $sum: { $cond: ["$is_answered", 1, 0] } }, total_talk: { $sum: "$talk_seconds" } } },
      { $match: { _id: { $ne: null } } },
      { $sort: { count: -1 } },
    ]).toArray();

    const rows = [];
    rows.push("Category,Number,Name,Calls,Answered,Talk Time (s)");
    for (const r of inboundDids) rows.push(`Inbound DID,"${r._id}","${r.name || ""}",${r.count},${r.answered},${Math.round((r.total_talk || 0) * 100) / 100}`);
    for (const r of outboundDialed) rows.push(`Outbound Dialed,"${r._id}","${r.name || ""}",${r.count},${r.answered},${Math.round((r.total_talk || 0) * 100) / 100}`);
    for (const r of inboundCallers) rows.push(`Inbound Caller,"${r._id}","${r.name || ""}",${r.count},${r.answered},${Math.round((r.total_talk || 0) * 100) / 100}`);

    reply.header("Content-Type", "text/csv");
    reply.header("Content-Disposition", `attachment; filename="numbers-export-${Date.now()}.csv"`);
    return rows.join("\n");
  });

}
