/**
 * Compliance Suite API Routes
 *
 * Rules:      GET/POST /api/compliance/rules, PUT/DELETE /api/compliance/rules/:id
 * Settings:   GET/PUT  /api/compliance/settings   (redaction + QA per tenant or global)
 * Stats:      GET /api/compliance/stats, GET /api/compliance/violations
 * QA:         GET /api/compliance/qa/leaderboard, POST /api/compliance/qa/:callid
 * Backfill:   POST /api/compliance/reevaluate     (queues throttled BullMQ jobs)
 */

import { requireAuth, requireRole } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";
import { logAudit, AUDIT } from "../services/audit.js";
import { getComplianceSettings, DEFAULT_COMPLIANCE_SETTINGS } from "../services/compliance-shared.js";

const SEVERITIES = ["low", "medium", "high", "critical"];
const RULE_TYPES = ["required_phrase", "prohibited_phrase"];
const MATCH_MODES = ["contains", "regex", "ai"];

const PRESET_PACKS = {
  general: [
    { name: "Recording disclosure", type: "required_phrase", match_mode: "ai", ai_description: "The caller is informed that the call is recorded or monitored (any wording counts)", window_seconds: 60, severity: "high" },
    { name: "Greeting with name/company", type: "required_phrase", match_mode: "ai", ai_description: "The agent greets the caller and states their own name and/or the company name", window_seconds: 30, severity: "medium" },
    { name: "Agent profanity or hostility", type: "prohibited_phrase", match_mode: "ai", ai_description: "The agent uses profanity, insults, or a hostile/dismissive tone toward the caller", severity: "critical" },
    { name: "Caller abuse flag", type: "prohibited_phrase", match_mode: "ai", ai_description: "The caller uses profanity, threats, or verbally abusive language toward the agent", severity: "medium" },
    { name: "No outcome guarantees", type: "prohibited_phrase", match_mode: "ai", ai_description: "The agent guarantees a specific outcome, result, refund, or approval that cannot be assured", severity: "high" },
    { name: "Offer of further assistance", type: "required_phrase", match_mode: "ai", ai_description: "Before ending the call, the agent asks if there is anything else they can help with or offers further assistance", severity: "low" },
    { name: "Profanity wordlist", type: "prohibited_phrase", match_mode: "regex", pattern: "\\b(fuck\\w*|shit\\w*|bullshit|bitch\\w*|asshole|arsehole|bastard|dickhead|cunt|wanker)\\b", severity: "high" },
  ],
  collections: [
    { name: "Mini-Miranda disclosure", type: "required_phrase", match_mode: "ai", ai_description: "The agent states that the call is an attempt to collect a debt and that any information obtained will be used for that purpose", window_seconds: 90, severity: "critical" },
    { name: "Recording disclosure", type: "required_phrase", match_mode: "ai", ai_description: "The caller is informed that the call is recorded or monitored", window_seconds: 60, severity: "high" },
    { name: "No false legal/arrest threats", type: "prohibited_phrase", match_mode: "ai", ai_description: "The agent threatens arrest, jail, wage garnishment, or legal action that is not actually intended or legally permitted", severity: "critical" },
    { name: "No third-party debt disclosure", type: "prohibited_phrase", match_mode: "ai", ai_description: "The agent discloses the existence of a debt to someone other than the debtor or their authorized representative", severity: "critical" },
    { name: "No harassment or intimidation", type: "prohibited_phrase", match_mode: "ai", ai_description: "The agent uses harassing, oppressive, or intimidating language, or threatens repeated contact", severity: "high" },
  ],
  payments: [
    { name: "Payment consent obtained", type: "required_phrase", match_mode: "ai", ai_description: "The agent confirms the payment amount and obtains the caller's explicit consent before processing the payment", severity: "high" },
    { name: "No read-back of full card number", type: "prohibited_phrase", match_mode: "ai", ai_description: "The agent reads back or repeats the caller's full card number aloud", severity: "high" },
    { name: "Never request PIN or password", type: "prohibited_phrase", match_mode: "ai", ai_description: "The agent asks the caller for their card PIN, online banking password, or one-time security code", severity: "critical" },
    { name: "Payment confirmation offered", type: "required_phrase", match_mode: "ai", ai_description: "The agent confirms the payment was processed and/or offers a receipt or confirmation number", severity: "low" },
  ],
};


function buildDateFilter(request, base = {}) {
  const filter = { ...base };
  const { start_from, start_to, domain } = request.query;
  if (domain && !filter.domain) filter.domain = domain;
  if (start_from || start_to) {
    filter.start = {};
    if (start_from) {
      const v = parseFloat(start_from);
      filter.start.$gte = v > 946684800 ? v : new Date(start_from).getTime() / 1000;
    }
    if (start_to) {
      const v = parseFloat(start_to);
      filter.start.$lte = v > 946684800 ? v : new Date(start_to).getTime() / 1000;
    }
  }
  return filter;
}

function allowedDomains(tf) {
  // super_admin -> null (unrestricted); scoped -> explicit list
  if (!tf || !tf.domain) return null;
  if (typeof tf.domain === "string") return [tf.domain];
  if (Array.isArray(tf.domain.$in)) return tf.domain.$in;
  return [];
}

async function resolveScope(db, request, domainOverride) {
  const tf = buildTenantFilter(request);
  const allowed = allowedDomains(tf); // null = unrestricted (super admin)
  let domain = domainOverride || null;

  if (allowed) {
    // Scoped user: requested domain must be within their allowed tenants
    if (domain && !allowed.includes(domain)) domain = null;
    // Single-tenant users default to their tenant
    if (!domain && allowed.length === 1) domain = allowed[0];
  }

  if (!domain) return { system: null, domain: null, restricted: !!allowed };
  const tenant = await db.collection("tenants").findOne({ domain });
  return { system: tenant?.system ?? null, domain, restricted: !!allowed };
}

function sanitizeRule(body) {
  const rule = {
    name: String(body.name || "").slice(0, 120).trim(),
    type: RULE_TYPES.includes(body.type) ? body.type : "required_phrase",
    match_mode: MATCH_MODES.includes(body.match_mode) ? body.match_mode : "contains",
    pattern: String(body.pattern || "").slice(0, 500),
    ai_description: String(body.ai_description || "").slice(0, 500),
    channel: ["any", "channel_0", "channel_1"].includes(body.channel) ? body.channel : "any",
    window_seconds: Math.max(0, Math.min(3600, parseInt(body.window_seconds) || 0)),
    severity: SEVERITIES.includes(body.severity) ? body.severity : "medium",
    direction: ["any", "inbound", "outbound", "internal"].includes(body.direction) ? body.direction : "any",
    queue: body.queue ? String(body.queue).slice(0, 60) : null,
    extension: body.extension ? String(body.extension).slice(0, 60) : null,
    enabled: body.enabled !== false,
  };
  if (rule.match_mode === "regex") {
    try { new RegExp(rule.pattern); } catch { throw new Error("Invalid regex pattern"); }
  }
  if (!rule.name) throw new Error("Rule name is required");
  if (rule.match_mode !== "ai" && !rule.pattern) throw new Error("Pattern is required");
  if (rule.match_mode === "ai" && !rule.ai_description) throw new Error("AI description is required for AI match mode");
  return rule;
}

export default async function complianceRoutes(app) {
  const { db } = app;

  // -- Rules CRUD --------------------------------------

  app.get("/api/compliance/rules", { preHandler: requireAuth }, async (request) => {
    const scope = await resolveScope(db, request, request.query.domain);
    const query = scope.domain
      ? { $or: [{ system: scope.system, domain: scope.domain }, { scope: "global" }] }
      : {};
    const rules = await db.collection("compliance_rules").find(query).sort({ created_at: -1 }).toArray();
    return { rules };
  });

  app.post("/api/compliance/rules", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    let rule;
    try { rule = sanitizeRule(request.body || {}); } catch (e) { return reply.code(400).send({ error: e.message }); }

    const wantGlobal = request.body?.scope === "global";
    if (wantGlobal && request.user.role !== "super_admin") {
      return reply.code(403).send({ error: "Only super admins can create global rules" });
    }
    const scope = wantGlobal
      ? { scope: "global", system: null, domain: null }
      : { scope: "tenant", ...(await resolveScope(db, request, request.body?.domain)) };
    if (scope.scope === "tenant" && !scope.domain) {
      return reply.code(400).send({ error: "Select a tenant (domain) for tenant-scoped rules" });
    }

    const doc = { ...rule, ...scope, created_by: request.user.email, created_at: new Date() };
    const result = await db.collection("compliance_rules").insertOne(doc);
    logAudit(db, { action: "compliance_rule_created", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, target: rule.name, ip: request.ip, details: { type: rule.type, severity: rule.severity } });
    return { message: "Rule created", id: result.insertedId.toString() };
  });

  app.put("/api/compliance/rules/:id", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id; try { id = new ObjectId(request.params.id); } catch { return reply.code(400).send({ error: "Invalid ID" }); }

    let rule;
    try { rule = sanitizeRule(request.body || {}); } catch (e) { return reply.code(400).send({ error: e.message }); }

    const existing = await db.collection("compliance_rules").findOne({ _id: id });
    if (!existing) return reply.code(404).send({ error: "Rule not found" });
    if (existing.scope === "global" && request.user.role !== "super_admin") {
      return reply.code(403).send({ error: "Only super admins can edit global rules" });
    }

    await db.collection("compliance_rules").updateOne({ _id: id }, { $set: { ...rule, updated_at: new Date() } });
    logAudit(db, { action: "compliance_rule_updated", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, target: rule.name, ip: request.ip });
    return { message: "Rule updated" };
  });

  app.delete("/api/compliance/rules/:id", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id; try { id = new ObjectId(request.params.id); } catch { return reply.code(400).send({ error: "Invalid ID" }); }

    const existing = await db.collection("compliance_rules").findOne({ _id: id });
    if (!existing) return reply.code(404).send({ error: "Rule not found" });
    if (existing.scope === "global" && request.user.role !== "super_admin") {
      return reply.code(403).send({ error: "Only super admins can delete global rules" });
    }

    await db.collection("compliance_rules").deleteOne({ _id: id });
    logAudit(db, { action: "compliance_rule_deleted", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, target: existing.name, ip: request.ip });
    return { message: "Rule deleted" };
  });

  app.post("/api/compliance/rules/preset", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    const { pack } = request.body || {};
    const preset = PRESET_PACKS[pack];
    if (!preset) return reply.code(400).send({ error: "Unknown preset pack" });

    const scope = await resolveScope(db, request, request.body?.domain);
    if (!scope.domain) return reply.code(400).send({ error: "Select a tenant (domain) to seed preset rules" });

    const existing = await db.collection("compliance_rules")
      .find({ system: scope.system, domain: scope.domain }).project({ name: 1 }).toArray();
    const have = new Set(existing.map(r => r.name));

    const docs = preset.filter(r => !have.has(r.name)).map(r => ({
      match_mode: "ai", pattern: "", ai_description: "", channel: "any",
      window_seconds: 0, direction: "any", queue: null, extension: null, enabled: true,
      ...r,
      scope: "tenant", system: scope.system, domain: scope.domain,
      created_by: request.user.email, created_at: new Date(), preset: pack,
    }));

    if (docs.length > 0) await db.collection("compliance_rules").insertMany(docs);
    logAudit(db, { action: "compliance_preset_seeded", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, target: pack + " -> " + scope.domain, ip: request.ip, details: { created: docs.length, skipped: preset.length - docs.length } });
    return { message: docs.length + " rule(s) added from preset (" + (preset.length - docs.length) + " skipped — already exist)", created: docs.length };
  });

  // -- Settings (redaction + QA) -----------------------

  app.get("/api/compliance/settings", { preHandler: requireAuth }, async (request) => {
    const scope = await resolveScope(db, request, request.query.domain);
    const settings = await getComplianceSettings(db, scope.system, scope.domain);
    return { scope, settings, defaults: DEFAULT_COMPLIANCE_SETTINGS };
  });

  app.put("/api/compliance/settings", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    const scope = await resolveScope(db, request, request.body?.domain);
    if (scope.restricted && !scope.domain) {
      return reply.code(403).send({ error: "Select one of your tenants — only super admins can edit the global defaults" });
    }
    const { redaction, qa } = request.body || {};
    const $set = { updated_at: new Date(), updated_by: request.user.email };

    if (redaction) {
      $set["redaction.enabled"] = !!redaction.enabled;
      if (redaction.strict_digits != null) $set["redaction.strict_digits"] = Math.max(0, Math.min(30, parseInt(redaction.strict_digits) || 0));
      if (redaction.categories) {
        for (const k of ["card", "cvv", "ssn", "email", "dob"]) {
          if (redaction.categories[k] != null) $set["redaction.categories." + k] = !!redaction.categories[k];
        }
      }
    }
    if (qa) {
      if (qa.sampling_pct != null) $set["qa.sampling_pct"] = Math.max(0, Math.min(100, parseInt(qa.sampling_pct) || 0));
      if (Array.isArray(qa.rubric)) {
        const rubric = qa.rubric
          .filter(r => r && r.label)
          .slice(0, 12)
          .map((r, i) => ({
            key: String(r.key || "cat_" + i).replace(/[^a-z0-9_]/gi, "_").slice(0, 40),
            label: String(r.label).slice(0, 80),
            weight: Math.max(1, Math.min(100, parseInt(r.weight) || 10)),
          }));
        $set["qa.rubric"] = rubric;
      }
    }

    await db.collection("compliance_settings").updateOne(
      { system: scope.system, domain: scope.domain },
      { $set, $setOnInsert: { system: scope.system, domain: scope.domain, created_at: new Date() } },
      { upsert: true }
    );
    logAudit(db, { action: "compliance_settings_saved", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, target: scope.domain || "global", ip: request.ip });
    return { message: "Compliance settings saved", scope };
  });

  // -- Stats -------------------------------------------

  app.get("/api/compliance/stats", { preHandler: requireAuth }, async (request) => {
    const tf = buildTenantFilter(request);
    const filter = buildDateFilter(request, tf);
    const evalFilter = { ...filter, "compliance.evaluated_at": { $exists: true } };

    const [summary] = await db.collection("calls").aggregate([
      { $match: evalFilter },
      { $group: {
        _id: null,
        evaluated: { $sum: 1 },
        avg_score: { $avg: "$compliance_score" },
        passed: { $sum: { $cond: ["$compliance_passed", 1, 0] } },
        violations: { $sum: { $size: { $ifNull: ["$compliance.violations", []] } } },
        unevaluated: { $sum: { $cond: [{ $gt: [{ $size: { $ifNull: ["$compliance.unevaluated", []] } }, 0] }, 1, 0] } },
      } },
    ]).toArray();

    const byRule = await db.collection("calls").aggregate([
      { $match: { ...evalFilter, compliance_passed: false } },
      { $unwind: "$compliance.violations" },
      { $group: { _id: { name: "$compliance.violations.name", severity: "$compliance.violations.severity" }, count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 15 },
    ]).toArray();

    const byExtension = await db.collection("calls").aggregate([
      { $match: { ...evalFilter, compliance_passed: false, answering_extension: { $ne: null } } },
      { $group: { _id: "$answering_extension", name: { $first: "$answering_extension_name" }, violations: { $sum: { $size: { $ifNull: ["$compliance.violations", []] } } } } },
      { $sort: { violations: -1 } },
      { $limit: 10 },
    ]).toArray();

    const [qaSummary] = await db.collection("calls").aggregate([
      { $match: { ...filter, qa_score: { $ne: null } } },
      { $group: { _id: null, scored: { $sum: 1 }, avg_score: { $avg: "$qa_score" } } },
    ]).toArray();

    const s = summary || { evaluated: 0, avg_score: null, passed: 0, violations: 0, unevaluated: 0 };
    return {
      summary: {
        evaluated: s.evaluated,
        avg_score: s.avg_score != null ? Math.round(s.avg_score) : null,
        passed: s.passed,
        pass_rate: s.evaluated > 0 ? Math.round((s.passed / s.evaluated) * 100) : null,
        violations: s.violations,
        unevaluated: s.unevaluated || 0,
      },
      by_rule: byRule.map(r => ({ name: r._id.name, severity: r._id.severity, count: r.count })),
      by_extension: byExtension.map(e => ({ extension: e._id, name: e.name, violations: e.violations })),
      qa: { scored: qaSummary?.scored || 0, avg_score: qaSummary?.avg_score != null ? Math.round(qaSummary.avg_score) : null },
    };
  });

  app.get("/api/compliance/violations", { preHandler: requireAuth }, async (request) => {
    const tf = buildTenantFilter(request);
    const filter = { ...buildDateFilter(request, tf), compliance_passed: false };
    const page = Math.max(1, parseInt(request.query.page) || 1);
    const limit = Math.min(50, parseInt(request.query.limit) || 20);

    const total = await db.collection("calls").countDocuments(filter);
    const calls = await db.collection("calls").find(filter, {
      projection: {
        callid: 1, start: 1, domain: 1, from_number_raw: 1, from_display_name: 1,
        answering_extension: 1, answering_extension_name: 1, answering_queue_name: 1,
        compliance_score: 1, "compliance.violations": 1, qa_score: 1,
      },
    }).sort({ start: -1 }).skip((page - 1) * limit).limit(limit).toArray();

    return { calls, total, page, pages: Math.max(1, Math.ceil(total / limit)) };
  });

  // -- QA ----------------------------------------------

  app.get("/api/compliance/qa/leaderboard", { preHandler: requireAuth }, async (request) => {
    const tf = buildTenantFilter(request);
    const filter = { ...buildDateFilter(request, tf), qa_score: { $ne: null }, answering_extension: { $ne: null } };

    const agents = await db.collection("calls").aggregate([
      { $match: filter },
      { $group: {
        _id: "$answering_extension",
        name: { $first: "$answering_extension_name" },
        avg_score: { $avg: "$qa_score" },
        scored: { $sum: 1 },
        avg_compliance: { $avg: "$compliance_score" },
      } },
      { $sort: { avg_score: -1 } },
      { $limit: 25 },
    ]).toArray();

    return { agents: agents.map(a => ({ extension: a._id, name: a.name, avg_score: Math.round(a.avg_score), scored: a.scored, avg_compliance: a.avg_compliance != null ? Math.round(a.avg_compliance) : null })) };
  });

  app.post("/api/compliance/qa/:callid", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    const scopeFilter = buildTenantFilter(request);
    const call = await db.collection("calls").findOne({ callid: request.params.callid, ...scopeFilter });
    if (!call) return reply.code(404).send({ error: "Call not found" });
    if (!call.has_transcript) return reply.code(400).send({ error: "No transcript available for this call" });

    let qRedis = null;
    try {
      const Redis = (await import("ioredis")).default;
      const { Queue } = await import("bullmq");
      qRedis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
      const queue = new Queue("compliance-eval", { connection: qRedis });
      await queue.add("qa-" + call.callid, { system: call.system, domain: call.domain, callid: call.callid, force_qa: true }, { attempts: 1, removeOnComplete: 100, removeOnFail: 500 });
      return { message: "QA scoring queued", callid: call.callid };
    } catch (err) {
      app.log.error(err, "Failed to queue QA scoring");
      return reply.code(500).send({ error: "Failed to queue QA scoring" });
    } finally {
      if (qRedis) { try { await qRedis.quit(); } catch { /* already gone */ } }
    }
  });

  // -- Backfill / Re-evaluate --------------------------

  app.post("/api/compliance/reevaluate", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    const tf = buildTenantFilter(request);
    const body = request.body || {};
    const filter = { ...tf, has_transcript: true };
    if (body.domain && !filter.domain) filter.domain = body.domain;
    if (body.start_from || body.start_to) {
      filter.start = {};
      if (body.start_from) { const v = parseFloat(body.start_from); filter.start.$gte = v > 946684800 ? v : new Date(body.start_from).getTime() / 1000; }
      if (body.start_to) { const v = parseFloat(body.start_to); filter.start.$lte = v > 946684800 ? v : new Date(body.start_to).getTime() / 1000; }
    }

    const calls = await db.collection("calls").find(filter, { projection: { callid: 1, system: 1, domain: 1 } }).limit(5000).toArray();
    if (calls.length === 0) return { queued: 0, message: "No transcribed calls in range" };

    let bRedis = null;
    try {
      const Redis = (await import("ioredis")).default;
      const { Queue } = await import("bullmq");
      bRedis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
      const queue = new Queue("compliance-eval", { connection: bRedis });
      await queue.addBulk(calls.map(c => ({
        name: "reeval-" + c.callid,
        data: { system: c.system, domain: c.domain, callid: c.callid, force_qa: !!body.include_qa },
        opts: { attempts: 1, removeOnComplete: 1000, removeOnFail: 500 },
      })));
    } catch (err) {
      app.log.error(err, "Failed to queue compliance re-evaluation");
      return reply.code(500).send({ error: "Failed to queue re-evaluation" });
    } finally {
      if (bRedis) { try { await bRedis.quit(); } catch { /* already gone */ } }
    }

    logAudit(db, { action: "compliance_reevaluate", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, ip: request.ip, details: { queued: calls.length, include_qa: !!body.include_qa } });
    return { queued: calls.length, message: calls.length + " calls queued for evaluation (throttled)" };
  });
}
