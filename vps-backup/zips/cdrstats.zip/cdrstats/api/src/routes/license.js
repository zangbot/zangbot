import { requireAuth } from "../middleware/authenticate.js";
import { getLicenseStatus, refreshExtensionCount } from "../services/licenseService.js";
import { isCloudMode } from "../config/plans.js";

export default async function licenseRoutes(app) {
  app.get("/api/license", { preHandler: requireAuth }, async (req, reply) => {
    if (!isCloudMode()) return reply.send({ mode: "self_hosted" });
    try {
      const status = await getLicenseStatus(app.db, app.redis);
      return reply.send(status);
    } catch (err) {
      app.log.error(err, "Failed to get license status");
      return reply.code(500).send({ error: "License check failed" });
    }
  });

  app.post("/api/license/refresh", { preHandler: requireAuth }, async (req, reply) => {
    if (!isCloudMode()) return reply.send({ mode: "self_hosted" });
    try {
      await refreshExtensionCount(app.db, app.redis);
      const status = await getLicenseStatus(app.db, app.redis);
      return reply.send(status);
    } catch (err) {
      app.log.error(err, "Failed to refresh license count");
      return reply.code(500).send({ error: "Refresh failed" });
    }
  });
}
