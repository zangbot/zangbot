import { requireAuthOrInternal } from "../middleware/internal.js";
/**
 * Statistics / Analytics Routes
 *
 * GET /api/stats/overview     — KPI dashboard
 * GET /api/stats/hourly       — Hourly call distribution
 * GET /api/stats/daily        — Daily call volume
 * GET /api/stats/agents       — Agent performance table
 * GET /api/stats/queues       — Queue analytics
 * GET /api/stats/directions   — Call direction breakdown
 * GET /api/stats/quality      — MOS quality distribution
 * GET /api/stats/countries    — Geographic breakdown
 *
 * All endpoints accept ?start_from=&start_to= for date range
 * and are automatically tenant-scoped.
 */

import { requireAuth } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";

/**
 * Queue filter value -> Mongo match.
 *
 * The Queues page can select several queues at once and sends them as a
 * comma-separated list. A single value still matches exactly, so existing
 * deep links and saved dashboards behave as before.
 */
function queueMatch(queue) {
  const list = String(queue).split(",").map((s) => s.trim()).filter(Boolean);
  if (list.length === 0) return null;
  return list.length > 1 ? { $in: list } : list[0];
}

/**
 * Build a date-range + tenant filter from request query params.
 */
function buildDateFilter(request) {
  const scope = buildTenantFilter(request);
  const { start_from, start_to, domain, system, queue } = request.query;

  const filter = { ...scope };

  if (start_from || start_to) {
    filter.start = {};
    if (start_from) {
      const val = parseFloat(start_from);
      // If it looks like a Unix timestamp (> year 2000 in seconds)
      filter.start.$gte = val > 946684800 ? val : new Date(start_from).getTime() / 1000;
    }
    if (start_to) {
      const val = parseFloat(start_to);
      filter.start.$lte = val > 946684800 ? val : new Date(start_to).getTime() / 1000;
    }
  }

  if (domain) filter.domain = domain;
  if (system) filter.system = system;
  if (queue) {
    const qm = queueMatch(queue);
    if (qm !== null) filter.answering_queue = qm;
  }

  return filter;
}

export default async function statsRoutes(app) {
  const { db } = app;
  const calls = db.collection("calls");

  /**
   * Time to answer, as an aggregation expression.
   *
   * Prefers the stored answer_seconds (written at ingest since the GoS
   * release) and otherwise recomputes it from fields every call record
   * already carries. That means Grade of Service covers the full history
   * with no backfill, while newer calls take the cheap indexed path.
   *
   * Mirrors computeAnswerSeconds() in api/src/services/ingest.js:
   *   not answered           -> null  (abandoned wait lives in queue_wait_seconds)
   *   acd and queue_wait > 0 -> queue_wait_seconds
   *   otherwise              -> connect - start, or 0 if never connected
   */
  const ANSWER_CALC = {
    $ifNull: [
      "$answer_seconds",
      {
        $cond: [
          { $ne: ["$is_answered", true] },
          null,
          {
            $let: {
              vars: {
                qw: { $ifNull: ["$queue_wait_seconds", 0] },
                cn: { $ifNull: ["$connect", 0] },
                st: { $ifNull: ["$start", 0] },
              },
              in: {
                $cond: [
                  { $and: [{ $eq: ["$routing_method", "acd"] }, { $gt: ["$$qw", 0] }] },
                  "$$qw",
                  {
                    $cond: [
                      { $and: [{ $gt: ["$$cn", 0] }, { $gt: ["$$cn", "$$st"] }] },
                      { $round: [{ $subtract: ["$$cn", "$$st"] }, 2] },
                      0,
                    ],
                  },
                ],
              },
            },
          },
        ],
      },
    ],
  };

/**
 * Merge base filter with additional conditions.
 * If both have the same field, combine with $and.
 */
function mergeFilter(base, extra) {
  const merged = { ...base };
  for (const [key, val] of Object.entries(extra)) {
    if (key in merged) {
      // Both have the same key — combine with $and
      if (!merged.$and) merged.$and = [];
      merged.$and.push({ [key]: merged[key] });
      merged.$and.push({ [key]: val });
      delete merged[key];
    } else {
      merged[key] = val;
    }
  }
  return merged;
}

  // ── Overview KPIs ───────────────────────────────────
  app.get("/api/stats/overview", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = buildDateFilter(request);

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: null,
          total_calls: { $sum: 1 },
          answered_calls: { $sum: { $cond: ["$is_answered", 1, 0] } },
          abandoned_calls: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
          missed_calls: { $sum: { $cond: [{ $and: [{ $ne: ["$is_answered", true] }, { $ne: ["$is_abandoned", true] }] }, 1, 0] } },
          forwarded_calls: { $sum: { $cond: [{ $eq: ["$is_forwarded", true] }, 1, 0] } },
          total_duration: { $sum: "$duration_seconds" },
          total_talk_time: { $sum: "$talk_seconds" },
          avg_duration: { $avg: "$duration_seconds" },
          avg_talk_time: { $avg: "$talk_seconds" },
          avg_mos: { $avg: "$avg_mos_score" },
          max_duration: { $max: "$duration_seconds" },
          min_duration: { $min: { $cond: [{ $gt: ["$duration_seconds", 0] }, "$duration_seconds", null] } },
          calls_with_recording: { $sum: { $cond: ["$has_recording", 1, 0] } },
          inbound_calls: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "inbound"] }, 1, 0] } },
          outbound_calls: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "outbound"] }, 1, 0] } },
          internal_calls: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "internal"] }, 1, 0] } },
          attended_transfers: { $sum: { $cond: [{ $eq: ["$transfer_type", "attended"] }, 1, 0] } },
          blind_transfers: { $sum: { $cond: [{ $eq: ["$transfer_type", "blind"] }, 1, 0] } },
          avg_ring_time: { $avg: "$ring_time_seconds" },
          avg_queue_wait: { $avg: "$queue_wait_seconds" },
          avg_hold_time: { $avg: "$hold_time_seconds" },
          avg_answer_seconds: { $avg: ANSWER_CALC },
          unique_domains: { $addToSet: "$domain" },
        },
      },
    ];

    const [result] = await calls.aggregate(pipeline).toArray();

    if (!result) {
      return {
        total_calls: 0, answered_calls: 0, abandoned_calls: 0, missed_calls: 0, forwarded_calls: 0,
        answer_rate: 0, abandon_rate: 0,
        total_duration: 0, total_talk_time: 0,
        avg_duration: 0, avg_talk_time: 0, avg_mos: null,
        inbound_calls: 0, outbound_calls: 0, internal_calls: 0,
        avg_ring_time: 0, avg_queue_wait: 0, avg_hold_time: 0, avg_answer_seconds: null,
        tenant_count: 0,
      };
    }

    const { _id, unique_domains, ...stats } = result;

    return {
      ...stats,
      answer_rate: stats.total_calls > 0
        ? Math.round((stats.answered_calls / stats.total_calls) * 10000) / 100
        : 0,
      abandon_rate: stats.total_calls > 0
        ? Math.round((stats.abandoned_calls / stats.total_calls) * 10000) / 100
        : 0,
      avg_mos: stats.avg_mos ? Math.round(stats.avg_mos * 100) / 100 : null,
      avg_duration: Math.round((stats.avg_duration || 0) * 100) / 100,
      avg_talk_time: Math.round((stats.avg_talk_time || 0) * 100) / 100,
      avg_ring_time: Math.round((stats.avg_ring_time || 0) * 100) / 100,
      avg_queue_wait: Math.round((stats.avg_queue_wait || 0) * 100) / 100,
      avg_hold_time: Math.round((stats.avg_hold_time || 0) * 100) / 100,
      avg_answer_seconds: stats.avg_answer_seconds != null ? Math.round(stats.avg_answer_seconds * 100) / 100 : null,
      tenant_count: unique_domains?.length || 0,
    };
  });

  // ── Hourly Distribution ─────────────────────────────
  app.get("/api/stats/hourly", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = buildDateFilter(request);

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: {
            hour: {
              $hour: { $toDate: { $multiply: ["$start", 1000] } },
            },
          },
          total: { $sum: 1 },
          answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
          abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
          avg_duration: { $avg: "$talk_seconds" },
        },
      },
      { $sort: { "_id.hour": 1 } },
    ];

    const results = await calls.aggregate(pipeline).toArray();

    // Fill in missing hours with zeros
    const hourly = Array.from({ length: 24 }, (_, i) => {
      const found = results.find((r) => r._id.hour === i);
      return {
        hour: i,
        label: `${String(i).padStart(2, "0")}:00`,
        total: found?.total || 0,
        answered: found?.answered || 0,
        abandoned: found?.abandoned || 0,
        avg_duration: Math.round((found?.avg_duration || 0) * 100) / 100,
      };
    });

    return { hourly };
  });

  // ── Daily Volume ────────────────────────────────────
  app.get("/api/stats/daily", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = buildDateFilter(request);

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: {
            $dateToString: {
              format: "%Y-%m-%d",
              date: { $toDate: { $multiply: ["$start", 1000] } },
            },
          },
          total: { $sum: 1 },
          answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
          abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
          avg_talk: { $avg: "$talk_seconds" },
          total_talk: { $sum: "$talk_seconds" },
        },
      },
      { $sort: { _id: 1 } },
    ];

    const results = await calls.aggregate(pipeline).toArray();

    const daily = results.map((r) => ({
      date: r._id,
      total: r.total,
      answered: r.answered,
      abandoned: r.abandoned,
      abandon_rate: r.total > 0 ? Math.round((r.abandoned / r.total) * 10000) / 100 : 0,
      avg_talk: Math.round((r.avg_talk || 0) * 100) / 100,
      total_talk: Math.round((r.total_talk || 0) * 100) / 100,
    }));

    return { daily };
  });

  // ── Agent Performance ───────────────────────────────
  app.get("/api/stats/agents", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = mergeFilter(buildDateFilter(request), { answering_extension: { $ne: null } });

    const pipeline = [
      { $match: filter },
      { $unwind: "$states" },
      { $match: { "states.extension": { $ne: null }, "states.extension": { $ne: "" } } },
      {
        $addFields: {
          "state_talk_ms": { $cond: {
            if: { $and: [{ $ne: ["$states.durationtalk", ""] }, { $ne: ["$states.durationtalk", null] }] },
            then: { $toInt: "$states.durationtalk" },
            else: 0,
          }},
          "state_ring_ms": { $cond: {
            if: { $and: [{ $ne: ["$states.durationring", ""] }, { $ne: ["$states.durationring", null] }] },
            then: { $toInt: "$states.durationring" },
            else: 0,
          }},
          "state_hold_ms": { $cond: {
            if: { $and: [{ $ne: ["$states.durationhold", ""] }, { $ne: ["$states.durationhold", null] }] },
            then: { $toInt: "$states.durationhold" },
            else: 0,
          }},
        },
      },
      {
        $group: {
          _id: {
            extension: "$states.extension",
            name: "$states.extension-name",
          },
          total_calls: { $sum: 1 },
          answered_calls: { $sum: { $cond: [{ $gt: ["$state_talk_ms", 0] }, 1, 0] } },
          total_talk: { $sum: { $divide: ["$state_talk_ms", 1000] } },
          total_hold: { $sum: { $divide: ["$state_hold_ms", 1000] } },
          total_ring: { $sum: { $divide: ["$state_ring_ms", 1000] } },
          avg_mos: { $avg: "$avg_mos_score" },
          max_talk: { $max: { $divide: ["$state_talk_ms", 1000] } },
          inbound: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "inbound"] }, 1, 0] } },
          outbound: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "outbound"] }, 1, 0] } },
          internal: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "internal"] }, 1, 0] } },
        },
      },
      { $sort: { total_calls: -1 } },
    ];

    const results = await calls.aggregate(pipeline).toArray();

    const agents = results.map((r) => ({
      extension: r._id.extension,
      name: r._id.name || r._id.extension,
      total_calls: r.total_calls,
      answered_calls: r.answered_calls,
      total_talk: Math.round(r.total_talk * 100) / 100,
      total_hold: Math.round(r.total_hold * 100) / 100,
      total_ring: Math.round(r.total_ring * 100) / 100,
      avg_talk: r.answered_calls > 0 ? Math.round((r.total_talk / r.answered_calls) * 100) / 100 : 0,
      avg_hold: r.answered_calls > 0 ? Math.round((r.total_hold / r.answered_calls) * 100) / 100 : 0,
      avg_ring: r.total_calls > 0 ? Math.round((r.total_ring / r.total_calls) * 100) / 100 : 0,
      avg_mos: r.avg_mos ? Math.round(r.avg_mos * 100) / 100 : null,
      max_talk: Math.round((r.max_talk || 0) * 100) / 100,
      inbound: r.inbound,
      outbound: r.outbound,
      internal: r.internal,
      avg_handle_time: r.answered_calls > 0
        ? Math.round(((r.total_talk + r.total_hold) / r.answered_calls) * 100) / 100
        : 0,
    }));

    return { agents };

  });

// ── Top Numbers (DIDs, Dialed, Callers) ──────────────
  app.get("/api/stats/numbers", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    // has_trunk_leg is a cheap indexed boolean set at ingest. The $or
    // keeps documents written before the hot/cold split matching, since
    // they carry trunklegs inline and no has_trunk_leg field.
    const filter = mergeFilter(buildDateFilter(request), {
      $or: [
        { has_trunk_leg: true },
        { has_trunk_leg: { $exists: false }, "trunklegs.0": { $exists: true } },
      ],
    });

    const limit = parseInt(request.query.limit) || 10;

    // Top Inbound DIDs (most called numbers)
    const inboundDids = await calls.aggregate([
      { $match: { ...filter, call_direction_origin: "inbound", to_number_raw: { $not: /^(\d{2,5}|\*.*)$/ } } },
      { $group: {
        _id: "$to_number_raw",
        count: { $sum: 1 },
        name: { $first: "$to_display_name" },
        e164: { $first: "$to_number_e164" },
        answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
        abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
        total_talk: { $sum: "$talk_seconds" },
      }},
      { $match: { _id: { $ne: null } } },
      { $sort: { count: -1 } },
      { $limit: limit },
    ]).toArray();

    // Top Outbound Numbers Dialed
    const outboundDialed = await calls.aggregate([
      { $match: { ...filter, call_direction_origin: "outbound", to_number_raw: { $not: /^(\d{2,5}|\*.*)$/ } } },
      { $group: {
        _id: "$to_number_raw",
        count: { $sum: 1 },
        name: { $first: "$to_display_name" },
        e164: { $first: "$to_number_e164" },
        answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
        total_talk: { $sum: "$talk_seconds" },
      }},
      { $match: { _id: { $ne: null } } },
      { $sort: { count: -1 } },
      { $limit: limit },
    ]).toArray();

    // Top Inbound Callers
    const inboundCallers = await calls.aggregate([
      { $match: { ...filter, call_direction_origin: "inbound", from_number_raw: { $not: /^(\d{2,5}|\*.*)$/ } } },
      { $group: {
        _id: "$from_number_raw",
        count: { $sum: 1 },
        name: { $first: "$from_display_name" },
        e164: { $first: "$from_number_e164" },
        country: { $first: "$from_country" },
        country_flag: { $first: "$from_country_flag" },
        answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
        total_talk: { $sum: "$talk_seconds" },
      }},
      { $match: { _id: { $ne: null } } },
      { $sort: { count: -1 } },
      { $limit: limit },
    ]).toArray();

    const fmt = (arr) => arr.map(r => ({
      number: r._id,
      name: r.name || r._id,
      e164: r.e164 || null,
      country: r.country || null,
      country_flag: r.country_flag || null,
      count: r.count,
      answered: r.answered || 0,
      abandoned: r.abandoned || 0,
      total_talk: Math.round((r.total_talk || 0) * 100) / 100,
      avg_talk: r.answered > 0 ? Math.round((r.total_talk / r.answered) * 100) / 100 : 0,
    }));

    return {
      inbound_dids: fmt(inboundDids),
      outbound_dialed: fmt(outboundDialed),
      inbound_callers: fmt(inboundCallers),
    };
  });

  // ── Queue Analytics ─────────────────────────────────
  app.get("/api/stats/queues", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = mergeFilter(buildDateFilter(request), { answering_queue: { $ne: null } });
    if (request.query.direction) filter.call_direction_origin = request.query.direction;

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: {
            queue: "$answering_queue",
            name: "$answering_queue_name",
          },
          total_calls: { $sum: 1 },
          answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
          abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
          inbound: { $sum: { $cond: [{ $and: [{ $eq: ["$call_direction_origin", "inbound"] }, "$is_answered"] }, 1, 0] } },
          outbound: { $sum: { $cond: [{ $and: [{ $eq: ["$call_direction_origin", "outbound"] }, "$is_answered"] }, 1, 0] } },
          avg_wait: { $avg: "$queue_wait_seconds" },
          max_wait: { $max: "$queue_wait_seconds" },
          avg_answer: { $avg: ANSWER_CALC },
          max_answer: { $max: ANSWER_CALC },
          avg_talk: { $avg: "$talk_seconds" },
          total_talk: { $sum: "$talk_seconds" },
          avg_hold: { $avg: "$hold_time_seconds" },
          avg_mos: { $avg: "$avg_mos_score" },
          unique_agents: { $addToSet: "$answering_extension" },
        },
      },
      { $sort: { total_calls: -1 } },
    ];

    const results = await calls.aggregate(pipeline).toArray();

    const queues = results.map((r) => ({
      queue: r._id.queue,
      name: r._id.name || r._id.queue,
      total_calls: r.total_calls,
      answered: r.answered,
      abandoned: r.abandoned,
      answer_rate: r.total_calls > 0
        ? Math.round((r.answered / r.total_calls) * 10000) / 100
        : 0,
      abandon_rate: r.total_calls > 0
        ? Math.round((r.abandoned / r.total_calls) * 10000) / 100
        : 0,
      avg_speed_of_answer: Math.round((r.avg_wait || 0) * 100) / 100,
      avg_answer_seconds: r.avg_answer != null ? Math.round(r.avg_answer * 100) / 100 : null,
      max_answer_seconds: r.max_answer != null ? Math.round(r.max_answer * 100) / 100 : null,
      max_wait: Math.round((r.max_wait || 0) * 100) / 100,
      avg_talk: Math.round((r.avg_talk || 0) * 100) / 100,
      total_talk: Math.round((r.total_talk || 0) * 100) / 100,
      avg_hold: Math.round((r.avg_hold || 0) * 100) / 100,
      avg_mos: r.avg_mos ? Math.round(r.avg_mos * 100) / 100 : null,
      agent_count: r.unique_agents?.filter(Boolean).length || 0,
      inbound: r.inbound || 0,
      outbound: r.outbound || 0,
    }));

    return { queues };
  });

  // ── Direction Breakdown ─────────────────────────────
  app.get("/api/stats/directions", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = buildDateFilter(request);

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: "$call_direction_origin",
          total: { $sum: 1 },
          answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
          abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
          avg_duration: { $avg: "$talk_seconds" },
        },
      },
      { $sort: { total: -1 } },
    ];

    const results = await calls.aggregate(pipeline).toArray();

    const directions = results.map((r) => ({
      direction: r._id,
      total: r.total,
      answered: r.answered,
      abandoned: r.abandoned,
      avg_duration: Math.round((r.avg_duration || 0) * 100) / 100,
    }));

    return { directions };
  });

  // ── Quality Distribution ────────────────────────────
  app.get("/api/stats/quality", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = mergeFilter(buildDateFilter(request), { avg_mos_score: { $ne: null } });

    const pipeline = [
      { $match: filter },
      {
        $bucket: {
          groupBy: "$avg_mos_score",
          boundaries: [0, 1, 2, 3, 3.5, 4, 4.5, 5.01],
          default: "unknown",
          output: {
            count: { $sum: 1 },
            avg_mos: { $avg: "$avg_mos_score" },
          },
        },
      },
    ];

    const results = await calls.aggregate(pipeline).toArray();

    const labels = {
      0: "0-1 (Unusable)",
      1: "1-2 (Bad)",
      2: "2-3 (Poor)",
      3: "3-3.5 (Fair)",
      3.5: "3.5-4 (Good)",
      4: "4-4.5 (Very Good)",
      4.5: "4.5-5 (Excellent)",
    };

    const quality = results.map((r) => ({
      range: labels[r._id] || `${r._id}`,
      count: r.count,
      avg_mos: Math.round((r.avg_mos || 0) * 100) / 100,
    }));

    // Overall average
    const overallPipeline = [
      { $match: filter },
      { $group: { _id: null, avg: { $avg: "$avg_mos_score" }, count: { $sum: 1 } } },
    ];
    const [overall] = await calls.aggregate(overallPipeline).toArray();

    return {
      quality,
      overall_avg_mos: overall ? Math.round(overall.avg * 100) / 100 : null,
      total_with_quality: overall?.count || 0,
    };
  });

  // ── Geographic / Country Breakdown ──────────────────
  app.get("/api/stats/countries", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = mergeFilter(buildDateFilter(request), { from_country: { $ne: null } });

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: "$from_country",
          total: { $sum: 1 },
          answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
          avg_duration: { $avg: "$talk_seconds" },
        },
      },
      { $sort: { total: -1 } },
      { $limit: 50 },
    ];

    const results = await calls.aggregate(pipeline).toArray();

    const countries = results.map((r) => ({
      country: r._id,
      total: r.total,
      answered: r.answered,
      avg_duration: Math.round((r.avg_duration || 0) * 100) / 100,
    }));

    return { countries };
  });

  // ── Routing Method Breakdown ────────────────────────
  app.get("/api/stats/routing", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = buildDateFilter(request);

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: "$routing_method",
          total: { $sum: 1 },
          answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
          abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
          avg_duration: { $avg: "$talk_seconds" },
        },
      },
      { $sort: { total: -1 } },
    ];

    const results = await calls.aggregate(pipeline).toArray();

    const routing = results.map((r) => ({
      method: r._id,
      total: r.total,
      answered: r.answered,
      abandoned: r.abandoned,
      avg_duration: Math.round((r.avg_duration || 0) * 100) / 100,
    }));

    return { routing };
  });

  // ── Hourly by Direction ─────────────────────────────
  app.get("/api/stats/hourly-detailed", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = buildDateFilter(request);
    // If queues_only=true, only include calls that went through a queue
    if (request.query.queues_only === "true") {
      filter.answering_queue = { $ne: null };
    }

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: {
            hour: { $hour: { $toDate: { $multiply: ["$start", 1000] } } },
          },
          total: { $sum: 1 },
          inbound: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "inbound"] }, 1, 0] } },
          outbound: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "outbound"] }, 1, 0] } },
          internal: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "internal"] }, 1, 0] } },
          abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
        },
      },
      { $sort: { "_id.hour": 1 } },
    ];

    const results = await calls.aggregate(pipeline).toArray();

    const hourly = Array.from({ length: 24 }, (_, i) => {
      const found = results.find((r) => r._id.hour === i);
      return {
        hour: i,
        label: `${String(i).padStart(2, "0")}:00`,
        total: found?.total || 0,
        inbound: found?.inbound || 0,
        outbound: found?.outbound || 0,
        internal: found?.internal || 0,
        abandoned: found?.abandoned || 0,
      };
    });

    return { hourly };
  });


  // ── Queue-Scoped Agent Performance ──────────────────
  app.get("/api/stats/queue-agents", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = mergeFilter(buildDateFilter(request), { answering_queue: { $ne: null }, answering_extension: { $ne: null } });

    if (request.query.queue) {
      const qm = queueMatch(request.query.queue);
      if (qm !== null) filter.answering_queue = qm;
    }
    if (request.query.direction) {
      filter.call_direction_origin = request.query.direction;
    }

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: {
            extension: "$answering_extension",
            name: "$answering_extension_name",
            queue: "$answering_queue",
            queue_name: "$answering_queue_name",
          },
          total_calls: { $sum: 1 },
          answered_calls: { $sum: { $cond: ["$is_answered", 1, 0] } },
          total_talk: { $sum: "$talk_seconds" },
          total_hold: { $sum: "$hold_time_seconds" },
          avg_talk: { $avg: "$talk_seconds" },
          avg_hold: { $avg: "$hold_time_seconds" },
          avg_ring: { $avg: "$ring_time_seconds" },
          total_ring: { $sum: "$ring_time_seconds" },
          avg_mos: { $avg: "$avg_mos_score" },
        },
      },
      { $sort: { total_calls: -1 } },
    ];

    const results = await calls.aggregate(pipeline).toArray();

    const agents = results.map((r) => ({
      extension: r._id.extension,
      name: r._id.name || r._id.extension,
      queue: r._id.queue,
      queue_name: r._id.queue_name,
      total_calls: r.total_calls,
      answered_calls: r.answered_calls,
      total_talk: Math.round(r.total_talk * 100) / 100,
      total_hold: Math.round(r.total_hold * 100) / 100,
      avg_talk: r.answered_calls > 0 ? Math.round((r.total_talk / r.answered_calls) * 100) / 100 : 0,
      avg_hold: r.answered_calls > 0 ? Math.round((r.total_hold / r.answered_calls) * 100) / 100 : 0,
      avg_ring: r.total_calls > 0 ? Math.round((r.total_ring / r.total_calls) * 100) / 100 : 0,
      avg_mos: r.avg_mos ? Math.round(r.avg_mos * 100) / 100 : null,
      avg_handle_time: r.answered_calls > 0
        ? Math.round(((r.total_talk + r.total_hold) / r.answered_calls) * 100) / 100
        : 0,
    }));

    return { agents };
  });



  // ── Distinct countries (for filter dropdowns) ─────
  app.get("/api/stats/countries-list", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const filter = buildDateFilter(request);
    
    const [fromCountries, toCountries] = await Promise.all([
      calls.distinct("from_country", { ...filter, from_country: { $ne: null } }),
      calls.distinct("to_country", { ...filter, to_country: { $ne: null } }),
    ]);

    return { from_countries: fromCountries.sort(), to_countries: toCountries.sort() };
  });

  // -- Grade of Service --------------------------------
  //
  // Denominator is ANSWERED calls only: "of the calls we picked up, what
  // fraction were picked up within N seconds". Abandoned calls are reported
  // separately via abandoned_wait (sourced from queue_wait_seconds), because
  // they are already counted elsewhere in the product.
  //
  // Buckets are computed at query time so thresholds stay changeable without
  // re-ingesting. Nine buckets for charts, four cumulative for tables.

  const GOS_BOUNDARIES = [0, 10, 20, 30, 60, 120, 300, 600, 900];

  const GOS_BUCKETS = [
    { key: "0-10",    label: "\u2264 10s", max: 10 },
    { key: "10-20",   label: "10-20s",     max: 20 },
    { key: "20-30",   label: "20-30s",     max: 30 },
    { key: "30-60",   label: "30-60s",     max: 60 },
    { key: "60-120",  label: "1-2m",       max: 120 },
    { key: "120-300", label: "2-5m",       max: 300 },
    { key: "300-600", label: "5-10m",      max: 600 },
    { key: "600-900", label: "10-15m",     max: 900 },
    { key: "900+",    label: "> 15m",      max: null },
  ];

  const emptyGosCounts = () => GOS_BUCKETS.map(() => 0);

  function gosWithin(counts, targetSeconds) {
    return GOS_BUCKETS.reduce(
      (sum, def, i) => (def.max !== null && def.max <= targetSeconds ? sum + counts[i] : sum),
      0
    );
  }

  function shapeGos(counts) {
    const scored = counts.reduce((s, n) => s + n, 0);
    const pct = (n) => (scored > 0 ? Math.round((n / scored) * 10000) / 100 : 0);

    let cumulative = 0;
    const buckets = GOS_BUCKETS.map((def, i) => {
      cumulative += counts[i];
      return {
        key: def.key,
        label: def.label,
        max_seconds: def.max,
        count: counts[i],
        pct: pct(counts[i]),
        cumulative_count: cumulative,
        cumulative_pct: pct(cumulative),
      };
    });

    const w30 = gosWithin(counts, 30);
    const w60 = gosWithin(counts, 60);
    const w300 = gosWithin(counts, 300);

    return {
      scored,
      buckets,
      summary: {
        within_30s: w30, within_30s_pct: pct(w30),
        within_60s: w60, within_60s_pct: pct(w60),
        within_300s: w300, within_300s_pct: pct(w300),
        over_300s: scored - w300, over_300s_pct: pct(scored - w300),
      },
    };
  }

  // answer time -> bucket key, for per-queue grouping ($bucket can't group by
  // a second dimension). Takes the value expression so it works against both
  // the stored field and the computed fallback.
  const gosSwitch = (v) => ({
    $switch: {
      branches: [
        { case: { $eq: [{ $ifNull: [v, null] }, null] }, then: "none" },
        { case: { $lt: [v, 10] },  then: "0-10" },
        { case: { $lt: [v, 20] },  then: "10-20" },
        { case: { $lt: [v, 30] },  then: "20-30" },
        { case: { $lt: [v, 60] },  then: "30-60" },
        { case: { $lt: [v, 120] }, then: "60-120" },
        { case: { $lt: [v, 300] }, then: "120-300" },
        { case: { $lt: [v, 600] }, then: "300-600" },
        { case: { $lt: [v, 900] }, then: "600-900" },
      ],
      default: "900+",
    },
  });

  // Per-tenant SLA target, defaulting to 80/30.
  // There is no UI for tenants.sla yet - set it directly in Mongo if needed.
  // gosWithin() sums whole buckets, so target_seconds should land on a
  // GOS_BOUNDARIES value (10/20/30/60/120/300/600/900) to score exactly.
  async function getSlaTarget(request) {
    const fallback = { target_seconds: 30, target_pct: 80 };
    const domain = request.query.domain;
    if (!domain || typeof domain !== "string") return fallback;
    try {
      const t = await db.collection("tenants").findOne({ domain }, { projection: { sla: 1 } });
      const secs = Number(t && t.sla && t.sla.target_seconds);
      const target = Number(t && t.sla && t.sla.target_pct);
      return {
        target_seconds: secs > 0 ? secs : fallback.target_seconds,
        target_pct: target > 0 ? target : fallback.target_pct,
      };
    } catch {
      return fallback;
    }
  }

  app.get("/api/stats/gos", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const scoped = buildDateFilter(request);
    scoped.call_direction_origin = request.query.direction || "inbound";
    if (request.query.queues_only === "true") scoped.answering_queue = { $ne: null };

    // No answer_seconds guard: ANSWER_CALC yields a number for every answered
    // call, whether or not the field was ever written.
    const answeredFilter = mergeFilter(scoped, { is_answered: true });

    const [raw, totalsArr, abandonedArr] = await Promise.all([
      calls.aggregate([
        { $match: answeredFilter },
        { $bucket: {
          groupBy: ANSWER_CALC,
          boundaries: GOS_BOUNDARIES,
          default: "over",
          output: { count: { $sum: 1 } },
        } },
      ]).toArray(),
      calls.aggregate([
        { $match: scoped },
        { $group: {
          _id: null,
          offered: { $sum: 1 },
          answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
          abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
          avg_answer: { $avg: ANSWER_CALC },
          max_answer: { $max: ANSWER_CALC },
        } },
      ]).toArray(),
      calls.aggregate([
        { $match: mergeFilter(scoped, { is_abandoned: true }) },
        { $group: {
          _id: null,
          count: { $sum: 1 },
          avg_wait: { $avg: "$queue_wait_seconds" },
          max_wait: { $max: "$queue_wait_seconds" },
        } },
      ]).toArray(),
    ]);

    const counts = emptyGosCounts();
    for (const b of raw) {
      const id = String(b._id);
      const idx = id === "over" ? GOS_BUCKETS.length - 1 : GOS_BOUNDARIES.indexOf(Number(id));
      if (idx >= 0 && idx < counts.length) counts[idx] += b.count;
    }

    const shaped = shapeGos(counts);
    const t = totalsArr[0] || { offered: 0, answered: 0, abandoned: 0, avg_answer: null, max_answer: null };
    const ab = abandonedArr[0] || { count: 0, avg_wait: null, max_wait: null };

    const sla = await getSlaTarget(request);
    const within = gosWithin(counts, sla.target_seconds);
    const achieved = shaped.scored > 0 ? Math.round((within / shaped.scored) * 10000) / 100 : 0;

    return {
      offered: t.offered || 0,
      answered: t.answered || 0,
      abandoned: t.abandoned || 0,
      scored: shaped.scored,
      // Retained for API compatibility. Always 0 now that answer time is
      // computed at query time, so every answered call is measurable.
      unscored: Math.max(0, (t.answered || 0) - shaped.scored),
      avg_answer_seconds: t.avg_answer != null ? Math.round(t.avg_answer * 100) / 100 : null,
      max_answer_seconds: t.max_answer != null ? Math.round(t.max_answer * 100) / 100 : null,
      buckets: shaped.buckets,
      summary: shaped.summary,
      sla: {
        target_seconds: sla.target_seconds,
        target_pct: sla.target_pct,
        achieved_pct: achieved,
        met: achieved >= sla.target_pct,
      },
      abandoned_wait: {
        count: ab.count || 0,
        avg_seconds: ab.avg_wait != null ? Math.round(ab.avg_wait * 100) / 100 : null,
        max_seconds: ab.max_wait != null ? Math.round(ab.max_wait * 100) / 100 : null,
      },
    };
  });

  app.get("/api/stats/gos-by-queue", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    const base = mergeFilter(buildDateFilter(request), { answering_queue: { $ne: null } });
    if (request.query.direction) base.call_direction_origin = request.query.direction;

    const [totals, bucketRows] = await Promise.all([
      calls.aggregate([
        { $match: base },
        { $group: {
          _id: { queue: "$answering_queue", name: "$answering_queue_name" },
          offered: { $sum: 1 },
          answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
          abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
          avg_answer: { $avg: ANSWER_CALC },
          max_answer: { $max: ANSWER_CALC },
        } },
        { $sort: { offered: -1 } },
      ]).toArray(),
      calls.aggregate([
        { $match: mergeFilter(base, { is_answered: true }) },
        { $addFields: { gos_bucket: gosSwitch(ANSWER_CALC) } },
        { $match: { gos_bucket: { $ne: "none" } } },
        { $group: {
          _id: { queue: "$answering_queue", bucket: "$gos_bucket" },
          count: { $sum: 1 },
        } },
      ]).toArray(),
    ]);

    const keyIndex = new Map(GOS_BUCKETS.map((b, i) => [b.key, i]));
    const countsByQueue = new Map();
    for (const r of bucketRows) {
      const q = r._id.queue;
      if (!countsByQueue.has(q)) countsByQueue.set(q, emptyGosCounts());
      const idx = keyIndex.get(r._id.bucket);
      if (idx != null) countsByQueue.get(q)[idx] += r.count;
    }

    const sla = await getSlaTarget(request);

    const queues = totals.map((t) => {
      const counts = countsByQueue.get(t._id.queue) || emptyGosCounts();
      const shaped = shapeGos(counts);
      const within = gosWithin(counts, sla.target_seconds);
      const achieved = shaped.scored > 0 ? Math.round((within / shaped.scored) * 10000) / 100 : 0;
      return {
        queue: t._id.queue,
        name: t._id.name || t._id.queue,
        offered: t.offered,
        answered: t.answered,
        abandoned: t.abandoned,
        scored: shaped.scored,
        avg_answer_seconds: t.avg_answer != null ? Math.round(t.avg_answer * 100) / 100 : null,
        max_answer_seconds: t.max_answer != null ? Math.round(t.max_answer * 100) / 100 : null,
        buckets: shaped.buckets,
        summary: shaped.summary,
        sla_achieved_pct: achieved,
        sla_met: achieved >= sla.target_pct,
      };
    });

    return {
      queues,
      sla,
      bucket_labels: GOS_BUCKETS.map((b) => ({ key: b.key, label: b.label, max_seconds: b.max })),
    };
  });

  // -- Call categories (Queues page) -------------------
  //
  // `category` comes straight from the PBX CDR and is empty on most
  // deployments, so the response carries an `available` flag: true when this
  // tenant has EVER categorised a queue call, regardless of the current date
  // range. The UI hides the whole card when it is false, and shows an empty
  // state when it is true but the range happens to contain none. A single
  // combined test would make the card flicker in and out as dates change.

  const CATEGORY_TOP_N = 10;
  const HAS_CATEGORY = { $nin: [null, ""] };
  const NO_CATEGORY = { $in: [null, ""] };

  app.get("/api/stats/categories", {
    preHandler: requireAuthOrInternal,
  }, async (request) => {
    // Queue calls only, matching every other card on the Queues page.
    const scoped = mergeFilter(buildDateFilter(request), { answering_queue: { $ne: null } });
    if (request.query.direction) scoped.call_direction_origin = request.query.direction;

    // Tenant-level availability: same scope, no date range, no queue filter.
    const tenantScope = {
      ...buildTenantFilter(request),
      answering_queue: { $ne: null },
      category: HAS_CATEGORY,
    };
    if (request.query.domain) tenantScope.domain = request.query.domain;
    if (request.query.system) tenantScope.system = request.query.system;

    const [everUsed, rows, uncategorised] = await Promise.all([
      calls.findOne(tenantScope, { projection: { _id: 1 } }),
      calls.aggregate([
        { $match: mergeFilter(scoped, { category: HAS_CATEGORY }) },
        { $group: {
          _id: "$category",
          count: { $sum: 1 },
          answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
          abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
          total_talk: { $sum: "$talk_seconds" },
        } },
        { $sort: { count: -1 } },
      ]).toArray(),
      calls.countDocuments(mergeFilter(scoped, { category: NO_CATEGORY })),
    ]);

    const shape = (name, r) => ({
      category: name,
      count: r.count,
      answered: r.answered,
      abandoned: r.abandoned,
      answered_pct: r.count > 0 ? Math.round((r.answered / r.count) * 10000) / 100 : 0,
      abandoned_pct: r.count > 0 ? Math.round((r.abandoned / r.count) * 10000) / 100 : 0,
      // talk_seconds is 0 on unanswered calls, so average over answered only
      avg_talk_seconds: r.answered > 0 ? Math.round((r.total_talk / r.answered) * 100) / 100 : 0,
    });

    const categories = rows.slice(0, CATEGORY_TOP_N).map((r) => shape(r._id, r));

    // Free-text categories grow a long tail (typos, one-offs). Roll up the
    // remainder rather than rendering forty bars.
    const rest = rows.slice(CATEGORY_TOP_N);
    if (rest.length > 0) {
      const merged = rest.reduce((a, r) => ({
        count: a.count + r.count,
        answered: a.answered + r.answered,
        abandoned: a.abandoned + r.abandoned,
        total_talk: a.total_talk + r.total_talk,
      }), { count: 0, answered: 0, abandoned: 0, total_talk: 0 });
      categories.push({ ...shape("Other", merged), is_other: true, merged_count: rest.length });
    }

    const categorised = rows.reduce((s, r) => s + r.count, 0);

    return {
      available: !!everUsed,
      categories,
      distinct_count: rows.length,
      categorised,
      uncategorised,
      total: categorised + uncategorised,
    };
  });

}
