/**
 * CDR Webhook Route — POST /cdr
 * Supports API key auth OR IP whitelist (for PBXes that can't do auth)
 */

import { extractApiKey, validateApiKey } from "../services/auth.js";
import { cdrRateLimit } from "../middleware/rate-limit.js";
import { addDomainToWhitelistEntry } from "./whitelist.js";
import {
  validateCdr,
  processCdr,
  upsertCdr,
  ensureTenant,
  buildUploadResponse,
} from "../services/ingest.js";

// IP whitelist from DB (cached in Redis for 60s)
async function isWhitelisted(request, db, redis) {
  const clientIp = request.headers["x-forwarded-for"]?.split(",")[0]?.trim()
    || request.headers["x-real-ip"]
    || request.ip;

  // Check Redis cache first
  let whitelist;
  try {
    const cached = await redis.get("cdr:ip_whitelist");
    if (cached) {
      whitelist = JSON.parse(cached);
    }
  } catch { /* ignore */ }

  if (!whitelist) {
    // Load from DB
    const doc = await db.collection("settings").findOne({ key: "ip_whitelist" });
    whitelist = doc?.ips || [];
    // Cache for 60 seconds
    try { await redis.set("cdr:ip_whitelist", JSON.stringify(whitelist), "EX", 60); } catch { }
  }

  if (whitelist.length === 0) return { allowed: false, ip: clientIp };
  return { allowed: whitelist.some(entry => (typeof entry === "string" ? entry : entry.ip) === clientIp), ip: clientIp };
}

export default async function cdrRoutes(app) {
  app.post("/cdr", { preHandler: cdrRateLimit }, async (request, reply) => {
    const startTime = process.hrtime.bigint();
    const { db, redis } = app;

    // Auth: API key OR IP whitelist
    let system = null;

    const apiKey = extractApiKey(request);
    if (apiKey) {
      const keyInfo = await validateApiKey(apiKey, db, redis);
      if (!keyInfo) {
        app.log.warn("CDR webhook: invalid API key");
        return reply.code(403).send({ error: "Invalid API key" });
      }
      system = keyInfo.system;
    } else {
      const wl = await isWhitelisted(request, db, redis);
      if (wl.allowed) {
        app.log.info({ ip: wl.ip }, "CDR accepted via IP whitelist");
        system = null;
      } else {
        app.log.warn({ ip: wl.ip }, "CDR webhook: no auth and not whitelisted");
        return reply.code(401).send({ error: "API key required or IP not whitelisted" });
      }
    }

    // Parse body
    const cdr = request.body;
    if (!cdr || typeof cdr !== "object") {
      return reply.code(400).send({ error: "Invalid JSON body" });
    }

    // Validate
    const validation = validateCdr(cdr);
    if (!validation.valid) {
      app.log.warn({ error: validation.error }, "CDR validation failed");
      return reply.code(400).send({ error: validation.error });
    }

    // Use system from API key if available, otherwise from payload
    if (!system) system = cdr.system;

    try {
      await ensureTenant(system, cdr.domain, db);
      if (!apiKey && cdr.domain) {
        const wlIp = request.headers["x-forwarded-for"]?.split(",")[0]?.trim() || request.headers["x-real-ip"] || request.ip;
        addDomainToWhitelistEntry(db, redis, wlIp, cdr.domain).catch(() => {});
      }	    
      const enriched = await processCdr(cdr, system, db, redis);
      const result = await upsertCdr(enriched, db);

      const isNew = result.upsertedCount > 0;
      app.log.info(
        {
          callid: cdr.callid,
          domain: cdr.domain,
          direction: enriched.call_direction,
          answered: enriched.is_answered,
          duration: enriched.duration_seconds,
          new: isNew,
        },
        "CDR %s",
        isNew ? "inserted" : "updated"
      );

      // Queue recording fetch.
      // Isolated: a queue failure (e.g. Redis OOM) must NOT turn an
      // already-stored CDR into a 500. A 500 here costs the PBX its
      // upload response, so the recording is never uploaded either --
      // one Redis problem silently destroys the audio for every call.
      if (enriched.has_recording && app.recordingQueue) {
        for (const rec of cdr.recordings) {
          try {
            await app.recordingQueue.add("fetch-recording", {
              system,
              domain: cdr.domain,
              callid: cdr.callid,
              file: rec.file,
              account: rec.account,
              extension: rec.extension,
            }, {
              attempts: 3,
              backoff: { type: "exponential", delay: 5000 },
              removeOnComplete: 100,
              removeOnFail: 500,
            });
          } catch (qErr) {
            app.log.warn(
              { err: qErr.message, callid: cdr.callid, domain: cdr.domain, file: rec.file },
              "Recording fetch enqueue failed -- CDR stored, upload response still returned"
            );
          }
        }
      }

      const upload = buildUploadResponse(cdr, request);
      const elapsed = Number(process.hrtime.bigint() - startTime) / 1e6;
      app.log.debug({ elapsed_ms: elapsed.toFixed(1) }, "CDR processed");

      return { upload };

    } catch (err) {
      if (err.code === 11000) {
        app.log.debug({ callid: cdr.callid }, "CDR duplicate — skipped");
        return { upload: buildUploadResponse(cdr, request) };
      }
      app.log.error(err, "CDR processing failed");
      return reply.code(500).send({ error: "Internal server error" });
    }
  });
}
