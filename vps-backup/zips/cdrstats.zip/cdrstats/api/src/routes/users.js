import { logAudit, AUDIT } from "../services/audit.js";
/**
 * User Management Routes
 *
 * POST   /api/users         — Create user (super_admin, or admin within own tenants)
 * GET    /api/users         — List users (scoped to role)
 * GET    /api/users/:id     — Get user
 * PUT    /api/users/:id     — Update user
 * DELETE /api/users/:id     — Deactivate user
 */

import { requireAuth, requireRole } from "../middleware/authenticate.js";
import { createUser, hashPassword, ROLES } from "../services/users.js";
import { sendMail } from "../services/mailer.js";

export default async function userRoutes(app) {
  const { db } = app;

  // ── Create User ─────────────────────────────────────
  app.post("/api/users", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request, reply) => {
    const { email, password, role, tenants, pbx_servers, queues } = request.body || {};
    const creator = request.user;

    // Admins can only create viewers within their own tenants
    if (creator.role === "admin") {
      if (role !== "viewer" && role !== "queue_manager") {
        return reply.code(403).send({
          error: "Admins can only create viewer and queue_manager accounts",
        });
      }

      // Verify all requested tenants belong to the admin
      const adminDomains = new Set(
        (creator.tenants || []).map((t) => (typeof t === "string" ? t : t.domain))
      );

      for (const t of (tenants || [])) {
        const domain = typeof t === "string" ? t : t.domain;
        if (!adminDomains.has(domain)) {
          return reply.code(403).send({
            error: `You don't have access to tenant: ${domain}`,
          });
        }
      }
    }

    try {
      const queuesArr = (queues || []).map(q => String(q));
      const user = await createUser(db, {
        email,
        password,
        role: role || "viewer",
        tenants: tenants || [],
        pbx_servers: pbx_servers || [],
        queues: role === "queue_manager" ? queuesArr : [],
      });

      logAudit(db, { action: "user_created", category: AUDIT.USERS, actor: creator.email, actor_id: creator.userId, target: email, ip: request.ip, details: { role: role || "viewer", tenants } });
      app.log.info(
        { email, role: role || "viewer", createdBy: creator.email },
        "User created"
      );

      // Send welcome email (non-blocking)
      const domain = process.env.DOMAIN || "localhost";
      const loginUrl = domain === "localhost" ? "http://localhost" : `https://${domain}`;
      sendMail(db, {
        to: email,
        subject: "Welcome to Vodia Analytics",
        html: `
          <div style="font-family:-apple-system,BlinkMacSystemFont,sans-serif;max-width:640px;margin:0 auto;padding:32px;">
            <div style="background:linear-gradient(135deg,#007aff 0%,#5856d6 100%);border-radius:16px;padding:32px;color:white;margin-bottom:24px;">
              <h2 style="margin:0 0 8px 0;font-size:20px;">Welcome to Vodia Analytics</h2>
              <p style="margin:0;opacity:0.9;font-size:14px;">Your account has been created</p>
            </div>
            <div style="color:#333;font-size:14px;line-height:1.7;">
              <p>Hi,</p>
              <p>An account has been created for you on Vodia Analytics.</p>
              <div style="background:#f8f9fa;border-radius:12px;padding:20px;margin:20px 0;">
                <p style="margin:0 0 8px 0;"><strong>Login URL:</strong> <a href="${loginUrl}" style="color:#007aff;">${loginUrl}</a></p>
                <p style="margin:0 0 8px 0;"><strong>Email:</strong> ${email}</p>
                <p style="margin:0 0 8px 0;"><strong>Password:</strong> ${password}</p>
                <p style="margin:0;"><strong>Role:</strong> ${role || "viewer"}</p>
              </div>
              <p>You will be asked to change your password and set up two-factor authentication on your first login.</p>
              <p style="margin-top:24px;">
                <a href="${loginUrl}" style="display:inline-block;background:#007aff;color:white;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:500;">Sign In Now</a>
              </p>
            </div>
            <hr style="border:none;border-top:1px solid #e5e5e5;margin:32px 0 16px 0;"/>
            <p style="color:#999;font-size:11px;text-align:center;">Vodia Analytics • ${domain}</p>
          </div>
        `,
      }).catch(err => app.log.warn({ err: err.message, email }, "Failed to send welcome email"));

      return reply.code(201).send({
        message: "User created",
        user: {
          id: user._id,
          email: user.email,
          role: user.role,
          tenants: user.tenants,
          queues: user.queues || [],
        },
      });
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
  });

  // ── List Users ──────────────────────────────────────
  app.get("/api/users", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request) => {
    const { user } = request;
    const filter = {};

    // Admins only see users in their own tenants
    if (user.role === "admin") {
      const adminDomains = (user.tenants || []).map((t) =>
        typeof t === "string" ? t : t.domain
      );
      filter["tenants.domain"] = { $in: adminDomains };
    }

    const users = await db
      .collection("users")
      .find(filter, { projection: { password_hash: 0 } })
      .sort({ created_at: -1 })
      .toArray();

    return { users };
  });

  // ── Get User ────────────────────────────────────────
  app.get("/api/users/:id", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try {
      id = new ObjectId(request.params.id);
    } catch {
      return reply.code(400).send({ error: "Invalid user ID" });
    }

    const target = await db.collection("users").findOne(
      { _id: id },
      { projection: { password_hash: 0 } }
    );

    if (!target) {
      return reply.code(404).send({ error: "User not found" });
    }

    return { user: target };
  });

  // ── Update User ─────────────────────────────────────
  app.put("/api/users/:id", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try {
      id = new ObjectId(request.params.id);
    } catch {
      return reply.code(400).send({ error: "Invalid user ID" });
    }

    const updates = {};
    const { email, password, role, tenants, pbx_servers, queues, active } = request.body || {};

    if (email) updates.email = email.toLowerCase();
    if (password) updates.password_hash = await hashPassword(password);
    if (role) {
      // Only super_admin can change roles
      if (request.user.role !== "super_admin") {
        return reply.code(403).send({ error: "Only super admins can change roles" });
      }
      updates.role = role;
    }
    if (tenants !== undefined) updates.tenants = tenants;
    if (pbx_servers !== undefined) updates.pbx_servers = pbx_servers;
    if (queues !== undefined) updates.queues = queues.map(q => String(q));
    if (active !== undefined) updates.active = active;

    updates.updated_at = new Date();

    const result = await db.collection("users").updateOne(
      { _id: id },
      { $set: updates }
    );

    if (result.matchedCount === 0) {
      return reply.code(404).send({ error: "User not found" });
    }

    app.log.info({ userId: request.params.id, updatedBy: request.user.email }, "User updated");
    logAudit(db, { action: "user_updated", category: AUDIT.USERS, actor: request.user.email, actor_id: request.user.userId, target: request.params.id, ip: request.ip, details: { fields: Object.keys(updates).filter(k => k !== "updated_at") } });

    return { message: "User updated" };
  });

  // ── Deactivate User ─────────────────────────────────
  app.delete("/api/users/:id", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try {
      id = new ObjectId(request.params.id);
    } catch {
      return reply.code(400).send({ error: "Invalid user ID" });
    }

    // Prevent self-deletion
    if (request.params.id === request.user.userId) {
      return reply.code(400).send({ error: "Cannot deactivate your own account" });
    }

    const result = await db.collection("users").updateOne(
      { _id: id },
      { $set: { active: false, deactivated_at: new Date() } }
    );

    if (result.matchedCount === 0) {
      return reply.code(404).send({ error: "User not found" });
    }

    app.log.info({ userId: request.params.id, deletedBy: request.user.email }, "User deactivated");
    logAudit(db, { action: "user_deactivated", category: AUDIT.USERS, actor: request.user.email, actor_id: request.user.userId, target: request.params.id, ip: request.ip });

    return { message: "User deactivated" };
  });

  // ── Reactivate User ─────────────────────────────────
  app.post("/api/users/:id/reactivate", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try { id = new ObjectId(request.params.id); } catch { return reply.code(400).send({ error: "Invalid ID" }); }

    const user = await db.collection("users").findOne({ _id: id });
    if (!user) return reply.code(404).send({ error: "User not found" });
    if (user.active !== false) return reply.code(400).send({ error: "User is already active" });

    await db.collection("users").updateOne(
      { _id: id },
      { $set: { active: true, must_reset_password: true, updated_at: new Date() }, $unset: { deactivated_at: "" } }
    );

    app.log.info({ userId: request.params.id, reactivatedBy: request.user.email }, "User reactivated");
    return { message: "User reactivated — they will need to reset their password on next login" };
  });
}
