/**
 * Live WebSocket Route — GET /api/ws/live
 *
 * Frontend connects with: ws://host/api/ws/live?tenant=DOMAIN&token=JWT
 * Authenticates via JWT, scopes events to the tenant domain.
 * Proxies PBX events from PbxWsManager to the browser.
 */

import jwt from "jsonwebtoken";

export default async function wsLiveRoute(app) {
  const { db, redis, pbxWsManager } = app;

  app.get("/api/ws/live", { websocket: true }, (socket, req) => {
    const ws = socket;
    let conn = null;
    let domain = null;
    let authenticated = false;

    // Parse query params
    const url = new URL(req.url, `http://${req.headers.host}`);
    const token = url.searchParams.get("token");
    const tenant = url.searchParams.get("tenant");

    if (!token || !tenant) {
      ws.send(JSON.stringify({ type: "error", message: "Missing token or tenant" }));
      ws.close(4001, "Missing token or tenant");
      return;
    }

    // Verify JWT
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Check user has access to this tenant
      // Super admins can access any tenant, others must have the tenant in their tenants array
      const userTenantDomains = (decoded.tenants || []).map(t => t.domain);
      if (decoded.role !== "super_admin" && !userTenantDomains.includes(tenant)) {
        ws.send(JSON.stringify({ type: "error", message: "Access denied for this tenant" }));
        ws.close(4003, "Access denied");
        return;
      }

      domain = tenant;
      authenticated = true;
    } catch (err) {
      ws.send(JSON.stringify({ type: "error", message: "Invalid token" }));
      ws.close(4001, "Invalid token");
      return;
    }

    // Connect to PBX manager
    (async () => {
      try {
        conn = await pbxWsManager.getConnectionForDomain(domain);

        if (!conn) {
          ws.send(JSON.stringify({ type: "error", message: "No PBX configured for this domain" }));
          ws.send(JSON.stringify({ type: "connection-state", state: "unavailable" }));
          return;
        }

        // Register this client
        pbxWsManager.addClient(conn, domain, ws);
      } catch (err) {
        app.log.error({ err: err.message, domain }, "Failed to connect to PBX for live WS");
        ws.send(JSON.stringify({ type: "error", message: "Failed to connect to PBX" }));
        ws.send(JSON.stringify({ type: "connection-state", state: "error" }));
      }
    })();

    // Handle messages from frontend
    ws.on("message", (raw) => {
      try {
        const msg = JSON.parse(raw.toString());

        if (msg.action === "snapshot" && conn && domain) {
          // Re-send current state
          pbxWsManager.addClient(conn, domain, ws);
        }

        if (msg.action === "refresh-queues" && conn) {
          // Force re-discover queues and agents from PBX
          app.log.info({ domain }, "Manual queue refresh requested");
          pbxWsManager._discoverAndSubscribe(conn).catch(err => {
            app.log.error({ err: err.message }, "Manual queue refresh failed");
          });
        }
      } catch {}
    });

    // Handle disconnect
    ws.on("close", () => {
      if (conn && domain) {
        pbxWsManager.removeClient(conn, domain, ws);
      }
    });

    ws.on("error", () => {
      if (conn && domain) {
        pbxWsManager.removeClient(conn, domain, ws);
      }
    });
  });
}
