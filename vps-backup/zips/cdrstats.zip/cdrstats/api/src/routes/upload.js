/**
 * Recording Upload + Playback Routes
 * Upload: accepts PUT and POST from PBX
 * Playback: proxies audio from MinIO through API
 */

import crypto from "crypto";
import { requireAuth } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";
import { getObjectRange } from "../services/storage.js";
import {
  buildObjectKey,
  uploadRecording,
  getObjectStream,
  getPresignedUrl,
  getCurrentBackend,
} from "../services/storage.js";

// ── Signed playback tokens ────────────────────────────────────
// <audio src> cannot send an Authorization header, so playback is gated by a
// short-lived HMAC over the recording id. Tokens are minted by authenticated
// endpoints (recordings list, share view) and expire well inside a listening
// session.
const PLAY_TTL_SECONDS = 6 * 60 * 60;

function playSecret() {
  return process.env.JWT_SECRET || "dev-secret-change-me";
}

function signPlay(id, exp) {
  return crypto.createHmac("sha256", playSecret()).update(String(id) + "." + String(exp)).digest("hex");
}

export function buildPlayUrl(id, ttlSeconds = PLAY_TTL_SECONDS) {
  const exp = Math.floor(Date.now() / 1000) + ttlSeconds;
  return "/api/recordings/play/" + String(id) + "?e=" + exp + "&t=" + signPlay(id, exp);
}

function playTokenValid(id, exp, token) {
  const expNum = Number(exp);
  if (!token || !expNum || !Number.isFinite(expNum)) return false;
  if (expNum < Math.floor(Date.now() / 1000)) return false;
  const expected = signPlay(id, expNum);
  const a = Buffer.from(String(token));
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

// Parse "bytes=start-end" against a known total size.
function parseRange(header, size) {
  if (!header || !size) return null;
  const m = /^bytes=(\d*)-(\d*)$/.exec(String(header).trim());
  if (!m) return null;
  const hasStart = m[1] !== "";
  const hasEnd = m[2] !== "";
  if (!hasStart && !hasEnd) return null;
  let start;
  let end;
  if (!hasStart) {
    const suffix = parseInt(m[2], 10);
    if (!suffix) return null;
    start = Math.max(0, size - suffix);
    end = size - 1;
  } else {
    start = parseInt(m[1], 10);
    end = hasEnd ? parseInt(m[2], 10) : size - 1;
  }
  if (!Number.isFinite(start) || !Number.isFinite(end)) return null;
  if (start > end || start >= size) return { unsatisfiable: true };
  return { start, end: Math.min(end, size - 1) };
}

export default async function uploadRoutes(app) {
  app.addContentTypeParser("*", function (request, payload, done) {
    const chunks = [];
    payload.on("data", (chunk) => chunks.push(chunk));
    payload.on("end", () => done(null, Buffer.concat(chunks)));
    payload.on("error", done);
  });

  async function handleUpload(request, reply) {
    const { system, domain, callid, file: filename } = request.params;
    const { db } = app;

    if (!system || !domain || !callid || !filename) {
      return reply.code(400).send({ error: "Missing path parameters" });
    }

    const body = request.body;
    if (!body || !Buffer.isBuffer(body) || body.length === 0) {
      return reply.code(400).send({ error: "Empty file body" });
    }

    const contentType = request.headers["content-type"] || "audio/wav";
    const objectKey = buildObjectKey(system, domain, callid, filename);

    try {
      const storageResult = await uploadRecording(objectKey, body, body.length, contentType);

      app.log.info(
        { system, domain, callid, file: filename, size: body.length, key: objectKey },
        "Recording uploaded to MinIO"
      );

      const decodedFilename = decodeURIComponent(filename);
      await db.collection("recordings").updateOne(
        { system, domain, callid, original_filename: decodedFilename },
        {
          $set: {
            system, domain, callid,
            original_filename: decodedFilename,
            storage_key: objectKey,
            storage_bucket: storageResult.bucket,
            storage_etag: storageResult.etag,
            storage_backend: storageResult.storage_backend,
            content_type: contentType,
            size_bytes: body.length,
            upload_status: "completed",
            uploaded_at: new Date(),
          },
          $setOnInsert: { created_at: new Date() },
        },
        { upsert: true }
      );

      await db.collection("calls").updateOne(
        { system, domain, callid },
        { $set: { has_recording: true }, $addToSet: { recording_keys: objectKey } }
      );

      // Queue transcription job
      let tRedis = null;
      try {
        const { Queue } = await import("bullmq");
        const Redis = (await import("ioredis")).default;
        tRedis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
        const tQueue = new Queue("transcription", { connection: tRedis });
        await tQueue.add("transcribe-" + callid, {
          system, domain, callid,
          storage_key: objectKey,
        }, {
          delay: 5000,
          attempts: 2,
          backoff: { type: "exponential", delay: 30000 },
          removeOnComplete: 100,
          removeOnFail: 500,
        });
        app.log.info({ callid, key: objectKey }, "Transcription job queued");
      } catch (qErr) {
        app.log.error(qErr, "Failed to queue transcription job");
      } finally {
        if (tRedis) { try { await tRedis.quit(); } catch { /* already gone */ } }
      }

      return reply.code(200).send({ status: "ok", key: objectKey, size: body.length });
    } catch (err) {
      app.log.error({ err, system, domain, callid, file: filename }, "Recording upload failed");
      return reply.code(500).send({ error: "Upload failed" });
    }
  }

  app.put("/upload/:system/:domain/:callid/:file", handleUpload);
  app.post("/upload/:system/:domain/:callid/:file", handleUpload);

  // Stream recording audio — proxies from MinIO to browser, with Range support
  app.get("/api/recordings/play/:id", async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    const { db } = app;
    const id = request.params.id;

    if (!playTokenValid(id, request.query.e, request.query.t)) {
      return reply.code(401).send({ error: "Invalid or expired playback token" });
    }

    let recording;
    try {
      recording = await db.collection("recordings").findOne({
        _id: new ObjectId(id),
        upload_status: "completed",
      });
    } catch {
      return reply.code(400).send({ error: "Invalid recording ID" });
    }

    if (!recording) {
      return reply.code(404).send({ error: "Recording not found" });
    }

    const size = Number(recording.size_bytes) || 0;
    const backend = recording.storage_backend || "minio";
    const range = parseRange(request.headers.range, size);

    if (range && range.unsatisfiable) {
      reply.header("Content-Range", "bytes */" + size);
      return reply.code(416).send({ error: "Range not satisfiable" });
    }

    try {
      reply.header("Content-Type", recording.content_type || "audio/wav");
      reply.header("Content-Disposition", `inline; filename="${recording.original_filename}"`);
      reply.header("Accept-Ranges", "bytes");
      reply.header("Cache-Control", "private, max-age=3600");

      if (range) {
        const spec = "bytes=" + range.start + "-" + range.end;
        const part = await getObjectRange(recording.storage_key, backend, spec);
        reply.header("Content-Range", part.contentRange || "bytes " + range.start + "-" + range.end + "/" + size);
        reply.header("Content-Length", part.contentLength ?? range.end - range.start + 1);
        reply.code(206);
        return reply.send(part.body);
      }

      const stream = await getObjectStream(recording.storage_key, backend);
      if (size) reply.header("Content-Length", size);
      return reply.send(stream);
    } catch (err) {
      app.log.error(err, "Failed to stream recording");
      return reply.code(500).send({ error: "Failed to stream recording" });
    }
  });

  // List recordings for a call (by callid) — authenticated + tenant scoped
  app.get("/api/recordings/call/:callid", { preHandler: requireAuth }, async (request, reply) => {
    const scope = buildTenantFilter(request);
    const call = await app.db.collection("calls").findOne({ callid: request.params.callid, ...scope });
    if (!call) return reply.code(404).send({ error: "Call not found" });

    const recordings = await app.db.collection("recordings")
      .find({
        callid: request.params.callid,
        system: call.system,
        domain: call.domain,
        upload_status: "completed",
      })
      .sort({ created_at: 1 })
      .toArray();

    return {
      recordings: recordings.map((r) => ({
        ...r,
        play_url: buildPlayUrl(r._id),
      })),
    };
  });

  // Legacy routes
  app.get("/api/recordings/:system/:domain/:callid/:file", async (request, reply) => {
    const { system, domain, callid, file: filename } = request.params;
    const decodedFilename = decodeURIComponent(filename);
    const recording = await app.db.collection("recordings").findOne({
      system, domain, callid, original_filename: decodedFilename, upload_status: "completed",
    });
    if (!recording) return reply.code(404).send({ error: "Recording not found" });
    try {
      const { getPresignedUrl } = await import("../services/storage.js");
      const url = await getPresignedUrl(recording.storage_key, 3600, recording.storage_backend || "minio");
      return { url, expires_in: 3600 };
    } catch (err) {
      return reply.code(500).send({ error: "Failed to generate URL" });
    }
  });

  app.get("/api/recordings/:system/:domain/:callid", async (request, reply) => {
    const { system, domain, callid } = request.params;
    const recordings = await app.db.collection("recordings")
      .find({ system, domain, callid }).sort({ created_at: 1 }).toArray();
    return { recordings };
  });
}
