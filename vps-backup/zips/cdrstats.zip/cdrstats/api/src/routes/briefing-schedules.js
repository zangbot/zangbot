/**
 * Briefing Schedule Routes
 *
 * GET    /api/briefing/schedules         — List schedules
 * POST   /api/briefing/schedules         — Create schedule
 * PUT    /api/briefing/schedules/:id     — Update schedule
 * DELETE /api/briefing/schedules/:id     — Delete schedule
 * POST   /api/briefing/schedules/:id/run — Run immediately
 */

import { requireRole } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";
import { logAudit, AUDIT } from "../services/audit.js";
import { computeNextRun, runScheduleNow } from "../services/briefing-scheduler.js";

function sanitizeSchedule(body) {
  const contexts = ["dashboard", "queues", "insights"];
  const freqs = ["daily", "weekly", "monthly"];
  const ranges = ["last_24h", "last_7d", "last_30d"];

  const s = {
    context: contexts.includes(body.context) ? body.context : "dashboard",
    frequency: freqs.includes(body.frequency) ? body.frequency : "daily",
    hour: Math.max(0, Math.min(23, parseInt(body.hour, 10))),
    day_of_week: Math.max(0, Math.min(6, parseInt(body.day_of_week, 10) || 0)),
    day_of_month: Math.max(1, Math.min(28, parseInt(body.day_of_month, 10) || 1)),
    timezone: String(body.timezone || "UTC").slice(0, 60),
    range: ranges.includes(body.range) ? body.range : "last_24h",
    recipients: (Array.isArray(body.recipients) ? body.recipients : String(body.recipients || "").split(","))
      .map(r => String(r).trim()).filter(r => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(r)).slice(0, 20),
    domain: body.domain ? String(body.domain).slice(0, 120) : null,
    queue: body.queue ? String(body.queue).slice(0, 60) : null,
    enabled: body.enabled !== false,
  };
  if (isNaN(s.hour)) s.hour = 8;
  try { new Intl.DateTimeFormat("en-US", { timeZone: s.timezone }); } catch { s.timezone = "UTC"; }
  if (s.recipients.length === 0) throw new Error("At least one valid recipient email is required");
  return s;
}

export default async function briefingScheduleRoutes(app) {
  const { db } = app;

  app.get("/api/briefing/schedules", { preHandler: requireRole("super_admin", "admin") }, async (request) => {
    const tf = buildTenantFilter(request);
    const filter = tf.domain ? { domain: tf.domain } : {};
    const schedules = await db.collection("briefing_schedules").find(filter).sort({ created_at: -1 }).toArray();
    return { schedules };
  });

  app.post("/api/briefing/schedules", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    let s;
    try { s = sanitizeSchedule(request.body || {}); } catch (e) { return reply.code(400).send({ error: e.message }); }
    const tf = buildTenantFilter(request);
    if (tf.domain) {
      const allowed = typeof tf.domain === "string" ? [tf.domain] : (Array.isArray(tf.domain.$in) ? tf.domain.$in : []);
      if (s.domain && !allowed.includes(s.domain)) {
        return reply.code(403).send({ error: "You can only schedule briefings for your own tenants" });
      }
      if (!s.domain) {
        if (allowed.length === 1) s.domain = allowed[0];
        else return reply.code(400).send({ error: "Select one of your tenants for this schedule" });
      }
    }

    const doc = { ...s, created_by: request.user.email, created_at: new Date(), next_run_at: computeNextRun(s), last_run_at: null, last_status: null };
    const result = await db.collection("briefing_schedules").insertOne(doc);
    logAudit(db, { action: "briefing_schedule_created", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, target: s.context, ip: request.ip, details: { frequency: s.frequency, recipients: s.recipients.length } });
    return { message: "Schedule created", id: result.insertedId.toString(), next_run_at: doc.next_run_at };
  });

  app.put("/api/briefing/schedules/:id", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id; try { id = new ObjectId(request.params.id); } catch { return reply.code(400).send({ error: "Invalid ID" }); }
    let s;
    try { s = sanitizeSchedule(request.body || {}); } catch (e) { return reply.code(400).send({ error: e.message }); }

    const existing = await db.collection("briefing_schedules").findOne({ _id: id });
    if (!existing) return reply.code(404).send({ error: "Schedule not found" });

    await db.collection("briefing_schedules").updateOne(
      { _id: id },
      { $set: { ...s, next_run_at: computeNextRun(s), updated_at: new Date() } }
    );
    return { message: "Schedule updated" };
  });

  app.delete("/api/briefing/schedules/:id", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id; try { id = new ObjectId(request.params.id); } catch { return reply.code(400).send({ error: "Invalid ID" }); }
    await db.collection("briefing_schedules").deleteOne({ _id: id });
    logAudit(db, { action: "briefing_schedule_deleted", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, target: request.params.id, ip: request.ip });
    return { message: "Schedule deleted" };
  });

  app.post("/api/briefing/schedules/:id/run", { preHandler: requireRole("super_admin", "admin") }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id; try { id = new ObjectId(request.params.id); } catch { return reply.code(400).send({ error: "Invalid ID" }); }
    const sched = await db.collection("briefing_schedules").findOne({ _id: id });
    if (!sched) return reply.code(404).send({ error: "Schedule not found" });

    try {
      const result = await runScheduleNow(db, sched, app.log);
      await db.collection("briefing_schedules").updateOne(
        { _id: id },
        { $set: { last_run_at: new Date(), last_status: "ok (manual) — emailed " + result.sent + "/" + result.recipients } }
      );
      return { message: "Briefing generated and emailed to " + result.sent + " recipient(s)" };
    } catch (err) {
      app.log.error(err, "Manual schedule run failed");
      return reply.code(500).send({ error: err.message });
    }
  });
}
