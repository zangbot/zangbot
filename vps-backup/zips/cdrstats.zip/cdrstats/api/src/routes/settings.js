import { logAudit, AUDIT } from "../services/audit.js";
/**
 * Settings Routes
 *
 * GET  /api/settings/smtp       — Get SMTP config (password masked)
 * PUT  /api/settings/smtp       — Save SMTP config
 * POST /api/settings/smtp/test  — Send test email
 */

import { requireRole } from "../middleware/authenticate.js";
import { encryptPassword, decryptPassword, sendMail } from "../services/mailer.js";
import { PROVIDERS, testAIConnection } from "../services/ai-provider.js";

export default async function settingsRoutes(app) {
  const { db } = app;

  // ── Get SMTP Config ─────────────────────────────────
  app.get("/api/settings/smtp", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request, reply) => {
    const doc = await db.collection("settings").findOne({ key: "smtp" });
    if (!doc) return { smtp: null };

    const config = { ...doc.value };
    // Mask password — only show if it's set
    if (config.password_encrypted) {
      config.has_password = true;
      delete config.password_encrypted;
    } else {
      config.has_password = false;
    }

    return { smtp: config };
  });

  // ── Save SMTP Config ───────────────────────────────
  app.put("/api/settings/smtp", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { host, port, username, password, from_address, encryption } = request.body || {};

    if (!host) return reply.code(400).send({ error: "SMTP host is required" });

    // Load existing to preserve password if not changed
    const existing = await db.collection("settings").findOne({ key: "smtp" });
    const existingPassword = existing?.value?.password_encrypted || null;

    const value = {
      host: host.trim(),
      port: parseInt(port) || 587,
      username: username?.trim() || "",
      // If password is sent, encrypt it. If empty string, keep existing. If null, clear.
      password_encrypted: password
        ? encryptPassword(password)
        : password === null
          ? null
          : existingPassword,
      from_address: from_address?.trim() || "",
      encryption: encryption || "starttls", // starttls | ssl | none
      updated_at: new Date(),
    };

    await db.collection("settings").updateOne(
      { key: "smtp" },
      { $set: { key: "smtp", value } },
      { upsert: true }
    );

    app.log.info({ host: value.host, port: value.port }, "SMTP settings updated");

    logAudit(db, { action: "smtp_saved", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, ip: request.ip });
    return { message: "SMTP settings saved", smtp: { ...value, password_encrypted: undefined, has_password: !!value.password_encrypted } };
  });

  // ── Test SMTP ───────────────────────────────────────
  app.post("/api/settings/smtp/test", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request, reply) => {
    const { to } = request.body || {};
    const recipient = to || request.user.email;

    if (!recipient) return reply.code(400).send({ error: "Recipient email required" });

    try {
      const info = await sendMail(db, {
        to: recipient,
        subject: "Vodia CDR Analytics — SMTP Test",
        html: `
          <div style="font-family: -apple-system, sans-serif; max-width: 500px; margin: 0 auto; padding: 32px;">
            <h2 style="color: #007aff; margin-bottom: 16px;">✓ SMTP Working</h2>
            <p style="color: #333; line-height: 1.6;">
              This test email confirms that your SMTP settings are correctly configured
              for the Vodia CDR Analytics platform.
            </p>
            <p style="color: #999; font-size: 12px; margin-top: 24px;">
              Sent at ${new Date().toISOString()}
            </p>
          </div>
        `,
      });

      app.log.info({ to: recipient, messageId: info.messageId }, "SMTP test sent");
      return { message: `Test email sent to ${recipient}`, messageId: info.messageId };
    } catch (err) {
      app.log.error({ err: err.message, to: recipient }, "SMTP test failed");
      return reply.code(400).send({
        error: "SMTP test failed",
        detail: err.message,
      });
    }
  });

  // ── Get AI Provider Config ────────────────────────────
  app.get("/api/settings/ai", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const doc = await db.collection("settings").findOne({ key: "ai_provider" });
    const envKey = process.env.OPENAI_API_KEY || "";
    const hasEnvKey = envKey && envKey !== "sk-PASTE-YOUR-KEY-HERE";

    if (!doc) {
      // Check legacy openai key
      const legacy = await db.collection("settings").findOne({ key: "openai" });
      if (legacy?.value) {
        return {
          ai: {
            provider: "openai",
            model: legacy.value.model || process.env.OPENAI_MODEL || "gpt-4o-mini",
            has_key: !!legacy.value.api_key_encrypted || hasEnvKey,
            source: legacy.value.api_key_encrypted ? "database" : (hasEnvKey ? "env" : "none"),
            endpoint: "",
          },
          providers: PROVIDERS,
        };
      }
      return {
        ai: { provider: "openai", model: "gpt-4o-mini", has_key: hasEnvKey, source: hasEnvKey ? "env" : "none", endpoint: "" },
        providers: PROVIDERS,
      };
    }

    const cfg = doc.value || {};
    return {
      ai: {
        provider: cfg.provider || "openai",
        model: cfg.model || "gpt-4o-mini",
        has_key: !!cfg.api_key_encrypted || hasEnvKey,
        source: cfg.api_key_encrypted ? "database" : (hasEnvKey ? "env" : "none"),
        endpoint: cfg.endpoint || "",
      },
      providers: PROVIDERS,
    };
  });

  // Legacy compat — redirect old endpoint
  app.get("/api/settings/openai", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const doc = await db.collection("settings").findOne({ key: "ai_provider" });
    const legacy = await db.collection("settings").findOne({ key: "openai" });
    const envKey = process.env.OPENAI_API_KEY || "";
    const hasEnvKey = envKey && envKey !== "sk-PASTE-YOUR-KEY-HERE";
    const src = doc || legacy;
    return {
      openai: {
        has_key: !!(src?.value?.api_key_encrypted) || hasEnvKey,
        source: src?.value?.api_key_encrypted ? "database" : (hasEnvKey ? "env" : "none"),
        model: src?.value?.model || process.env.OPENAI_MODEL || "gpt-4o-mini",
      }
    };
  });

  // ── Save AI Provider Config ──────────────────────────
  app.put("/api/settings/ai", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { provider, api_key, model, endpoint } = request.body || {};

    if (provider && !PROVIDERS[provider]) {
      return reply.code(400).send({ error: `Unknown provider: ${provider}. Supported: ${Object.keys(PROVIDERS).join(", ")}` });
    }

    const existing = await db.collection("settings").findOne({ key: "ai_provider" });
    const existingKey = existing?.value?.api_key_encrypted || null;

    const value = {
      provider: provider || existing?.value?.provider || "openai",
      model: model || existing?.value?.model || PROVIDERS[provider || "openai"]?.defaultModel || "gpt-4o-mini",
      api_key_encrypted: api_key ? encryptPassword(api_key) : (api_key === null ? null : existingKey),
      endpoint: endpoint !== undefined ? (endpoint || "").trim() : (existing?.value?.endpoint || ""),
      updated_at: new Date(),
    };

    await db.collection("settings").updateOne(
      { key: "ai_provider" },
      { $set: { key: "ai_provider", value } },
      { upsert: true }
    );

    app.log.info({ provider: value.provider, model: value.model, hasKey: !!value.api_key_encrypted }, "AI provider settings updated");
    logAudit(db, { action: "ai_settings_saved", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, ip: request.ip });
    logAudit(db, { action: "openai_key_saved", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, ip: request.ip });
    return { message: "AI settings saved" };
  });

  // Legacy compat
  app.put("/api/settings/openai", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { api_key, model } = request.body || {};
    const existing = await db.collection("settings").findOne({ key: "ai_provider" });
    const existingKey = existing?.value?.api_key_encrypted || null;
    const value = {
      provider: "openai",
      model: model || "gpt-4o-mini",
      api_key_encrypted: api_key ? encryptPassword(api_key) : (api_key === null ? null : existingKey),
      endpoint: existing?.value?.endpoint || "",
      updated_at: new Date(),
    };
    await db.collection("settings").updateOne(
      { key: "ai_provider" },
      { $set: { key: "ai_provider", value } },
      { upsert: true }
    );
    return { message: "AI settings saved" };
  });

  // ── Test AI Connection ───────────────────────────────
  app.post("/api/settings/ai/test", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { provider, api_key, model, endpoint } = request.body || {};

    // Use provided credentials for test, or fall back to saved config
    let testConfig;
    if (api_key || endpoint) {
      testConfig = { provider: provider || "openai", api_key, model, endpoint };
    } else {
      const { getAIConfig } = await import("../services/ai-provider.js");
      testConfig = await getAIConfig(db);
    }

    if (PROVIDERS[testConfig.provider]?.needsKey && !testConfig.api_key) {
      return reply.code(400).send({ error: `No API key configured for ${PROVIDERS[testConfig.provider]?.name}` });
    }

    try {
      const result = await testAIConnection(testConfig);
      const providerName = PROVIDERS[testConfig.provider]?.name || testConfig.provider;
      return { message: `${providerName} connection successful`, response: result.response };
    } catch (err) {
      app.log.error({ err: err.message, provider: testConfig.provider }, "AI connection test failed");
      return reply.code(400).send({ error: err.message });
    }
  });

  // Legacy compat
  app.post("/api/settings/openai/test", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { getAIConfig } = await import("../services/ai-provider.js");
    const config = await getAIConfig(db);
    if (!config.api_key) return reply.code(400).send({ error: "No API key configured" });
    try {
      const result = await testAIConnection(config);
      return { message: "Connection successful", response: result.response };
    } catch (err) { return reply.code(400).send({ error: err.message }); }
  });

  // ═══ Storage Settings ═══════════════════════════════════════

  // ── Get Storage Config ──────────────────────────────
  app.get("/api/settings/storage", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const doc = await db.collection("settings").findOne({ key: "storage" });
    if (!doc) {
      return { storage: { backend: "minio", endpoint: "", region: "", bucket: "", has_credentials: false, force_path_style: false } };
    }

    const cfg = doc.value || {};
    return {
      storage: {
        backend: cfg.backend || "minio",
        endpoint: cfg.endpoint || "",
        region: cfg.region || "",
        bucket: cfg.bucket || "",
        has_credentials: !!(cfg.access_key_encrypted && cfg.secret_key_encrypted),
        force_path_style: !!cfg.force_path_style,
      },
    };
  });

  // ── Save Storage Config ─────────────────────────────
  app.put("/api/settings/storage", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { backend, endpoint, region, bucket, access_key, secret_key, force_path_style } = request.body || {};

    if (!backend || !["minio", "s3"].includes(backend)) {
      return reply.code(400).send({ error: "backend must be 'minio' or 's3'" });
    }

    if (backend === "s3") {
      if (!bucket) return reply.code(400).send({ error: "S3 bucket is required" });
      if (!access_key && !secret_key) {
        // Check if existing credentials exist
        const existing = await db.collection("settings").findOne({ key: "storage" });
        if (!existing?.value?.access_key_encrypted) {
          return reply.code(400).send({ error: "S3 credentials are required" });
        }
      }
    }

    const { encryptStorageField, clearStorageConfigCache } = await import("../services/storage.js");

    // Load existing to preserve credentials if not changed
    const existing = await db.collection("settings").findOne({ key: "storage" });
    const existingAK = existing?.value?.access_key_encrypted || null;
    const existingSK = existing?.value?.secret_key_encrypted || null;

    const value = {
      backend,
      endpoint: endpoint?.trim() || "",
      region: region?.trim() || "",
      bucket: bucket?.trim() || "",
      force_path_style: !!force_path_style,
      access_key_encrypted: access_key ? encryptStorageField(access_key) : existingAK,
      secret_key_encrypted: secret_key ? encryptStorageField(secret_key) : existingSK,
      updated_at: new Date(),
    };

    await db.collection("settings").updateOne(
      { key: "storage" },
      { $set: { key: "storage", value } },
      { upsert: true }
    );

    // Clear cache so new config takes effect immediately
    clearStorageConfigCache();

    app.log.info({ backend, bucket: value.bucket, endpoint: value.endpoint }, "Storage settings updated");

    // Count recordings per backend for info
    const minioCnt = await db.collection("recordings").countDocuments({ storage_backend: { $ne: "s3" } });
    const s3Cnt = await db.collection("recordings").countDocuments({ storage_backend: "s3" });

    logAudit(db, { action: "storage_config_saved", category: AUDIT.SETTINGS, actor: request.user.email, actor_id: request.user.userId, ip: request.ip, details: { backend: value.backend } });
    return {
      message: "Storage settings saved",
      storage: {
        backend: value.backend,
        endpoint: value.endpoint,
        region: value.region,
        bucket: value.bucket,
        has_credentials: !!(value.access_key_encrypted && value.secret_key_encrypted),
        force_path_style: value.force_path_style,
      },
      recording_counts: { minio: minioCnt, s3: s3Cnt },
    };
  });

  // ── Test S3 Connection ──────────────────────────────
  app.post("/api/settings/storage/test", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { endpoint, region, bucket, access_key, secret_key, force_path_style } = request.body || {};

    if (!bucket) return reply.code(400).send({ error: "Bucket is required" });
    if (!access_key || !secret_key) return reply.code(400).send({ error: "Access key and secret key are required" });

    try {
      const { testS3Connection } = await import("../services/storage.js");
      await testS3Connection({ endpoint, region, bucket, access_key, secret_key, force_path_style });
      return { message: "S3 connection successful — bucket is writable" };
    } catch (err) {
      app.log.error({ err: err.message }, "S3 connection test failed");
      return reply.code(400).send({ error: err.message });
    }
  });


  // ── Storage Usage (cached in Redis) ─────────────────
  app.get("/api/settings/storage/usage", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const redis = app.redis;
    const CACHE_KEY = "storage:usage_cache";
    const CACHE_TTL = 1800; // 30 minutes

    // Check Redis cache first
    if (redis) {
      try {
        const cached = await redis.get(CACHE_KEY);
        if (cached) {
          const parsed = JSON.parse(cached);
          return { ...parsed, cached: true };
        }
      } catch {}
    }

    // Calculate usage from S3/MinIO
    try {
      const { getStorageUsage } = await import("../services/storage.js");
      const usage = await getStorageUsage();

      // Cache the result
      if (redis) {
        try { await redis.setex(CACHE_KEY, CACHE_TTL, JSON.stringify(usage)); } catch {}
      }

      return { ...usage, cached: false };
    } catch (err) {
      app.log.error({ err: err.message }, "Storage usage query failed");
      return reply.code(500).send({ error: "Failed to query storage usage: " + err.message });
    }
  });

  // ── Clear storage usage cache ───────────────────────
  app.post("/api/settings/storage/usage/refresh", {
    preHandler: requireRole("super_admin"),
  }, async (request) => {
    const redis = app.redis;
    if (redis) {
      try { await redis.del("storage:usage_cache"); } catch {}
    }
    return { message: "Cache cleared" };
  });

}
