/**
 * Shareable Call Link Routes
 *
 * POST   /api/share              — Generate share token (auth required)
 * GET    /api/share/:token       — View shared call (public, no auth)
 * GET    /api/share              — List active share links (admin)
 * DELETE /api/share/:id          — Revoke share link (admin)
 * POST   /api/share/email        — Email a share link (auth required)
 */

import crypto from "crypto";
import { ObjectId } from "mongodb";
import { requireAuth, requireRole } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";
import { sendMail } from "../services/mailer.js";
import { buildPlayUrl } from "./upload.js";  

const TOKEN_LENGTH = 48;
const DEFAULT_EXPIRY_HOURS = 24;

function generateToken() {
  return crypto.randomBytes(TOKEN_LENGTH).toString("base64url").slice(0, TOKEN_LENGTH);
}

export default async function shareRoutes(app) {
  const { db } = app;

  // ── Create Share Token ──────────────────────────────
  app.post("/api/share", {
    preHandler: requireAuth,
  }, async (request, reply) => {
    const { callid, domain, system, expiry_hours } = request.body || {};

    if (!callid) return reply.code(400).send({ error: "callid is required" });

    // Verify user has access to this call
    const tenantFilter = buildTenantFilter(request);
    const call = await db.collection("calls").findOne({ callid, ...tenantFilter });
    if (!call) return reply.code(404).send({ error: "Call not found or access denied" });

    const token = generateToken();
    const hours = Math.min(Math.max(parseInt(expiry_hours) || DEFAULT_EXPIRY_HOURS, 1), 168); // 1h to 7 days
    const expires_at = new Date(Date.now() + hours * 60 * 60 * 1000);

    const doc = {
      token,
      callid,
      domain: call.domain,
      system: call.system,
      created_by: request.user.email,
      created_at: new Date(),
      expires_at,
      viewed: false,
      viewed_at: null,
      revoked: false,
    };

    await db.collection("share_tokens").insertOne(doc);

    const baseUrl = process.env.DOMAIN
      ? `https://${process.env.DOMAIN}`
      : `${request.protocol}://${request.hostname}`;
    const shareUrl = `${baseUrl}/share/${token}`;

    app.log.info({ callid, token: token.slice(0, 8) + "...", expires_at, by: request.user.email }, "Share link created");

    return {
      share_url: shareUrl,
      token,
      expires_at,
      expiry_hours: hours,
    };
  });

  // ── View Shared Call (PUBLIC — no auth) ─────────────
  app.get("/api/share/:token", async (request, reply) => {
    const { token } = request.params;

    const shareDoc = await db.collection("share_tokens").findOne({
      token,
      revoked: { $ne: true },
      expires_at: { $gt: new Date() },
    });

    if (!shareDoc) {
      return reply.code(404).send({
        error: "Share link not found, expired, or already used",
      });
    }

    // Check if already viewed (one-time use)
    if (shareDoc.viewed) {
      return reply.code(410).send({
        error: "This share link has already been viewed",
        viewed_at: shareDoc.viewed_at,
      });
    }

    // Fetch the call
    const call = await db.collection("calls").findOne({ callid: shareDoc.callid });
    if (!call) {
      return reply.code(404).send({ error: "Call data no longer available" });
    }

    // Fetch recordings (only completed uploads)
    const recordings = await db.collection("recordings")
      .find({ callid: shareDoc.callid, upload_status: "completed" })
      .sort({ created_at: 1 })
      .toArray();

    // Build playback URLs (use existing public play route)
    const recordingsWithUrls = recordings.map(r => ({
      _id: r._id,
      original_filename: r.original_filename,
      size_bytes: r.size_bytes,
      duration: r.duration,
      created_at: r.created_at,
      playback_url: buildPlayUrl(r._id),
      play_url: buildPlayUrl(r._id),
      peaks_ch0: r.peaks_ch0 || null,
      peaks_ch1: r.peaks_ch1 || null,
      duration_seconds: r.duration_seconds || null,
    }));

    // Fetch transcripts (includes AI summary)
    const transcripts = await db.collection("transcripts")
      .find({ callid: shareDoc.callid })
      .sort({ created_at: 1 })
      .toArray();

    // AI summary is stored inside transcript.summary
    const aiData = transcripts.find(t => t.summary);
    const aiSummary = aiData ? aiData.summary : null;

    // Mark as viewed
    await db.collection("share_tokens").updateOne(
      { _id: shareDoc._id },
      { $set: { viewed: true, viewed_at: new Date() } }
    );

    app.log.info({ callid: shareDoc.callid, token: token.slice(0, 8) + "..." }, "Share link viewed");

    return {
      call: {
        callid: call.callid,
        from_number: call.from_number || call.from_number_raw,
        from_name: call.from_name || call.from_display_name,
        to_number: call.to_number || call.to_number_raw,
        to_name: call.to_name || call.to_display_name,
        call_direction: call.call_direction,
        is_answered: call.is_answered,
        is_abandoned: call.is_abandoned,
        transfer_type: call.transfer_type || null,
        duration_seconds: call.duration_seconds,
        talk_seconds: call.talk_seconds,
        start: call.start,
        end: call.end,
        routing_method: call.routing_method,
        answering_extension: call.answering_extension,
        answering_extension_name: call.answering_extension_name,
        answering_queue: call.answering_queue,
        answering_queue_name: call.answering_queue_name,
        avg_mos_score: call.avg_mos_score,
        answer_seconds: call.answer_seconds != null ? call.answer_seconds : null,
        category: call.category || null,
        cmc: call.cmc || null,
        comment: call.comment || null,
        states: call.states,
        domain: call.domain,
      },
      recordings: recordingsWithUrls,
      transcripts: transcripts.map(t => ({
        full_text: t.full_text,
        channel_0_text: t.channel_0_text,
        channel_1_text: t.channel_1_text,
        segments: t.segments,
        is_mono: t.is_mono,
        created_at: t.created_at,
      })),
      ai_analysis: aiSummary ? {
        summary: aiSummary.summary,
        sentiment: aiSummary.sentiment?.overall || null,
        caller_mood: aiSummary.sentiment?.caller_mood || null,
        agent_performance: aiSummary.sentiment?.agent_performance || null,
        topics: aiSummary.topics || [],
        action_items: aiSummary.action_items || [],
        resolution: aiSummary.resolution || null,
        key_phrases: aiSummary.key_phrases || [],
      } : null,
      shared_by: shareDoc.created_by,
      shared_at: shareDoc.created_at,
    };
  });

  // ── List Active Share Links (admin) ─────────────────
  app.get("/api/share", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request) => {
    const links = await db.collection("share_tokens")
      .find({ revoked: { $ne: true }, expires_at: { $gt: new Date() } })
      .sort({ created_at: -1 })
      .limit(100)
      .toArray();

    const baseUrl = process.env.DOMAIN
      ? `https://${process.env.DOMAIN}`
      : `${request.protocol}://${request.hostname}`;

    return {
      links: links.map(l => ({
        _id: l._id,
        callid: l.callid,
        domain: l.domain,
        share_url: `${baseUrl}/share/${l.token}`,
        created_by: l.created_by,
        created_at: l.created_at,
        expires_at: l.expires_at,
        viewed: l.viewed,
        viewed_at: l.viewed_at,
      })),
    };
  });

  // ── Revoke Share Link ───────────────────────────────
  app.delete("/api/share/:id", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request, reply) => {
    const { id } = request.params;
    let objectId;
    try { objectId = new ObjectId(id); } catch { return reply.code(400).send({ error: "Invalid ID" }); }

    const result = await db.collection("share_tokens").updateOne(
      { _id: objectId },
      { $set: { revoked: true, revoked_at: new Date(), revoked_by: request.user.email } }
    );

    if (result.matchedCount === 0) return reply.code(404).send({ error: "Share link not found" });

    return { message: "Share link revoked" };
  });

  // ── Email Share Link ────────────────────────────────
  app.post("/api/share/email", {
    preHandler: requireAuth,
  }, async (request, reply) => {
    const { share_url, to, callid, note } = request.body || {};

    if (!to) return reply.code(400).send({ error: "Recipient email is required" });
    if (!share_url) return reply.code(400).send({ error: "Share URL is required" });

    try {
      await sendMail(db, {
        to,
        subject: `Shared Call Recording — ${callid || "Call Detail"}`,
        html: `
          <div style="font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 560px; margin: 0 auto; padding: 32px;">
            <div style="background: linear-gradient(135deg, #007aff 0%, #5856d6 100%); border-radius: 16px; padding: 32px; color: white; margin-bottom: 24px;">
              <h2 style="margin: 0 0 8px 0; font-size: 20px;">Call Recording Shared</h2>
              <p style="margin: 0; opacity: 0.9; font-size: 14px;">${request.user.email} has shared a call with you</p>
            </div>
            ${note ? `<div style="background: #f8f9fa; border-radius: 12px; padding: 16px; margin-bottom: 20px; color: #333;"><p style="margin: 0; font-size: 14px; line-height: 1.5;">${note.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</p></div>` : ''}
            <div style="text-align: center; margin: 28px 0;">
              <a href="${share_url}" style="display: inline-block; background: #007aff; color: white; text-decoration: none; padding: 14px 32px; border-radius: 12px; font-weight: 600; font-size: 15px;">View Call Detail</a>
            </div>
            <p style="color: #999; font-size: 12px; text-align: center; margin-top: 24px;">
              This is a one-time link. It will expire after viewing or within 24 hours.
            </p>
          </div>
        `,
      });

      return { message: `Share link emailed to ${to}` };
    } catch (err) {
      return reply.code(400).send({ error: "Failed to send email", detail: err.message });
    }
  });
}
