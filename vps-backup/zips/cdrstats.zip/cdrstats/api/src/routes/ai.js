/**
 * AI Analysis Routes
 *
 * GET  /api/calls/:callid/transcript   — Get transcript for a call
 * POST /api/calls/:callid/summarize    — Generate summary + sentiment via AI
 * POST /api/calls/:callid/retranscribe — Re-queue transcription job
 */

import { requireAuth } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";
import { chatCompletion, getAIModel } from "../services/ai-provider.js";

function buildSummaryPrompts(callContext, transcriptText) {
  const systemPrompt = `You are an expert call center analyst. Analyze the following phone call transcript and provide a structured analysis.

The call metadata: ${callContext}

The transcript has two channels:
- Channel 0 (Ch0): One party (could be caller or agent)
- Channel 1 (Ch1): The other party

Respond in valid JSON only — no markdown, no backticks, no preamble. Use this exact structure:
{
  "summary": "2-3 sentence summary of the call's purpose and outcome",
  "sentiment": {
    "overall": "positive" | "neutral" | "negative",
    "confidence": 0.0-1.0,
    "caller_mood": "brief description of caller's emotional state",
    "agent_performance": "brief assessment of how the agent handled the call"
  },
  "topics": ["topic1", "topic2"],
  "action_items": ["action1", "action2"],
  "resolution": "resolved" | "unresolved" | "transferred" | "callback_needed" | "unknown",
  "key_phrases": ["notable phrase 1", "notable phrase 2"]
}`;

  return [
    { role: "system", content: systemPrompt },
    { role: "user", content: "Here is the call transcript:\n\n" + transcriptText.slice(0, 8000) },
  ];
}

export default async function aiRoutes(app) {
  const { db } = app;

  // ── Get Transcript ──────────────────────────────────
  app.get("/api/calls/:callid/transcript", { preHandler: requireAuth }, async (request, reply) => {
    const { callid } = request.params;
    const scopeFilter = buildTenantFilter(request);

    const call = await db.collection("calls").findOne({ callid, ...scopeFilter });
    if (!call) return reply.code(404).send({ error: "Call not found" });

    const transcript = await db.collection("transcripts").findOne({
      callid, system: call.system, domain: call.domain,
    });

    if (!transcript) {
      return reply.code(404).send({
        error: "No transcript available",
        has_recording: call.has_recording || false,
        message: call.has_recording
          ? "Transcription may still be processing. Try again in a moment."
          : "No recording available for this call.",
      });
    }

    return {
      callid,
      transcript: {
        segments: transcript.segments,
        full_text: transcript.full_text,
        channel_0_text: transcript.channel_0_text,
        channel_1_text: transcript.channel_1_text,
        model: transcript.model,
        duration_seconds: transcript.duration_seconds,
        is_mono: transcript.is_mono,
        recordings_meta: transcript.recordings_meta || [],
        segmentation: transcript.segmentation || "chunked",
        created_at: transcript.created_at,
      },
      summary: transcript.summary || null,
    };
  });

  // ── Summarize (AI) ─────────────────────────────────
  app.post("/api/calls/:callid/summarize", { preHandler: requireAuth }, async (request, reply) => {
    const { callid } = request.params;
    const scopeFilter = buildTenantFilter(request);

    const call = await db.collection("calls").findOne({ callid, ...scopeFilter });
    if (!call) return reply.code(404).send({ error: "Call not found" });

    const transcript = await db.collection("transcripts").findOne({
      callid, system: call.system, domain: call.domain,
    });

    if (!transcript || !transcript.full_text) {
      return reply.code(400).send({ error: "No transcript available to summarize" });
    }

    const callContext = [
      `Direction: ${call.call_direction || "unknown"}`,
      `Duration: ${Math.round(call.duration_seconds || 0)}s`,
      call.answering_queue_name ? `Queue: ${call.answering_queue_name}` : null,
      call.answering_extension_name ? `Agent: ${call.answering_extension_name}` : null,
      `Status: ${call.is_answered ? "Answered" : call.is_abandoned ? "Abandoned" : "Missed"}`,
    ].filter(Boolean).join(", ");

    const messages = buildSummaryPrompts(callContext, transcript.full_text);

    try {
      app.log.info({ callid }, "Calling AI for summary");
      const raw = await chatCompletion(db, messages, { maxTokens: 1500 });

      let analysis;
      try {
        const cleaned = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();
        analysis = JSON.parse(cleaned);
      } catch (parseErr) {
        app.log.error({ raw: raw.slice(0, 500) }, "Failed to parse AI response as JSON");
        return reply.code(500).send({ error: "Failed to parse AI response", raw: raw.slice(0, 200) });
      }

      const modelUsed = await getAIModel(db);

      await db.collection("transcripts").updateOne(
        { callid, system: call.system, domain: call.domain },
        { $set: { summary: { ...analysis, model: modelUsed, generated_at: new Date() } } }
      );

      await db.collection("calls").updateOne(
        { callid, system: call.system, domain: call.domain },
        { $set: { has_summary: true, sentiment: analysis.sentiment?.overall || null, summary_generated_at: new Date() } }
      );

      app.log.info({ callid, sentiment: analysis.sentiment?.overall }, "Summary generated");
      return { callid, summary: { ...analysis, model: modelUsed, generated_at: new Date() } };

    } catch (err) {
      app.log.error(err, "AI summarization failed");
      return reply.code(500).send({ error: err.message });
    }
  });

  // ── Re-transcribe ───────────────────────────────────
  app.post("/api/calls/:callid/retranscribe", { preHandler: requireAuth }, async (request, reply) => {
    const { callid } = request.params;
    const scopeFilter = buildTenantFilter(request);

    const call = await db.collection("calls").findOne({ callid, ...scopeFilter });
    if (!call) return reply.code(404).send({ error: "Call not found" });

    const recording = await db.collection("recordings").findOne({
      callid, system: call.system, domain: call.domain, upload_status: "completed",
    });

    if (!recording) {
      return reply.code(400).send({ error: "No completed recording found for this call" });
    }

    await db.collection("transcripts").deleteOne({ callid, system: call.system, domain: call.domain });
    await db.collection("calls").updateOne(
      { callid, system: call.system, domain: call.domain },
      { $set: { has_transcript: false, has_summary: false, sentiment: null } }
    );

    let qRedis = null;
    try {
      const Redis = (await import("ioredis")).default;
      const { Queue } = await import("bullmq");
      qRedis = new Redis(process.env.REDIS_URL || "redis://redis:6379", { maxRetriesPerRequest: null });
      const queue = new Queue("transcription", { connection: qRedis });
      await queue.add("retranscribe-" + callid, {
        system: call.system, domain: call.domain, callid,
        recording_id: recording._id.toString(),
        storage_key: recording.storage_key,
      }, { attempts: 2, backoff: { type: "exponential", delay: 30000 }, removeOnComplete: 100, removeOnFail: 500 });
      return { message: "Transcription job queued", callid };
    } catch (err) {
      app.log.error(err, "Failed to queue retranscription");
      return reply.code(500).send({ error: "Failed to queue transcription" });
    } finally {
      if (qRedis) { try { await qRedis.quit(); } catch { /* already gone */ } }
    }
  });
}
