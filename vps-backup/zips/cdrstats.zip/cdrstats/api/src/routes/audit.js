/**
 * Audit Log Routes
 *
 * GET /api/audit — List audit events (super_admin only)
 *   Query: category, action, page, limit, from, to
 */

import { requireRole } from "../middleware/authenticate.js";

export default async function auditRoutes(app) {
  const { db } = app;

  app.get("/api/audit", {
    preHandler: requireRole("super_admin"),
  }, async (request) => {
    const { category, action, page = 1, limit = 50, from, to } = request.query || {};

    const filter = {};
    if (category) filter.category = category;
    if (action) filter.action = action;
    if (from || to) {
      filter.created_at = {};
      if (from) filter.created_at.$gte = new Date(from);
      if (to) filter.created_at.$lte = new Date(to);
    }

    const pageNum = Math.max(1, parseInt(page) || 1);
    const pageSize = Math.min(100, Math.max(1, parseInt(limit) || 50));
    const skip = (pageNum - 1) * pageSize;

    const [events, total] = await Promise.all([
      db.collection("audit_logs")
        .find(filter)
        .sort({ created_at: -1 })
        .skip(skip)
        .limit(pageSize)
        .toArray(),
      db.collection("audit_logs").countDocuments(filter),
    ]);

    return { events, total, page: pageNum, pages: Math.ceil(total / pageSize) };
  });
}
