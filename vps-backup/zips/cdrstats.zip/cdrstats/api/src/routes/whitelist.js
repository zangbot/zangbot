import { logAudit, AUDIT } from "../services/audit.js";
/**
 * IP Whitelist Management — Extended with PBX WebSocket credentials
 *
 * Each IP entry can now store:
 *   { ip, label, pbx_url, pbx_port, admin_user_encrypted, admin_pass_encrypted,
 *     ws_user, ws_enabled, domains[] }
 *
 * GET  /api/admin/whitelist              — Get current whitelist (passwords masked)
 * PUT  /api/admin/whitelist              — Update whitelist (full replace)
 * POST /api/admin/whitelist/test-pbx     — Test PBX connection for a given entry
 */

import { requireRole } from "../middleware/authenticate.js";
import crypto from "crypto";
import https from "https";
import dns from "dns";

// ── AES-256-GCM helpers (same pattern as storage.js / mailer.js) ──
function getEncryptionKey() {
  const KEY_ENV = process.env.SMTP_ENCRYPTION_KEY || process.env.JWT_SECRET;
  return crypto.createHash("sha256").update(KEY_ENV).digest();
}

function encrypt(text) {
  if (!text) return null;
  const key = getEncryptionKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  let enc = cipher.update(text, "utf8", "hex");
  enc += cipher.final("hex");
  const tag = cipher.getAuthTag().toString("hex");
  return iv.toString("hex") + ":" + tag + ":" + enc;
}

function decrypt(encrypted) {
  try {
    if (!encrypted) return null;
    const key = getEncryptionKey();
    const [ivHex, tagHex, data] = encrypted.split(":");
    if (!ivHex || !tagHex || !data) return null;
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(ivHex, "hex"));
    decipher.setAuthTag(Buffer.from(tagHex, "hex"));
    let dec = decipher.update(data, "hex", "utf8");
    dec += decipher.final("utf8");
    return dec;
  } catch { return null; }
}

// ── Mask entry for frontend (never send encrypted passwords) ──
function maskEntry(entry) {
  const out = { ...entry };
  // Replace encrypted fields with boolean indicators
  out.has_admin_user = !!entry.admin_user_encrypted;
  out.has_admin_pass = !!entry.admin_pass_encrypted;
  delete out.admin_user_encrypted;
  delete out.admin_pass_encrypted;
  return out;
}

// ── Process entry from frontend (encrypt passwords if provided) ──
function processEntry(incoming, existing) {
  const entry = {
    ip: (incoming.ip || "").trim(),
    label: (incoming.label || "").trim(),
    pbx_url: (incoming.pbx_url || "").trim(),
    pbx_port: parseInt(incoming.pbx_port) || 443,
    ws_user: (incoming.ws_user || "admin").trim(),
    ws_enabled: incoming.ws_enabled === true,
    domains: Array.isArray(incoming.domains) ? incoming.domains.filter(Boolean) : [],
  };

  // Admin user: if new value provided, encrypt it. Otherwise keep existing.
  if (incoming.admin_user && incoming.admin_user !== "••••••••") {
    entry.admin_user_encrypted = encrypt(incoming.admin_user);
  } else if (existing?.admin_user_encrypted) {
    entry.admin_user_encrypted = existing.admin_user_encrypted;
  }

  // Admin password: same logic
  if (incoming.admin_pass && incoming.admin_pass !== "••••••••") {
    entry.admin_pass_encrypted = encrypt(incoming.admin_pass);
  } else if (existing?.admin_pass_encrypted) {
    entry.admin_pass_encrypted = existing.admin_pass_encrypted;
  }

  return entry;
}

// ── HTTPS request helper for PBX test ──
function pbxRequest(hostname, port, path, method, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const postData = body ? JSON.stringify(body) : null;
    const opts = {
      hostname, port: port || 443, path, method,
      headers: {
        "Content-Type": "application/json",
        ...(postData && { "Content-Length": Buffer.byteLength(postData) }),
        ...headers,
      },
      rejectUnauthorized: false, // PBX may use self-signed certs
      timeout: 10000,
    };

    const req = https.request(opts, (res) => {
      let data = "";
      const cookies = res.headers["set-cookie"];
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(data), cookies }); }
        catch { resolve({ status: res.statusCode, data, cookies }); }
      });
    });

    req.on("error", reject);
    req.on("timeout", () => { req.destroy(); reject(new Error("Connection timeout")); });
    if (postData) req.write(postData);
    req.end();
  });
}

export default async function whitelistRoutes(app) {
  const { db } = app;

  // ── GET — return whitelist with passwords masked ──
  app.get("/api/admin/whitelist", {
    preHandler: requireRole("super_admin"),
  }, async () => {
    const doc = await db.collection("settings").findOne({ key: "ip_whitelist" });
    const ips = doc?.ips || [];

    // Normalize old format (plain strings) + mask
    const normalized = ips.map(entry => {
      if (typeof entry === "string") return maskEntry({ ip: entry, label: "" });
      return maskEntry(entry);
    });

    return { ips: normalized, updated_at: doc?.updated_at, updated_by: doc?.updated_by };
  });

  // ── PUT — update whitelist (encrypt credentials) ──
  app.put("/api/admin/whitelist", {
    preHandler: requireRole("super_admin"),
  }, async (request) => {
    const { ips } = request.body || {};
    if (!Array.isArray(ips)) return { error: "ips must be an array" };

    // Load existing entries for password preservation
    const existingDoc = await db.collection("settings").findOne({ key: "ip_whitelist" });
    const existingIps = existingDoc?.ips || [];
    const existingMap = new Map();
    existingIps.forEach(e => {
      if (typeof e === "object" && e.ip) existingMap.set(e.ip, e);
    });

    // Process each entry
    const processed = ips
      .filter(e => e && (typeof e === "string" ? e.trim() : e.ip?.trim()))
      .map(entry => {
        if (typeof entry === "string") {
          return processEntry({ ip: entry }, null);
        }
        const existing = existingMap.get(entry.ip?.trim());
        return processEntry(entry, existing);
      })
      .filter(e => /^[\d.:/]+$/.test(e.ip));

    await db.collection("settings").updateOne(
      { key: "ip_whitelist" },
      { $set: { ips: processed, updated_at: new Date(), updated_by: request.user.email } },
      { upsert: true }
    );

    // Flush Redis cache so cdr.js picks up changes immediately
    try { await app.redis.del("cdr:ip_whitelist"); } catch {}

    app.log.info({ count: processed.length, by: request.user.email }, "IP whitelist updated");
    logAudit(db, { action: "whitelist_updated", category: AUDIT.WHITELIST, actor: request.user.email, actor_id: request.user.userId, ip: request.ip, details: { count: processed.length } });
    return { ips: processed.map(maskEntry), message: "Whitelist updated" };
  });

  // ── POST — test PBX connection ──
  app.post("/api/admin/whitelist/test-pbx", {
    preHandler: requireRole("super_admin"),
  }, async (request) => {
    const { ip, pbx_url, pbx_port, admin_user, admin_pass } = request.body || {};

    if (!pbx_url) return { success: false, error: "PBX hostname is required" };

    // Resolve credentials: use provided values, or decrypt from DB
    let user = admin_user;
    let pass = admin_pass;

    if ((!user || user === "••••••••") || (!pass || pass === "••••••••")) {
      const doc = await db.collection("settings").findOne({ key: "ip_whitelist" });
      const entry = (doc?.ips || []).find(e => typeof e === "object" && e.ip === ip);
      if (entry) {
        if (!user || user === "••••••••") user = decrypt(entry.admin_user_encrypted);
        if (!pass || pass === "••••••••") pass = decrypt(entry.admin_pass_encrypted);
      }
    }

    if (!user || !pass) return { success: false, error: "Admin credentials required" };

    const port = parseInt(pbx_port) || 443;
    const wsUser = request.body.ws_user || "admin";

    // Step 0: DNS A record lookup — pbx_url must resolve to the whitelisted IP
    if (ip) {
      try {
        const addresses = await dns.promises.resolve4(pbx_url);
        if (!addresses.includes(ip)) {
          return {
            success: false,
            ip_match: false,
            resolved_ip: addresses[0] || null,
            resolved_all: addresses,
            expected_ip: ip,
            error: `DNS mismatch: ${pbx_url} resolves to ${addresses.join(", ")} but this entry is ${ip}`
          };
        }
      } catch (dnsErr) {
        return {
          success: false,
          ip_match: false,
          resolved_ip: null,
          expected_ip: ip,
          error: `Cannot resolve ${pbx_url}: ${dnsErr.code || dnsErr.message}`
        };
      }
    }

    try {
      // Step 1: Create third-party session
      const authHeader = "Basic " + Buffer.from(`${user}:${pass}`).toString("base64");
      const domain = (request.body.domains || [])[0] || "localhost";

      const step1 = await pbxRequest(pbx_url, port, "/rest/system/session", "POST",
        { name: "3rd", admin: true },
        { Authorization: authHeader }
      );

      if (step1.status !== 200 || !step1.data) {
        return { success: false, error: `Auth failed (HTTP ${step1.status})`, detail: step1.data };
      }

      const sessionId = typeof step1.data === "string" ? step1.data : step1.data.toString();

      // Step 2: Activate session
      const cookieHeader = step1.cookies?.map(c => c.split(";")[0]).join("; ") || "";
      const step2 = await pbxRequest(pbx_url, port, "/rest/system/session", "POST",
        { name: "session", value: sessionId },
        { Cookie: cookieHeader }
      );

      const allCookies = [
        cookieHeader,
        ...(step2.cookies || []).map(c => c.split(";")[0])
      ].filter(Boolean).join("; ");

      return {
        success: true,
        ip_match: true,
        resolved_ip: ip,
        message: `Connected to ${pbx_url} — session established (DNS ✓ IP match ✓)`,
        sessionId,
        pbx_url,
      };
    } catch (err) {
      return { success: false, ip_match: true, resolved_ip: ip, error: err.message || "Connection failed" };
    }
  });
}

// ── Exported helper: add domain to whitelist entry (called from cdr.js) ──
export async function addDomainToWhitelistEntry(db, redis, clientIp, domain) {
  if (!clientIp || !domain) return;

  try {
    const doc = await db.collection("settings").findOne({ key: "ip_whitelist" });
    if (!doc?.ips) return;

    let updated = false;
    const ips = doc.ips.map(entry => {
      if (typeof entry !== "object") return entry;
      const entryIp = entry.ip;
      if (entryIp !== clientIp) return entry;

      const domains = entry.domains || [];
      if (!domains.includes(domain)) {
        domains.push(domain);
        updated = true;
        return { ...entry, domains };
      }
      return entry;
    });

    if (updated) {
      await db.collection("settings").updateOne(
        { key: "ip_whitelist" },
        { $set: { ips } }
      );
      // Flush cache
      try { await redis.del("cdr:ip_whitelist"); } catch {}
    }
  } catch (err) {
    // Non-critical — log but don't throw
    console.error("Failed to auto-add domain to whitelist entry:", err.message);
  }
}
