/**
 * AI Insights API Routes
 *
 * GET  /api/ai/insights         — Aggregate sentiment, topics, resolution stats
 * GET  /api/ai/sentiment-trend  — Daily sentiment trend
 * GET  /api/ai/negative-calls   — Recent negative sentiment calls
 * GET  /api/ai/topics           — Top topics across calls
 * GET  /api/ai/search           — Full-text transcript search
 * GET  /api/ai/resolution       — Resolution rate breakdown
 */

import { requireAuth } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";

function buildDateFilter(request) {
  const scope = buildTenantFilter(request);
  const { start_from, start_to, domain } = request.query;
  const filter = { ...scope };
  if (domain) filter.domain = domain;
  if (start_from || start_to) {
    filter.start = {};
    if (start_from) {
      const val = parseFloat(start_from);
      filter.start.$gte = val > 946684800 ? val : new Date(start_from).getTime() / 1000;
    }
    if (start_to) {
      const val = parseFloat(start_to);
      filter.start.$lte = val > 946684800 ? val : new Date(start_to).getTime() / 1000;
    }
  }
  return filter;
}

function mergeFilter(base, extra) {
  const merged = { ...base };
  for (const [key, val] of Object.entries(extra)) {
    if (key in merged) {
      if (!merged.$and) merged.$and = [];
      merged.$and.push({ [key]: merged[key] });
      merged.$and.push({ [key]: val });
      delete merged[key];
    } else {
      merged[key] = val;
    }
  }
  return merged;
}

export default async function insightsRoutes(app) {
  const { db } = app;

  // ── Aggregate Insights ──────────────────────────────
  app.get("/api/ai/insights", { preHandler: requireAuth }, async (request) => {
    const filter = mergeFilter(buildDateFilter(request), { sentiment: { $ne: null } });

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: null,
          total_analyzed: { $sum: 1 },
          positive: { $sum: { $cond: [{ $eq: ["$sentiment", "positive"] }, 1, 0] } },
          neutral: { $sum: { $cond: [{ $eq: ["$sentiment", "neutral"] }, 1, 0] } },
          negative: { $sum: { $cond: [{ $eq: ["$sentiment", "negative"] }, 1, 0] } },
        },
      },
    ];

    const [result] = await db.collection("calls").aggregate(pipeline).toArray();

    // Total calls in range (for comparison)
    const baseFilter = buildDateFilter(request);
    const totalCalls = await db.collection("calls").countDocuments(baseFilter);
    const totalWithTranscript = await db.collection("calls").countDocuments({ ...baseFilter, has_transcript: true });
    const totalWithSummary = await db.collection("calls").countDocuments({ ...baseFilter, has_summary: true });

    return {
      total_calls: totalCalls,
      total_transcribed: totalWithTranscript,
      total_analyzed: result?.total_analyzed || 0,
      sentiment: {
        positive: result?.positive || 0,
        neutral: result?.neutral || 0,
        negative: result?.negative || 0,
      },
    };
  });

  // ── Sentiment Trend (daily) ─────────────────────────
  app.get("/api/ai/sentiment-trend", { preHandler: requireAuth }, async (request) => {
    const filter = mergeFilter(buildDateFilter(request), { sentiment: { $ne: null } });

    const pipeline = [
      { $match: filter },
      {
        $group: {
          _id: {
            date: { $dateToString: { format: "%Y-%m-%d", date: { $toDate: { $multiply: ["$start", 1000] } } } },
          },
          positive: { $sum: { $cond: [{ $eq: ["$sentiment", "positive"] }, 1, 0] } },
          neutral: { $sum: { $cond: [{ $eq: ["$sentiment", "neutral"] }, 1, 0] } },
          negative: { $sum: { $cond: [{ $eq: ["$sentiment", "negative"] }, 1, 0] } },
          total: { $sum: 1 },
        },
      },
      { $sort: { "_id.date": 1 } },
    ];

    const results = await db.collection("calls").aggregate(pipeline).toArray();

    return {
      trend: results.map(r => ({
        date: r._id.date,
        positive: r.positive,
        neutral: r.neutral,
        negative: r.negative,
        total: r.total,
        negative_rate: r.total > 0 ? Math.round((r.negative / r.total) * 10000) / 100 : 0,
      })),
    };
  });

  // ── Recent Negative Calls ───────────────────────────
  app.get("/api/ai/negative-calls", { preHandler: requireAuth }, async (request) => {
    const filter = mergeFilter(buildDateFilter(request), { sentiment: "negative" });
    const limit = parseInt(request.query.limit || "20");

    const calls = await db.collection("calls")
      .find(filter, {
        projection: {
          callid: 1, domain: 1, start: 1, call_direction: 1,
          from_display_name: 1, from_number_raw: 1,
          to_display_name: 1, to_number_raw: 1,
          answering_extension: 1, answering_extension_name: 1, answering_queue_name: 1,
          duration_seconds: 1, talk_seconds: 1, sentiment: 1,
          has_summary: 1,
        },
      })
      .sort({ start: -1 })
      .limit(limit)
      .toArray();

    // Fetch summaries for these calls
    const callids = calls.map(c => c.callid);
    const transcripts = await db.collection("transcripts")
      .find({ callid: { $in: callids }, "summary.summary": { $exists: true } },
        { projection: { callid: 1, "summary.summary": 1, "summary.sentiment": 1, "summary.resolution": 1 } })
      .toArray();

    const transcriptMap = {};
    transcripts.forEach(t => { transcriptMap[t.callid] = t.summary; });

    return {
      calls: calls.map(c => ({
        ...c,
        summary_text: transcriptMap[c.callid]?.summary || null,
        resolution: transcriptMap[c.callid]?.resolution || null,
        caller_mood: transcriptMap[c.callid]?.sentiment?.caller_mood || null,
      })),
    };
  });

  // ── Top Topics ──────────────────────────────────────
  app.get("/api/ai/topics", { preHandler: requireAuth }, async (request) => {
    const scope = buildTenantFilter(request);
    const { start_from, start_to, domain } = request.query;

    const matchFilter = { "summary.topics": { $exists: true, $ne: [] } };
    if (domain) matchFilter.domain = domain;
    if (scope.domain) matchFilter.domain = scope.domain;

    // Filter by call time range — find matching callids from calls collection
    if (start_from || start_to) {
      const callFilter = {};
      if (matchFilter.domain) callFilter.domain = matchFilter.domain;
      callFilter.start = {};
      if (start_from) {
        const val = parseFloat(start_from);
        callFilter.start.$gte = val > 946684800 ? val : new Date(start_from).getTime() / 1000;
      }
      if (start_to) {
        const val = parseFloat(start_to);
        callFilter.start.$lte = val > 946684800 ? val : new Date(start_to).getTime() / 1000;
      }
      const callids = await db.collection("calls").distinct("callid", callFilter);
      matchFilter.callid = { $in: callids };
    }

    const pipeline = [
      { $match: matchFilter },
      { $unwind: "$summary.topics" },
      {
        $group: {
          _id: { $toLower: "$summary.topics" },
          count: { $sum: 1 },
          avg_sentiment_score: {
            $avg: {
              $switch: {
                branches: [
                  { case: { $eq: ["$summary.sentiment.overall", "positive"] }, then: 1 },
                  { case: { $eq: ["$summary.sentiment.overall", "neutral"] }, then: 0 },
                  { case: { $eq: ["$summary.sentiment.overall", "negative"] }, then: -1 },
                ],
                default: 0,
              },
            },
          },
        },
      },
      { $sort: { count: -1 } },
      { $limit: 30 },
    ];

    const results = await db.collection("transcripts").aggregate(pipeline).toArray();

    return {
      topics: results.map(r => ({
        topic: r._id,
        count: r.count,
        avg_sentiment: r.avg_sentiment_score > 0.3 ? "positive" : r.avg_sentiment_score < -0.3 ? "negative" : "neutral",
      })),
    };
  });

  // ── Transcript Search ───────────────────────────────
  app.get("/api/ai/search", { preHandler: requireAuth }, async (request) => {
    const { q, domain } = request.query;
    const limit = parseInt(request.query.limit || "25");
    const page = parseInt(request.query.page || "1");

    if (!q || q.length < 2) {
      return { results: [], total: 0, message: "Search query must be at least 2 characters" };
    }

    const scope = buildTenantFilter(request);
    const searchFilter = {
      $text: { $search: q },
      ...scope,
    };
    if (domain) searchFilter.domain = domain;

    const total = await db.collection("transcripts").countDocuments(searchFilter);

    const results = await db.collection("transcripts")
      .find(searchFilter, {
        projection: {
          score: { $meta: "textScore" },
          callid: 1, domain: 1, system: 1,
          channel_0_text: 1, channel_1_text: 1,
          duration_seconds: 1, model: 1, created_at: 1,
          "summary.summary": 1, "summary.sentiment": 1,
        },
      })
      .sort({ score: { $meta: "textScore" } })
      .skip((page - 1) * limit)
      .limit(limit)
      .toArray();

    // Fetch call details for each result
    const callids = results.map(r => r.callid);
    const calls = await db.collection("calls")
      .find({ callid: { $in: callids } }, {
        projection: {
          callid: 1, start: 1, call_direction: 1, sentiment: 1,
          from_display_name: 1, from_number_raw: 1,
          answering_extension: 1, answering_extension_name: 1, answering_queue_name: 1,
          duration_seconds: 1, domain: 1,
        },
      })
      .toArray();

    const callMap = {};
    calls.forEach(c => { callMap[c.callid] = c; });

    return {
      results: results.map(r => ({
        callid: r.callid,
        domain: r.domain,
        score: r.score,
        snippet: highlightSnippet(r.channel_0_text + " " + r.channel_1_text, q, 200),
        summary: r.summary?.summary || null,
        sentiment: r.summary?.sentiment?.overall || null,
        call: callMap[r.callid] || null,
        created_at: r.created_at,
      })),
      total,
      page,
      pages: Math.ceil(total / limit),
    };
  });

  // ── Resolution Breakdown ────────────────────────────
  app.get("/api/ai/resolution", { preHandler: requireAuth }, async (request) => {
    const scope = buildTenantFilter(request);
    const { start_from, start_to, domain } = request.query;

    const matchFilter = { "summary.resolution": { $exists: true } };
    if (domain) matchFilter.domain = domain;
    if (scope.domain) matchFilter.domain = scope.domain;

    // Filter by call time range
    if (start_from || start_to) {
      const callFilter = {};
      if (matchFilter.domain) callFilter.domain = matchFilter.domain;
      callFilter.start = {};
      if (start_from) {
        const val = parseFloat(start_from);
        callFilter.start.$gte = val > 946684800 ? val : new Date(start_from).getTime() / 1000;
      }
      if (start_to) {
        const val = parseFloat(start_to);
        callFilter.start.$lte = val > 946684800 ? val : new Date(start_to).getTime() / 1000;
      }
      const callids = await db.collection("calls").distinct("callid", callFilter);
      matchFilter.callid = { $in: callids };
    }

    const pipeline = [
      { $match: matchFilter },
      {
        $group: {
          _id: "$summary.resolution",
          count: { $sum: 1 },
        },
      },
      { $sort: { count: -1 } },
    ];

    const results = await db.collection("transcripts").aggregate(pipeline).toArray();
    const total = results.reduce((s, r) => s + r.count, 0);

    return {
      resolution: results.map(r => ({
        status: r._id,
        count: r.count,
        percentage: total > 0 ? Math.round((r.count / total) * 10000) / 100 : 0,
      })),
      total,
    };
  });

  // ── Tenant AI Settings ──────────────────────────────
  app.put("/api/tenants/:id/ai-settings", { preHandler: requireAuth }, async (request, reply) => {
    if (request.user.role !== "super_admin" && request.user.role !== "admin") {
      return reply.code(403).send({ error: "Admin access required" });
    }

    const { ObjectId } = await import("mongodb");
    let id;
    try { id = new ObjectId(request.params.id); } catch { return reply.code(400).send({ error: "Invalid ID" }); }

    const { ai_auto_summarize } = request.body || {};

    await db.collection("tenants").updateOne(
      { _id: id },
      { $set: { ai_auto_summarize: !!ai_auto_summarize, updated_at: new Date() } }
    );

    return { message: "AI settings updated", ai_auto_summarize: !!ai_auto_summarize };
  });
}

/**
 * Extract a snippet around the search term with highlighting markers
 */
function highlightSnippet(text, query, maxLen) {
  if (!text) return "";
  const lower = text.toLowerCase();
  const qLower = query.toLowerCase();
  const idx = lower.indexOf(qLower);
  if (idx === -1) return text.slice(0, maxLen) + (text.length > maxLen ? "..." : "");

  const start = Math.max(0, idx - 60);
  const end = Math.min(text.length, idx + query.length + 60);
  let snippet = (start > 0 ? "..." : "") + text.slice(start, end) + (end < text.length ? "..." : "");
  return snippet;
}
