import { logAudit, AUDIT } from "../services/audit.js";
/**
 * Tenant Management Routes
 *
 * GET    /api/tenants            — List tenants (scoped)
 * GET    /api/tenants/:id        — Get tenant details
 * PUT    /api/tenants/:id        — Update tenant (display name, normalisation)
 * POST   /api/tenants/:id/test   — Test number normalisation config
 */

import { requireAuth, requireRole } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";
import { normalizeNumber } from "../services/normalize.js";

export default async function tenantRoutes(app) {
  const { db } = app;

  // ── List Tenants ────────────────────────────────────
  app.get("/api/tenants", {
    preHandler: requireAuth,
  }, async (request) => {
    const scopeFilter = buildTenantFilter(request);

    const tenants = await db
      .collection("tenants")
      .find(scopeFilter)
      .sort({ domain: 1 })
      .toArray();

    return { tenants };
  });

  // ── Get Tenant ──────────────────────────────────────
  app.get("/api/tenants/:id", {
    preHandler: requireAuth,
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try {
      id = new ObjectId(request.params.id);
    } catch {
      return reply.code(400).send({ error: "Invalid tenant ID" });
    }

    const scopeFilter = buildTenantFilter(request);
    const tenant = await db.collection("tenants").findOne({
      _id: id,
      ...scopeFilter,
    });

    if (!tenant) {
      return reply.code(404).send({ error: "Tenant not found" });
    }

    return { tenant };
  });

  // ── Update Tenant ───────────────────────────────────
  app.put("/api/tenants/:id", {
    preHandler: requireRole("super_admin", "admin"),
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try {
      id = new ObjectId(request.params.id);
    } catch {
      return reply.code(400).send({ error: "Invalid tenant ID" });
    }

    const scopeFilter = buildTenantFilter(request);
    const existing = await db.collection("tenants").findOne({
      _id: id,
      ...scopeFilter,
    });

    if (!existing) {
      return reply.code(404).send({ error: "Tenant not found" });
    }

    const updates = {};
    const { display_name, normalization, timezone } = request.body || {};

    if (display_name) updates.display_name = display_name;
    if (timezone !== undefined) {
      // Validate IANA timezone string
      if (timezone === null || timezone === "") {
        updates.timezone = null;
      } else {
        try {
          Intl.DateTimeFormat(undefined, { timeZone: timezone });
          updates.timezone = timezone;
        } catch {
          return reply.code(400).send({ error: "Invalid timezone: " + timezone });
        }
      }
    }

    if (normalization) {
      // Validate normalisation config shape
      const norm = { ...existing.normalization, ...normalization };
      if (norm.default_country && typeof norm.default_country !== "string") {
        return reply.code(400).send({ error: "default_country must be a string" });
      }
      if (normalization.show_country_flags !== undefined) {
        norm.show_country_flags = !!normalization.show_country_flags;
      }
      updates.normalization = norm;
    }

    updates.updated_at = new Date();

    await db.collection("tenants").updateOne({ _id: id }, { $set: updates });
    logAudit(db, { action: "tenant_updated", category: AUDIT.TENANTS, actor: request.user.email, actor_id: request.user.userId, target: request.params.id, ip: request.ip, details: { fields: Object.keys(updates).filter(k => k !== "updated_at") } });

    // Invalidate Redis cache for this tenant's normalisation config
    try {
      await app.redis.del(`tenant_norm:${existing.system}:${existing.domain}`);
    } catch { /* ignore */ }

    app.log.info(
      { tenantId: request.params.id, domain: existing.domain, updatedBy: request.user.email },
      "Tenant updated"
    );

    return { message: "Tenant updated" };
  });

  // ── Test Normalisation ──────────────────────────────
  // Live tool: type a number, see normalised result
  app.post("/api/tenants/:id/test-normalize", {
    preHandler: requireAuth,
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try {
      id = new ObjectId(request.params.id);
    } catch {
      return reply.code(400).send({ error: "Invalid tenant ID" });
    }

    const scopeFilter = buildTenantFilter(request);
    const tenant = await db.collection("tenants").findOne({
      _id: id,
      ...scopeFilter,
    });

    if (!tenant) {
      return reply.code(404).send({ error: "Tenant not found" });
    }

    const { number } = request.body || {};
    if (!number) {
      return reply.code(400).send({ error: "number field required" });
    }

    const result = normalizeNumber(number, tenant.normalization);

    return {
      input: number,
      config: {
        default_country: tenant.normalization.default_country,
        trunk_prefix: tenant.normalization.trunk_prefix,
        international_prefix: tenant.normalization.international_prefix,
      },
      result,
    };
  });


  // ── Bulk Update All Tenants ─────────────────────────
  app.put("/api/admin/tenants/bulk", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { field, value } = request.body || {};

    if (!field) return reply.code(400).send({ error: "field is required" });

    const allowedFields = ["data_retention_days", "default_country", "international_prefix", "show_country_flags"];
    if (!allowedFields.includes(field)) {
      return reply.code(400).send({ error: `Invalid field. Allowed: ${allowedFields.join(", ")}` });
    }

    let update;
    let description;

    switch (field) {
      case "data_retention_days": {
        const days = parseInt(value);
        if (isNaN(days) || days < 0) return reply.code(400).send({ error: "Invalid retention days" });
        update = { $set: { data_retention_days: days, updated_at: new Date() } };
        description = days === 0 ? "Forever" : `${days} days`;
        break;
      }
      case "default_country": {
        if (!value || typeof value !== "string" || value.length !== 2) {
          return reply.code(400).send({ error: "default_country must be a 2-letter country code" });
        }
        update = { $set: { "normalization.default_country": value.toUpperCase(), updated_at: new Date() } };
        description = value.toUpperCase();
        break;
      }
      case "international_prefix": {
        if (typeof value !== "string") return reply.code(400).send({ error: "international_prefix must be a string" });
        update = { $set: { "normalization.international_prefix": value, updated_at: new Date() } };
        description = value || "(empty)";
        break;
      }
      case "show_country_flags": {
        const flagVal = !!value;
        update = { $set: { "normalization.show_country_flags": flagVal, updated_at: new Date() } };
        description = flagVal ? "On" : "Off";
        break;
      }
    }

    const result = await db.collection("tenants").updateMany({}, update);

    // Clear Redis cache for all tenant normalization configs
    try {
      const tenants = await db.collection("tenants").find({}, { projection: { system: 1, domain: 1 } }).toArray();
      for (const t of tenants) {
        try { await app.redis.del(`tenant_norm:${t.system}:${t.domain}`); } catch {}
      }
    } catch {}

    app.log.info(
      { field, value: description, updated: result.modifiedCount, by: request.user.email },
      "Bulk tenant update"
    );

    return {
      message: `Updated ${field} to "${description}" for ${result.modifiedCount} tenants`,
      modified: result.modifiedCount,
    };
  });

  // ── Delete Tenant & All Associated Data ─────────────
  app.post("/api/tenants/:id/delete", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try { id = new ObjectId(request.params.id); } catch { return reply.code(400).send({ error: "Invalid tenant ID" }); }

    const { confirm_domain } = request.body || {};
    const tenant = await db.collection("tenants").findOne({ _id: id });
    if (!tenant) return reply.code(404).send({ error: "Tenant not found" });

    if (confirm_domain !== tenant.domain) {
      return reply.code(400).send({ error: "Domain confirmation does not match. Type the exact domain to confirm deletion." });
    }

    const domain = tenant.domain;
    app.log.warn({ domain, by: request.user.email }, "Deleting tenant and all associated data");

    const callids = await db.collection("calls").distinct("callid", { domain });

    const results = {
      calls: (await db.collection("calls").deleteMany({ domain })).deletedCount,
      transcripts: callids.length > 0 ? (await db.collection("transcripts").deleteMany({ callid: { $in: callids } })).deletedCount : 0,
      recordings: callids.length > 0 ? (await db.collection("recordings").deleteMany({ callid: { $in: callids } })).deletedCount : 0,
      share_tokens: (await db.collection("share_tokens").deleteMany({ domain })).deletedCount,
      briefings: (await db.collection("briefings").deleteMany({ domain })).deletedCount,
      tenant: (await db.collection("tenants").deleteOne({ _id: id })).deletedCount,
    };

    app.log.warn({ domain, results, by: request.user.email }, "Tenant deleted");
    logAudit(db, { action: "tenant_deleted", category: AUDIT.TENANTS, actor: request.user.email, actor_id: request.user.userId, target: domain, ip: request.ip, details: results });

    return {
      message: "Tenant " + domain + " and all associated data deleted",
      deleted: results,
    };
  });
}
