/**
 * API Key Management Routes — now auth-protected
 *
 * POST   /api/keys      — Create API key (super_admin only)
 * GET    /api/keys      — List API keys (super_admin only)
 * DELETE /api/keys/:id  — Deactivate API key (super_admin only)
 */

import { randomBytes } from "crypto";
import { hashApiKey } from "../services/auth.js";
import { requireRole } from "../middleware/authenticate.js";

export default async function apiKeyRoutes(app) {
  const { db } = app;

  app.post("/api/keys", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { system, label } = request.body || {};

    if (!system) {
      return reply.code(400).send({ error: "system identifier required" });
    }

    const rawKey = "vcd_" + randomBytes(32).toString("hex");
    const keyHash = hashApiKey(rawKey);

    const doc = {
      system,
      label: label || system,
      key_hash: keyHash,
      key_prefix: rawKey.slice(0, 8),
      active: true,
      created_by: request.user.email,
      created_at: new Date(),
    };

    try {
      await db.collection("api_keys").insertOne(doc);
    } catch (err) {
      if (err.code === 11000) {
        return reply.code(409).send({ error: "Duplicate key hash — retry" });
      }
      throw err;
    }

    app.log.info({ system, label, createdBy: request.user.email }, "API key created");

    return reply.code(201).send({
      message: "API key created. Save this key — it cannot be retrieved again.",
      key: rawKey,
      system,
      label: doc.label,
      prefix: doc.key_prefix,
      webhook_url: `webcdr http://${rawKey}@YOUR_SERVER/cdr`,
    });
  });

  app.get("/api/keys", {
    preHandler: requireRole("super_admin"),
  }, async () => {
    const keys = await db
      .collection("api_keys")
      .find({}, { projection: { key_hash: 0 } })
      .sort({ created_at: -1 })
      .toArray();

    return { keys };
  });

  app.delete("/api/keys/:id", {
    preHandler: requireRole("super_admin"),
  }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try {
      id = new ObjectId(request.params.id);
    } catch {
      return reply.code(400).send({ error: "Invalid key ID" });
    }

    const result = await db.collection("api_keys").updateOne(
      { _id: id },
      { $set: { active: false, deactivated_at: new Date() } }
    );

    if (result.matchedCount === 0) {
      return reply.code(404).send({ error: "Key not found" });
    }

    const key = await db.collection("api_keys").findOne({ _id: id });
    if (key?.key_hash) {
      try {
        await app.redis.del(`apikey:${key.key_hash}`);
      } catch { /* ignore */ }
    }

    app.log.info({ id: request.params.id, deletedBy: request.user.email }, "API key deactivated");
    return { message: "API key deactivated" };
  });
}
