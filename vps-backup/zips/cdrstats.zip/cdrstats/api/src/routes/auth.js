import { logAudit, AUDIT } from "../services/audit.js";
import { authenticateUser, getUserById, resetPassword } from "../services/users.js";
import { signAccessToken, signRefreshToken, verifyToken } from "../services/jwt.js";
import { requireAuth } from "../middleware/authenticate.js";
import { loginRateLimit } from "../middleware/rate-limit.js";
import {
  generateRegOptions, verifyRegResponse,
  generateAuthOptions, verifyAuthResponse,
} from "../services/webauthn.js";
import { generateTotpSecret, verifyTotpCode, encryptTotpSecret, decryptTotpSecret } from "../services/totp.js";

export default async function authRoutes(app) {
  const { db, redis } = app;

  // ── Login (password) ────────────────────────────────
  app.post("/api/auth/login", { preHandler: loginRateLimit }, async (request, reply) => {
    const { email, password } = request.body || {};
    if (!email || !password) return reply.code(400).send({ error: "Email and password required" });

    const user = await authenticateUser(db, email, password);
    if (!user) {
      logAudit(db, { action: "login_failed", category: AUDIT.AUTH, target: email, ip: request.ip, details: { reason: "invalid_credentials" } });
      return reply.code(401).send({ error: "Invalid email or password" });
    }

    // Password expired or must reset
    if (user.password_expired || user.must_reset_password) {
      // Issue a short-lived reset token
      const resetToken = signAccessToken({
        userId: user._id.toString(), email: user.email, role: user.role,
        tenants: user.tenants, pbx_servers: user.pbx_servers, queues: user.queues || [],
        reset_only: true,
      });
      return reply.code(200).send({
        must_reset_password: true,
        reset_token: resetToken,
        message: user.password_expired
          ? "Password has expired. Please set a new password."
          : "You must set a new password on first login.",
      });
    }

    // ── 2FA check ─────────────────────────────────────
    if (user.totp_enabled) {
      const totpToken = signAccessToken({
        userId: user._id.toString(), email: user.email,
        totp_pending: true,
      });
      return reply.code(200).send({
        requires_2fa: true,
        totp_token: totpToken,
        message: "Enter your 2FA code to continue.",
      });
    }

    // ── Passkey challenge — user has passkey(s), require as 2FA ───
    const passkeyCount = user.passkey_count || 0;
    if (passkeyCount > 0 && !user.totp_enabled) {
      const challengeToken = signAccessToken({
        userId: user._id.toString(), email: user.email,
        passkey_pending: true,
      });
      return reply.code(200).send({
        requires_passkey_challenge: true,
        passkey_token: challengeToken,
        message: "Verify your identity with your passkey.",
      });
    }

    // ── 2FA enforcement — no passkey and no TOTP, force setup ───
    if (passkeyCount === 0 && !user.totp_enabled) {
      const setupToken = signAccessToken({
        userId: user._id.toString(), email: user.email, role: user.role,
        tenants: user.tenants, pbx_servers: user.pbx_servers, queues: user.queues || [],
      });
      const refreshToken = signRefreshToken(user._id.toString());
      return reply.code(200).send({
        requires_2fa_setup: true,
        access_token: setupToken,
        refresh_token: refreshToken,
        user: { id: user._id, email: user.email, role: user.role, tenants: user.tenants, queues: user.queues || [], passkey_count: passkeyCount },
        message: "Please set up two-factor authentication to secure your account.",
      });
    }

    const accessToken = signAccessToken({
      userId: user._id.toString(), email: user.email, role: user.role,
      tenants: user.tenants, pbx_servers: user.pbx_servers, queues: user.queues || [],
    });
    const refreshToken = signRefreshToken(user._id.toString());

    logAudit(db, { action: "login_success", category: AUDIT.AUTH, actor: user.email, actor_id: user._id.toString(), ip: request.ip });

    return {
      access_token: accessToken, refresh_token: refreshToken,
      user: { id: user._id, email: user.email, role: user.role, tenants: user.tenants, queues: user.queues || [], passkey_count: user.passkey_count || 0 },
    };
  });

  // ── Password Reset ──────────────────────────────────
  app.post("/api/auth/reset-password", async (request, reply) => {
    const { reset_token, new_password } = request.body || {};
    if (!reset_token || !new_password) return reply.code(400).send({ error: "Reset token and new password required" });
    if (new_password.length < 8) return reply.code(400).send({ error: "Password must be at least 8 characters" });

    let decoded;
    try { decoded = verifyToken(reset_token); } catch { return reply.code(401).send({ error: "Invalid or expired reset token" }); }

    await resetPassword(db, decoded.userId, new_password);
    const user = await getUserById(db, decoded.userId);

    const accessToken = signAccessToken({
      userId: user._id.toString(), email: user.email, role: user.role,
      tenants: user.tenants, pbx_servers: user.pbx_servers, queues: user.queues || [],
    });
    const refreshToken = signRefreshToken(user._id.toString());

    // Check if 2FA setup is needed
    const passkeyCount = user.passkey_count || 0;
    if (passkeyCount === 0 && !user.totp_enabled) {
      return {
        requires_2fa_setup: true,
        access_token: accessToken,
        refresh_token: refreshToken,
        user: { id: user._id, email: user.email, role: user.role, tenants: user.tenants, queues: user.queues || [], passkey_count: passkeyCount },
        message: "Please set up two-factor authentication to secure your account.",
      };
    }

    return {
      access_token: accessToken, refresh_token: refreshToken,
      user: { id: user._id, email: user.email, role: user.role, tenants: user.tenants },
      message: "Password reset successful",
    };
  });

  // ── Refresh Token ───────────────────────────────────
  app.post("/api/auth/refresh", async (request, reply) => {
    const { refresh_token } = request.body || {};
    if (!refresh_token) return reply.code(400).send({ error: "Refresh token required" });

    let decoded;
    try { decoded = verifyToken(refresh_token); } catch { return reply.code(401).send({ error: "Invalid refresh token" }); }
    if (decoded.type !== "refresh") return reply.code(401).send({ error: "Invalid token type" });

    const user = await getUserById(db, decoded.userId);
    if (!user || user.active === false) return reply.code(401).send({ error: "User not found" });

    const accessToken = signAccessToken({
      userId: user._id.toString(), email: user.email, role: user.role,
      tenants: user.tenants, pbx_servers: user.pbx_servers, queues: user.queues || [],
    });
    return { access_token: accessToken };
  });

  // ── Current User ────────────────────────────────────
  app.get("/api/auth/me", { preHandler: requireAuth }, async (request) => {
    const user = await getUserById(db, request.user.userId);
    if (!user) return { error: "User not found" };
    const passkeyCount = await db.collection("webauthn_credentials").countDocuments({ user_id: user._id.toString() });
    return {
      id: user._id, email: user.email, role: user.role,
      tenants: user.tenants, pbx_servers: user.pbx_servers, queues: user.queues || [], queues: user.queues || [],
      passkey_count: passkeyCount, created_at: user.created_at,
    };
  });

  // ── Passkey Registration: Generate Options ──────────
  app.post("/api/auth/passkey/register-options", { preHandler: requireAuth }, async (request) => {
    const user = await getUserById(db, request.user.userId);
    if (!user) return { error: "User not found" };

    const existingCreds = await db.collection("webauthn_credentials")
      .find({ user_id: user._id.toString() }).toArray();

    const options = await generateRegOptions(user, existingCreds);

    // Store challenge in Redis (5 min TTL)
    await redis.set(`wac:reg:${user._id}`, options.challenge, "EX", 300);

    return options;
  });

  // ── Passkey Registration: Verify ────────────────────
  app.post("/api/auth/passkey/register-verify", { preHandler: requireAuth }, async (request) => {
    const user = await getUserById(db, request.user.userId);
    if (!user) return { error: "User not found" };

    const expectedChallenge = await redis.get(`wac:reg:${user._id}`);
    if (!expectedChallenge) return { error: "Challenge expired — try again" };

    try {
      const verification = await verifyRegResponse(request.body, expectedChallenge);
      if (!verification.verified) return { error: "Verification failed" };

      const { credential } = verification.registrationInfo;

      await db.collection("webauthn_credentials").insertOne({
        user_id: user._id.toString(),
        credential_id: credential.id,
        public_key: Buffer.from(credential.publicKey).toString("base64"),
        counter: credential.counter,
        transports: request.body.response?.transports || [],
        device_name: request.body.device_name || "Passkey",
        created_at: new Date(),
      });

      await db.collection("users").updateOne(
        { _id: user._id },
        { $inc: { passkey_count: 1 } }
      );

      await redis.del(`wac:reg:${user._id}`);

      const count = await db.collection("webauthn_credentials").countDocuments({ user_id: user._id.toString() });
      return { verified: true, passkey_count: count };

    } catch (err) {
      app.log.error(err, "Passkey registration failed");
      return { error: "Registration failed: " + err.message };
    }
  });

  // ── Passkey Authentication: Generate Options ────────
  app.post("/api/auth/passkey/auth-options", { preHandler: loginRateLimit }, async (request) => {
    const { email } = request.body || {};
    if (!email) return { error: "Email required" };

    const user = await db.collection("users").findOne({ email: email.toLowerCase(), active: { $ne: false } });
    if (!user) return { error: "User not found" };

    const credentials = await db.collection("webauthn_credentials")
      .find({ user_id: user._id.toString() }).toArray();

    if (credentials.length === 0) return { error: "No passkeys registered for this account" };

    const options = await generateAuthOptions(credentials);
    await redis.set(`wac:auth:${user._id}`, JSON.stringify({ challenge: options.challenge, userId: user._id.toString() }), "EX", 300);

    return { ...options, user_id: user._id.toString() };
  });

  // ── Passkey Authentication: Verify ──────────────────
  app.post("/api/auth/passkey/auth-verify", { preHandler: loginRateLimit }, async (request, reply) => {
    const { user_id, response: authResponse } = request.body || {};
    if (!user_id || !authResponse) return reply.code(400).send({ error: "Missing data" });

    const cached = await redis.get(`wac:auth:${user_id}`);
    if (!cached) return reply.code(401).send({ error: "Challenge expired" });

    const { challenge: expectedChallenge } = JSON.parse(cached);

    const credId = authResponse.id;
    const credential = await db.collection("webauthn_credentials").findOne({ credential_id: credId });
    if (!credential) return reply.code(401).send({ error: "Unknown credential" });

    try {
      const verification = await verifyAuthResponse(authResponse, expectedChallenge, credential);
      if (!verification.verified) return reply.code(401).send({ error: "Verification failed" });

      // Update counter
      await db.collection("webauthn_credentials").updateOne(
        { credential_id: credId },
        { $set: { counter: verification.authenticationInfo.newCounter, last_used: new Date() } }
      );

      await redis.del(`wac:auth:${user_id}`);

      const user = await getUserById(db, user_id);
      if (!user) return reply.code(401).send({ error: "User not found" });
      logAudit(db, { action: "passkey_verified", category: AUDIT.AUTH, actor: user.email, actor_id: user_id, ip: request.ip });

      const accessToken = signAccessToken({
        userId: user._id.toString(), email: user.email, role: user.role,
        tenants: user.tenants, pbx_servers: user.pbx_servers, queues: user.queues || [],
      });
      const refreshToken = signRefreshToken(user._id.toString());

      return {
        access_token: accessToken, refresh_token: refreshToken,
        user: { id: user._id, email: user.email, role: user.role, tenants: user.tenants },
      };

    } catch (err) {
      app.log.error(err, "Passkey auth failed");
      return reply.code(401).send({ error: "Authentication failed" });
    }
  });

  // ── List user's passkeys ────────────────────────────
  app.get("/api/auth/passkeys", { preHandler: requireAuth }, async (request) => {
    const passkeys = await db.collection("webauthn_credentials")
      .find({ user_id: request.user.userId }, { projection: { public_key: 0 } })
      .sort({ created_at: -1 }).toArray();
    return { passkeys };
  });

  // ── Delete a passkey ────────────────────────────────
  app.delete("/api/auth/passkeys/:id", { preHandler: requireAuth }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    let id;
    try { id = new ObjectId(request.params.id); } catch { return reply.code(400).send({ error: "Invalid ID" }); }

    const result = await db.collection("webauthn_credentials").deleteOne({ _id: id, user_id: request.user.userId });
    if (result.deletedCount === 0) return reply.code(404).send({ error: "Passkey not found" });

    await db.collection("users").updateOne(
      { _id: new ObjectId(request.user.userId) },
      { $inc: { passkey_count: -1 } }
    );

    return { message: "Passkey deleted" };
  });

  // ── TOTP 2FA Routes ─────────────────────────────────

  app.post("/api/auth/totp/setup", { preHandler: requireAuth }, async (request) => {
    const { ObjectId } = await import("mongodb");
    const user = await db.collection("users").findOne({ _id: new ObjectId(request.user.userId) });
    if (!user) return { error: "User not found" };
    if (user.totp_enabled) return { error: "TOTP is already enabled. Disable it first to reconfigure." };

    const { secret, uri, qrDataUrl } = await generateTotpSecret(user.email);
    await db.collection("users").updateOne(
      { _id: user._id },
      { $set: { totp_pending_secret: encryptTotpSecret(secret), updated_at: new Date() } }
    );
    return { qr: qrDataUrl, uri, manual_key: secret };
  });

  app.post("/api/auth/totp/enable", { preHandler: requireAuth }, async (request) => {
    const { ObjectId } = await import("mongodb");
    const { code } = request.body || {};
    if (!code) return { error: "Code is required" };

    const user = await db.collection("users").findOne({ _id: new ObjectId(request.user.userId) });
    if (!user) return { error: "User not found" };
    if (!user.totp_pending_secret) return { error: "No pending TOTP setup. Call /totp/setup first." };

    const secret = decryptTotpSecret(user.totp_pending_secret);
    if (!verifyTotpCode(secret, code)) return { error: "Invalid code. Please try again." };

    await db.collection("users").updateOne(
      { _id: user._id },
      { $set: { totp_secret: user.totp_pending_secret, totp_enabled: true, updated_at: new Date() }, $unset: { totp_pending_secret: "" } }
    );
    return { enabled: true, message: "2FA is now active." };
  });

  app.post("/api/auth/totp/verify", { preHandler: loginRateLimit }, async (request, reply) => {
    const { ObjectId } = await import("mongodb");
    const { totp_token, code } = request.body || {};
    if (!totp_token || !code) return reply.code(400).send({ error: "Token and code are required" });

    let payload;
    try { payload = verifyToken(totp_token); } catch (err) {
      return reply.code(401).send({ error: "Invalid or expired 2FA token" });
    }
    if (!payload.totp_pending) return reply.code(401).send({ error: "Invalid token type" });

    const user = await db.collection("users").findOne({ _id: new ObjectId(payload.userId) });
    if (!user || !user.totp_enabled || !user.totp_secret) return reply.code(401).send({ error: "2FA is not configured" });

    const secret = decryptTotpSecret(user.totp_secret);
    if (!verifyTotpCode(secret, code)) {
      logAudit(db, { action: "totp_failed", category: AUDIT.AUTH, target: payload.userId, ip: request.ip });
      return reply.code(401).send({ error: "Invalid 2FA code" });
    }

    const accessToken = signAccessToken({
      userId: user._id.toString(), email: user.email, role: user.role,
      tenants: user.tenants, pbx_servers: user.pbx_servers, queues: user.queues || [],
    });
    const refreshToken = signRefreshToken(user._id.toString());
    logAudit(db, { action: "totp_verified", category: AUDIT.AUTH, actor: user.email, actor_id: user._id.toString(), ip: request.ip });
    return {
      access_token: accessToken, refresh_token: refreshToken,
      user: { id: user._id, email: user.email, role: user.role, tenants: user.tenants, queues: user.queues || [], passkey_count: user.passkey_count || 0 },
    };
  });

  app.post("/api/auth/totp/disable", { preHandler: requireAuth }, async (request) => {
    const { ObjectId } = await import("mongodb");
    const { user_id } = request.body || {};
    const targetId = user_id || request.user.userId;
    if (user_id && user_id !== request.user.userId) {
      if (request.user.role !== "super_admin" && request.user.role !== "admin") {
        return { error: "Only admins can disable 2FA for other users" };
      }
    }
    await db.collection("users").updateOne(
      { _id: new ObjectId(targetId) },
      { $set: { totp_enabled: false, updated_at: new Date() }, $unset: { totp_secret: "", totp_pending_secret: "" } }
    );
    return { disabled: true };
  });

  app.get("/api/auth/totp/status", { preHandler: requireAuth }, async (request) => {
    const { ObjectId } = await import("mongodb");
    const user = await db.collection("users").findOne({ _id: new ObjectId(request.user.userId) });
    return {
      totp_enabled: user?.totp_enabled || false,
      totp_enforced: user?.totp_enforced !== false,
    };
  });

}
