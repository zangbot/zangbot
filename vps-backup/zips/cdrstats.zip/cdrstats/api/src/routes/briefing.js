/**
 * AI Briefing Routes
 *
 * POST /api/ai/briefing              — Generate AI briefing from page data
 * POST /api/ai/briefing/email        — Email a briefing
 * POST /api/ai/briefing/share        — Create shareable briefing link
 * GET  /api/ai/briefing/share/:token — View shared briefing (public)
 */

import crypto from "crypto";
import { requireAuth } from "../middleware/authenticate.js";
import { buildTenantFilter } from "../middleware/tenant-scope.js";
import { chatCompletion } from "../services/ai-provider.js";
import { sendMail } from "../services/mailer.js";

const TOKEN_LENGTH = 48;

function generateToken() {
  return crypto.randomBytes(TOKEN_LENGTH).toString("base64url").slice(0, TOKEN_LENGTH);
}

function buildDateFilter(query, tenantFilter = {}) {
  const filter = { ...tenantFilter };
  const { start_from, start_to, domain } = query;
  if (domain && !filter.domain) filter.domain = domain;
  if (start_from || start_to) {
    filter.start = {};
    if (start_from) {
      const v = parseFloat(start_from);
      filter.start.$gte = v > 946684800 ? v : new Date(start_from).getTime() / 1000;
    }
    if (start_to) {
      const v = parseFloat(start_to);
      filter.start.$lte = v > 946684800 ? v : new Date(start_to).getTime() / 1000;
    }
  }
  return filter;
}

// ── Data collectors per context ───────────────────────────────

async function collectDashboardData(db, filter) {
  const calls = db.collection("calls");

  const [overview] = await calls.aggregate([
    { $match: filter },
    {
      $group: {
        _id: null,
        total_calls: { $sum: 1 },
        answered_calls: { $sum: { $cond: ["$is_answered", 1, 0] } },
        abandoned_calls: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
        missed_calls: { $sum: { $cond: [{ $and: [{ $ne: ["$is_answered", true] }, { $ne: ["$is_abandoned", true] }] }, 1, 0] } },
        forwarded_calls: { $sum: { $cond: [{ $eq: ["$is_forwarded", true] }, 1, 0] } },
        total_duration: { $sum: "$duration_seconds" },
        total_talk_time: { $sum: "$talk_seconds" },
        avg_duration: { $avg: "$duration_seconds" },
        avg_talk_time: { $avg: "$talk_seconds" },
        avg_mos: { $avg: "$avg_mos_score" },
        inbound_calls: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "inbound"] }, 1, 0] } },
        outbound_calls: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "outbound"] }, 1, 0] } },
        internal_calls: { $sum: { $cond: [{ $eq: ["$call_direction_origin", "internal"] }, 1, 0] } },
        attended_transfers: { $sum: { $cond: [{ $eq: ["$transfer_type", "attended"] }, 1, 0] } },
        blind_transfers: { $sum: { $cond: [{ $eq: ["$transfer_type", "blind"] }, 1, 0] } },
        avg_ring_time: { $avg: "$ring_time_seconds" },
        avg_queue_wait: { $avg: "$queue_wait_seconds" },
        avg_hold_time: { $avg: "$hold_time_seconds" },
      },
    },
  ]).toArray();

  const directions = await calls.aggregate([
    { $match: filter },
    { $group: { _id: "$call_direction_origin", count: { $sum: 1 } } },
    { $sort: { count: -1 } },
  ]).toArray();

  const topAgents = await calls.aggregate([
    { $match: { ...filter, answering_extension: { $ne: null } } },
    {
      $group: {
        _id: "$answering_extension",
        name: { $first: "$answering_extension_name" },
        total: { $sum: 1 },
        answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
        avg_talk: { $avg: "$talk_seconds" },
      },
    },
    { $sort: { total: -1 } },
    { $limit: 10 },
  ]).toArray();

  const quality = await calls.aggregate([
    { $match: { ...filter, avg_mos_score: { $ne: null } } },
    {
      $group: {
        _id: null,
        excellent: { $sum: { $cond: [{ $gte: ["$avg_mos_score", 4.0] }, 1, 0] } },
        good: { $sum: { $cond: [{ $and: [{ $gte: ["$avg_mos_score", 3.0] }, { $lt: ["$avg_mos_score", 4.0] }] }, 1, 0] } },
        fair: { $sum: { $cond: [{ $and: [{ $gte: ["$avg_mos_score", 2.0] }, { $lt: ["$avg_mos_score", 3.0] }] }, 1, 0] } },
        poor: { $sum: { $cond: [{ $lt: ["$avg_mos_score", 2.0] }, 1, 0] } },
      },
    },
  ]).toArray();

  return { overview: overview || {}, directions, topAgents, quality: quality[0] || {} };
}

async function collectQueuesData(db, filter, queue) {
  const calls = db.collection("calls");
  const queueFilter = { ...filter, answering_queue: { $ne: null } };
  if (queue) {
    const qList = String(queue).split(",").map((s) => s.trim()).filter(Boolean);
    if (qList.length > 0) {
      queueFilter.answering_queue = qList.length > 1 ? { $in: qList } : qList[0];
    }
  }

  const queues = await calls.aggregate([
    { $match: queueFilter },
    {
      $group: {
        _id: "$answering_queue",
        name: { $first: "$answering_queue_name" },
        total: { $sum: 1 },
        answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
        abandoned: { $sum: { $cond: ["$is_abandoned", 1, 0] } },
        avg_wait: { $avg: "$queue_wait_seconds" },
        avg_talk: { $avg: "$talk_seconds" },
        avg_mos: { $avg: "$avg_mos_score" },
      },
    },
    { $sort: { total: -1 } },
    { $limit: 15 },
  ]).toArray();

  const queueAgents = await calls.aggregate([
    { $match: { ...queueFilter, answering_extension: { $ne: null } } },
    {
      $group: {
        _id: { queue: "$answering_queue", ext: "$answering_extension" },
        queue_name: { $first: "$answering_queue_name" },
        agent_name: { $first: "$answering_extension_name" },
        total: { $sum: 1 },
        answered: { $sum: { $cond: ["$is_answered", 1, 0] } },
        avg_talk: { $avg: "$talk_seconds" },
      },
    },
    { $sort: { total: -1 } },
    { $limit: 20 },
  ]).toArray();

  return { queues, queueAgents };
}

async function collectInsightsData(db, filter) {
  const calls = db.collection("calls");
  const sentimentFilter = { ...filter, sentiment: { $ne: null } };

  const [sentimentOverview] = await calls.aggregate([
    { $match: sentimentFilter },
    {
      $group: {
        _id: null,
        total: { $sum: 1 },
        positive: { $sum: { $cond: [{ $eq: ["$sentiment", "positive"] }, 1, 0] } },
        neutral: { $sum: { $cond: [{ $eq: ["$sentiment", "neutral"] }, 1, 0] } },
        negative: { $sum: { $cond: [{ $eq: ["$sentiment", "negative"] }, 1, 0] } },
      },
    },
  ]).toArray();

  const totalCalls = await calls.countDocuments(filter);
  const totalTranscribed = await calls.countDocuments({ ...filter, has_transcript: true });

  // Top topics from transcripts
  const topicFilter = { "summary.topics": { $exists: true, $ne: [] } };
  if (filter.domain) topicFilter.domain = filter.domain;
  if (filter.start) {
    const callids = await calls.distinct("callid", filter);
    topicFilter.callid = { $in: callids };
  }

  const topics = await db.collection("transcripts").aggregate([
    { $match: topicFilter },
    { $unwind: "$summary.topics" },
    { $group: { _id: { $toLower: "$summary.topics" }, count: { $sum: 1 } } },
    { $sort: { count: -1 } },
    { $limit: 10 },
  ]).toArray();

  // Resolution breakdown
  const resFilter = { "summary.resolution": { $exists: true } };
  if (filter.domain) resFilter.domain = filter.domain;
  if (topicFilter.callid) resFilter.callid = topicFilter.callid;

  const resolution = await db.collection("transcripts").aggregate([
    { $match: resFilter },
    { $group: { _id: "$summary.resolution", count: { $sum: 1 } } },
    { $sort: { count: -1 } },
  ]).toArray();

  // Recent negative calls
  const negativeCalls = await calls
    .find({ ...sentimentFilter, sentiment: "negative" }, {
      projection: { callid: 1, from_number_raw: 1, from_display_name: 1, answering_extension_name: 1, answering_queue_name: 1, duration_seconds: 1 },
    })
    .sort({ start: -1 })
    .limit(5)
    .toArray();

  return {
    totalCalls,
    totalTranscribed,
    sentiment: sentimentOverview || { total: 0, positive: 0, neutral: 0, negative: 0 },
    topics: topics.map(t => ({ topic: t._id, count: t.count })),
    resolution: resolution.map(r => ({ status: r._id, count: r.count })),
    negativeCalls,
  };
}

// ── Prompt builders ───────────────────────────────────────────

function buildDashboardPrompt(data, dateRange) {
  const o = data.overview;
  const answerRate = o.total_calls > 0 ? ((o.answered_calls / o.total_calls) * 100).toFixed(1) : "0";
  const abandonRate = o.total_calls > 0 ? ((o.abandoned_calls / o.total_calls) * 100).toFixed(1) : "0";

  return `You are an expert telecommunications analyst. Generate a concise executive briefing for a PBX call center.

Date range: ${dateRange}

## Call Volume & Disposition
- Total calls: ${o.total_calls || 0}
- Answered: ${o.answered_calls || 0} (${answerRate}%)
- Abandoned: ${o.abandoned_calls || 0} (${abandonRate}%)
- Missed: ${o.missed_calls || 0}
- Forwarded: ${o.forwarded_calls || 0}

## Direction Breakdown
${data.directions.map(d => `- ${d._id}: ${d.count}`).join("\n")}

## Timing
- Avg duration: ${Math.round(o.avg_duration || 0)}s
- Avg talk time: ${Math.round(o.avg_talk_time || 0)}s
- Avg ring time: ${Math.round(o.avg_ring_time || 0)}s
- Avg queue wait: ${Math.round(o.avg_queue_wait || 0)}s
- Total talk time: ${Math.round((o.total_talk_time || 0) / 3600 * 10) / 10} hours

## Call Quality (MOS)
- Average MOS: ${o.avg_mos ? o.avg_mos.toFixed(2) : "N/A"}
- Excellent (≥4.0): ${data.quality.excellent || 0}
- Good (3.0–3.9): ${data.quality.good || 0}
- Fair (2.0–2.9): ${data.quality.fair || 0}
- Poor (<2.0): ${data.quality.poor || 0}

## Transfers
- Attended: ${o.attended_transfers || 0}
- Blind: ${o.blind_transfers || 0}

## Top 10 Extensions by Call Volume
${data.topAgents.map(a => `- ${a.name || a._id}: ${a.total} calls, ${a.answered} answered, avg talk ${Math.round(a.avg_talk || 0)}s`).join("\n")}

Write a structured executive briefing with these sections:
1. **Overview** — 2-3 sentence summary of the period
2. **Key Highlights** — bullet points of notable metrics (good or bad)
3. **Concerns** — anything that needs attention (high abandon rate, poor MOS, long wait times, etc.)
4. **Recommendations** — actionable suggestions based on the data

Keep it concise and professional. Use specific numbers from the data. Do not invent data.`;
}

function buildQueuesPrompt(data, dateRange) {
  return `You are an expert call center analyst. Generate a concise queue performance briefing.

Date range: ${dateRange}

## Queue Performance
${data.queues.map(q => {
    const ansRate = q.total > 0 ? ((q.answered / q.total) * 100).toFixed(1) : "0";
    const abRate = q.total > 0 ? ((q.abandoned / q.total) * 100).toFixed(1) : "0";
    return `- ${q.name || q._id}: ${q.total} calls, ${ansRate}% answered, ${abRate}% abandoned, avg wait ${Math.round(q.avg_wait || 0)}s, avg talk ${Math.round(q.avg_talk || 0)}s, MOS ${q.avg_mos ? q.avg_mos.toFixed(2) : "N/A"}`;
  }).join("\n")}

## Top Agents Across Queues
${data.queueAgents.map(a => `- ${a.agent_name || a._id.ext} (${a.queue_name || a._id.queue}): ${a.total} calls, ${a.answered} answered, avg talk ${Math.round(a.avg_talk || 0)}s`).join("\n")}

Write a structured queue performance briefing with these sections:
1. **Overview** — 2-3 sentence summary of queue performance
2. **Queue Rankings** — best and worst performing queues by answer rate and wait time
3. **Agent Highlights** — standout performers and those needing support
4. **Concerns** — queues with high abandon rates, long wait times, or quality issues
5. **Recommendations** — staffing or routing adjustments based on the data

Keep it concise and professional. Use specific numbers. Do not invent data.`;
}

function buildInsightsPrompt(data, dateRange) {
  const s = data.sentiment;
  const negRate = s.total > 0 ? ((s.negative / s.total) * 100).toFixed(1) : "0";
  const posRate = s.total > 0 ? ((s.positive / s.total) * 100).toFixed(1) : "0";

  return `You are an expert call center analyst specializing in customer sentiment and experience. Generate a concise AI insights briefing.

Date range: ${dateRange}

## Coverage
- Total calls in period: ${data.totalCalls}
- Calls transcribed: ${data.totalTranscribed}
- Calls with sentiment analysis: ${s.total || 0}

## Sentiment Distribution
- Positive: ${s.positive || 0} (${posRate}%)
- Neutral: ${s.neutral || 0}
- Negative: ${s.negative || 0} (${negRate}%)

## Top Discussion Topics
${data.topics.length > 0 ? data.topics.map(t => `- "${t.topic}": ${t.count} calls`).join("\n") : "- No topics data available"}

## Resolution Outcomes
${data.resolution.length > 0 ? data.resolution.map(r => `- ${r.status}: ${r.count}`).join("\n") : "- No resolution data available"}

## Recent Negative Calls
${data.negativeCalls.length > 0 ? data.negativeCalls.map(c => `- ${c.from_display_name || c.from_number_raw || "Unknown"} → ${c.answering_extension_name || "N/A"}${c.answering_queue_name ? " (" + c.answering_queue_name + ")" : ""}, ${Math.round((c.duration_seconds || 0) / 60)}min`).join("\n") : "- No negative calls in period"}

Write a structured AI insights briefing with these sections:
1. **Overview** — 2-3 sentence summary of customer sentiment
2. **Sentiment Analysis** — key findings from the sentiment data
3. **Trending Topics** — what customers are calling about and any patterns
4. **Resolution Performance** — how well calls are being resolved
5. **Concerns** — negative sentiment patterns, recurring complaints, unresolved issues
6. **Recommendations** — training, process, or staffing suggestions based on sentiment and topics

Keep it concise and professional. Use specific numbers. Do not invent data.`;
}

function formatDateRange(query) {
  const { start_from, start_to } = query;
  if (!start_from && !start_to) return "All time";
  const fmt = (v) => {
    if (!v) return "?";
    const n = parseFloat(v);
    const d = n > 946684800 ? new Date(n * 1000) : new Date(v);
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  };
  return `${fmt(start_from)} — ${fmt(start_to)}`;
}

// ── Routes ────────────────────────────────────────────────────

export default async function briefingRoutes(app) {
  const { db } = app;

  // ── Generate Briefing ─────────────────────────────────
  app.post("/api/ai/briefing", {
    preHandler: requireAuth,
  }, async (request, reply) => {
    const { context, filters = {} } = request.body || {};

    if (!["dashboard", "queues", "insights"].includes(context)) {
      return reply.code(400).send({ error: "context must be dashboard, queues, or insights" });
    }

    const tenantFilter = buildTenantFilter(request);
    const dateFilter = buildDateFilter(filters, tenantFilter);
    const dateRange = formatDateRange(filters);

    let data, prompt;

    try {
      switch (context) {
        case "dashboard":
          data = await collectDashboardData(db, dateFilter);
          prompt = buildDashboardPrompt(data, dateRange);
          break;
        case "queues":
          data = await collectQueuesData(db, dateFilter, filters.queue);
          prompt = buildQueuesPrompt(data, dateRange);
          break;
        case "insights":
          data = await collectInsightsData(db, dateFilter);
          prompt = buildInsightsPrompt(data, dateRange);
          break;
      }
    } catch (err) {
      app.log.error(err, "Failed to collect briefing data");
      return reply.code(500).send({ error: "Failed to collect data for briefing" });
    }

    try {
      const messages = [
        { role: "system", content: "You are a professional telecommunications analyst. Write clear, data-driven briefings. Format with markdown headings and bullet points." },
        { role: "user", content: prompt },
      ];

      const briefing = await chatCompletion(db, messages, { maxTokens: 2000, temperature: 0.4 });

      const doc = {
        context,
        filters,
        date_range: dateRange,
        briefing,
        raw_data: data,
        generated_at: new Date(),
        generated_by: request.user.email,
        domain: tenantFilter.domain || "all",
      };

      const result = await db.collection("briefings").insertOne(doc);

      return {
        briefing_id: result.insertedId.toString(),
        briefing,
        context,
        date_range: dateRange,
        generated_at: doc.generated_at,
      };
    } catch (err) {
      app.log.error(err, "AI briefing generation failed");
      return reply.code(500).send({ error: "AI briefing generation failed", detail: err.message });
    }
  });

  // ── Email Briefing ────────────────────────────────────
  app.post("/api/ai/briefing/email", {
    preHandler: requireAuth,
  }, async (request, reply) => {
    const { to, briefing, context, date_range, note } = request.body || {};

    if (!to) return reply.code(400).send({ error: "Recipient email is required" });
    if (!briefing) return reply.code(400).send({ error: "Briefing content is required" });

    const contextLabels = { dashboard: "Dashboard", queues: "Queue Performance", insights: "AI Insights" };
    const label = contextLabels[context] || "Analytics";

    // Convert markdown to simple HTML
    const briefingHtml = briefing
      .replace(/^### (.+)$/gm, '<h3 style="color:#1a1a1a;margin:20px 0 8px 0;font-size:15px;">$1</h3>')
      .replace(/^## (.+)$/gm, '<h2 style="color:#1a1a1a;margin:24px 0 10px 0;font-size:17px;">$1</h2>')
      .replace(/^# (.+)$/gm, '<h1 style="color:#1a1a1a;margin:24px 0 12px 0;font-size:20px;">$1</h1>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/^- (.+)$/gm, '<li style="margin:4px 0;color:#333;">$1</li>')
      .replace(/(<li.*<\/li>\n?)+/g, '<ul style="padding-left:20px;margin:8px 0;">$&</ul>')
      .replace(/\n\n/g, '<br/><br/>')
      .replace(/\n/g, '<br/>');

    try {
      await sendMail(db, {
        to,
        subject: `${label} Briefing — ${date_range || "Summary"}`,
        html: `
          <div style="font-family:-apple-system,BlinkMacSystemFont,sans-serif;max-width:640px;margin:0 auto;padding:32px;">
            <div style="background:linear-gradient(135deg,#007aff 0%,#5856d6 100%);border-radius:16px;padding:32px;color:white;margin-bottom:24px;">
              <h2 style="margin:0 0 8px 0;font-size:20px;">📊 ${label} Briefing</h2>
              <p style="margin:0;opacity:0.9;font-size:14px;">${date_range || ""} • Generated by ${request.user.email}</p>
            </div>
            ${note ? `<div style="background:#f0f4ff;border-radius:12px;padding:16px;margin-bottom:20px;color:#333;border-left:4px solid #007aff;"><p style="margin:0;font-size:14px;">${note.replace(/</g,"&lt;").replace(/>/g,"&gt;")}</p></div>` : ""}
            <div style="color:#333;font-size:14px;line-height:1.7;">
              ${briefingHtml}
            </div>
            <hr style="border:none;border-top:1px solid #e5e5e5;margin:32px 0 16px 0;"/>
            <p style="color:#999;font-size:11px;text-align:center;">
              Generated by Vodia Analytics AI • ${new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
            </p>
          </div>
        `,
      });

      return { message: `Briefing emailed to ${to}` };
    } catch (err) {
      return reply.code(400).send({ error: "Failed to send email", detail: err.message });
    }
  });

  // ── Create Shareable Briefing Link ────────────────────
  app.post("/api/ai/briefing/share", {
    preHandler: requireAuth,
  }, async (request, reply) => {
    const { briefing_id, expiry_hours } = request.body || {};

    if (!briefing_id) return reply.code(400).send({ error: "briefing_id is required" });

    // Verify briefing exists
    let objectId;
    try { const { ObjectId } = await import("mongodb"); objectId = new ObjectId(briefing_id); } catch { return reply.code(400).send({ error: "Invalid briefing_id" }); }

    const briefingDoc = await db.collection("briefings").findOne({ _id: objectId });
    if (!briefingDoc) return reply.code(404).send({ error: "Briefing not found" });

    const token = generateToken();
    const hours = Math.min(Math.max(parseInt(expiry_hours) || 72, 1), 720); // 1h to 30 days
    const expires_at = new Date(Date.now() + hours * 60 * 60 * 1000);

    await db.collection("briefing_shares").insertOne({
      token,
      briefing_id: objectId,
      created_by: request.user.email,
      created_at: new Date(),
      expires_at,
      viewed: false,
    });

    const baseUrl = process.env.DOMAIN
      ? `https://${process.env.DOMAIN}`
      : `${request.protocol}://${request.hostname}`;

    return {
      share_url: `${baseUrl}/briefing/${token}`,
      token,
      expires_at,
    };
  });

  // ── View Shared Briefing (PUBLIC) ─────────────────────
  app.get("/api/ai/briefing/share/:token", async (request, reply) => {
    const { token } = request.params;

    const shareDoc = await db.collection("briefing_shares").findOne({
      token,
      expires_at: { $gt: new Date() },
    });

    if (!shareDoc) {
      return reply.code(404).send({ error: "Briefing link not found or expired" });
    }

    const briefingDoc = await db.collection("briefings").findOne({ _id: shareDoc.briefing_id });
    if (!briefingDoc) {
      return reply.code(404).send({ error: "Briefing data no longer available" });
    }

    // One-time use — block if already viewed
    if (shareDoc.viewed) {
      return reply.code(410).send({
        error: "This briefing link has already been viewed",
        viewed_at: shareDoc.viewed_at,
      });
    }

    // Mark as viewed
    await db.collection("briefing_shares").updateOne(
      { _id: shareDoc._id },
      { $set: { viewed: true, viewed_at: new Date() } }
    );

    return {
      briefing: briefingDoc.briefing,
      context: briefingDoc.context,
      date_range: briefingDoc.date_range,
      generated_at: briefingDoc.generated_at,
      shared_by: shareDoc.created_by,
    };
  });
}

// -- Exports for briefing scheduler (compliance suite) --------
export { collectDashboardData, collectQueuesData, collectInsightsData, buildDashboardPrompt, buildQueuesPrompt, buildInsightsPrompt };
