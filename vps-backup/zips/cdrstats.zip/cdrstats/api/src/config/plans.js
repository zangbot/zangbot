export const PLANS = {
 // ext5:   { limit: 5,   name: "5 Extensions" },
  ext10:  { limit: 10,  name: "10 Agents" },
  ext20:  { limit: 20,  name: "20 Agents" },
//  ext50:  { limit: 50,  name: "50 Extensions" },
//  ext100: { limit: 100, name: "100 Extensions" },
//  ext200: { limit: 200, name: "200 Extensions" },
  extunlimited: { limit: 500000, name: "500000 Agents" },
};

export const GRACE_PERIOD_DAYS = 7;
export const LICENSE_CHECK_INTERVAL_MS = 15 * 60 * 1000;

export function isCloudMode() {
  return process.env.LICENSE_MODE === "cloud";
}

export function getCurrentPlan() {
  const code = process.env.LICENSE_PLAN || "";
  return PLANS[code] || null;
}
