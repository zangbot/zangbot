/**
 * Rate Limiting Middleware
 * Uses Redis sliding window counters.
 */

const WINDOW_MS = 60 * 1000; // 1 minute

/**
 * Create a rate limiter preHandler.
 * @param {string} prefix - Redis key prefix (e.g. "rl:login", "rl:api")
 * @param {number} maxRequests - Max requests per window per IP
 */
export function rateLimit(prefix, maxRequests) {
  return async (request, reply) => {
    const redis = request.server.redis;
    if (!redis) return; // No Redis, skip

    const ip = request.headers["x-real-ip"]
      || request.headers["x-forwarded-for"]?.split(",")[0]?.trim()
      || request.ip;

    // Skip rate limiting for whitelisted PBX IPs
    try {
      const cached = await redis.get("ip_whitelist_cache");
      if (cached) {
        const whitelist = JSON.parse(cached);
        if (whitelist.some(entry => entry.ip === ip)) return;
      }
    } catch {}

    const key = `${prefix}:${ip}`;

    try {
      const current = await redis.incr(key);
      if (current === 1) {
        await redis.pexpire(key, WINDOW_MS);
      }

      // Set rate limit headers
      reply.header("X-RateLimit-Limit", maxRequests);
      reply.header("X-RateLimit-Remaining", Math.max(0, maxRequests - current));

      if (current > maxRequests) {
        const ttl = await redis.pttl(key);
        reply.header("Retry-After", Math.ceil((ttl > 0 ? ttl : WINDOW_MS) / 1000));
        return reply.code(429).send({
          error: "Too many requests",
          retry_after: Math.ceil((ttl > 0 ? ttl : WINDOW_MS) / 1000),
        });
      }
    } catch {
      // Redis failure — allow request
    }
  };
}

/**
 * Pre-configured rate limiters
 */
export const loginRateLimit = rateLimit("rl:login", parseInt(process.env.RATE_LIMIT_LOGIN || "10"));
export const apiRateLimit = rateLimit("rl:api", parseInt(process.env.RATE_LIMIT_API || "100"));
export const cdrRateLimit = rateLimit("rl:cdr", parseInt(process.env.RATE_LIMIT_CDR || "200"));
