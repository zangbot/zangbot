/**
 * Tenant Scoping Middleware
 *
 * Automatically builds a MongoDB filter based on the
 * authenticated user's role and tenant assignments.
 *
 * super_admin      → no filter (sees everything)
 * admin/viewer     → { domain: { $in: [...allowedDomains] } }
 * queue_manager    → { domain: { $in: [...] }, answering_queue: { $in: [...queues] } }
 *
 * Adds request.tenantFilter to be spread into queries.
 */

/**
 * Build the tenant scope filter for the current user.
 * Call after requireAuth — depends on request.user.
 */
export function buildTenantFilter(request) {
  const { user } = request;
  if (!user) return { _blocked: true }; // Safety: block if no user

  // Super admin sees everything
  if (user.role === "super_admin") {
    return {};
  }

  const filter = {};

  // Tenant scoping — admin, viewer, queue_manager all use tenants
  const tenants = user.tenants || [];
  if (tenants.length === 0) {
    // No tenants assigned → see nothing
    return { domain: { $in: [] } };
  }

  const domains = tenants.map((t) => {
    if (typeof t === "string") return t;
    return t.domain;
  });

  filter.domain = { $in: domains };

  // Queue manager — additionally scope to assigned queues
  if (user.role === "queue_manager") {
    const queues = user.queues || [];
    if (queues.length === 0) {
      // No queues assigned → see nothing
      return { domain: { $in: [] }, answering_queue: { $in: [] } };
    }
    filter.answering_queue = { $in: queues };
  }

  return filter;
}

/**
 * Build tenant + system scope (for PBX-level queries).
 */
export function buildFullScope(request) {
  const { user } = request;
  if (!user) return { _blocked: true };

  if (user.role === "super_admin") {
    return {};
  }

  const filter = {};
  const tenants = user.tenants || [];
  const servers = user.pbx_servers || [];

  if (tenants.length > 0) {
    const domains = tenants.map((t) => (typeof t === "string" ? t : t.domain));
    filter.domain = { $in: domains };
  }

  if (servers.length > 0) {
    filter.system = { $in: servers };
  }

  // If neither is set, block access
  if (!filter.domain && !filter.system) {
    filter.domain = { $in: [] };
  }

  // Queue manager scope
  if (user.role === "queue_manager") {
    const queues = user.queues || [];
    if (queues.length > 0) {
      filter.answering_queue = { $in: queues };
    } else {
      filter.answering_queue = { $in: [] };
    }
  }

  return filter;
}

/**
 * Fastify preHandler — injects request.tenantFilter.
 */
export async function injectTenantScope(request, reply) {
  if (!request.user) return; // Skip if no auth (handled elsewhere)
  request.tenantFilter = buildTenantFilter(request);
}
