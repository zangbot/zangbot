/**
 * Authentication Middleware
 *
 * Verifies JWT from Authorization: Bearer <token> header.
 * Decorates request with user context for downstream handlers.
 */

import { verifyToken } from "../services/jwt.js";

/**
 * Fastify preHandler hook — requires valid JWT.
 * Adds request.user with { userId, email, role, tenants, pbx_servers }
 */
export async function requireAuth(request, reply) {
  const authHeader = request.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return reply.code(401).send({ error: "Authentication required" });
  }

  const token = authHeader.slice(7).trim();
  if (!token) {
    return reply.code(401).send({ error: "Authentication required" });
  }

  try {
    const decoded = verifyToken(token);
    if (decoded.type === "refresh") {
      return reply.code(401).send({ error: "Access token required, not refresh token" });
    }
    request.user = decoded;
  } catch (err) {
    if (err.name === "TokenExpiredError") {
      return reply.code(401).send({ error: "Token expired" });
    }
    return reply.code(401).send({ error: "Invalid token" });
  }
}

/**
 * Require a specific role (or higher).
 * Role hierarchy: super_admin > admin > viewer
 */
export function requireRole(...allowedRoles) {
  return async (request, reply) => {
    await requireAuth(request, reply);
    if (reply.sent) return; // Auth failed, response already sent

    if (!allowedRoles.includes(request.user.role)) {
      return reply.code(403).send({
        error: "Insufficient permissions",
        required: allowedRoles,
        current: request.user.role,
      });
    }
  };
}
