/**
 * Internal Request Detection
 * Allows Grafana (and other Docker services) to hit stats endpoints
 * without JWT by checking for internal Docker network IPs.
 */

const INTERNAL_PREFIXES = ["172.", "10.", "192.168.", "127."];

export function isInternalRequest(request) {
  const ip = request.headers["x-real-ip"]
    || request.headers["x-forwarded-for"]?.split(",")[0]?.trim()
    || request.ip;

  return INTERNAL_PREFIXES.some(p => ip.startsWith(p));
}

/**
 * Auth middleware that skips JWT for internal Docker network requests.
 * Use on read-only endpoints only (stats, health).
 */
export async function requireAuthOrInternal(request, reply) {
  if (isInternalRequest(request)) return; // Skip auth for internal

  // Fall through to normal JWT auth
  const { requireAuth } = await import("./authenticate.js");
  return requireAuth(request, reply);
}
