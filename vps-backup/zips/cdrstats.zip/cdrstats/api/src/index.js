import Fastify from "fastify";
import cors from "@fastify/cors";
import { MongoClient } from "mongodb";
import Redis from "ioredis";
import { Queue } from "bullmq";

import healthRoutes from "./routes/health.js";
import cdrRoutes from "./routes/cdr.js";
import apiKeyRoutes from "./routes/apikeys.js";
import uploadRoutes from "./routes/upload.js";
import authRoutes from "./routes/auth.js";
import userRoutes from "./routes/users.js";
import tenantRoutes from "./routes/tenants.js";
import callRoutes from "./routes/calls.js";
import statsRoutes from "./routes/stats.js";
import exportRoutes from "./routes/exports.js";
import aiRoutes from "./routes/ai.js";
import insightsRoutes from "./routes/insights.js";
import retentionRoutes from "./routes/retention.js";
import whitelistRoutes from "./routes/whitelist.js";
import settingsRoutes from "./routes/settings.js";
import shareRoutes from "./routes/share.js";
import licenseRoutes from "./routes/license.js";
import { restoreGraceFromDb, startLicensePolling } from "./services/licenseService.js";
import briefingRoutes from "./routes/briefing.js";
import setupRoutes from "./routes/setup.js";
import auditRoutes from "./routes/audit.js";
import { initAuditIndexes } from "./services/audit.js";
import complianceRoutes from "./routes/compliance.js";
import briefingScheduleRoutes from "./routes/briefing-schedules.js";
import { startBriefingScheduler } from "./services/briefing-scheduler.js";
import websocket from "@fastify/websocket";
import PbxWsManager from "./services/pbx-ws-manager.js";
import wsLiveRoute from "./routes/ws-live.js";
import { initStorage, setStorageDb } from "./services/storage.js";
import { seedSuperAdmin } from "./services/users.js";
import { runMigrations } from "./services/migrations.js";

const PORT = parseInt(process.env.API_PORT || "3000", 10);
const MONGO_URI = process.env.MONGO_URI || "mongodb://mongo:27017/vodia_cdr";
const REDIS_URL = process.env.REDIS_URL || "redis://redis:6379";

const app = Fastify({ logger: { level: process.env.LOG_LEVEL || "info" }, trustProxy: true, bodyLimit: 100 * 1024 * 1024 });
const DOMAIN = process.env.DOMAIN || "localhost";
const corsOrigins = DOMAIN === "localhost"
  ? [/localhost/, /127\.0\.0\.1/]
  : [`https://${DOMAIN}`, `http://${DOMAIN}`];
await app.register(cors, { origin: corsOrigins, credentials: true });

const mongo = new MongoClient(MONGO_URI, { maxPoolSize: 20, minPoolSize: 5, retryWrites: true, serverSelectionTimeoutMS: 10000 });
await mongo.connect();
const db = mongo.db();
app.log.info("MongoDB connected: %s", db.databaseName);
app.decorate("db", db);
app.decorate("mongo", mongo);

const redis = new Redis(REDIS_URL, { maxRetriesPerRequest: 3, retryStrategy: (t) => Math.min(t * 200, 5000) });
await redis.ping();
app.decorate("redis", redis);

const recordingRedis = new Redis(REDIS_URL, { maxRetriesPerRequest: null });
const recordingQueue = new Queue("recording-fetch", { connection: recordingRedis });
app.decorate("recordingQueue", recordingQueue);

try { initStorage(); } catch (err) { app.log.warn(err, "MinIO init failed"); }
setStorageDb(db);

// Run database migrations
await runMigrations(db, app.log);
  await initAuditIndexes(db);

// JWT_SECRET validation
const JWT_SECRET = process.env.JWT_SECRET || "";
if (JWT_SECRET.length < 32) {
  app.log.error("JWT_SECRET must be at least 32 characters. Current length: " + JWT_SECRET.length);
  process.exit(1);
}

const seeded = await seedSuperAdmin(db);
if (seeded) app.log.info({ email: seeded.email }, "Super admin seeded");
await restoreGraceFromDb(db, redis);
startLicensePolling(db, redis, app.log);

const pbxWsManager = new PbxWsManager(db, redis, app.log);
app.decorate("pbxWsManager", pbxWsManager);

await app.register(healthRoutes);
await app.register(websocket);
await app.register(authRoutes);
await app.register(cdrRoutes);
await app.register(uploadRoutes);
await app.register(apiKeyRoutes);
await app.register(userRoutes);
await app.register(tenantRoutes);
await app.register(callRoutes);
await app.register(statsRoutes);
await app.register(exportRoutes);
await app.register(aiRoutes);
await app.register(insightsRoutes);
await app.register(retentionRoutes);
await app.register(whitelistRoutes);
await app.register(settingsRoutes);
await app.register(shareRoutes);
await app.register(briefingRoutes);
await app.register(wsLiveRoute);
await app.register(licenseRoutes);
await app.register(setupRoutes);
  await app.register(auditRoutes);
await app.register(complianceRoutes);
await app.register(briefingScheduleRoutes);

try { await app.listen({ port: PORT, host: "0.0.0.0" }); app.log.info("API listening on %d", PORT); }
catch (err) { app.log.error(err, "Failed to start"); process.exit(1); }

startBriefingScheduler(db, redis, app.log);

async function shutdown(sig) {
  app.log.info("Received %s", sig);
  await app.close(); await recordingQueue.close(); await recordingRedis.quit(); await redis.quit(); await mongo.close(); process.exit(0);
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
